"""Optimized standalone worker for the two-branch causal feature task.

Usage (identical surface to the reference worker):
    python flashrt/apps/branch_features/backend/worker.py \
        --repository <repo root> --config <config json>

Design (see notes/experiment_log.md):
  * `branch_features.model.CausalConv1d` is a plain replicate-padded causal conv
    and the reference keeps exactly `k-1` past samples per layer, so processing a
    whole request as one sequence with the per-layer history prepended is
    bit-identical (to fp32 rounding) to the reference's per-chunk loop.  That
    turns 9 chunks * 4 convolutions into one fused graph per request.
  * The two branches are merged into two convolutions with zero-tap-aligned
    filters (see fused_core.py), halving the kernel count.
  * The fused graph is captured once per session flavour (session start uses
    replicate padding, later requests prepend the carried history) and replayed
    per request, so per-request GPU time is one graph launch plus 2 copies.
  * The 9 output chunks are published into the adapter's ring buffers in one
    burst straight from the host-side output array (no per-chunk temporaries).
"""
import argparse
import json
import sys
import time
from pathlib import Path


def _load_fused() -> type:
    here = str(Path(__file__).resolve().parent)
    if here not in sys.path:
        sys.path.insert(0, here)
    from fused_core import FusedBranches
    return FusedBranches


class EagerEngine:
    """Fallback engine: fused math in eager torch (also the CPU path)."""

    def __init__(self, fused, config, torch):
        self.fused = fused
        self.torch = torch

    def reset(self):
        self.fused.reset()

    def request(self, values):
        torch = self.torch
        x = torch.from_numpy(values).unsqueeze(0).to(self.fused.device)
        with torch.inference_mode():
            out = self.fused.step(x)
        return out.squeeze(0).cpu().numpy()


class GraphEngine(EagerEngine):
    """CUDA-graph engine: one replay per request, fixed shapes."""

    def __init__(self, fused, config, torch):
        super().__init__(fused, config, torch)
        length = int(config['length'])
        channels = int(config['channels'])
        hidden = int(config['hidden'])
        dev = fused.device
        self.x = torch.zeros(1, channels, length, device=dev)
        self.h1 = torch.zeros(1, channels, fused.K1 - 1, device=dev)
        self.h2 = torch.zeros(1, 2 * hidden, fused.K2 - 1, device=dev)
        self.out = torch.zeros(1, channels, length, device=dev)
        self.host = torch.empty(channels, length)
        self.host_np = self.host.numpy()
        self.graph_start = self._capture(True)
        self.graph_warm = self._capture(False)
        self.warm = False

    def _body(self, start):
        fb, torch = self.fused, self.torch
        F = torch.nn.functional
        k1, k2 = fb.K1 - 1, fb.K2 - 1
        h1 = self.x[:, :, :1].expand(-1, -1, k1) if start else self.h1
        xin = torch.cat([h1, self.x], dim=-1)
        h = F.conv1d(xin, fb.W1, fb.b1)
        s = F.silu(h)
        h2 = s[:, :, :1].expand(-1, -1, k2) if start else self.h2
        s2 = torch.cat([h2, s], dim=-1)
        y = F.conv1d(s2, fb.W2, fb.b2)
        c = fb.channels
        gate = torch.sigmoid(self.x.mean(dim=1, keepdim=True))
        out = torch.lerp(y[:, c:], y[:, :c], gate)
        out.add_(self.x, alpha=0.1)
        # histories are updated in place at the tail of the captured graph
        self.h1.copy_(xin[:, :, -k1:])
        self.h2.copy_(s2[:, :, -k2:])
        self.out.copy_(out)

    def _capture(self, start):
        torch = self.torch
        fb = self.fused
        stream = torch.cuda.Stream()
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for _ in range(3):
                with torch.inference_mode():
                    self._body(start)
        torch.cuda.current_stream().wait_stream(stream)
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            with torch.inference_mode():
                self._body(start)
        # keep the parameters referenced from the graph's static tensors alive
        self.params = (fb.W1, fb.b1, fb.W2, fb.b2)
        return graph

    def reset(self):
        self.warm = False

    def request(self, values):
        torch = self.torch
        self.x[0].copy_(torch.from_numpy(values))
        (self.graph_warm if self.warm else self.graph_start).replay()
        self.host.copy_(self.out[0])
        torch.cuda.synchronize()
        self.warm = True
        return self.host_np


def build_engine(repository, config, torch, fused_cls):
    from branch_features.model import build_layers
    device = config.get('device', 'cuda')
    layers = build_layers(str(repository), config, device)
    fused = fused_cls(layers, device)
    if str(device).startswith('cuda') and torch.cuda.is_available():
        try:
            return GraphEngine(fused, config, torch), 'graph'
        except Exception as exc:  # pragma: no cover - defensive fallback
            print(json.dumps({'warn': f'graph engine unavailable: {exc!r}'}), flush=True)
    return EagerEngine(fused, config, torch), 'eager'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))
    import numpy as np
    import torch
    from branch_features.adapter import open_buffers, close_buffers

    fused_cls = _load_fused()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.set_grad_enabled(False)

    engine, kind = build_engine(args.repository.resolve(), config, torch, fused_cls)
    length, chunk = int(config['length']), int(config['chunk'])
    positions = list(range(0, length, chunk))
    nchunks = len(positions)
    buffers = open_buffers(config, create=True)
    # ring-buffer views, hoisted out of the per-chunk path
    out_tensor = buffers['output'].tensor
    out_num = buffers['output'].num_arr
    meta_tensor = buffers['metadata'].tensor
    meta_num = buffers['metadata'].num_arr
    capacity = out_tensor.shape[0]
    in_num = buffers['input'].num_arr
    ctrl = buffers['control']._arr
    consumed, last_command, active = 0, 0, False
    idle = 0
    try:
        print(json.dumps({'ready': True, 'device': config.get('device'),
                          'task': 'branch_features', 'engine': kind}), flush=True)
        while True:
            opcode = int(ctrl[0])
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue
            request_id = int(in_num[0]) - 1
            if request_id < consumed:
                idle += 1
                if idle > 2000:
                    time.sleep(0.0002)
                    idle = 0
                continue
            if request_id != consumed:
                raise RuntimeError('Input overwritten before processing')
            idle = 0
            values = buffers['input'].read(consumed, 1)[1][0]
            consumed = request_id + 1
            host = engine.request(values)
            base = int(out_num[0])
            if base != int(meta_num[0]):
                raise RuntimeError('Output and metadata cursors diverged')
            for index, position in enumerate(positions):
                valid = min(chunk, length - position)
                slot = (base + index) % capacity
                out_tensor[slot, :, :valid] = host[:, position:position + valid]
                if valid != chunk:
                    out_tensor[slot, :, valid:] = 0.0
                meta_tensor[slot, 0] = request_id
                meta_tensor[slot, 1] = index
                meta_tensor[slot, 2] = valid
            # data of every chunk is visible before either cursor is published
            out_num[0] = base + nchunks
            meta_num[0] = base + nchunks
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
