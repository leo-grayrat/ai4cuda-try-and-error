Small simulated-input fixtures live here (config JSONs are written by the
harnesses at run time; inputs are generated from a fixed seed in
`tests/common.py::scenario`).
