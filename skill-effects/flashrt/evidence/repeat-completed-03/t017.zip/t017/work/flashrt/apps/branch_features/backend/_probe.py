import ast, json, sys, time
from pathlib import Path
import torch

root = Path(__file__).resolve().parents[4]
print("root", root, "exists", (root / 'flashrt/layers/audio.py').exists())
src = (root / 'flashrt/layers/audio.py').read_text(encoding='utf-8')
node = next(n for n in ast.parse(src).body if isinstance(n, ast.ClassDef) and n.name == 'CausalConv1d')
print(ast.get_source_segment(src, node))
print("cuda", torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)
print("torch", torch.__version__)
