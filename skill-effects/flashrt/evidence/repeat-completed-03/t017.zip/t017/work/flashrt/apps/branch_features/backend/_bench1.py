import json, statistics, sys, time
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from branch_features.model import build_layers, ReferencePipeline, full_sequence_oracle
from fused_core import FusedBranches

torch.backends.cudnn.benchmark = False
torch.backends.cudnn.allow_tf32 = False
torch.backends.cuda.matmul.allow_tf32 = False

cfg = dict(device='cuda', channels=16, hidden=32, length=1043, chunk=127, weight_seed=1234, prefix='bfbench')
C, H, T, CH = cfg['channels'], cfg['hidden'], cfg['length'], cfg['chunk']
CHUNKS = [p for p in range(0, T, CH)]

rng = np.random.default_rng(0)
seq = rng.standard_normal((2, C, T)).astype(np.float32)

layers = build_layers(str(ROOT), cfg, 'cuda')
fused = FusedBranches(layers, 'cuda')

def ref_request(pipeline, x):
    outs = []
    for p in CHUNKS:
        o = pipeline.step(x[:, p:p + CH])
        outs.append(o)
    return np.concatenate(outs, axis=-1)

# ---- numeric check: continuation + reset -------------------------------
pipeline = ReferencePipeline(str(ROOT), cfg)
ref1 = ref_request(pipeline, seq[0])
ref2 = ref_request(pipeline, seq[1])
pipeline.reset()
ref3 = ref_request(pipeline, seq[1])

def fused_request(x):
    outs = []
    xt = torch.from_numpy(x.copy()).unsqueeze(0).cuda()
    with torch.inference_mode():
        out = fused.step(xt)
    return out.squeeze(0).cpu().numpy()

f1 = fused_request(seq[0]); f2 = fused_request(seq[1])
fused.reset(); f3 = fused_request(seq[1])
oracle = {}
for name, x in (('a', seq[0]), ('b', seq[1])):
    oracle[name] = full_sequence_oracle(str(ROOT), cfg, x)
print('max|ref-oracle| req1', float(np.abs(ref1 - oracle['a']).max()),
      'req2(cont)', float(np.abs(ref2 - np.concatenate([oracle['b'][:, :0], oracle['b']], -1)).max()))
print('max|fused-ref| req1', float(np.abs(f1 - ref1).max()),
      'req2', float(np.abs(f2 - ref2).max()), 'after-reset', float(np.abs(f3 - ref3).max()))

# ---- timings ----------------------------------------------------------
def med(fn, n=200):
    ts = []
    for i in range(n):
        t0 = time.perf_counter_ns(); fn(); ts.append(time.perf_counter_ns() - t0)
    ts = np.array(ts) / 1e3
    return dict(median=float(np.median(ts)), p95=float(np.percentile(ts, 95)))

pipe2 = ReferencePipeline(str(ROOT), cfg)
x0 = seq[0].copy()
print('ref   per-request us', json.dumps(med(lambda: ref_request(pipe2, x0), 60)))

xt = torch.from_numpy(x0.copy()).unsqueeze(0).cuda()
fused.reset()
def fused_full():
    with torch.inference_mode():
        o = fused.step(xt)
    return o.squeeze(0).cpu().numpy()
print('fused full-request us', json.dumps(med(fused_full, 200)))

def fused_chunked():
    fused.reset()
    with torch.inference_mode():
        for p in CHUNKS:
            o = fused.step(xt[:, :, p:p + CH])
        o.cpu().numpy()
print('fused per-chunk us', json.dumps(med(fused_chunked, 100)))

# H2D only
host = torch.from_numpy(x0.copy())
print('h2d+d2h us', json.dumps(med(lambda: host.cuda().cpu(), 200)))

# ---- cuda graph variant ----------------------------------------------
class GraphFused:
    def __init__(self, fb):
        self.fb = fb
        self.x = torch.zeros(1, C, T, device='cuda')
        self.h1 = torch.zeros(1, C, fb.K1 - 1, device='cuda')
        self.h2 = torch.zeros(1, 2 * H, fb.K2 - 1, device='cuda')
        self.out = torch.zeros(1, C, T, device='cuda')
        self.g_start = self._capture(True)
        self.g_warm = self._capture(False)
        self.warm = False

    def _body(self, start):
        fb = self.fb
        h1 = self.x[:, :, :1].expand(-1, -1, fb.K1 - 1) if start else self.h1
        xin = torch.cat([h1, self.x], dim=-1)
        h = torch.nn.functional.conv1d(xin, fb.W1, fb.b1)
        s = torch.nn.functional.silu(h)
        h2 = s[:, :, :1].expand(-1, -1, fb.K2 - 1) if start else self.h2
        s2 = torch.cat([h2, s], dim=-1)
        y = torch.nn.functional.conv1d(s2, fb.W2, fb.b2)
        a = y[:, : C]
        b = y[:, C:]
        gate = torch.sigmoid(self.x.mean(dim=1, keepdim=True))
        out = torch.lerp(b, a, gate)
        out.add_(self.x, alpha=0.1)
        self.h1.copy_(xin[:, :, -(fb.K1 - 1):])
        self.h2.copy_(s2[:, :, -(fb.K2 - 1):])
        self.out.copy_(out)

    def _capture(self, start):
        pool = torch.cuda.graph_pool_handle()
        s = torch.cuda.Stream()
        s.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(s):
            for _ in range(3):
                self._body(start)
        torch.cuda.current_stream().wait_stream(s)
        g = torch.cuda.CUDAGraph()
        with torch.cuda.graph(g, pool=pool):
            self._body(start)
        return g

    def request(self, x):
        self.x.copy_(torch.from_numpy(x.copy()).unsqueeze(0))
        (self.g_start if not self.warm else self.g_warm).replay()
        self.warm = True
        return self.out.squeeze(0).cpu().numpy()

gf = GraphFused(fused)
fused.reset()
g1 = gf.request(seq[0]); g2 = gf.request(seq[1])
print('graph vs ref req1', float(np.abs(g1 - ref1).max()), 'req2', float(np.abs(g2 - ref2).max()))
print('graph per-request us', json.dumps(med(lambda: gf.request(x0), 300)))
