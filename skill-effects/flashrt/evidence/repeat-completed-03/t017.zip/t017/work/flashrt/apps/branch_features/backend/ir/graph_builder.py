"""Graph builders for the branch_features IR (worker-level + model-level).

Executor wiring rules used here (from `flashrt/ir/executor.py`): an `IREdge` with
both ports set routes `src_op.src_port -> dst_op.dst_port`; an operator input
port with no incoming edge is filled from the `external_inputs` dict by *port
name*.  External outputs are resolved by matching the output port name against
the last chunk operators that produce it.
"""
import torch

from flashrt.ir import IROperator, IRGraph, IREdge, OpType, StateObject, \
    StreamMode, TensorPort

from .ops import ConvOp, FusedStage, GateMerge, branch_states, fused_states

__all__ = ['build_reference_graph', 'build_fused_graph', 'build_worker_graph',
           'make_context', 'fused_weights', 'aligned']


def build_reference_graph(layers) -> IRGraph:
    """Model-level graph that is operator-for-operator the reference pipeline.

    Chunk cadence in == chunk cadence out (one 127-sample chunk per step), so no
    rate-conversion metadata is needed on the streaming edges.
    """
    g = IRGraph(name='branch_features_model')
    for state in branch_states():
        g.add_state(state)
    g.external_inputs.extend([TensorPort('features', ('channels', 'T')),
                              TensorPort('x', ('channels', 'T'))])
    g.external_outputs.append(TensorPort('output', ('channels', 'T')))
    g.add_operator(ConvOp('a0', layers, 'hist_a0'))
    g.add_operator(ConvOp('a1', layers, 'hist_a1'))
    g.add_operator(ConvOp('b0', layers, 'hist_b0'))
    g.add_operator(ConvOp('b1', layers, 'hist_b1'))
    g.add_operator(GateMerge())
    g.add_edge(IREdge('conv_a0', 'y', 'conv_a1', 'x'))
    g.add_edge(IREdge('conv_b0', 'y', 'conv_b1', 'x'))
    g.add_edge(IREdge('conv_a1', 'y', 'gate_merge', 'a'))
    g.add_edge(IREdge('conv_b1', 'y', 'gate_merge', 'b'))
    g.chunk_ops = ['conv_a0', 'conv_a1', 'conv_b0', 'conv_b1', 'gate_merge']
    return g


def aligned(weight: torch.Tensor, kernel: int) -> torch.Tensor:
    """Zero-pad a causal filter to a longer kernel, keeping tap alignment."""
    k = weight.shape[-1]
    if k == kernel:
        return weight
    out = weight.new_zeros(*weight.shape[:-1], kernel)
    out[..., kernel - k:] = weight
    return out


def fused_weights(layers, device):
    """Merge the four reference layers into two zero-tap-aligned filters."""
    names = ('a0', 'a1', 'b0', 'b1')
    w = {n: layers[n].conv.weight.detach().to(device).contiguous() for n in names}
    b = {n: layers[n].conv.bias.detach().to(device).contiguous() for n in names}
    K1 = max(w['a0'].shape[-1], w['b0'].shape[-1])
    K2 = max(w['a1'].shape[-1], w['b1'].shape[-1])
    channels, hidden = w['a0'].shape[1], w['a0'].shape[0]
    W1 = torch.cat([aligned(w['a0'], K1), aligned(w['b0'], K1)], dim=0).contiguous()
    b1 = torch.cat([b['a0'], b['b0']], dim=0).contiguous()
    W2 = w['a1'].new_zeros(2 * channels, 2 * hidden, K2)
    W2[:channels, :hidden] = aligned(w['a1'], K2)
    W2[channels:, hidden:] = aligned(w['b1'], K2)
    b2 = torch.cat([b['a1'], b['b1']], dim=0).contiguous()
    return dict(W1=W1, b1=b1, W2=W2.contiguous(), b2=b2, K1=K1, K2=K2,
                channels=channels, hidden=hidden)


def make_context(layers, device):
    from .ops import PipelineContext
    fw = fused_weights(layers, device)
    return PipelineContext(layers=layers, W1=fw['W1'], b1=fw['b1'], W2=fw['W2'],
                           b2=fw['b2'], device=device,
                           extras={k: fw[k] for k in ('K1', 'K2', 'channels', 'hidden')})


def build_fused_graph(layers, device) -> IRGraph:
    """Model-level graph of the deployed variant: 2 fused convs + one merge.

    Stage 1 fuses both branches' input convolutions (shared input stream, the
    kernel-3 filter zero-padded to kernel 5) and folds `silu` into the stage, so
    the activation tensor never leaves the kernel.  Stage 2 fuses both branches'
    output convolutions with block-diagonal weights.  Four histories collapse to
    two, which is what makes `hist_s1`/`hist_s2` the only cross-chunk constraints.
    """
    g = IRGraph(name='branch_features_fused')
    for state in fused_states():
        g.add_state(state)
    fw = fused_weights(layers, device)
    g.external_inputs.extend([TensorPort('features', (fw['channels'], 'T')),
                              TensorPort('x', (fw['channels'], 'T'))])
    g.external_outputs.append(TensorPort('output', (fw['channels'], 'T')))
    g.add_operator(FusedStage('stage1', fw['W1'], fw['b1'], 'hist_s1', fw['K1'] - 1,
                              fw['channels'], 2 * fw['hidden'], silu=True))
    g.add_operator(FusedStage('stage2', fw['W2'], fw['b2'], 'hist_s2', fw['K2'] - 1,
                              2 * fw['hidden'], 2 * fw['channels']))
    g.add_operator(GateMerge())
    g.add_edge(IREdge('stage1', 'y', 'stage2', 'x'))
    g.add_edge(IREdge('stage2', 'y', 'gate_merge', 'a'))
    g.add_edge(IREdge('stage2', 'y', 'gate_merge', 'b'))
    g.chunk_ops = ['stage1', 'stage2', 'gate_merge']
    return g


def build_worker_graph(layers, device, chunk: int = 127) -> IRGraph:
    """Worker-level view: one exposed COMPOSITE streaming stage.

    This app has no opaque engine: the whole pipeline is visible and its input
    and output cadence are identical (one chunk in, one chunk out), so the
    worker graph is a single composite operator carrying the model sub-graph.
    """
    g = IRGraph(name='branch_features_worker')
    g.external_inputs.append(TensorPort('features', ('channels', 'T')))
    g.external_outputs.append(TensorPort('output', ('channels', 'T')))
    g.add_operator(IROperator(
        name='branch_pipeline', op_type=OpType.COMPOSITE,
        inputs=[TensorPort('features', ('channels', 'T'))],
        outputs=[TensorPort('output', ('channels', 'T'))],
        state_reads=[], state_writes=[],
        stream_mode=StreamMode.STREAMING,
        sub_graph='branch_features_fused',
        config={'rate_in': chunk, 'rate_out': chunk}))
    g.chunk_ops = ['branch_pipeline']
    g.sub_graphs['branch_features_fused'] = build_fused_graph(layers, device)
    return g
