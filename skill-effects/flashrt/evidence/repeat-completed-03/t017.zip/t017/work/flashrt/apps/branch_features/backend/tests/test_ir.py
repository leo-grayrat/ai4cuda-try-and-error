"""Phase 2 IR validation for branch_features.

Executes the IR graphs with `SequentialExecutor` over the same six-request
scenario the deployment harness uses (continuation, repeated input without
reset, reset, tail chunk) and compares every output sample with the researcher's
strictly sequential `ReferencePipeline`, which is the specification.

Tolerance: 1e-5 absolute.  Both sides run the same cuDNN convolutions on the same
GPU, so the only difference is accumulation order (and the fused graph's exactly
zero taps, which contribute exact zeros).  Observed spread is ~1e-7; 1e-5 keeps a
100x margin, while a wrong history/state wiring produces O(1e-1) errors.
"""
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import common as H  # noqa: E402

sys.path.insert(0, str(H.BACKEND))
from branch_features.model import ReferencePipeline, build_layers  # noqa: E402
from flashrt.ir import (SequentialExecutor, analyze_cross_chunk_dependencies,  # noqa: E402
                        compute_critical_path, find_pipeline_stages,
                        find_streaming_overlaps, summarize_graph)
from ir.graph_builder import (build_fused_graph, build_reference_graph,  # noqa: E402
                              build_worker_graph, make_context)
from ir.ops import branch_states, fused_states  # noqa: E402

ATOL = 1e-5
# Rough per-operator costs (eager GPU, us) including the ~12us Windows
# kernel-launch floor that dominates this workload; used only as the cost model
# for the critical-path/pipeline-stage analysis.
LAT = {'conv_a0': 30.0, 'conv_a1': 30.0, 'conv_b0': 25.0, 'conv_b1': 35.0,
       'gate_merge': 48.0, 'stage1': 48.0, 'stage2': 78.0}


def show(*parts):
    text = ' '.join(str(p) for p in parts)
    print(text.encode('ascii', 'backslashreplace').decode('ascii'), flush=True)


def main():
    length, channels, chunk = 1043, 16, 127
    config = H.make_config(length=length, channels=channels)
    requests, resets = H.scenario(length, channels)
    positions = list(range(0, length, chunk))
    layers = build_layers(str(H.ROOT), config, 'cuda')
    ctx = make_context(layers, 'cuda')

    pipeline = ReferencePipeline(str(H.ROOT), config)
    want = []
    for values, do_reset in zip(requests, resets):
        if do_reset:
            pipeline.reset()
        out = [pipeline.step(values[:, p:p + chunk]) for p in positions]
        want.append(np.concatenate(out, axis=-1))
    show(f'scenario: {len(requests)} requests x {len(positions)} chunks, '
         f'reset before request {[i for i, r in enumerate(resets) if r]}')

    verdict = {}
    for name, graph, states in (
            ('ir_reference', build_reference_graph(layers), branch_states()),
            ('ir_fused', build_fused_graph(layers, 'cuda'), fused_states())):
        keep = [s.name for s in states]
        executor = SequentialExecutor(graph)
        executor.init_state({s: None for s in keep})
        worst, ok = 0.0, True
        for r, (values, do_reset) in enumerate(zip(requests, resets)):
            if do_reset:
                executor.init_state({s: None for s in keep})
            outs = []
            for i, p in enumerate(positions):
                ctx.chunk_index = i
                x = torch.from_numpy(values[:, p:p + chunk].copy()).unsqueeze(0).cuda()
                with torch.no_grad():
                    out = executor.run_chunk({'x': x, 'features': x}, ctx)['output']
                outs.append(out.detach().squeeze(0).cpu().numpy())
            got = np.concatenate(outs, axis=-1)
            diff = float(np.abs(got.astype(np.float64) - want[r]).max())
            worst = max(worst, diff)
            ok &= diff <= ATOL
        show(f'  {name:14s} exec order={executor.chunk_execution_order} '
             f'max|diff|={worst:.3e} {"PASS" if ok else "FAIL"}')
        verdict[name] = ok

    show('\n--- analysis: reference-faithful model graph ---')
    graph = build_reference_graph(layers)
    show(summarize_graph(graph, op_latencies=LAT))
    show('cross-chunk deps:', analyze_cross_chunk_dependencies(graph))
    show('pipeline stages:', find_pipeline_stages(graph))
    show('critical path:', compute_critical_path(graph, LAT))
    show('streaming overlaps:', find_streaming_overlaps(graph))
    show('\n--- analysis: fused model graph ---')
    fgraph = build_fused_graph(layers, 'cuda')
    show(summarize_graph(fgraph, op_latencies={'stage1': 48.0, 'stage2': 78.0,
                                              'gate_merge': 48.0}))
    show('cross-chunk deps:', analyze_cross_chunk_dependencies(fgraph))
    show('pipeline stages:', find_pipeline_stages(fgraph))
    show('\n--- analysis: worker-level graph ---')
    show(summarize_graph(build_worker_graph(layers, 'cuda', chunk)))

    ok = all(verdict.values())
    show('\nRESULT', 'PASS' if ok else 'FAIL', json.dumps(verdict))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
