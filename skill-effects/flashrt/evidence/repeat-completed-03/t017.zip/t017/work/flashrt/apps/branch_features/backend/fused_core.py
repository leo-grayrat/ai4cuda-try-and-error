"""Fused single-GPU kernel for the two-branch causal feature task.

Reference graph (per chunk, all causal along time):
    a = a1(silu(a0(x)))
    b = b1(silu(b0(x)))
    out = sigmoid(mean_c(x)) * a + (1 - sigmoid(mean_c(x))) * b + 0.1 * x

Key facts used here (derived from `branch_features/model.py`):
  * `CausalConv1d` is a plain left-padded (replicate) causal conv, and the
    reference keeps exactly `kernel_size - 1` past input samples per layer, so
    chunked processing is numerically identical to processing the whole request
    as one sequence with the per-layer history prepended.  That lets us replace
    9*4 conv launches by one fused graph per request.
  * Both first-stage convs read the *same* input stream, so they can be merged
    into one conv with `2*hidden` output channels once the kernel-3 filter is
    zero-tap-aligned to the kernel-5 filter (extra taps are exactly zero).
  * Both second-stage convs read `silu` of the merged hidden state, so they merge
    the same way (block-diagonal weights over the 2*hidden channels).

All tensors are 3-D, batch of one: x = (1, channels, T).
"""
import torch
import torch.nn.functional as F

__all__ = ["FusedBranches", "align_filter"]


def align_filter(weight: torch.Tensor, kernel: int) -> torch.Tensor:
    """Zero-pad a causal filter to a longer kernel, keeping tap alignment.

    y[t] = sum_j W[j] * x[t - (k-1) + j]; with length K the same filter is
    G[j + K - k] = W[j], i.e. zeros occupy the *oldest* taps.
    """
    k = weight.shape[-1]
    if k == kernel:
        return weight
    out = weight.new_zeros(*weight.shape[:-1], kernel)
    out[..., kernel - k:] = weight
    return out


class FusedBranches:
    """Turns the four reference conv layers into two fused convolutions."""

    def __init__(self, layers, device):
        self.device = device
        w, b = {}, {}
        for name in ("a0", "a1", "b0", "b1"):
            layer = layers[name]
            w[name] = layer.conv.weight.detach().to(device).contiguous()
            b[name] = layer.conv.bias.detach().to(device).contiguous()
        self.k = {name: w[name].shape[-1] for name in w}
        hidden = w["a0"].shape[0]
        channels = w["a0"].shape[1]
        self.channels, self.hidden = channels, hidden
        self.K1 = max(self.k["a0"], self.k["b0"])
        self.K2 = max(self.k["a1"], self.k["b1"])
        # stage 1: (channels -> 2*hidden), both branches share the input stream
        self.W1 = torch.cat([align_filter(w["a0"], self.K1),
                             align_filter(w["b0"], self.K1)], dim=0).contiguous()
        self.b1 = torch.cat([b["a0"], b["b0"]], dim=0).contiguous()
        # stage 2: (2*hidden -> 2*channels), block diagonal over the branches
        self.W2 = w["a1"].new_zeros(2 * channels, 2 * hidden, self.K2)
        self.W2[:channels, :hidden] = align_filter(w["a1"], self.K2)
        self.W2[channels:, hidden:] = align_filter(w["b1"], self.K2)
        self.W2 = self.W2.contiguous()
        self.b2 = torch.cat([b["a1"], b["b1"]], dim=0).contiguous()
        self.reset()

    # ---- state -----------------------------------------------------------
    def reset(self):
        """Clear all four histories; the next request starts the session."""
        self.warm = False
        self.hist1 = None   # (1, channels, K1-1): last K1-1 columns of x
        self.hist2 = None   # (1, 2*hidden, K2-1): last columns of silu(stage 1)

    # ---- execution -------------------------------------------------------
    def forward(self, x, hist1=None, hist2=None):
        """x: (1, channels, T) on device -> (out, new_hist1, new_hist2)."""
        if hist1 is None:
            # session start: replicate padding, matching CausalConv1d(pad_mode)
            hist1 = x[:, :, :1].expand(-1, -1, self.K1 - 1)
        xin = torch.cat([hist1, x], dim=-1)
        h = F.conv1d(xin, self.W1, self.b1)
        s = F.silu(h)
        if hist2 is None:
            hist2 = s[:, :, :1].expand(-1, -1, self.K2 - 1)
        s2 = torch.cat([hist2, s], dim=-1)
        y = F.conv1d(s2, self.W2, self.b2)
        a = y[:, : self.channels]
        b = y[:, self.channels:]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        out = torch.lerp(b, a, gate)
        out.add_(x, alpha=0.1)
        new1 = xin[:, :, -(self.K1 - 1):].clone()
        new2 = s2[:, :, -(self.K2 - 1):].clone()
        return out, new1, new2

    def step(self, x):
        """Feed one complete request (1, channels, T); keeps session history."""
        out, self.hist1, self.hist2 = self.forward(
            x, self.hist1 if self.warm else None, self.hist2 if self.warm else None)
        self.warm = True
        return out
