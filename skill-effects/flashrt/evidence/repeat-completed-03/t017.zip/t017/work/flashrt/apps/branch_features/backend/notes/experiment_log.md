# Experiment log — branch_features (single RTX 5060 8GB laptop, Windows, torch 2.11.0+cu128)

Assignment: continuous feature processing, default targets (latency to first
output; maximum sustainable output rate with smoothness). Weights fixed, one GPU,
no multi-GPU work applicable.

## 1. What the reference does (hypotheses from `model.py` / `reference.py`)

* `CausalConv1d` = `replicate`-padded left-only conv; `ReferencePipeline` keeps
  exactly `k-1` past input samples per layer and re-prepends them each chunk.
  ⇒ per-chunk processing is numerically identical to one full-sequence pass with
  the carried histories prepended (causality). This is the central hypothesis and
  it is confirmed by `tests/test_deploy.py`: the fused whole-request
  implementation matches the CPU full-sequence oracle to 2.4e-7, and the
  unmodified reference worker matches it to the same order.
* Both branches' first convs read the *same* input stream (kernel 5 and 3).
  Both second convs read `silu` of their own hidden state. A kernel-3 causal
  filter zero-padded to kernel 5 (`G[j+2]=W3[j]`) consumes exactly the same
  inputs, so the two stages can be merged into one conv each (block-diagonal
  second stage). Extra taps are exact zeros ⇒ same values, half the launches.
* The gate needs only the current chunk (`mean` over channels, sigmoid), so it
  can be applied as `lerp(b, a, gate) + 0.1*x` in two kernels.
* The four histories are the only cross-chunk state; nothing else persists.

## 2. IR work (`ir/ops.py`, `ir/graph_builder.py`, `tests/test_ir.py`)

* `build_reference_graph`: 5 ops (`conv_a0/a1/b0/b1` = `EXPOSED`, `STREAMING`,
  one `chunk_persistent` history each, in-place `state.set` of the history) plus
  `gate_merge` (no state). This is the reference pipeline operator-for-operator.
* `build_fused_graph`: 3 ops (`stage1` fused conv + silu, `stage2` fused conv,
  `gate_merge`) with 2 `chunk_persistent` histories — the deployed variant.
* `build_worker_graph`: one `COMPOSITE` streaming op (no opaque engine in this
  app) with in-cadence == out-cadence (127 samples), so no rate-conversion edge.
* Analysis (`tests/test_ir.py` prints `summarize_graph`,
  `analyze_cross_chunk_dependencies`, `find_pipeline_stages`,
  `compute_critical_path`, `find_streaming_overlaps`) with a cost model taken
  from the per-op measurements below. The state-disjoint split of the fused graph
  (`hist_s1` vs `hist_s2`) is the only pipeline-parallel axis available; on one
  GPU it is not exploitable, and the adapter allows only one request in flight, so
  cross-chunk overlap cannot be exercised end-to-end here.
* Known gap: the reference-faithful IR chain initially produced a chunk-length
  mismatch inside `gate_merge` (chunk 127 vs branch output 119, max|diff| 0.93 on
  the first chunk chain). A length guard plus a one-shot `[ir]` diagnostic print
  was added in `ir/ops.py` to expose the offending history length on the next
  run. The IR is therefore **not yet validated** as of this note; the deployed
  path does not depend on the IR executor and is independently verified.

## 3. Variants and measurements (in-process microbenchmarks, one request = 1043
samples = 9 chunks of 127, C=16, H=32)

| variant | idea | per-request time (median) |
| --- | --- | --- |
| `reference` | reference chunk loop (4 conv + cat + slice + clone per chunk) | 8.08 ms (p95 9.84 ms) |
| `fused_chunk` | fused 2-conv math, still per chunk (9 replays) | 2.11 ms |
| `fused_request_eager` | whole request in one fused eager pass | 417 µs |
| `fused_request_graph` | whole request in one captured CUDA graph | 108 µs (replay alone 39–65 µs) |

Per-op eager cost on this box (each includes the ~12 µs Windows launch floor,
which dominates): cat 12, conv(k5,64out) 48, conv(k5,32out) 78, silu 12, mean 11,
sigmoid 12, lerp 17, add_ 18, history copy 14 µs. Host↔device of one 67 KB
request ≈ 10 µs H2D + 30 µs D2H on WDDM.

Rejected variants: `unfold`+`addmm` instead of `conv1d` (graph replay 50 µs vs
39 µs — more kernels, worse); `torch.compile` (fused replay 31.5 µs vs 39 µs, but
7.3 s startup and an MSVC/inductor dependency for a ≈6 % end-to-end gain).

## 4. Official paired measurement (`workspace.benchmark`, 20 ms chunk-gap budget)

| backend | highest passing offered rate | first output median / p95 |
| --- | --- | --- |
| reference | 50 req/s (100 and 200 req/s: queue grows) | 1.548 ms / 2.85 ms |
| candidate | 200 req/s (all tested rates pass the rate gate) | 0.547 ms / 1.02 ms |

Gap distribution: candidate median gap 8–9 µs (all 9 chunks published in one
burst). Trade-off found: at 50 offered req/s the burst pattern leaves an ~20 ms
idle between the last chunk of one request and the first chunk of the next, so
3.8 % of gaps exceed the 20 ms budget (`smoothness_gate_passed=false`) even
though every rate gate passes; at 100/200 req/s the over-budget fraction is 0.0.
The reference spreads its chunks over ~1 ms each, so it looks smoother at the
lowest rate but cannot sustain more than 50 req/s.

## 5. Remaining work / risks

* Finish IR validation (see §2 gap): the fused deployment is verified, the IR
  graph execution is not yet.
* Latency floor: 0.547 ms median is now dominated by the controller's own
  adapter polling (0.2 ms sleeps) and WDDM copies, not by the 39 µs graph.
  Untried: pinned staging buffers (measured *slower* in an early A/B: 116 µs vs
  108 µs), overlapping the input read with the replay, publishing chunks straight
  from a device-to-host ring.
* Smoothness at low offered rates could be improved by pacing the burst (sleep
  between chunk publications) — deliberately not done: it trades first-output
  latency and throughput for a smoother idle-period gap profile.
