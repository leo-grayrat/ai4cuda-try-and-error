import dataclasses, inspect
import flashrt.ir as ir

def out(text):
    print(text.encode('ascii', 'backslashreplace').decode('ascii'))

out(repr([f.name for f in dataclasses.fields(ir.StreamingInfo)]))
out(repr([f.name for f in dataclasses.fields(ir.IRGraph)]))
src = inspect.getsource(ir.SequentialExecutor)
out(src)
