"""IR conversion for branch_features (Phases 1-2)."""
