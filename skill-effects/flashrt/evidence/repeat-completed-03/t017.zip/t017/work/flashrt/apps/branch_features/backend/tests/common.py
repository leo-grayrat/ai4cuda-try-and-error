"""Shared harness utilities for the branch_features backend workspace.

Drives a backend worker subprocess through the *unmodified* shared adapter
(`branch_features.adapter`) and compares outputs against the researcher's CPU
full-sequence oracle (`branch_features.model.full_sequence_oracle`).
"""
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:  # repo-root discovery through the shared runtime
    from flashrt.paths import repo_root as _repo_root
    ROOT = Path(_repo_root())
except Exception:  # pragma: no cover
    ROOT = Path(__file__).resolve().parents[5]

BACKEND = Path(__file__).resolve().parents[1]
WORKER = BACKEND / 'worker.py'
REFERENCE = ROOT / 'flashrt/apps/branch_features/reference.py'
IS_WIN = os.name == 'nt'


def make_config(prefix=None, length=1043, chunk=127, channels=16, hidden=32,
                seed=1234, device='cuda'):
    return {
        'prefix': prefix or f'bf{uuid.uuid4().hex[:8]}',
        'channels': channels, 'hidden': hidden, 'length': length, 'chunk': chunk,
        'weight_seed': seed, 'device': device,
    }


def write_config(path, config):
    Path(path).write_text(json.dumps(config), encoding='utf-8')
    return Path(path)


def launch(entry, config_path, log_path=None):
    """Start a worker subprocess and wait until it prints its ready line."""
    cmd = [sys.executable, '-u', str(entry), '--repository', str(ROOT),
           '--config', str(config_path)]
    env = dict(os.environ)
    env.setdefault('CUDA_VISIBLE_DEVICES', '0')
    kwargs = {}
    if IS_WIN:
        kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs['preexec_fn'] = os.setsid
    log = open(log_path, 'w', encoding='utf-8') if log_path else subprocess.DEVNULL
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=log, env=env,
                            text=True, bufsize=1, **kwargs)
    deadline = time.time() + 180
    while time.time() < deadline:
        line = proc.stdout.readline()
        if not line:
            if proc.poll() is not None:
                raise RuntimeError(f'{entry} exited early: {proc.returncode}')
            continue
        if log_path:
            print(f'  [{Path(entry).name}] {line.rstrip()}', flush=True)
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if payload.get('ready'):
            return proc, payload
    raise TimeoutError(f'{entry} did not report ready')


def stop(proc):
    if proc is None:
        return
    try:
        if proc.poll() is None:
            try:
                if IS_WIN:
                    proc.terminate()
                else:
                    proc.terminate()
            except Exception:
                pass
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                if IS_WIN:
                    subprocess.run(['taskkill', '/F', '/T', '/PID', str(proc.pid)],
                                   capture_output=True)
                else:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                proc.wait(timeout=20)
    finally:
        try:
            if proc.stdout:
                proc.stdout.close()
        except Exception:
            pass


def drive(config, requests, resets, timeout_s=60):
    """Run a request sequence through a live backend; returns per-request chunks.

    `resets[i]` means: send an adapter reset immediately before request i.
    """
    from branch_features.adapter import FeatureAdapter
    adapter = FeatureAdapter(config)
    out = []
    try:
        adapter.start()
        for values, do_reset in zip(requests, resets):
            if do_reset:
                adapter.reset()
            request_id, t_pub = adapter.submit(values)
            chunks = []
            while adapter.pending is not None:
                chunk, t_obs = adapter.receive(timeout_s=timeout_s)
                chunks.append((chunk.copy(), t_obs))
            out.append({'request_id': request_id, 'published_ns': t_pub,
                        'chunks': chunks})
    finally:
        try:
            adapter.terminate()
        finally:
            adapter.close()
    return out


def chunks_to_array(entry):
    return np.concatenate([c for c, _ in entry['chunks']], axis=-1)


def oracle_sequence(config, requests, resets):
    """CPU full-sequence oracle honouring session-reset boundaries.

    The reference processes each request as one continuous stream that keeps the
    four conv histories across requests and drops them on reset.  Causality means
    the same output comes from running the oracle once over the concatenation of
    every request since the last reset, so we slice the tail of that run.
    """
    from branch_features.model import full_sequence_oracle
    length = config['length']
    outs, buffer = [], []
    for values, do_reset in zip(requests, resets):
        if do_reset:
            buffer = []
        buffer.append(values)
        joined = np.concatenate(buffer, axis=-1)
        full = full_sequence_oracle(str(ROOT), config, joined)
        outs.append(full[:, -length:])
    return outs


def padded_stack(config, array):
    """Re-assemble a chunked output list into (channels, length) for comparison."""
    return array


def scenario(length, channels, count=6, seed=7):
    rng = np.random.default_rng(seed)
    base = [rng.standard_normal((channels, length)).astype(np.float32) for _ in range(3)]
    requests = [base[0], base[1], base[0], base[2], base[2], base[0] * -1.5 + 0.25]
    resets = [False, False, False, True, False, False]
    return requests[:count], resets[:count]


def compare(name, got, want, atol=5e-5, rtol=0.0):
    finite = np.isfinite(got).all()
    diff = np.abs(got.astype(np.float64) - want.astype(np.float64))
    worst = float(diff.max()) if diff.size else 0.0
    ok = finite and worst <= atol
    print(f'  {name:28s} max|diff|={worst:.3e} finite={finite} '
          f'{"PASS" if ok else "FAIL"}', flush=True)
    return ok


def orphans(pattern='branch_features/backend/worker.py'):
    try:
        out = subprocess.run(['pgrep', '-af', pattern], capture_output=True, text=True)
        return [ln for ln in out.stdout.splitlines() if ln.strip()]
    except FileNotFoundError:
        return []
