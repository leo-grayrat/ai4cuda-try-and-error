import inspect
import flashrt.ir as ir
print([n for n in dir(ir) if not n.startswith('_')])
for name in ('IROperator', 'IRGraph', 'IREdge', 'StateObject', 'TensorPort', 'SequentialExecutor'):
    obj = getattr(ir, name)
    try:
        print('\n==', name, inspect.signature(obj.__init__))
    except Exception as exc:
        print(name, 'no init sig', exc)
for name in ('add_operator', 'add_edge', 'add_state', 'add_external_input', 'add_external_output',
             'init_state', 'run_preamble', 'run_chunk', 'summarize_graph',
             'analyze_cross_chunk_dependencies', 'find_pipeline_stages', 'find_streaming_overlaps',
             'compute_critical_path', 'ir_operator'):
    for owner in (ir.IRGraph, ir.SequentialExecutor, ir):
        fn = getattr(owner, name, None)
        if fn is not None:
            try:
                print(f'{getattr(owner, "__name__", "ir")}.{name}{inspect.signature(fn)}')
            except Exception as exc:
                print(name, exc)
            break
print('\nIROperator source (init/execute/should_run):')
print(inspect.getsource(ir.IROperator))
