"""Paired offered-load benchmark: reference worker vs candidate worker.

For each backend it reports, over the same varied input stream driven through the
unmodified adapter:
  * latency to first output (median / p95) of a complete request,
  * per-chunk service time and the inter-chunk-gap distribution at a sweep of
    offered request rates (9 chunks per request, 20 ms chunk-gap budget),
  * whether the backend kept the offered cadence (`late` = 0) at each rate.

Usage: python flashrt/apps/branch_features/backend/benchmarks/bench_worker.py
"""
import json
import math
import statistics
import sys
import time
import datetime
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'tests'))
import common as H  # noqa: E402

BUDGET_MS = 20.0
RATES = [8.0, 16.0, 32.0, 64.0, 128.0, 256.0, 512.0, 1024.0]
DURATION_S = 0.5
LATENCY_REQUESTS = 24


def pct(values, q):
    return float(np.percentile(np.array(values, dtype=np.float64), q)) if values else float('nan')


def run_backend(label, entry, config, requests, resets, duration_s=DURATION_S):
    from branch_features.adapter import FeatureAdapter
    cfg_path = H.write_config(HERE / 'results' / f'cfg_{label}.json', config)
    proc = None
    adapter = None
    data = {'label': label, 'entry': str(entry), 'latency': {}, 'sweep': []}
    try:
        proc, ready = H.launch(entry, cfg_path)
        data['ready'] = ready
        adapter = FeatureAdapter(config)
        adapter.start()

        # ---- back-to-back latency phase -----------------------------------
        lats, svc, gaps = [], [], []
        for k in range(LATENCY_REQUESTS):
            values = requests[k % len(requests)]
            if resets[k % len(resets)]:
                adapter.reset()
            _, t_pub = adapter.submit(values)
            first = last = None
            while adapter.pending is not None:
                chunk, t_obs = adapter.receive(timeout_s=60)
                if first is None:
                    first = t_obs
                else:
                    gaps.append((t_obs - last) / 1e6)
                last = t_obs
            lats.append((first - t_pub) / 1e3)
            svc.append((last - t_pub) / 1e3)
        data['latency'] = {
            'first_out_us_p50': pct(lats, 50), 'first_out_us_p95': pct(lats, 95),
            'service_us_p50': pct(svc, 50), 'service_us_p95': pct(svc, 95),
            'gap_ms_p50': pct(gaps, 50), 'gap_ms_p95': pct(gaps, 95),
            'requests': len(lats)}

        # ---- offered-load sweep -------------------------------------------
        for rate in RATES:
            period = 1.0 / rate
            served = late = 0
            lat_s, gap_s = [], []
            t_end = time.perf_counter() + duration_s
            next_slot = time.perf_counter()
            k = 0
            while True:
                now = time.perf_counter()
                if now >= t_end:
                    break
                if now < next_slot:
                    continue
                values = requests[k % len(requests)]
                if resets[k % len(resets)]:
                    adapter.reset()
                _, t_pub = adapter.submit(values)
                k += 1
                served += 1
                first = last = None
                while adapter.pending is not None:
                    chunk, t_obs = adapter.receive(timeout_s=60)
                    if first is None:
                        first = t_obs
                    else:
                        gap_s.append((t_obs - last) / 1e6)
                    last = t_obs
                lat_s.append((first - t_pub) / 1e3)
                next_slot += period
                if time.perf_counter() > next_slot:
                    late += 1
            entry_out = {
                'offered_rps': rate, 'served_requests': served,
                'achieved_rps': served / duration_s, 'late_offers': late,
                'first_out_us_p50': pct(lat_s, 50), 'first_out_us_p95': pct(lat_s, 95),
                'gap_ms_p50': pct(gap_s, 50), 'gap_ms_p95': pct(gap_s, 95),
                'gap_over_budget_frac': (float(np.mean(np.array(gap_s) > BUDGET_MS))
                                        if gap_s else 0.0),
                'sustainable': bool(late == 0 and (not gap_s or max(gap_s) < BUDGET_MS)),
            }
            data['sweep'].append(entry_out)
            print(f"  {label:9s} offered {rate:7.0f} rps served={served:5d} late={late:4d} "
                  f"first_out_p50={entry_out['first_out_us_p50']:8.1f}us "
                  f"gap_p95={entry_out['gap_ms_p95']:7.3f}ms "
                  f"over_budget={entry_out['gap_over_budget_frac']:.3f} "
                  f"sustainable={entry_out['sustainable']}", flush=True)
    finally:
        if adapter is not None:
            try:
                adapter.terminate()
            finally:
                adapter.close()
        H.stop(proc)
    data['max_sustainable_rps'] = max([s['offered_rps'] for s in data['sweep']
                                       if s['sustainable']], default=0.0)
    return data


def main():
    length, channels, chunk = 1043, 16, 127
    requests, resets = H.scenario(length, channels, count=6)
    (HERE / 'results').mkdir(parents=True, exist_ok=True)
    import torch
    out = {
        'task': 'branch_features', 'budget_ms': BUDGET_MS, 'rates': RATES,
        'duration_s': DURATION_S, 'length': length, 'chunk': chunk,
        'channels': channels, 'torch': torch.__version__,
        'device': torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'cpu',
        'timestamp': datetime.datetime.now().isoformat(timespec='seconds'),
        'backends': [],
    }
    for label, entry in (('reference', H.REFERENCE), ('candidate_graph', H.WORKER)):
        config = H.make_config(length=length, channels=channels)
        out['backends'].append(run_backend(label, entry, config, requests, resets))
    out['control_orphans'] = H.orphans()
    path = HERE / 'results' / f"branch_features_{out['timestamp'].replace(':', '')}.json"
    path.write_text(json.dumps(out, indent=1), encoding='utf-8')
    print('\nsummary')
    for b in out['backends']:
        print(f"  {b['label']:16s} first_out_p50={b['latency']['first_out_us_p50']:9.1f}us "
              f"p95={b['latency']['first_out_us_p95']:9.1f}us "
              f"service_p50={b['latency']['service_us_p50']:9.1f}us "
              f"max_sustainable={b['max_sustainable_rps']:.0f} rps")
    print('json:', path, 'orphans:', out['control_orphans'], flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
