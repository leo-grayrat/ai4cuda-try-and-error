"""Deployment correctness harness (Phase 4).

Launches the researcher's reference worker and our candidate worker as separate
subprocesses, drives both through the unmodified `branch_features.adapter` with
the same six-request scenario (continuation, repeated input without reset, reset,
tail chunk), and compares every chunk against the CPU full-sequence oracle.

Tolerance: 5e-5 absolute on float32.  Justification: the oracle evaluates the four
convolutions on CPU with a full-sequence call while the backends use cuDNN on GPU
(and our candidate merges the two branches into zero-tap-aligned filters and uses
two fused convs), so only accumulation order differs.  With unit-scale inputs the
observed spread of pure fp32 rounding here is ~3e-7; 5e-5 keeps ~150x margin while
any structural error (wrong history, swapped branch, missing gate or residual)
produces O(1e-1) differences.
"""
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import common as H  # noqa: E402

ATOL = 5e-5


def main():
    length, channels, chunk = 1043, 16, 127
    requests, resets = H.scenario(length, channels)
    requests = [r.copy() for r in requests]
    print(f'scenario: {len(requests)} requests, length={length}, chunk={chunk}, '
          f'resets at {[i for i, r in enumerate(resets) if r]}', flush=True)
    want = H.oracle_sequence(H.make_config(length=length, channels=channels),
                             requests, resets)
    verdicts = {}

    for label, entry in (('reference', H.REFERENCE), ('candidate', H.WORKER)):
        config = H.make_config(length=length, channels=channels)
        path = H.write_config(HERE / 'fixtures' / f'cfg_{label}.json', config)
        proc = None
        try:
            proc, ready = H.launch(entry, path)
            print(f'{label}: ready {ready}', flush=True)
            result = H.drive(config, requests, resets)
            ok = True
            for i, entry_out in enumerate(result):
                got = H.chunks_to_array(entry_out)
                if got.shape != want[i].shape:
                    print(f'  {label} request {i}: shape {got.shape} != {want[i].shape}')
                    ok = False
                    continue
                ok &= H.compare(f'{label} request {i}', got, want[i], atol=ATOL)
            # chunk metadata: every chunk of every request must arrive in order
            counts = [len(e['chunks']) for e in result]
            expected = -(-length // chunk)
            ok &= counts == [expected] * len(result)
            print(f'  {label} chunks/request {counts} (expected {expected})', flush=True)
            verdicts[label] = ok
        finally:
            H.stop(proc)
    leftover = H.orphans()
    if leftover:
        print('orphans:', leftover)
    print('RESULT', 'PASS' if all(verdicts.values()) and not leftover else 'FAIL',
          verdicts, flush=True)
    return 0 if all(verdicts.values()) and not leftover else 1


if __name__ == '__main__':
    sys.exit(main())
