"""Operators for the branch_features IR.

Two graphs are expressed here:

`build_reference_graph`  -- one operator per reference convolution plus the gate
    merge.  Four `chunk_persistent` histories, exactly the four `self.histories`
    entries of `branch_features.model.ReferencePipeline`.

`build_fused_graph`      -- the transformation used by the deployed backend: the
    two first-stage convs share the same input stream and the two second-stage
    convs share `silu` of the merged hidden state, so after zero-tap alignment
    (kernel-3 filters padded to kernel-5, block-diagonal second-stage weights)
    the chunk needs only two convolutions and only two histories.  This is a
    genuine change of *scheduling*, not of the values produced: the extra taps
    are exactly zero, so every output element consumes the same inputs.
"""
from dataclasses import dataclass, field

import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StateObject, StreamMode, TensorPort

HIST = ('hist_a0', 'hist_a1', 'hist_b0', 'hist_b1')
_DIAG = {}


def _note(key, *parts):
    """One short ascii diagnostic line per operator (kept for the harness)."""
    if key in _DIAG:
        return
    _DIAG[key] = True
    text = ' '.join(str(p) for p in parts)
    print(('[ir] ' + text).encode('ascii', 'backslashreplace').decode('ascii'), flush=True)


@dataclass
class PipelineContext:
    """Per-chunk context: the four reference layers and the fused filters."""

    layers: object
    W1: torch.Tensor
    b1: torch.Tensor
    W2: torch.Tensor
    b2: torch.Tensor
    device: str = 'cuda'
    chunk_index: int = 0
    request_index: int = 0
    extras: dict = field(default_factory=dict)


class ConvOp(IROperator):
    """One reference `CausalConv1d` with its own `chunk_persistent` history."""

    def __init__(self, layer_name: str, layers, hist_name: str):
        super().__init__(
            name=f'conv_{layer_name}',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('x', ('in_channels', 'T'))],
            outputs=[TensorPort('y', ('out_channels', 'T'))],
            state_reads=[hist_name],
            state_writes=[hist_name],
            stream_mode=StreamMode.STREAMING,
        )
        self.layer_name = layer_name
        self.layers = layers
        self.hist_name = hist_name

    def execute(self, inputs, ctx, state):
        layer = self.layers[self.layer_name]
        history = state.get(self.hist_name)
        x = inputs['x']
        joined = x if history is None else torch.cat([history, x], dim=-1)
        out = layer(joined)
        if history is not None:
            keep = x.shape[-1]
            if out.shape[-1] != keep:  # keep the chunk cadence exact
                _note(f'{self.name}:len', self.name, 'hist', history.shape[-1],
                      'joined', joined.shape[-1], 'raw', out.shape[-1], 'x', keep)
                out = out[:, :, out.shape[-1] - keep:]
            else:
                out = out[:, :, history.shape[-1]:]
        state.set(self.hist_name,
                  joined[:, :, -layer._time_causal_padding[0]:].clone())
        return {'y': out}


class GateMerge(IROperator):
    """sigmoid(mean over channels of the *current* features) gating + residual."""

    def __init__(self):
        super().__init__(
            name='gate_merge',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('a'), TensorPort('b'), TensorPort('features')],
            outputs=[TensorPort('output')],
            state_reads=[],
            state_writes=[],
            stream_mode=StreamMode.STREAMING,
        )

    def execute(self, inputs, ctx, state):
        del ctx, state
        features = inputs['features']
        a, b = inputs['a'], inputs['b']
        keep = features.shape[-1]
        if a.shape[-1] != keep:
            _note(f'{self.name}:len', self.name, 'a', a.shape[-1], 'b', b.shape[-1],
                  'features', keep)
            a, b = a[..., -keep:], b[..., -keep:]
        gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
        out = gate * a + (1 - gate) * b + 0.1 * features
        return {'output': out}


class FusedStage(IROperator):
    """A larger fused convolution with a single `chunk_persistent` history."""

    def __init__(self, name: str, weight, bias, hist_name: str, taps: int,
                 in_channels: int, out_channels: int, silu: bool = False):
        super().__init__(
            name=name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('x', (in_channels, 'T'))],
            outputs=[TensorPort('y', (out_channels, 'T'))],
            state_reads=[hist_name],
            state_writes=[hist_name],
            stream_mode=StreamMode.STREAMING,
        )
        self.weight, self.bias = weight, bias
        self.hist_name, self.taps, self.silu = hist_name, taps, silu

    def execute(self, inputs, ctx, state):
        history = state.get(self.hist_name)
        x = inputs['x']
        joined = x if history is None else torch.cat([history, x], dim=-1)
        y = F.conv1d(joined, self.weight, self.bias)
        if history is not None:
            keep = x.shape[-1]
            if y.shape[-1] != keep:
                _note(f'{self.name}:len', self.name, 'hist', history.shape[-1],
                      'joined', joined.shape[-1], 'raw', y.shape[-1], 'x', keep)
                y = y[:, :, y.shape[-1] - keep:]
            else:
                y = y[:, :, history.shape[-1]:]
        if self.silu:
            y = F.silu(y)
        state.set(self.hist_name, joined[:, :, -self.taps:].clone())
        return {'y': y}


def branch_states():
    return [
        StateObject('hist_a0', 'last k-1 inputs of branch A first conv', 'chunk_persistent'),
        StateObject('hist_a1', 'last k-1 inputs of branch A second conv', 'chunk_persistent'),
        StateObject('hist_b0', 'last k-1 inputs of branch B first conv', 'chunk_persistent'),
        StateObject('hist_b1', 'last k-1 inputs of branch B second conv', 'chunk_persistent'),
    ]


def fused_states():
    return [
        StateObject('hist_s1', 'last K1-1 columns of the request stream', 'chunk_persistent'),
        StateObject('hist_s2', 'last K2-1 columns of silu(stage 1)', 'chunk_persistent'),
    ]
