import json, sys, time, traceback
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(Path(__file__).resolve().parent))
from branch_features.model import build_layers
from fused_core import FusedBranches

torch.backends.cudnn.benchmark = False
cfg = dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=1234)
C, H, T = cfg['channels'], cfg['hidden'], cfg['length']
t0 = time.time()
fb = FusedBranches(build_layers(str(ROOT), cfg, 'cuda'), 'cuda')
print('setup', round(time.time() - t0, 2), flush=True)
x = torch.randn(1, C, T, device='cuda')
xin = torch.randn(1, C, T + fb.K1 - 1, device='cuda')
s2 = torch.randn(1, 2 * H, T + fb.K2 - 1, device='cuda')
h = torch.randn(1, 2 * H, T, device='cuda')
y = torch.randn(1, 2 * C, T, device='cuda')
h1 = torch.zeros(1, C, fb.K1 - 1, device='cuda')
W1m = fb.W1.reshape(2 * H, -1)
W2m = fb.W2.reshape(2 * C, -1)

def ev(name, fn, n=50):
    t = time.time()
    for _ in range(3): fn()
    torch.cuda.synchronize()
    s = torch.cuda.Event(True); e = torch.cuda.Event(True)
    s.record()
    for _ in range(n): fn()
    e.record(); torch.cuda.synchronize()
    us = s.elapsed_time(e) * 1e3 / n
    print(f'{name:16s} {us:8.2f} us   wall {time.time()-t:6.2f}s', flush=True)
    return us

ev('cat1', lambda: torch.cat([h1, x], dim=-1))
ev('conv1_k5_64', lambda: F.conv1d(xin, fb.W1, fb.b1))
ev('conv2_k5_32', lambda: F.conv1d(s2, fb.W2, fb.b2))
ev('silu', lambda: F.silu(h))
ev('mean', lambda: x.mean(dim=1, keepdim=True))
ev('sigmoid', lambda: torch.sigmoid(x))
ev('lerp', lambda: torch.lerp(y[:, C:], y[:, :C], x))
ev('add_alpha', lambda: y[:, :C].add_(x, alpha=0.1))
ev('copyH', lambda: h1.copy_(x[:, :, :4]))
ev('unfold1', lambda: torch.addmm(fb.b1, xin.unfold(-1, fb.K1, 1).reshape(-1, C * fb.K1), W1m.t()))
ev('unfold2', lambda: torch.addmm(fb.b2, s2.unfold(-1, fb.K2, 1).reshape(-1, 2 * H * fb.K2), W2m.t()))

def body():
    xin2 = torch.cat([h1, x], dim=-1)
    hh = F.conv1d(xin2, fb.W1, fb.b1)
    ss = F.silu(hh)
    s22 = torch.cat([s2[:, :, :fb.K2 - 1], ss], dim=-1)
    yy = F.conv1d(s22, fb.W2, fb.b2)
    g = torch.sigmoid(x.mean(dim=1, keepdim=True))
    o = torch.lerp(yy[:, C:], yy[:, :C], g); o.add_(x, alpha=0.1)
    h1.copy_(xin2[:, :, -4:]); return o

def body_mm():
    xin2 = torch.cat([h1, x], dim=-1)
    hh = torch.addmm(fb.b1, xin2.unfold(-1, fb.K1, 1).reshape(-1, C * fb.K1), W1m.t()).t().unsqueeze(0)
    ss = F.silu(hh)
    s22 = torch.cat([s2[:, :, :fb.K2 - 1], ss], dim=-1)
    yy = torch.addmm(fb.b2, s22.unfold(-1, fb.K2, 1).reshape(-1, 2 * H * fb.K2), W2m.t()).t().unsqueeze(0)
    g = torch.sigmoid(x.mean(dim=1, keepdim=True))
    o = torch.lerp(yy[:, C:], yy[:, :C], g); o.add_(x, alpha=0.1)
    h1.copy_(xin2[:, :, -4:]); return o

def make_graph(fn):
    st = torch.cuda.Stream(); st.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(st):
        for _ in range(5): fn()
    torch.cuda.current_stream().wait_stream(st)
    g = torch.cuda.CUDAGraph()
    with torch.cuda.graph(g): fn()
    return g

gb = make_graph(body)
gm = make_graph(body_mm)
ev('graph_conv', lambda: (gb.replay(), torch.cuda.synchronize()), 100)
ev('graph_mm', lambda: (gm.replay(), torch.cuda.synchronize()), 100)

try:
    t1 = time.time()
    cf = torch.compile(body, dynamic=False)
    cf(); torch.cuda.synchronize()
    print('compile ok in %.1fs' % (time.time() - t1), flush=True)
    ev('compiled_eager', lambda: (cf(), torch.cuda.synchronize()), 50)
    try:
        gcs = make_graph(lambda: cf())
        ev('compiled_graph', lambda: (gcs.replay(), torch.cuda.synchronize()), 100)
    except Exception as exc:
        print('compile graph failed:', repr(exc)[:300])
except Exception as exc:
    print('compile failed:', repr(exc)[:600], flush=True)
