import json, sys, time
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(Path(__file__).resolve().parent))
from branch_features.model import build_layers
from fused_core import FusedBranches

torch.backends.cudnn.benchmark = False
cfg = dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=1234)
C, H, T = cfg['channels'], cfg['hidden'], cfg['length']
fb = FusedBranches(build_layers(str(ROOT), cfg, 'cuda'), 'cuda')

x = torch.zeros(1, C, T, device='cuda')
h1 = torch.zeros(1, C, fb.K1 - 1, device='cuda')
h2 = torch.zeros(1, 2 * H, fb.K2 - 1, device='cuda')
out = torch.zeros(1, C, T, device='cuda')

def body():
    xin = torch.cat([h1, x], dim=-1)
    h = torch.nn.functional.conv1d(xin, fb.W1, fb.b1)
    s = torch.nn.functional.silu(h)
    s2 = torch.cat([h2, s], dim=-1)
    y = torch.nn.functional.conv1d(s2, fb.W2, fb.b2)
    a = y[:, :C]; b = y[:, C:]
    g = torch.sigmoid(x.mean(dim=1, keepdim=True))
    o = torch.lerp(b, a, g); o.add_(x, alpha=0.1)
    h1.copy_(xin[:, :, -(fb.K1 - 1):]); h2.copy_(s2[:, :, -(fb.K2 - 1):]); out.copy_(o)

st = torch.cuda.Stream(); st.wait_stream(torch.cuda.current_stream())
with torch.cuda.stream(st):
    for _ in range(5): body()
torch.cuda.current_stream().wait_stream(st)
g = torch.cuda.CUDAGraph()
with torch.cuda.graph(g): body()

host = np.random.default_rng(0).standard_normal((C, T)).astype(np.float32)
ht = torch.from_numpy(host)
pin_in = torch.empty(1, C, T, pin_memory=True)
pin_out = torch.empty(1, C, T, pin_memory=True)

def med(fn, n=400):
    ts = []
    for _ in range(n):
        t0 = time.perf_counter_ns(); fn(); ts.append(time.perf_counter_ns() - t0)
    ts = np.array(ts) / 1e3
    return dict(median=round(float(np.median(ts)), 1), p95=round(float(np.percentile(ts, 95)), 1))

def replay_sync():
    g.replay(); torch.cuda.synchronize()

def copy_replay():
    x.copy_(ht.unsqueeze(0)); g.replay(); torch.cuda.synchronize()

def copy_replay_d2h():
    x.copy_(ht.unsqueeze(0)); g.replay(); out[0].cpu().numpy()

def pinned_async():
    pin_in[0].copy_(ht); x.copy_(pin_in, non_blocking=True); g.replay()
    pin_out.copy_(out, non_blocking=True); torch.cuda.synchronize(); pin_out[0].numpy()

def pinned_async_direct():
    np.copyto(pin_in[0].numpy(), host); x.copy_(pin_in, non_blocking=True); g.replay()
    pin_out.copy_(out, non_blocking=True); torch.cuda.synchronize(); pin_out[0].numpy()

def sync_only():
    torch.cuda.synchronize()

print('sync only          ', json.dumps(med(sync_only)))
print('replay+sync        ', json.dumps(med(replay_sync)))
print('copy+replay+sync   ', json.dumps(med(copy_replay)))
print('copy+replay+d2h    ', json.dumps(med(copy_replay_d2h)))
print('pinned pipeline    ', json.dumps(med(pinned_async)))
print('pinned np.copyto   ', json.dumps(med(pinned_async_direct)))
print('h2d only (pageable)', json.dumps(med(lambda: x.copy_(ht.unsqueeze(0)))))
print('d2h pageable       ', json.dumps(med(lambda: out[0].cpu().numpy())))
print('cpu reference numpy work (padded write x9)', json.dumps(med(lambda: [np.zeros((C, 127), np.float32)[:, :27].__setitem__(slice(None), out[0].numpy()[:, :27]) for _ in range(1)])))
