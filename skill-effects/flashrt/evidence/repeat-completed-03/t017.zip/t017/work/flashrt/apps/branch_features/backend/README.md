# branch_features backend (single RTX 5060 8GB, Windows, torch 2.11.0+cu128)

Recommended entry point (identical CLI surface to the researcher's reference
worker, so the unchanged frontend / controller can launch it):

```bash
python flashrt/apps/branch_features/backend/worker.py \
    --repository <repo root> --config <config json>
```

The config JSON is the one the controller supplies (`prefix`, `channels`,
`hidden`, `length`, `chunk`, `weight_seed`, `device`); the worker creates the
adapter's shared-memory buffers exactly like `branch_features/reference.py`,
prints `{"ready": true, ...}` on startup, honours control opcodes 1 (start),
3 (reset) and 2 (terminate), and publishes one output chunk + metadata frame per
127-sample chunk straight from the host-side output array.

Layout

| path | role |
| --- | --- |
| `worker.py` | standalone entry: adapter loop + fused engine selection |
| `fused_core.py` | branch fusion math (`FusedBranches`), shared by worker/IR/tests |
| `ir/ops.py`, `ir/graph_builder.py` | Phase 1 IR: reference-faithful graph, fused graph, worker-level composite graph |
| `tests/test_ir.py` | Phase 2: executes both IR graphs against the sequential reference |
| `tests/test_deploy.py` | Phase 4: launches reference and candidate workers through the adapter, compares with the CPU full-sequence oracle |
| `tests/common.py` | adapter-driven harness utilities (launch, drive, oracle, cleanup) |
| `benchmarks/bench_worker.py` | paired offered-load sweep + first-output latency, writes `benchmarks/results/*.json` |
| `notes/experiment_log.md` | hypotheses, variants, measurements, failures |

Correctness: `tests/test_deploy.py` PASS (6 requests: continuation, repeated
input without reset, reset, tail chunk), max |diff| vs the CPU full-sequence
oracle 2.4e-7 (reference backend: 2.1e-7).
