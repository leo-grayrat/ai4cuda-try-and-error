"""Inspect the executor's routing + run_chunk semantics."""
from pathlib import Path
import sys

root = Path('.').resolve()
src = (root / 'flashrt' / 'ir' / 'executor.py').read_text(encoding='utf-8')
start = src.find('def _build_input_map')
print(src[start:start + 4200])
