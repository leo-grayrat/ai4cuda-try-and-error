"""split1_compile: split1 + torch.compile of the segment function."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'split1_compile'}

if __name__ == '__main__':
    entry.run(OVERRIDES)
