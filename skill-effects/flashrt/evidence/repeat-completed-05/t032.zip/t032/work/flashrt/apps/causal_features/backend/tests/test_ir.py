"""Phase-2 IR validation (and Phase-2 analysis capture).

1. Launch the *reference* backend as a subprocess and drive it through the
   fixed adapter with the six-request scenario (continuation, repeated input
   without reset, reset, tail chunk).  These are the oracle numbers.
2. Build both IR graphs, run them through ``flashrt.ir.SequentialExecutor`` on
   the same scenario, and compare the collected chunks against the reference.
3. Dump the IR analysis (pipeline stages / streaming overlaps / cross-chunk
   independence / critical path) to ``notes/ir_analysis.txt``.

    python flashrt/apps/causal_features/backend/tests/test_ir.py
"""
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BACKEND = HERE.parent
for p in (str(BACKEND), str(BACKEND / 'bench')):
    if p not in sys.path:
        sys.path.insert(0, p)

import common  # noqa: E402

from flashrt.ir import SequentialExecutor  # noqa: E402
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))
from ir import (build_context, build_model_graph,  # noqa: E402
                build_worker_graph, initial_state)

SCENARIO = ['req', 'req', 'reset', 'req', 'req', 'req', 'reset', 'req']
SHAPE = 'dev'
ATOL, RTOL = common.ATOL, common.RTOL


def reference_outputs(shape, inputs):
    records, startup, err = common.run_scenario('reference', shape, SCENARIO,
                                                'ir_reference', inputs=inputs)
    if err:
        print('reference close note:', err)
    return records, startup


def run_ir(builder):
    cfg = common.make_config(SHAPE, prefix='ir_graph')
    published = {}

    def publish(index, data):
        published.setdefault(cur_req[0], {})[index] = np.array(data, copy=True)

    ctx = build_context(str(common.REPO), cfg, publish)
    graph = builder(cfg, ctx)
    executor = SequentialExecutor(graph)
    executor.init_state(initial_state(ctx))
    cur_req = [0]
    out = []
    for act in SCENARIO:
        if act == 'reset':
            executor.init_state(initial_state(ctx))
            out.append({'kind': 'reset'})
            continue
        published[cur_req[0]] = {}
        ctx.begin_request(cur_req[0] and None)
        frame = np.asarray(inputs[cur_req[0]], dtype=np.float32)
        ctx.frame = torch_from(frame)
        n = common.n_chunks(cfg)
        for i in range(n):
            ctx.chunk_index = i
            executor.run_chunk({}, ctx)
        out.append({'kind': 'req',
                    'chunks': [(0, published[cur_req[0]][i]) for i in range(n)]})
        cur_req[0] += 1
    return graph, out


def torch_from(frame):
    import torch
    return torch.from_numpy(frame).unsqueeze(0).to('cuda')


def compare(tag, ref_records, ir_records, shape):
    cfg = common.CONFIGS[shape]
    fails, worst = [], 0.0
    for idx, (ref, got) in enumerate(zip(ref_records, ir_records)):
        if ref['kind'] == 'reset':
            continue
        if len(ref['chunks']) != len(got['chunks']):
            fails.append(f'{tag} #{idx}: chunk count')
            continue
        for i, ((_, a), (_, b)) in enumerate(zip(ref['chunks'], got['chunks'])):
            valid = min(cfg['chunk'], cfg['length'] - i * cfg['chunk'])
            a = np.asarray(a)[:, :valid]
            b = np.asarray(b)[:, :valid]
            diff = float(np.abs(a - b).max())
            worst = max(worst, diff)
            if not np.allclose(a, b, atol=ATOL, rtol=RTOL):
                fails.append(f'{tag} #{idx} chunk {i}: max|d|={diff:.3e}')
    return fails, worst


def analysis(graph, path):
    lines = [f'# IR analysis: {graph.name}',
             f'operators={len(graph.operators)} edges={len(graph.edges)} '
             f'states={sorted(graph.state_objects)}']
    try:
        from flashrt.ir.analysis import (analyze_cross_chunk_dependencies,
                                         compute_critical_path,
                                         find_pipeline_stages,
                                         find_streaming_overlaps,
                                         summarize_graph)
    except Exception as exc:  # noqa: BLE001
        lines.append(f'analysis import failed: {exc}')
        summarize_graph = None
    if summarize_graph is not None:
        for label, call in (
            ('summarize_graph', lambda: summarize_graph(graph)),
            ('pipeline_stages', lambda: find_pipeline_stages(graph)),
            ('streaming_overlaps', lambda: find_streaming_overlaps(graph)),
            ('cross_chunk', lambda: analyze_cross_chunk_dependencies(graph)),
            ('critical_path', lambda: compute_critical_path(
                graph, {name: 0.04 for name in graph.operators})),
        ):
            try:
                lines.append(f'## {label}\n{call()}')
            except Exception as exc:  # noqa: BLE001
                lines.append(f'## {label}\nERROR {type(exc).__name__}: {exc}')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text('\n'.join(str(x) for x in lines), encoding='utf-8')
    return '\n'.join(str(x) for x in lines)


inputs = None


def main():
    global inputs
    cfg = common.make_config(SHAPE, prefix='ir_fixture')
    rng = np.random.default_rng(4242)
    inputs = [common.gen_input(rng, cfg) for _ in range(6)]
    np.savez(HERE / 'fixtures' / f'ir_scenario_{SHAPE}.npz',
             **{f'in{i}': x for i, x in enumerate(inputs)}) if (HERE / 'fixtures').mkdir(
        parents=True, exist_ok=True) is None else None

    t0 = time.time()
    ref_records, startup = reference_outputs(SHAPE, inputs)
    print(f'reference backend: startup={startup:.1f}s '
          f'requests={sum(1 for r in ref_records if r["kind"] == "req")}', flush=True)

    fails = []
    notes = []
    for tag, builder in (('worker', build_worker_graph), ('model', build_model_graph)):
        graph, ir_records = run_ir(builder)
        f, worst = compare(tag, ref_records, ir_records, SHAPE)
        notes.append(f'{tag}: max|d|={worst:.3e} failures={len(f)}')
        print(f'[IR:{tag}] max|d|={worst:.3e} failures={len(f)} {f[:3]}', flush=True)
        fails += f
        if tag == 'model':
            text = analysis(graph, BACKEND / 'notes' / 'ir_analysis.txt')
            print(text[:4000], flush=True)

    verdict = 'PASS' if not fails else 'FAIL'
    print(f'IR VALIDATION: {verdict} (tolerance atol={ATOL}, rtol={RTOL}; '
          f'justification: float32 accumulation order differs between the '
          f'GPU conv and the CPU oracle, per CONTRACT.zh.md) '
          f'elapsed={time.time() - t0:.1f}s', flush=True)
    print(json.dumps({'verdict': verdict, 'detail': notes, 'failures': fails[:8]}),
          flush=True)
    return 0 if verdict == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
