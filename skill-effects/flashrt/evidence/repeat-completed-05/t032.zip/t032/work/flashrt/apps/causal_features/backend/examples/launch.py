"""Launch the recommended backend end-to-end (unchanged frontend drives it).

    python flashrt/apps/causal_features/backend/examples/launch.py --config dev
"""
import argparse
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))
import entry

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='dev')
    ap.add_argument('--repository', default=None)
    args = ap.parse_args()
    sys.path.insert(0, str(BACKEND))
    from flashrt.paths import repo_root
    repo = Path(args.repository) if args.repository else repo_root()
    cfg = BACKEND / 'configs' / f'{args.config}.json'
    entry.run({'mode': 'split1_pin'},
              argv=['--repository', str(repo), '--config', str(cfg)])
