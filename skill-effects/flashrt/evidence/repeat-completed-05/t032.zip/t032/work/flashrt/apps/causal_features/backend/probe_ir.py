"""Fix SliceChunk's time-axis slicing and diagnose the IR graph in-process."""
import sys
from pathlib import Path

import numpy as np
import torch

BACKEND = Path(__file__).resolve().parent
for p in (str(BACKEND), str(BACKEND / 'bench')):
    if p not in sys.path:
        sys.path.insert(0, p)

# --- patch ops.py: SliceChunk must cut the time axis (dim -1) --------------
p = BACKEND / 'ir' / 'ops.py'
src = p.read_text(encoding='utf-8')
old = "        return {'chunk': ctx.frame[:, a:a + valid]}"
new = "        return {'chunk': ctx.frame[:, :, a:a + valid]}"
assert old in src, 'slice anchor missing'
p.write_text(src.replace(old, new), encoding='utf-8')
print('patched SliceChunk time slicing')

import common  # noqa: E402
from flashrt.ir import SequentialExecutor  # noqa: E402
from ir import (build_context, build_model_graph, build_worker_graph,  # noqa: E402
                initial_state)

cfg = common.make_config('dev', prefix='probe_ir')
got = []


def publish(index, data):
    got.append((index, np.array(data, copy=True)))


ctx = build_context(str(common.REPO), cfg, publish)
frame = np.random.default_rng(0).standard_normal(
    (cfg['channels'], cfg['length'])).astype(np.float32)
ctx.begin_request(None)
ctx.frame = torch.from_numpy(frame).unsqueeze(0).cuda()
print('frame', tuple(ctx.frame.shape))

for name, builder in (('worker', build_worker_graph), ('model', build_model_graph)):
    graph = builder(cfg, ctx)
    ex = SequentialExecutor(graph)
    ex.init_state(initial_state(ctx))
    ctx.frame = torch.from_numpy(frame).unsqueeze(0).cuda()
    got.clear()
    n = common.n_chunks(cfg)
    try:
        for i in range(n):
            ctx.chunk_index = i
            vals = ex.run_chunk({}, ctx)
        print(name, 'ops ok, chunks published', len(got),
              [tuple(d.shape) for _, d in got[:2]], [tuple(d.shape) for _, d in got[-1:]])
        stacked = np.concatenate([d for _, d in got], axis=1)
    except Exception as exc:
        import traceback
        print(name, 'FAILED', type(exc).__name__, exc)
        traceback.print_exc()
        continue
    # compare against the CPU full-sequence oracle
    from causal_features.model import full_sequence_oracle
    cfg_cpu = dict(cfg, device='cpu')
    ref = full_sequence_oracle(str(common.REPO), cfg_cpu, frame)
    print(name, 'max|d| vs oracle =', float(np.abs(stacked - ref).max()))

    from flashrt.ir.analysis import (analyze_cross_chunk_dependencies,
                                     find_pipeline_stages,
                                     find_streaming_overlaps, summarize_graph)
    out = []
    for label, fn in (('summarize', lambda: summarize_graph(graph)),
                      ('stages', lambda: find_pipeline_stages(graph)),
                      ('overlaps', lambda: find_streaming_overlaps(graph)),
                      ('cross_chunk', lambda: analyze_cross_chunk_dependencies(graph))):
        try:
            out.append(f'## {label}\n{fn()}')
        except Exception as exc:  # noqa: BLE001
            out.append(f'## {label}\nERROR {type(exc).__name__}: {exc}')
    text = f'# IR analysis: {graph.name}\n' + '\n'.join(str(x) for x in out)
    (BACKEND / 'notes').mkdir(parents=True, exist_ok=True)
    (BACKEND / 'notes' / f'ir_analysis_{name}.txt').write_text(text, encoding='utf-8')
    print(text[:3000])
