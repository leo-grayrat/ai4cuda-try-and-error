"""batch_full_pin variant."""
