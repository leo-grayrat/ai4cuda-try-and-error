"""split2: First two chunks up front, then the remainder in one pass."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'split2', 'first_chunks': 2}

if __name__ == '__main__':
    entry.run(OVERRIDES)
