# causal_features backend (CUDA)

Recommended entry: `worker.py` (mode `split1_pin`: publish chunk 0 as soon as it
is computed, then run the rest of the request as one causal pass; history kept
on the device; pinned staging for the D2H copy).

    python -m causal_features.backend.worker --repository <repo> --config <json>

or, from the repo root with the app importable:

    python flashrt/apps/causal_features/backend/worker.py \
        --repository . --config flashrt/apps/causal_features/backend/configs/dev.json

The unchanged frontend under `flashrt/apps/causal_features/frontend/` drives it
through `causal_features.adapter` (`python -m causal_features.reference` can be
replaced by the command above).

Other measured variants: `variants/<name>/worker.py` (same CLI).
Harnesses: `tests/test_ir.py` (IR vs reference), `bench/run_suite.py`
(correctness + both targets per variant). Results: `bench/results/`.
