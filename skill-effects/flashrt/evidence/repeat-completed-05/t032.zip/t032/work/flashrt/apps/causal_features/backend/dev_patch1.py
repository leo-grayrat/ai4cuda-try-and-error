"""Dev helper: patch the numpy-comparison bug in bench/common.py, then run a
first sweep (ref + first agent variants) on the dev config."""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
p = HERE / 'bench' / 'common.py'
src = p.read_text(encoding='utf-8')
old = """        if rec['kind'] == 'reset' or want == 'reset':
            if rec['kind'] != 'reset':
                fails.append(f'#{idx}: expected reset')
            continue"""
new = """        if rec['kind'] == 'reset':
            continue
        if isinstance(want, str):
            fails.append(f'#{idx}: expected reset, got request')
            continue"""
assert old in src, 'anchor missing'
p.write_text(src.replace(old, new), encoding='utf-8')
print('patched verify()')

sys.argv = ['run_suite.py', '--configs', 'dev',
            '--variants', 'ref,chunk_ref,split1,split1_pin']
sys.path.insert(0, str(HERE / 'bench'))
import run_suite  # noqa: E402

run_suite.main()
