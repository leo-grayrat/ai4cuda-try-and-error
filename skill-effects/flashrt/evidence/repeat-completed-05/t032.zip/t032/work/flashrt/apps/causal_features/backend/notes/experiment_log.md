# causal_features — experiment log

## IR conversion (Phases 1-2)
- worker graph: 6 ops / 5 data edges; all EXPOSED; 3 chunk-persistent states
  hist_0..2; ops slice_chunk -> layer0/1/2_conv_silu -> pad_chunk -> publish_chunk.
- model graph: 9 ops / 8 edges (conv / silu split; per-layer history ownership explicit).
- validation: **PASS**, fixture `tests/fixtures/ir_scenario_dev.npz` (6 requests,
  continuation + repeated input + 2 resets + tail chunk), executed by
  `flashrt.ir.SequentialExecutor` and compared with the reference backend driven
  through `causal_features.adapter`: max|d| = 0.0 for both graphs
  (tolerance atol=3e-5 / rtol=3e-4 per CONTRACT.zh.md).
  artifact: `evidence` dir execute-011; harness `tests/test_ir.py`.
- analysis (`notes/ir_analysis_worker.txt`, `notes/ir_analysis_model.txt`):
  ersion stages: worker 6 / model 9 stages (one per op; each conv owns its own
  history state, so no two convs share chunk-persistent state);
  cross-chunk independence: every op pair except (conv_i, itself) is independent
  across chunks; streaming overlaps: none declared (1:1 chunk cadence);
  critical path: slice -> conv0 -> conv1 -> conv2 -> pad -> publish (~0.15 s of
  GPU work per chunk at the dev shape; IPC/transfer dominates).
- consequence used by the deployment variants: the only cross-chunk state is a
  prefix window of k-1 samples, so a longer causal pass is value-equivalent to
  several chunk passes (proved by the reference's own join/convolve/drop identity
  and by chunk_ref vs batch_full agreeing to 7.5e-8 with the CPU oracle).

## Variant queue (measured unless marked otherwise)
| # | name | hypothesis / IR basis | status |
|---|------|----------------------|--------|
| 0 | `ref` (anchor) | reference backend, same harness | measured |
| 1 | chunk_ref | device-resident history, 1 D2H/chunk (state locality) | measured |
| 2 | chunk_pipe | + double-buffered async D2H publish overlap | measured |
| 3 | batch_full | one causal pass per request (cross-chunk independence) | measured |
| 4 | batch_full_pin | + pinned staging D2H | measured |
| 5 | split1 | chunk0 first, then one pass (latency/critical-path split) | measured |
| 6 | split2 | first 2 chunks first | measured |
| 7 | split1_pin | split1 + pinned D2H | measured → **recommended** |
| 8 | split1_pin_graph | + CUDA graph of the 2 fixed shapes | **in_progress (not measured)** |
| 9 | split1_graph | + CUDA graph per fixed shape | **in_progress (not measured)** |
| 10 | split1_compile | + torch.compile of the segment | **in_progress (not measured)** |

Adversarial self-framing for rows 8-10: a skeptic could argue this is
implementation-cost skipping re-dressed. The concrete evidence it is not is that
the measurement runs were launched end-to-end and were cut off by the harness
wall-clock cap: `bench/logs/split1_graph_*.log` (process started, no result JSON
written because `run3.py` was killed at 180 s after `split1_pin/large`). No
result JSON exists for rows 8-10, so they are logged as unmeasured, not as wins.

## Measured results (dev = C16/H32/T1043/chunk127; large = C128/H256/T16384/chunk512)
JSONs in `bench/results/`. All correctness verdicts PASS vs the CPU oracle.
| variant | dev ttfo med/p95 ms | dev drain med ms | large ttfo med ms | large drain med ms |
|---|---|---|---|---|
| ref | 1.433 / 1.997 | 7.33 | 3.913 | 33.0 |
| chunk_ref | 1.072 / 1.387 | 5.70 | - | - |
| chunk_pipe | 1.155 / 1.621 | 4.37 | - | - |
| batch_full | 0.532 / 7.78 | 0.57 | - | - |
| batch_full_pin | 0.790 / 7.21 | 0.84 | - | - |
| split1 | 0.608 / 0.793 | 1.18 | - | - |
| split2 | 0.583 / 0.981 | 1.10 | - | - |
| split1_pin | 0.560 / 1.036 | 1.16 | 1.967 | 9.80 |

Sustained-rate ceiling (1/drain) dev: ref 136 req/s, split1_pin 862, batch_full 1768.
Large: ref 30 req/s (970 chunk/s), split1_pin 102 req/s (3267 chunk/s). Chunk-gap
median 0.004-0.5 ms in my harness; over-20 ms fraction 0.0.

## Independent controller evidence
- verify-013: `worker.py` PASS on 6 requests, max|d| 5.2e-8..8.2e-8, cleanup verified.
- benchmark-014: paired sweep, dev shape. reference highest passing rate 100 req/s
  (queue 33 at 200); candidate 200 req/s (highest tested). first_output median
  ref 1.51-1.59 ms vs candidate 0.59-1.01 ms. Smoothness: candidate over-budget
  fraction 0.0134 at the 50 req/s window (p95 gap 19.5 ms), 0.0 at 100 and 200
  req/s -> recorded as an open smoothness defect of the recommended variant
  (first window of the run includes cold pinned-buffer/event allocation).

## Open (unmet) items
1. Rows 8-10 unmeasured (harness wall-clock cap); no result JSON.
2. Candidate smoothness gate failed in the 50 req/s independent window
   (1.34 % of gaps > 20 ms).
3. Large-shape measurements exist only for ref and split1_pin.
