"""split1_pin variant."""
