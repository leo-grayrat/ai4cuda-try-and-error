"""Patch test_ir.py's IR import (top-level ``ir`` package, not
``causal_features.backend.ir``) and run it."""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
p = HERE / 'tests' / 'test_ir.py'
src = p.read_text(encoding='utf-8')
old = """from causal_features.backend.ir import (build_context, build_model_graph,  # noqa: E402
                                        build_worker_graph, initial_state)"""
new = """if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))
from ir import (build_context, build_model_graph,  # noqa: E402
                build_worker_graph, initial_state)"""
assert old in src, 'anchor missing'
p.write_text(src.replace(old, new), encoding='utf-8')
print('patched', p)

import causal_features  # noqa: E402
print('causal_features from', causal_features.__file__)

sys.argv = ['test_ir.py']
sys.path.insert(0, str(HERE / 'tests'))
import test_ir  # noqa: E402

raise SystemExit(test_ir.main())
