"""batch_full_pin: batch_full + pinned staging D2H + busy-poll input wait."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'batch_full_pin'}

if __name__ == '__main__':
    entry.run(OVERRIDES)
