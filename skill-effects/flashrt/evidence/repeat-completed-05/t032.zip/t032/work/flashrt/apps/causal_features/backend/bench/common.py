"""Harness utilities: build configs, launch a backend subprocess, drive it
through the fixed adapter, compare against the CPU full-sequence oracle, and
measure the two active targets (time-to-first-output and sustained rate).

Everything here is headless: the user frontend is never executed.
"""
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import numpy as np

_HERE = Path(__file__).resolve()
BACKEND_DIR = _HERE.parents[1]


def repo_root() -> Path:
    try:
        from flashrt.paths import repo_root as _root
        return Path(_root())
    except Exception:
        return _HERE.parents[5]


REPO = repo_root()
RESULT_DIR = BACKEND_DIR / 'bench' / 'results'
LOG_DIR = BACKEND_DIR / 'bench' / 'logs'
CC = {'device': 'cuda'}

CONFIGS = {
    'dev': dict(channels=16, hidden=32, length=1043, chunk=127),
    'large': dict(channels=128, hidden=256, length=16384, chunk=512),
}

# tolerance from CONTRACT.zh.md (CPU/GPU float32 accumulation-order differences)
ATOL = 3e-5
RTOL = 3e-4
CHUNK_GAP_BUDGET_MS = 20.0


def make_config(shape: str, prefix: str, device: str = 'cuda') -> dict:
    cfg = dict(CONFIGS[shape])
    cfg.update({'prefix': prefix, 'device': device, 'weight_seed': 703})
    return cfg


def gen_input(rng, cfg, scale=1.0):
    return (rng.standard_normal((cfg['channels'], cfg['length'])) * scale).astype(np.float32)


def n_chunks(cfg) -> int:
    return -(-cfg['length'] // cfg['chunk'])


# ---------------------------------------------------------------- process I/O
_DIST_VARS = (
    'RANK', 'LOCAL_RANK', 'WORLD_SIZE', 'LOCAL_WORLD_SIZE', 'GROUP_RANK',
    'ROLE_RANK', 'ROLE_NAME', 'OMP_NUM_THREADS', 'MASTER_ADDR', 'MASTER_PORT',
    'TORCHELASTIC_USE_AGENT_STORE', 'TORCHELASTIC_MAX_RESTARTS',
    'TORCHELASTIC_RUN_ID', 'TORCH_NCCL_ASYNC_ERROR_HANDLING',
    'TORCHELASTIC_ERROR_FILE',
)


def _child_env():
    env = os.environ.copy()
    for var in _DIST_VARS:
        env.pop(var, None)
    paths = [str(REPO), str(REPO / 'flashrt' / 'apps')]
    if env.get('PYTHONPATH'):
        paths.append(env['PYTHONPATH'])
    env['PYTHONPATH'] = os.pathsep.join(paths)
    env['CUDA_VISIBLE_DEVICES'] = env.get('CF_GPU', '0')
    env['PYTHONUNBUFFERED'] = '1'
    return env


def _cleanup_shm(prefix: str):
    from multiprocessing import shared_memory
    for name in (prefix + '__ctrl', prefix + '_input__meta',
                 prefix + '_input__tensor', prefix + '_output__meta',
                 prefix + '_output__tensor', prefix + '_metadata__meta',
                 prefix + '_metadata__tensor'):
        try:
            shm = shared_memory.SharedMemory(name=name)
        except FileNotFoundError:
            continue
        except Exception:
            continue
        try:
            shm.unlink()
        finally:
            shm.close()


class Backend:
    """A backend subprocess plus its adapter handle."""

    def __init__(self, worker: str, cfg: dict, tag: str):
        self.cfg = cfg
        self.tag = tag
        self.prefix = cfg['prefix']
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        self.log_path = LOG_DIR / f'{tag}_{self.prefix}.log'
        cfg_dir = BACKEND_DIR / 'bench' / 'configs'
        cfg_dir.mkdir(parents=True, exist_ok=True)
        self.cfg_path = cfg_dir / f'{tag}_{self.prefix}.json'
        self.cfg_path.write_text(json.dumps(cfg, indent=2), encoding='utf-8')
        if worker == 'reference':
            cmd = [sys.executable, '-u', '-m', 'causal_features.reference',
                   '--repository', str(REPO), '--config', str(self.cfg_path)]
        else:
            path = Path(worker)
            if not path.is_absolute():
                path = REPO / path
            cmd = [sys.executable, '-u', str(path), '--repository', str(REPO),
                   '--config', str(self.cfg_path)]
        _cleanup_shm(self.prefix)
        flags = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0) if os.name == 'nt' else 0
        self._log = open(self.log_path, 'wb')
        env = _child_env()
        self.proc = subprocess.Popen(cmd, cwd=str(REPO), env=env,
                                     stdout=self._log, stderr=subprocess.STDOUT,
                                     stdin=subprocess.DEVNULL,
                                     creationflags=flags)
        self.adapter = None
        self.startup_s = None

    def wait_ready(self, timeout=300.0, want=b'"ready"'):
        t0 = time.time()
        while time.time() - t0 < timeout:
            if self.proc.poll() is not None:
                raise RuntimeError(f'backend exited early (rc={self.proc.returncode}); '
                                   f'see {self.log_path}')
            try:
                blob = self.log_path.read_bytes()
            except OSError:
                blob = b''
            if want in blob:
                return time.time() - t0
            time.sleep(0.02)
        raise TimeoutError(f'backend not ready in {timeout}s; see {self.log_path}')

    def open(self, ready_timeout=300.0):
        self.startup_s = self.wait_ready(ready_timeout)
        from causal_features.adapter import FeatureAdapter
        self.adapter = FeatureAdapter(self.cfg)
        self.adapter.start()
        return self

    def close(self, grace=20.0):
        err = None
        try:
            if self.adapter is not None:
                try:
                    if self.adapter.pending is None:
                        self.adapter.terminate()
                    else:
                        self.adapter.terminate()
                except Exception as exc:  # noqa: BLE001
                    err = f'terminate: {exc}'
        finally:
            try:
                self.proc.wait(timeout=grace)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                try:
                    self.proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    pass
            try:
                self._log.close()
            except Exception:
                pass
            if self.adapter is not None:
                self.adapter.close()
                self.adapter = None
            _cleanup_shm(self.prefix)
        return err

    def __enter__(self):
        return self.open()

    def __exit__(self, *exc):
        self.close()
        return False

    # -------------------------------------------------------------- driving
    def submit_and_drain(self, values, timeout=180.0):
        rid, published_ns = self.adapter.submit(values)
        chunks = []
        while self.adapter.pending is not None:
            data, ts = self.adapter.receive(timeout_s=timeout)
            chunks.append((ts, np.array(data, copy=True)))
        return {'request_id': rid, 'published_ns': published_ns, 'chunks': chunks}


def run_scenario(worker, shape, actions, tag, device='cuda', inputs=None,
                 timeout=180.0):
    """actions: sequence of 'req' / 'reset'.  Returns (records, startup_s, err)."""
    rng = np.random.default_rng(20240607)
    cfg = make_config(shape, prefix=f'cf{uuid.uuid4().hex[:10]}', device=device)
    if inputs is None:
        inputs = [gen_input(rng, cfg) for _ in range(len(actions))]
    backend = Backend(worker, cfg, tag)
    records = []
    err = None
    try:
        backend.open()
        cursor = 0
        for act in actions:
            if act == 'reset':
                backend.adapter.reset()
                records.append({'kind': 'reset'})
                continue
            rec = backend.submit_and_drain(inputs[cursor], timeout=timeout)
            rec['kind'] = 'req'
            rec['input'] = inputs[cursor]
            cursor += 1
            records.append(rec)
    finally:
        err = backend.close()
    return records, backend.startup_s, err


# ------------------------------------------------------------------ oracle
def oracle_sessions(records, shape):
    """Expected per-chunk outputs from the CPU full-sequence oracle."""
    from causal_features.model import full_sequence_oracle
    cfg_cpu = dict(CONFIGS[shape])
    cfg_cpu['weight_seed'] = 703
    cfg_cpu['device'] = 'cpu'
    expected = []
    buf = []
    for rec in records:
        if rec['kind'] == 'reset':
            expected.append('reset')
            buf = []
            continue
        buf.append(rec['input'])
        joined = np.concatenate(buf, axis=1) if len(buf) > 1 else buf[0]
        full = full_sequence_oracle(str(REPO), cfg_cpu, joined)
        off = joined.shape[1] - rec['input'].shape[1]
        expected.append(full[:, off:off + rec['input'].shape[1]])
    return expected


def verify(records, shape, atol=ATOL, rtol=RTOL):
    exp = oracle_sessions(records, shape)
    cfg = CONFIGS[shape]
    worst = 0.0
    fails = []
    for idx, (rec, want) in enumerate(zip(records, exp)):
        if rec['kind'] == 'reset':
            continue
        if isinstance(want, str):
            fails.append(f'#{idx}: expected reset, got request')
            continue
        chunks = rec['chunks']
        want_n = n_chunks(cfg)
        if len(chunks) != want_n:
            fails.append(f'#{idx}: got {len(chunks)} chunks, want {want_n}')
            continue
        for i, (_, data) in enumerate(chunks):
            valid = min(cfg['chunk'], cfg['length'] - i * cfg['chunk'])
            ref = want[:, i * cfg['chunk']:i * cfg['chunk'] + valid]
            if data.shape != ref.shape:
                fails.append(f'#{idx} chunk {i}: shape {data.shape} != {ref.shape}')
                continue
            diff = np.abs(data - ref)
            worst = max(worst, float(diff.max()))
            if not np.allclose(data, ref, atol=atol, rtol=rtol):
                fails.append(f'#{idx} chunk {i}: max|d|={diff.max():.3e}')
    verdict = 'PASS' if not fails else 'FAIL'
    return verdict, {'chunks_checked': sum(1 for r in records if r['kind'] == 'req'),
                     'max_abs_diff': worst, 'failures': fails[:12]}


# -------------------------------------------------------------- benchmarks
def _stats(xs):
    if not xs:
        return {'n': 0}
    arr = np.asarray(xs, dtype=np.float64)
    return {'n': int(arr.size), 'median_ms': float(np.median(arr)),
            'p95_ms': float(np.percentile(arr, 95)),
            'mean_ms': float(arr.mean()), 'max_ms': float(arr.max())}


def bench_latency(backend, cfg, rng, n=10):
    first, total, gaps = [], [], []
    for _ in range(n):
        values = gen_input(rng, cfg)
        t_sub = time.perf_counter_ns()
        rid, published_ns = backend.adapter.submit(values)
        stamps = []
        while backend.adapter.pending is not None:
            data, ts = backend.adapter.receive(timeout_s=180)
            stamps.append(ts)
        if stamps:
            first.append((stamps[0] - published_ns) / 1e6)
            total.append((stamps[-1] - published_ns) / 1e6)
            total.append((stamps[-1] - t_sub) / 1e6)
            total.pop()
            for a, b in zip(stamps, stamps[1:]):
                gaps.append((b - a) / 1e6)
    return {
        'ttfo_ms': _stats(first),
        'drain_ms': _stats(total),
        'gaps_ms': _stats(gaps),
        'gaps_over_budget_frac': (float(np.mean(np.asarray(gaps) > CHUNK_GAP_BUDGET_MS))
                                  if gaps else None),
        'cold_ttfo_ms': first[0] if first else None,
        'warm_ttfo_ms': _stats(first[1:]),
    }


def bench_rate(backend, cfg, rng, rates, n_per_rate=24):
    chunks_per_req = n_chunks(cfg)
    rows = []
    for rate in rates:
        period = 1.0 / float(rate)
        t_start = time.perf_counter()
        lat, gaps, misses = [], [], 0
        for i in range(n_per_rate):
            target = t_start + i * period
            now = time.perf_counter()
            if now < target:
                time.sleep(target - now)
            values = gen_input(rng, cfg)
            rid, published_ns = backend.adapter.submit(values)
            stamps = []
            while backend.adapter.pending is not None:
                data, ts = backend.adapter.receive(timeout_s=180)
                stamps.append(ts)
            lat.append((stamps[0] - published_ns) / 1e6)
            for a, b in zip(stamps, stamps[1:]):
                gaps.append((b - a) / 1e6)
            if (time.perf_counter() - published_ns) > period:
                misses += 1
        elapsed = time.perf_counter() - t_start
        achieved = n_per_rate / elapsed
        rows.append({
            'offered_req_per_s': float(rate),
            'achieved_req_per_s': achieved,
            'achieved_chunk_per_s': achieved * chunks_per_req,
            'kept_up_frac': 1.0 - misses / n_per_rate,
            'ttfo_ms': _stats(lat),
            'gaps_ms': _stats(gaps),
            'gaps_over_budget_frac': (float(np.mean(np.asarray(gaps) > CHUNK_GAP_BUDGET_MS))
                                      if gaps else None),
        })
    sustained = [r['offered_req_per_s'] for r in rows if r['kept_up_frac'] >= 0.999]
    return {
        'n_per_rate': n_per_rate,
        'chunks_per_request': chunks_per_req,
        'sweep': rows,
        'max_sustained_req_per_s': max(sustained) if sustained else None,
        'max_sustained_chunk_per_s': (max(sustained) * chunks_per_req) if sustained else None,
    }


def save_result(name, payload):
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULT_DIR / f'{name}.json'
    path.write_text(json.dumps(payload, indent=2, default=float), encoding='utf-8')
    return path


def gpu_info():
    try:
        import torch
        if torch.cuda.is_available():
            return {'name': torch.cuda.get_device_name(0),
                    'capability': torch.cuda.get_device_capability(0),
                    'torch': torch.__version__}
    except Exception as exc:  # noqa: BLE001
        return {'error': str(exc)}
    return {}
