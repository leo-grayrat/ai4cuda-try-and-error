"""Optimized execution engine + worker loop for the causal_features app.

The fixed computation is the three-layer causal Conv1d/SiLU stack built by
``causal_features.model.build_layers`` (weights from seed 703, channel layout
C->H->H->C, kernels 5/5/3).  Nothing about the *computation* changes here:
every mode below evaluates exactly the same causal convolution with the same
per-layer history of ``kernel-1`` samples, so all modes are mathematically
equivalent to the reference's chunked evaluation (and to the CPU full-sequence
oracle).  What changes is only *how* the work is scheduled and how data moves:

  chunk_ref        per-chunk GPU step with the history kept resident on the
                   GPU; one D2H transfer per chunk (reference cadence, minus
                   the reference's per-chunk CPU copy / cat / clone churn).
  chunk_pipe       chunk_ref + double-buffered async D2H so that publishing
                   chunk k overlaps the device work for chunk k+1.
  batch_full       the whole request as a single causal-conv pass (per chunk
                   the result is identical because the conv is position-local),
                   one D2H transfer, then host-side chunk publication.
  batch_full_pin   batch_full with a pinned staging buffer + non-blocking D2H
                   and a busy-poll input wait.
  split1           compute+publish chunk 0 first (minimum time-to-first-output),
                   then the whole remainder in one pass.
  split2           same trade-off curve with the first *two* chunks up front.
  split1_pin       split1 + pinned staging D2H.
  split1_graph     split1 + CUDA-graph capture of the two fixed-shape segments
                   (removes per-request kernel-launch overhead).
  split1_compile   split1 + torch.compile of the segment function.
  split1_pin_graph combined: split1 + pinned D2H + CUDA graphs.

Legality (see ``notes/experiment_log.md`` and ``ir/``): the only cross-chunk
state is the per-layer convolution history, a *prefix* window of length
``kernel-1``.  Each output sample at time t depends only on inputs
[t-k+1, t], so concatenating consecutive chunk computations into one longer
causal pass is value preserving; the reference's own "join history + chunk,
convolve, drop the prefix" identity proves it.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

MODES = (
    'chunk_ref', 'chunk_pipe', 'batch_full', 'batch_full_pin', 'split1',
    'split2', 'split1_pin', 'split1_graph', 'split1_compile',
    'split1_pin_graph',
)


def n_chunks(length: int, chunk: int) -> int:
    return -(-int(length) // int(chunk))


def _seg_fwd(params, x, hs):
    """Three causal conv layers + SiLU over one segment.

    ``params`` is [(weight, bias)] per layer; ``x`` is (1, Cin, L) on device;
    ``hs`` is one history tensor per layer of shape (1, Cout, k), k == kernel-1
    (a zero-length tensor means "start of session": no left context yet).

    With k samples of true left context the convolution needs no extra left
    padding, and the stored history is the last k samples of the layer input,
    exactly matching ``ReferencePipeline.step``.  At the true start of a
    session (zero-length history) the layer's own replicate pad is used, which
    is also what the CPU full-sequence oracle does.
    """
    new_h = []
    for (w, b), h in zip(params, hs):
        k = w.shape[-1] - 1
        if h.shape[-1] == 0:
            if k:
                padded = F.pad(x, (k, 0), mode='replicate')
                y = F.conv1d(padded, w, b)
            else:
                y = F.conv1d(x, w, b)
            new_h.append(x[..., -k:].clone() if k else x[..., :0].clone())
        else:
            joined = torch.cat((h, x), dim=-1)
            y = F.conv1d(joined, w, b)
            new_h.append(joined[..., joined.shape[-1] - k:].clone() if k
                         else joined[..., :0].clone())
        x = F.silu(y)
    return x, tuple(new_h)


class _GraphSeg:
    """CUDA-graph capture of one fixed-shape segment of ``_seg_fwd``."""

    def __init__(self, params, length: int, has_hist: bool, device):
        self.params = params
        self.length = int(length)
        self.has_hist = bool(has_hist)
        cin = params[0][0].shape[1]
        self.xs = torch.zeros(1, cin, self.length, device=device)
        self.hs = [torch.zeros(1, w.shape[0], w.shape[-1] - 1, device=device)
                   for w, _ in params]
        self.hs_out = [torch.zeros_like(h) for h in self.hs]
        self.out = torch.empty(1, params[-1][0].shape[0], self.length, device=device)
        self.graph = torch.cuda.CUDAGraph()
        empty = tuple(h[..., :0] for h in self.hs)
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(3):
                _seg_fwd(params, self.xs, tuple(self.hs) if self.has_hist else empty)
        torch.cuda.current_stream().wait_stream(side)
        with torch.cuda.graph(self.graph):
            y, nh = _seg_fwd(params, self.xs, tuple(self.hs) if self.has_hist else empty)
            self.out.copy_(y)
            for dst, src in zip(self.hs_out, nh):
                if dst.shape[-1]:
                    dst.copy_(src)

    def replay(self, x, hs):
        self.xs.copy_(x)
        if self.has_hist:
            for dst, src in zip(self.hs, hs):
                if dst.shape[-1]:
                    dst.copy_(src)
        self.graph.replay()
        return self.out, tuple(h.clone() for h in self.hs_out)


class Engine:
    """Session state (per-layer history) + the mode-specific request driver."""

    def __init__(self, repository, cfg, mode='split1', first_chunks=1,
                 pinned=None, use_graph=None, use_compile=None, spin=True):
        if str(repository) not in sys.path:
            sys.path.insert(0, str(repository))
        self.cfg = cfg
        self.device = torch.device(cfg['device'])
        self.chunk = int(cfg['chunk'])
        self.length = int(cfg['length'])
        self.channels = int(cfg['channels'])
        self.mode = mode
        self.first_chunks = max(1, int(first_chunks))
        self.spin = bool(spin)
        self.pinned = (mode in ('batch_full_pin', 'split1_pin', 'split1_pin_graph')
                       if pinned is None else bool(pinned))
        self.use_graph = (mode in ('split1_graph', 'split1_pin_graph')
                          if use_graph is None else bool(use_graph))
        self.use_compile = (mode == 'split1_compile'
                            if use_compile is None else bool(use_compile))

        from causal_features.model import build_layers
        layers = build_layers(repository, cfg, cfg['device'])
        self.params = [(l.conv.weight.detach().clone(), l.conv.bias.detach().clone())
                       for l in layers]
        self.ks = [w.shape[-1] - 1 for w, _ in self.params]

        self._pins = {}
        self._evs = {}
        self._graphs = {}
        self._compiled = self._make_compiled() if self.use_compile else None
        self.reset()

    # ---------------- session state ----------------
    def reset(self):
        dev = self.device
        self.hist = [torch.zeros(1, w.shape[0], 0, device=dev) for w, _ in self.params]

    def _make_compiled(self):
        params = self.params

        def f(x, h0, h1, h2):
            return _seg_fwd(params, x, (h0, h1, h2))

        return torch.compile(f, dynamic=False)

    def _seg(self, x, has_hist):
        if self.use_compile:
            y, nh = self._compiled(x, self.hist[0], self.hist[1], self.hist[2])
            self.hist = list(nh)
            return y
        if self.use_graph:
            key = (int(x.shape[-1]), bool(has_hist))
            seg = self._graphs.get(key)
            if seg is None:
                seg = _GraphSeg(self.params, x.shape[-1], has_hist, self.device)
                self._graphs[key] = seg
            y, nh = seg.replay(x, self.hist)
            self.hist = list(nh)
            return y
        y, nh = _seg_fwd(self.params, x, tuple(self.hist))
        self.hist = list(nh)
        return y

    # ---------------- host transfer helpers ----------------
    def _h2d(self, host, a, b):
        return host[:, a:b].to(self.device).unsqueeze(0)

    def _pin_buf(self, length, slot=0):
        key = (int(length), int(slot))
        buf = self._pins.get(key)
        if buf is None:
            buf = torch.empty(1, self.channels, int(length), dtype=torch.float32,
                              pin_memory=True)
            self._pins[key] = buf
        return buf

    def _ev(self, key):
        ev = self._evs.get(key)
        if ev is None:
            ev = torch.cuda.Event()
            self._evs[key] = ev
        return ev

    def _to_host(self, y, key=0):
        if self.pinned:
            buf = self._pin_buf(y.shape[-1], key)
            buf.copy_(y, non_blocking=True)
            ev = self._ev(key)
            ev.record()
            ev.synchronize()
            return buf.numpy()[0]
        return y[0].detach().cpu().numpy()

    def _emit(self, y, seg_start, seg_end, publish, key=0):
        arr = self._to_host(y, key)
        ch = self.chunk
        a = seg_start
        i = seg_start // ch
        while a < seg_end:
            valid = min(ch, self.length - a)
            off = a - seg_start
            publish(i, arr[:, off:off + valid])
            a += valid
            i += 1

    # ---------------- request driver ----------------
    def run_request(self, host, publish):
        mode = self.mode
        T, ch = self.length, self.chunk
        if mode in ('chunk_ref', 'chunk_pipe'):
            self._run_chunked(host, publish, pipelined=(mode == 'chunk_pipe'))
            return
        if mode in ('batch_full', 'batch_full_pin'):
            x = self._h2d(host, 0, T)
            self._emit(self._seg(x, False), 0, T, publish, key=0)
            return
        # split modes: chunk 0 (or the first `first_chunks` chunks) first
        L1 = min(self.first_chunks * ch, T)
        x1 = self._h2d(host, 0, L1)
        self._emit(self._seg(x1, False), 0, L1, publish, key=0)
        if T > L1:
            x2 = self._h2d(host, L1, T)
            self._emit(self._seg(x2, True), L1, T, publish, key=1)

    def _run_chunked(self, host, publish, pipelined):
        T, ch = self.length, self.chunk
        pending = None
        for i in range(n_chunks(T, ch)):
            a = i * ch
            valid = min(ch, T - a)
            x = self._h2d(host, a, a + valid)
            y = self._seg(x, i > 0)
            if not pipelined:
                self._emit(y, a, a + valid, publish)
                continue
            slot = i % 2
            buf = self._pin_buf(valid, slot)
            buf.copy_(y, non_blocking=True)
            ev = self._ev(slot)
            ev.record()
            if pending is not None:
                p_ev, p_idx, p_len, p_slot = pending
                p_ev.synchronize()
                publish(p_idx, self._pins[(p_len, p_slot)].numpy()[0])
            pending = (ev, i, valid, slot)
        if pending is not None:
            p_ev, p_idx, p_len, p_slot = pending
            p_ev.synchronize()
            publish(p_idx, self._pins[(p_len, p_slot)].numpy()[0])


# --------------------------------------------------------------------------
# worker main loop (adapter contract identical to the reference backend)
# --------------------------------------------------------------------------
def run_worker(cfg, overrides=None):
    overrides = dict(overrides or {})
    repository = Path(cfg.pop('_repository'))
    if str(repository) not in sys.path:
        sys.path.insert(0, str(repository))
    from causal_features.adapter import open_buffers, close_buffers

    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    cfg.setdefault('device', 'cuda')
    eng = Engine(repository, cfg, mode=overrides.get('mode', 'split1'),
                 first_chunks=overrides.get('first_chunks', 1),
                 pinned=overrides.get('pinned'),
                 use_graph=overrides.get('use_graph'),
                 use_compile=overrides.get('use_compile'),
                 spin=overrides.get('spin', True))
    ch = int(cfg['chunk'])
    C = int(cfg['channels'])
    buffers = open_buffers(cfg, create=True)
    frame = np.zeros((C, ch), dtype=np.float32)
    spin_gap = 0.0 if eng.spin else 0.0002
    try:
        print(json.dumps({'ready': True, 'device': cfg['device'],
                          'mode': eng.mode}), flush=True)
        consumed, last_command, active = 0, 0, False
        req = [0]
        in_tensor = buffers['input'].tensor
        max_len = int(buffers['input'].max_len)

        def publish(index, data):
            valid = int(data.shape[1])
            frame[:, :valid] = data
            if valid < ch:
                frame[:, valid:] = 0.0
            buffers['output'].write(frame)
            buffers['metadata'].write(
                np.array([req[0], index, valid], dtype=np.int64))

        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    eng.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active or buffers['input'].num <= consumed:
                if spin_gap:
                    time.sleep(spin_gap)
                continue
            request_id = consumed
            consumed = request_id + 1
            req[0] = request_id
            host = torch.from_numpy(in_tensor[request_id % max_len])
            with torch.inference_mode():
                eng.run_request(host, publish)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)
