"""Dev helper: measure the remaining dev-config variants and print the sweeps."""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'bench'))
import run_suite  # noqa: E402
import common  # noqa: E402

NAMES = sys.argv[1].split(',') if len(sys.argv) > 1 else [
    'batch_full', 'batch_full_pin', 'split2', 'chunk_pipe', 'split1_graph',
    'split1_pin_graph', 'split1_compile']
SHAPES = sys.argv[2].split(',') if len(sys.argv) > 2 else ['dev']

for name in NAMES:
    out = run_suite.run_variant(name, SHAPES, n_latency=10)
    common.save_result(name, out)
    for shape, block in out['shapes'].items():
        for row in block.get('rate', {}).get('sweep', []):
            print(f'   {name}/{shape} offered={row["offered_req_per_s"]:7.0f} '
                  f'achieved={row["achieved_req_per_s"]:7.1f} '
                  f'kept_up={row["kept_up_frac"]:.3f} '
                  f'ttfo_med={row["ttfo_ms"]["median_ms"]:.3f} '
                  f'gap_med={row["gaps_ms"]["median_ms"]:.3f} '
                  f'over20ms={row["gaps_over_budget_frac"]}', flush=True)
