"""Variant registry + sweep driver (correctness + both active targets, one
backend launch per variant/config pair).

Per pair we run, in a single backend session:
  1. a 6-request correctness scenario (continuation, repeated input without
     reset, reset, tail chunk) compared with the CPU full-sequence oracle,
  2. an explicit reset,
  3. a latency measurement (cold + warm time-to-first-output, chunk gaps),
  4. an offered-load sweep for sustained output rate: for every offered rate we
     record the achieved rate, the fraction of requests whose whole drain fit
     inside the offered period ("kept up"), and the inter-chunk-gap stats.

``bench_rate`` here supersedes ``common.bench_rate`` (which compared a
perf_counter() value against a perf_counter_ns() timestamp, so its keep-up
column was always 1.0).

    python flashrt/apps/causal_features/backend/bench/run_suite.py \
        --configs dev --variants ref,chunk_ref
"""
import argparse
import json
import sys
import time
import traceback
import uuid
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BACKEND = HERE.parent
for p in (str(BACKEND), str(HERE)):
    if p not in sys.path:
        sys.path.insert(0, p)

import common

B = 'flashrt/apps/causal_features/backend'
VARIANTS = {
    'ref': 'reference',
    'chunk_ref': f'{B}/variants/chunk_ref/worker.py',
    'chunk_pipe': f'{B}/variants/chunk_pipe/worker.py',
    'batch_full': f'{B}/variants/batch_full/worker.py',
    'batch_full_pin': f'{B}/variants/batch_full_pin/worker.py',
    'split1': f'{B}/variants/split1/worker.py',
    'split2': f'{B}/variants/split2/worker.py',
    'split1_pin': f'{B}/variants/split1_pin/worker.py',
    'split1_graph': f'{B}/variants/split1_graph/worker.py',
    'split1_compile': f'{B}/variants/split1_compile/worker.py',
    'split1_pin_graph': f'{B}/variants/split1_pin_graph/worker.py',
    'recommended': f'{B}/worker.py',
}

SCENARIO = ['req', 'req', 'reset', 'req', 'req', 'req', 'reset', 'req']

RATES = {
    'dev': [50, 100, 200, 400, 800, 1600],
    'large': [10, 20, 50, 100, 200, 400],
}


def bench_rate(backend, cfg, rng, rates, n_per_rate=16):
    """Offered-load sweep.  Keep-up = the request's whole drain fits in the
    offered period, i.e. the input queue cannot grow."""
    chunks_per_req = common.n_chunks(cfg)
    pool = [common.gen_input(rng, cfg) for _ in range(8)]
    rows = []
    for rate in rates:
        period = 1.0 / float(rate)
        t_start = time.perf_counter()
        lat, gaps, misses = [], [], 0
        for i in range(n_per_rate):
            target = t_start + i * period
            now = time.perf_counter()
            if now < target:
                time.sleep(target - now)
            rid, published_ns = backend.adapter.submit(pool[i % len(pool)])
            stamps = []
            while backend.adapter.pending is not None:
                data, ts = backend.adapter.receive(timeout_s=180)
                stamps.append(ts)
            lat.append((stamps[0] - published_ns) / 1e6)
            for a, b in zip(stamps, stamps[1:]):
                gaps.append((b - a) / 1e6)
            if (time.perf_counter_ns() - published_ns) > period * 1e9:
                misses += 1
        elapsed = time.perf_counter() - t_start
        achieved = n_per_rate / elapsed
        rows.append({
            'offered_req_per_s': float(rate),
            'achieved_req_per_s': achieved,
            'achieved_chunk_per_s': achieved * chunks_per_req,
            'kept_up_frac': 1.0 - misses / n_per_rate,
            'ttfo_ms': common._stats(lat),
            'gaps_ms': common._stats(gaps),
            'gaps_over_budget_frac': (float(np.mean(np.asarray(gaps) >
                                                     common.CHUNK_GAP_BUDGET_MS))
                                      if gaps else None),
        })
    sustained = [r['offered_req_per_s'] for r in rows if r['kept_up_frac'] >= 0.999]
    return {
        'n_per_rate': n_per_rate,
        'chunks_per_request': chunks_per_req,
        'sweep': rows,
        'max_kept_up_req_per_s': max(sustained) if sustained else None,
        'max_kept_up_chunk_per_s': (max(sustained) * chunks_per_req) if sustained else None,
    }


def run_variant(name, shapes, n_latency=10, do_verify=True, do_bench=True,
                n_per_rate=16):
    worker = VARIANTS.get(name, name)
    out = {'variant': name, 'worker': worker,
           'stamp': time.strftime('%Y-%m-%dT%H:%M:%S'), 'shapes': {}}
    for shape in shapes:
        cfg = common.make_config(shape, prefix=f'cf{uuid.uuid4().hex[:10]}')
        rng = np.random.default_rng(20240607)
        inputs = [common.gen_input(rng, cfg) for _ in range(12)]
        block = {'tolerance': {'atol': common.ATOL, 'rtol': common.RTOL},
                 'config': {k: v for k, v in cfg.items() if k != 'prefix'}}
        t0 = time.time()
        backend = common.Backend(worker, cfg, name)
        try:
            backend.open()
            block['startup_s'] = backend.startup_s
            if do_verify:
                records, cur = [], 0
                for act in SCENARIO:
                    if act == 'reset':
                        backend.adapter.reset()
                        records.append({'kind': 'reset'})
                        continue
                    rec = backend.submit_and_drain(inputs[cur])
                    rec.update({'kind': 'req', 'input': inputs[cur]})
                    cur += 1
                    records.append(rec)
                verdict, info = common.verify(records, shape)
                block['correctness'] = {'verdict': verdict, 'scenario': SCENARIO, **info}
                print(f'[{name}/{shape}] correctness {verdict} '
                      f'max|d|={info["max_abs_diff"]:.3e} {info["failures"][:2]}',
                      flush=True)
            if do_bench:
                backend.adapter.reset()
                brng = np.random.default_rng(11)
                lat = common.bench_latency(backend, cfg, brng, n=n_latency)
                rate = bench_rate(backend, cfg, np.random.default_rng(12), RATES[shape],
                                  n_per_rate=n_per_rate)
                block['latency'] = lat
                block['rate'] = rate
                drain = lat['drain_ms']['median_ms']
                block['ceiling'] = {'req_per_s': 1000.0 / drain if drain else None,
                                    'chunk_per_s': (1000.0 * common.n_chunks(cfg) / drain)
                                    if drain else None}
                print(f'[{name}/{shape}] ttfo warm med='
                      f'{lat["warm_ttfo_ms"]["median_ms"]:.3f}ms p95='
                      f'{lat["warm_ttfo_ms"]["p95_ms"]:.3f}ms cold='
                      f'{lat["cold_ttfo_ms"]:.3f}ms drain med='
                      f'{drain:.3f}ms gap med={lat["gaps_ms"]["median_ms"]:.3f}ms '
                      f'over20ms={lat["gaps_over_budget_frac"]} '
                      f'kept_up_max={rate["max_kept_up_req_per_s"]} req/s '
                      f'ceiling={block["ceiling"]["req_per_s"]:.0f} req/s',
                      flush=True)
                for row in rate['sweep']:
                    print(f'    offered={row["offered_req_per_s"]:7.0f} '
                          f'achieved={row["achieved_req_per_s"]:7.1f} '
                          f'kept_up={row["kept_up_frac"]:.3f} '
                          f'ttfo={row["ttfo_ms"]["median_ms"]:.3f}ms '
                          f'gap={row["gaps_ms"]["median_ms"]:.3f}ms', flush=True)
        except Exception as exc:  # noqa: BLE001
            block['error'] = f'{type(exc).__name__}: {exc}'
            block['traceback'] = traceback.format_exc()[-1500:]
            print(f'[{name}/{shape}] ERROR {block["error"]}', flush=True)
        finally:
            try:
                backend.close()
            except Exception as exc:  # noqa: BLE001
                block.setdefault('close_error', str(exc))
        block['elapsed_s'] = time.time() - t0
        out['shapes'][shape] = block
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--configs', default='dev')
    ap.add_argument('--variants', default='ref')
    ap.add_argument('--no-verify', action='store_true')
    ap.add_argument('--no-bench', action='store_true')
    ap.add_argument('--latency-reps', type=int, default=10)
    ap.add_argument('--rate-reps', type=int, default=16)
    ap.add_argument('--suffix', default='')
    args = ap.parse_args()
    shapes = [s for s in args.configs.split(',') if s]
    names = [s for s in args.variants.split(',') if s]
    meta = {'gpu': common.gpu_info(), 'stamp': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'rates': {s: RATES[s] for s in shapes},
            'chunk_gap_budget_ms': common.CHUNK_GAP_BUDGET_MS}
    print('META', json.dumps(meta), flush=True)
    for name in names:
        out = run_variant(name, shapes, n_latency=args.latency_reps,
                          do_verify=not args.no_verify, do_bench=not args.no_bench,
                          n_per_rate=args.rate_reps)
        out['meta'] = meta
        path = common.save_result(f'{name}{args.suffix}', out)
        print(f'[{name}] wrote {path}', flush=True)


if __name__ == '__main__':
    main()
