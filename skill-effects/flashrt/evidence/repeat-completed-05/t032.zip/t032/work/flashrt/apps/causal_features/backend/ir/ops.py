"""IR operator definitions for the causal_features app.

Two graphs are built from these operators (see ``graph_builder.py``):

* ``worker`` graph - the high-level streaming pipeline of one request:
  slice a chunk out of the request frame, run the three fixed layers with the
  history carried in chunk-persistent state, pad the tail chunk and publish it.
* ``model`` graph - the same computation one level finer: each layer split into
  its convolution (which owns that layer's history state) and its SiLU, plus
  the tail-pad and publish steps.

The state declarations are the load-bearing part: every layer owns exactly one
``hist_<i>`` state object (scope ``chunk_persistent``), and no layer touches
another layer's history.  That is what makes (a) ``find_pipeline_stages``
separate the layers, and (b) the "run a longer causal pass instead of several
chunks" transformation legal, since a longer pass only extends the same
prefix-window recurrence that the history state already encodes.
"""
import numpy as np
import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort


class SliceChunk(IROperator):
    """Cut chunk ``ctx.chunk_index`` out of the request frame (causal: the rest
    of the frame is never touched by this chunk's computation)."""

    def __init__(self, chunk, length):
        super().__init__(
            name='slice_chunk',
            op_type=OpType.EXPOSED,
            outputs=[TensorPort('chunk', ('C', 'L'), 'float32')],
            config={'chunk': int(chunk), 'length': int(length)},
            stream_mode=StreamMode.STREAMING,
        )

    def execute(self, inputs, ctx, state):
        a = ctx.chunk_index * self.config['chunk']
        valid = min(self.config['chunk'], self.config['length'] - a)
        ctx.valid = valid
        return {'chunk': ctx.frame[:, :, a:a + valid]}


class LayerConvSilu(IROperator):
    """One fixed CausalConv1d + SiLU, owning that layer's history state."""

    def __init__(self, index, kernel):
        self.index = index
        self.kernel = int(kernel)
        super().__init__(
            name=f'layer{index}_conv_silu',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')],
            outputs=[TensorPort('y')],
            state_reads=[f'hist_{index}'],
            state_writes=[f'hist_{index}'],
            stream_mode=StreamMode.STREAMING,
            config={'kernel': self.kernel},
        )

    def execute(self, inputs, ctx, state):
        x = inputs['x']
        k = self.kernel - 1
        h = state.get(f'hist_{self.index}')
        weight, bias = ctx.weight[self.index], ctx.bias[self.index]
        if h.shape[-1]:
            joined = torch.cat((h, x), dim=-1)
            y = F.conv1d(joined, weight, bias)
            new_h = joined[..., joined.shape[-1] - k:].clone()
        else:
            y = F.conv1d(F.pad(x, (k, 0), mode='replicate'), weight, bias)
            new_h = x[..., -k:].clone()
        state.set(f'hist_{self.index}', new_h)
        return {'y': F.silu(y)}


class LayerConv(IROperator):
    """Convolution half of a layer (model-level graph)."""

    def __init__(self, index, kernel):
        self.index = index
        self.kernel = int(kernel)
        super().__init__(
            name=f'conv{index}',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')],
            outputs=[TensorPort('z')],
            state_reads=[f'hist_{index}'],
            state_writes=[f'hist_{index}'],
            config={'kernel': self.kernel},
        )

    def execute(self, inputs, ctx, state):
        x = inputs['x']
        k = self.kernel - 1
        h = state.get(f'hist_{self.index}')
        weight, bias = ctx.weight[self.index], ctx.bias[self.index]
        if h.shape[-1]:
            joined = torch.cat((h, x), dim=-1)
            z = F.conv1d(joined, weight, bias)
            new_h = joined[..., joined.shape[-1] - k:].clone()
        else:
            z = F.conv1d(F.pad(x, (k, 0), mode='replicate'), weight, bias)
            new_h = x[..., -k:].clone()
        state.set(f'hist_{self.index}', new_h)
        return {'z': z}


class Silu(IROperator):
    """Element-wise SiLU with no persistent state (model-level graph)."""

    def __init__(self, index):
        super().__init__(
            name=f'silu{index}',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('z')],
            outputs=[TensorPort('y')],
            stream_mode=StreamMode.STREAMING,
        )

    def execute(self, inputs, ctx, state):
        return {'y': F.silu(inputs['z'])}


class PadChunk(IROperator):
    """Zero-pad the tail chunk to the configured chunk width."""

    def __init__(self, channels, chunk):
        super().__init__(
            name='pad_chunk',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('y')],
            outputs=[TensorPort('padded')],
            config={'channels': int(channels), 'chunk': int(chunk)},
        )

    def execute(self, inputs, ctx, state):
        y = inputs['y']
        padded = torch.zeros(1, self.config['channels'], self.config['chunk'],
                             dtype=y.dtype, device=y.device)
        padded[:, :, :y.shape[-1]] = y
        return {'padded': padded}


class PublishChunk(IROperator):
    """Hand the padded chunk to the adapter's output ring (data then metadata)."""

    def __init__(self):
        super().__init__(
            name='publish_chunk',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('padded')],
            outputs=[TensorPort('published')],
            stream_mode=StreamMode.STREAMING,
        )

    def execute(self, inputs, ctx, state):
        data = inputs['padded']
        valid = ctx.valid
        ctx.publish(ctx.chunk_index, data[0, :, :valid].detach().cpu().numpy())
        return {'published': data}
