"""split1_graph variant."""
