"""IR graph builders for the causal_features app (Phases 1-2).

``build_worker_graph``   high-level chunk-periodic pipeline of one request.
``build_model_graph``    the same computation, one level finer (conv / SiLU
                         split, so per-layer state ownership is explicit).
``build_context``        the opaque context object the operators read: the
                         request frame, the layer weights, the chunk cursor and
                         the publish callback.

Both graphs are executed by ``flashrt.ir.SequentialExecutor`` in
``tests/test_ir.py`` and compared against the reference backend driven through
the fixed adapter.
"""
import torch

from flashrt.ir.graph import IREdge, IRGraph, StateObject

from .ops import (LayerConv, LayerConvSilu, PadChunk, PublishChunk, Silu,
                  SliceChunk)


class Context:
    """Per-chunk scalars + session-wide handles handed to every operator."""

    def __init__(self, weight, bias, kwidth, chunk, length, publish, device='cuda'):
        self.weight = weight
        self.bias = bias
        self.kwidth = kwidth
        self.chunk = chunk
        self.length = length
        self.publish = publish
        self.device = device
        self.frame = None
        self.chunk_index = 0
        self.valid = 0

    def begin_request(self, frame):
        self.frame = frame
        self.chunk_index = 0


def build_context(repository, cfg, publish, device='cuda'):
    from causal_features.model import build_layers
    layers = build_layers(repository, cfg, device)
    weight = [l.conv.weight.detach().clone() for l in layers]
    bias = [l.conv.bias.detach().clone() for l in layers]
    kwidth = [int(w.shape[-1]) for w in weight]
    return Context(weight, bias, kwidth, int(cfg['chunk']), int(cfg['length']),
                   publish, device)


def _hist_state(index, context):
    dev = torch.device(context.device)
    return torch.zeros(1, context.weight[index].shape[0], 0, device=dev)


def initial_state(context):
    return {f'hist_{i}': _hist_state(i, context) for i in range(3)}


def _declare_state(graph):
    for i in range(3):
        graph.add_state(StateObject(
            name=f'hist_{i}', scope='chunk_persistent',
            description=f'last kernel-1 samples of layer {i} input'))


def _chain(graph, ops):
    for op in ops:
        graph.add_operator(op)
        graph.chunk_ops.append(op.name)
    for a, b in zip(ops, ops[1:]):
        graph.add_edge(IREdge(src_op=a.name, src_port=a.outputs[0].name,
                              dst_op=b.name, dst_port=b.inputs[0].name))


def build_worker_graph(cfg, context):
    graph = IRGraph(name='causal_features.worker')
    _declare_state(graph)
    ops = [SliceChunk(cfg['chunk'], cfg['length'])]
    ops += [LayerConvSilu(i, context.kwidth[i]) for i in range(3)]
    ops.append(PadChunk(cfg['channels'], cfg['chunk']))
    ops.append(PublishChunk())
    _chain(graph, ops)
    return graph


def build_model_graph(cfg, context):
    graph = IRGraph(name='causal_features.model')
    _declare_state(graph)
    ops = [SliceChunk(cfg['chunk'], cfg['length'])]
    for i in range(3):
        ops.append(LayerConv(i, context.kwidth[i]))
        ops.append(Silu(i))
    ops.append(PadChunk(cfg['channels'], cfg['chunk']))
    ops.append(PublishChunk())
    _chain(graph, ops)
    return graph
