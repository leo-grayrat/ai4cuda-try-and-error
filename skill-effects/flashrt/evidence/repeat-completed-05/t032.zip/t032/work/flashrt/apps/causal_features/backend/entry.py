"""Shared CLI entry used by every worker variant in this workspace."""
import argparse
import json
import sys
from pathlib import Path


def run(overrides, argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args(argv)
    here = Path(__file__).resolve().parent
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))
    import cf_engine
    cfg = json.loads(args.config.read_text(encoding='utf-8'))
    cfg['_repository'] = str(args.repository.resolve())
    cf_engine.run_worker(cfg, overrides)
