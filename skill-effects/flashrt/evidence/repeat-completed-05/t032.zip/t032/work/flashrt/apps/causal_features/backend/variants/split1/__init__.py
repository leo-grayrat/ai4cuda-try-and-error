"""split1 variant."""
