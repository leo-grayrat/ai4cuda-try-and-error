"""batch_full: Whole request as one causal-conv pass, one D2H, host-side chunk publish."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'batch_full'}

if __name__ == '__main__':
    entry.run(OVERRIDES)
