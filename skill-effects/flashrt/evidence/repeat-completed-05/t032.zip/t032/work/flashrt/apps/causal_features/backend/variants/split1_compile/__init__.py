"""split1_compile variant."""
