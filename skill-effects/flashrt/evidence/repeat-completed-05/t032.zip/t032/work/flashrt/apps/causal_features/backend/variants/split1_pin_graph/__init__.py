"""split1_pin_graph variant."""
