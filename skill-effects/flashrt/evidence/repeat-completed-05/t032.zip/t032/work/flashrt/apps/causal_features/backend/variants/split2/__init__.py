"""split2 variant."""
