"""Agent backend workspace for the causal_features app (RTX 5060 / CUDA)."""
