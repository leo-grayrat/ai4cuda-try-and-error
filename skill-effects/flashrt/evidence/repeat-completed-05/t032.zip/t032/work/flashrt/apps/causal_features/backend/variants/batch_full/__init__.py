"""batch_full variant."""
