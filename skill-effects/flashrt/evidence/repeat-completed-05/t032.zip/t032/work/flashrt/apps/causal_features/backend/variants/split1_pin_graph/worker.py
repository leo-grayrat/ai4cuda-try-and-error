"""split1_pin_graph: split1 + pinned D2H + CUDA graphs (combined lever stack)."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'split1_pin_graph'}

if __name__ == '__main__':
    entry.run(OVERRIDES)
