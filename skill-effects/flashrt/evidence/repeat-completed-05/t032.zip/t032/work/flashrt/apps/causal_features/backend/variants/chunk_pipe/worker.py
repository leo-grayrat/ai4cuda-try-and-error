"""chunk_pipe: Per-chunk GPU step + double-buffered async D2H; publish k overlaps k+1."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'chunk_pipe'}

if __name__ == '__main__':
    entry.run(OVERRIDES)
