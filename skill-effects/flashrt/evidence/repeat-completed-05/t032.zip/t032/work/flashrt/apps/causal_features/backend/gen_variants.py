"""Generate the variant subpackages, config files and launch examples.

Each variant gets its own subpackage (own worker entry + own config), so no
variant mutates another in place.  Run once:

    python flashrt/apps/causal_features/backend/gen_variants.py
"""
import json
from pathlib import Path

BACKEND = Path(__file__).resolve().parent

VARIANTS = [
    ('chunk_ref', {'mode': 'chunk_ref'},
     'Per-chunk GPU step, history resident on the device; one D2H per chunk.'),
    ('chunk_pipe', {'mode': 'chunk_pipe'},
     'Per-chunk GPU step + double-buffered async D2H; publish k overlaps k+1.'),
    ('batch_full', {'mode': 'batch_full'},
     'Whole request as one causal-conv pass, one D2H, host-side chunk publish.'),
    ('batch_full_pin', {'mode': 'batch_full_pin'},
     'batch_full + pinned staging D2H + busy-poll input wait.'),
    ('split1', {'mode': 'split1'},
     'Publish chunk 0 first (min TTFO), then the remainder in one pass.'),
    ('split2', {'mode': 'split2', 'first_chunks': 2},
     'First two chunks up front, then the remainder in one pass.'),
    ('split1_pin', {'mode': 'split1_pin'},
     'split1 + pinned staging D2H.'),
    ('split1_graph', {'mode': 'split1_graph'},
     'split1 + CUDA-graph capture of the two fixed-shape segments.'),
    ('split1_compile', {'mode': 'split1_compile'},
     'split1 + torch.compile of the segment function.'),
    ('split1_pin_graph', {'mode': 'split1_pin_graph'},
     'split1 + pinned D2H + CUDA graphs (combined lever stack).'),
]

WORKER_TEMPLATE = '''"""{doc}"""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {overrides!r}

if __name__ == '__main__':
    entry.run(OVERRIDES)
'''


def main():
    for name, overrides, doc in VARIANTS:
        d = BACKEND / 'variants' / name
        d.mkdir(parents=True, exist_ok=True)
        (d / '__init__.py').write_text(f'"""{name} variant."""\n', encoding='utf-8')
        (d / 'worker.py').write_text(
            WORKER_TEMPLATE.format(doc=f'{name}: {doc}', overrides=overrides),
            encoding='utf-8')
    cfg_dir = BACKEND / 'configs'
    cfg_dir.mkdir(parents=True, exist_ok=True)
    (cfg_dir / 'dev.json').write_text(json.dumps({
        'prefix': 'causal_features_dev', 'device': 'cuda', 'channels': 16,
        'hidden': 32, 'length': 1043, 'chunk': 127, 'weight_seed': 703,
    }, indent=2), encoding='utf-8')
    (cfg_dir / 'large.json').write_text(json.dumps({
        'prefix': 'causal_features_large', 'device': 'cuda', 'channels': 128,
        'hidden': 256, 'length': 16384, 'chunk': 512, 'weight_seed': 703,
    }, indent=2), encoding='utf-8')
    ex_dir = BACKEND / 'examples'
    ex_dir.mkdir(parents=True, exist_ok=True)
    (ex_dir / 'launch.py').write_text('''"""Launch the recommended backend end-to-end (unchanged frontend drives it).

    python flashrt/apps/causal_features/backend/examples/launch.py --config dev
"""
import argparse
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))
import entry

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='dev')
    ap.add_argument('--repository', default=None)
    args = ap.parse_args()
    sys.path.insert(0, str(BACKEND))
    from flashrt.paths import repo_root
    repo = Path(args.repository) if args.repository else repo_root()
    cfg = BACKEND / 'configs' / f'{args.config}.json'
    entry.run({'mode': 'split1_pin'},
              argv=['--repository', str(repo), '--config', str(cfg)])
''', encoding='utf-8')
    print('generated', len(VARIANTS), 'variants')


if __name__ == '__main__':
    main()
