"""Measure the large config (ref vs split1_pin) plus the two graph variants."""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'bench'))
import common  # noqa: E402
import run_suite  # noqa: E402

TARGETS = [('ref', ['large']), ('split1_pin', ['large']),
           ('split1_graph', ['dev']), ('split1_pin_graph', ['dev'])]

for name, shapes in TARGETS:
    out = run_suite.run_variant(name, shapes, n_latency=6, n_per_rate=6)
    common.save_result(name, out)
    for sh, b in out['shapes'].items():
        if 'error' in b:
            print(f'>>> {name}/{sh} ERROR {b["error"][:200]}', flush=True)
            continue
        c = b.get('correctness', {})
        l = b.get('latency', {})
        r = b.get('rate', {})
        print(f'>>> {name}/{sh} {c.get("verdict")} maxd={c.get("max_abs_diff")} '
              f'ttfo={l.get("warm_ttfo_ms", {}).get("median_ms", 0):.3f}ms '
              f'drain={l.get("drain_ms", {}).get("median_ms", 0):.3f}ms '
              f'kept_up_max={r.get("max_kept_up_req_per_s")} '
              f'ceiling={b.get("ceiling")}', flush=True)
