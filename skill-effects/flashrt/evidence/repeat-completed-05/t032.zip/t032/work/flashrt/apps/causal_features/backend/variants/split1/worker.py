"""split1: Publish chunk 0 first (min TTFO), then the remainder in one pass."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'split1'}

if __name__ == '__main__':
    entry.run(OVERRIDES)
