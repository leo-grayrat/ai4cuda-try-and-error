"""Probe (dev-only): print CausalConv1d source, ir executor, template listing."""
from pathlib import Path

root = Path('.').resolve()
src = (root / 'flashrt' / 'layers' / 'audio.py').read_text(encoding='utf-8')
i = src.find('class CausalConv1d')
print('=== CausalConv1d ===')
print(src[i:i + 1800])
print('=== template backend ===')
tpl = root / 'flashrt' / 'apps' / '_template' / 'backend'
for p in sorted(tpl.rglob('*')):
    if p.is_file():
        print(p.relative_to(tpl))
print('=== apps ===')
print(sorted(p.name for p in (root / 'flashrt' / 'apps').iterdir()))
print('=== ir executor ===')
print((root / 'flashrt' / 'ir' / 'executor.py').read_text(encoding='utf-8')[:6000])
