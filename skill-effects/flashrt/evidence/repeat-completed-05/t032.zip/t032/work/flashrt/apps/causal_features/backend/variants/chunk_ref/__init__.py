"""chunk_ref variant."""
