"""chunk_ref: Per-chunk GPU step, history resident on the device; one D2H per chunk."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'chunk_ref'}

if __name__ == '__main__':
    entry.run(OVERRIDES)
