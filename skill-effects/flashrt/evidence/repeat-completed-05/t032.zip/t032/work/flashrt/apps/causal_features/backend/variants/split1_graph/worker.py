"""split1_graph: split1 + CUDA-graph capture of the two fixed-shape segments."""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parents[2]) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import entry

OVERRIDES = {'mode': 'split1_graph'}

if __name__ == '__main__':
    entry.run(OVERRIDES)
