"""chunk_pipe variant."""
