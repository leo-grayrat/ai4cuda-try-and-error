# causal_features 单卡（RTX 5060 8GB / Windows / torch 2.11.0+cu128）优化报告

## 1. 任务理解与假设
固定计算是 `causal_features.model.build_layers` 生成的三层因果 `CausalConv1d`+SiLU（核 5/5/3，权重种子 703），按配置块长逐块输出，块间必须保留每层 `kernel-1` 的卷积历史，reset 清空，会话内连续请求等价于把输入按时间拼接。由此得到两个可检验的假设：

1. **状态局部性假设**：唯一跨块状态是长度为 `kernel-1` 的“前缀窗口”，每个输出点只依赖 `[t-k+1, t]`，因此把多个块合并成一次更长的因果 pass 与逐块计算在数值上等价（参考实现自身“拼接历史→卷积→丢掉前缀”的恒等式就是证明）。这给出把 9/32 次小 kernel 启动压成 1~2 次、并把每块一次 D2H 压成每请求一次的合法性。
2. **临界路径假设**：首块输出只依赖前 `chunk` 个样本，因此“先算并发布第 0 块，再把剩余部分整段算完”应当降低首输出延迟，而逐块管线化（publish 与 device 工作重叠）只应改善后续块的平滑度。

## 2. 交付物
- `backend/cf_engine.py`：同一套数值核心（`_seg_fwd`：历史拼接 + `F.conv1d` + SiLU，历史存最后 k 个样本、会话起点用 replicate pad，与参考逐位一致）加 10 种调度/搬运模式：`chunk_ref, chunk_pipe, batch_full, batch_full_pin, split1, split2, split1_pin, split1_graph, split1_compile, split1_pin_graph`；`run_worker` 实现与参考完全相同的适配器协议（同 7 个共享内存对象、0/1/2/3 电平控制码去重、先数据后元数据、退出时 `unlink`）。
- `backend/worker.py`（推荐入口，`--repository/--config`，模式 `split1_pin`）与 `backend/variants/<name>/worker.py`（10 个独立子包 + `configs/dev.json`、`configs/large.json`、`examples/launch.py`）。
- `backend/ir/ops.py`、`ir/graph_builder.py`、`tests/test_ir.py`：worker 图（6 算子/5 边/3 个 `chunk_persistent` 状态）与 model 图（9 算子，conv/silu 拆开）。
- `backend/bench/common.py`、`bench/run_suite.py`：headless 适配器驱动、6 请求正确性场景（续传、未 reset 重复输入、两次 reset、尾块）、CPU 全序列 oracle 比对（atol=3e-5/rtol=3e-4）、首输出延迟与 offered-load 扫描（含块间隔分布、20ms 预算超支比例）、子进程 `try/finally` 清理与 shm 前缀清理。

## 3. 证据与结果
- **IR 验证（真跑）**：`tests/test_ir.py` 用 `SequentialExecutor` 跑两张图并与经适配器采集的**参考后端**输出逐块比较，`max|d| = 0.0`，判定 **PASS**（execute-011）。分析输出落在 `notes/ir_analysis_worker.txt`、`notes/ir_analysis_model.txt`：每个 conv 独占自己的 `hist_i`，跨块仅“自身↔自身”有依赖，`find_pipeline_stages` 给出 6/9 个阶段（每算子一阶段）。工作区隔离下的独立验证也确认了 IR 与 CPU oracle 一致（5.96e-08）。
- **独立工具验证**：`workspace.verify backend/worker.py` → `candidate_run_passed`，6 个请求全部数值匹配（5.2e-8…8.2e-8），清理已验证（verify-013）。
- **独立工具测量**：`workspace.benchmark backend/worker.py`（dev 形状成对扫描，benchmark-014）：参考最高通过 100 req/s（200 时外部队列涨到 33），候选 200 req/s（本次最高档）；首输出中位数参考 1.51–1.59 ms，候选 0.59–1.01 ms。参考块间隔中位数 0.56 ms，候选 0.009 ms。
- **自建扫描**（`bench/results/*.json`，全部 PASS）：dev 形状首输出中位/尾延迟（ms）参考 1.433/7.33 → `chunk_ref` 1.072/5.70 → `batch_full` 0.532/0.57 → `split1` 0.608/1.18 → `split1_pin` 0.560/1.16；可持续上限（1/排空时间）参考 136 req/s（1224 chunk/s）→ `split1_pin` 862 → `batch_full` 1768。large 形状（C128/H256/T16384/chunk512）：参考 3.913 ms / 33.0 ms / 30 req/s（970 chunk/s），`split1_pin` 1.967 ms / 9.80 ms / 102 req/s（3267 chunk/s），两项指标同时改善约 2.0× 与 3.4×。

## 4. 失败、反例与权衡
- **无效运行**：第一次 `run_suite` 的 keep-up 列恒为 1.0，原因是我把 `perf_counter()` 与 `perf_counter_ns()` 直接相减；该列作废，`run_suite.bench_rate` 重写后（`*1e9`，并预热输入池）才使用；此前旧 `common.bench_rate` 的数字只用于排空时间/达成速率，不用于 keep-up 结论。
- **超时切断**：`run2.py` 与 `run3.py` 各在 ~180–233 s 被上限切断，`split1_graph`、`split1_pin_graph`、`split1_compile` 已启动但**没有**产生结果 JSON（`bench/logs/split1_graph_*.log` 存在、无 `bench/results/split1_graph.json`）。我不把它们记成测量结果，队列里保持未完成。
- **平滑度缺陷（真实回归）**：独立测量中 50 req/s 窗口候选 `smoothness_gate_passed=false`，1.34% 的块间隔 >20 ms（p95 19.5 ms），而 100/200 窗口为 0.0；同一窗口 ttfo 也偏高（1.006 ms vs 0.587 ms），指向该窗口起始处的冷启动（首次 pinned 缓冲/CUDA event 分配）。这是推荐变体上未修的问题，不宣称达标。
- **权衡**：dev 形状上 `batch_full`（单次 pass）在两个指标上都优于 `split1_pin`（0.532/0.57 vs 0.560/1.16，可持续上限 1768 vs 862 req/s），但 large 形状未测；`split1_pin` 在已测的两个形状上都优于参考且首输出最优，故作为推荐——代价是 dev 上可持续上限只有 `batch_full` 的一半。`chunk_pipe` 的块间隔最均匀（0.55 ms）但排空最慢（4.37 ms），因为每块一次 D2H 与 9 次 `cat` 启动不可省。pinned staging 在 dev 上反而变慢（`batch_full_pin` 0.790 ms > `batch_full` 0.532 ms），只在 large 上体现价值。

## 5. 未完成（诚实清单）
1. 队列中 3 行（`split1_graph`、`split1_pin_graph`、`split1_compile`）非终态：无结果 JSON，未测。
2. 实际测到的不同变体为 8 个（含锚点），低于“≥10 个已测量变体”的要求。
3. 推荐变体在独立测量的 50 req/s 窗口平滑度门未通过（需修冷启动路径，例如启动时预分配 pinned 缓冲与 event，或把首个请求排除在门限窗口外并单独标注为冷启动）。
4. large 形状只有参考与 `split1_pin` 两个数据点；`batch_full` 在 large 上是否仍占优未测，因此“按形状自适应选择模式”的策略未被测量，未实现。
5. 无 NVLink/多 GPU 相关项（本任务单卡，不适用）。

## 6. 交付前反拖延门（逐条作答）
- **“Implementation and debugging cost are never valid rationale …”**：本会话不以此为由跳过项；未测的 3 行是运行被墙钟上限切断（`bench/logs/` 有启动日志、无结果 JSON），并已在日志中按未完成记录，而不是以成本为由删除。
- **“Read-only areas are not a blocker — vendor the file into your workspace”**：本会话未修改任何只读文件；全部代码在 `flashrt/apps/causal_features/backend/`（`cf_engine.py`、`ir/`、`bench/`、`tests/`），参考/适配器/IR 只被导入（例如 `tests/test_ir.py` 导入 `causal_features.adapter` 与 `flashrt.ir`）。
- **“Terminal statuses”**：违反——`notes/experiment_log.md` 的变体队列第 8–10 行仍非终态（`in_progress`），因此本会话按定义未完成，我不声称完成。
- **“What blocked means (strict)”**：本会话没有把任何行标为 `blocked`，因为不满足三类环境证据；未测行保持未完成。
- **“Forbidden session-handoff language”**：已按机械检查避免使用“下次会话/后续会话/留待将来”等表述；日志与 README 只描述本次实测状态（`notes/experiment_log.md`、`README.md`）。
- **“Adversarial self-framing (required)”**：`notes/experiment_log.md` 对第 8–10 行给出了该段落，指向的具体在盘证据是 `bench/logs/split1_graph_*.log`（进程已启动）与缺失的 `bench/results/split1_graph.json`。

## 7. 结论
在默认 dev 形状上，推荐入口 `backend/worker.py`（`split1_pin`）经独立工具验证数值正确（6/6 请求，max|d| ≤ 8.2e-8，清理通过），首输出中位数从参考 1.51–1.59 ms 降到 0.59–1.01 ms，可持续通过速率从 100 req/s 提升到 200 req/s（本次最高测试档）；large 形状自测显示首输出 3.913→1.967 ms、排空 33.0→9.80 ms。仍未满足：3 个变体未测（测量被墙钟切断）、已测变体数 8 < 10、50 req/s 窗口平滑度门未通过、large 形状覆盖不全。
