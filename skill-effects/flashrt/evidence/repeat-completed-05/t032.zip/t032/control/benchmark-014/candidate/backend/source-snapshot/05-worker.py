"""Recommended standalone backend entry for the causal_features app.

Usage (identical CLI surface to the reference backend):

    python flashrt/apps/causal_features/backend/worker.py \
        --repository <repo root> --config <config.json>

The mode selected here is the measured best variant; see
``notes/experiment_log.md`` for the sweep and ``bench/results/`` for the raw
timings.  Set ``RECOMMENDED['mode']`` to any name in ``cf_engine.MODES`` to run
another measured variant through the same entry.
"""
import sys
from pathlib import Path

if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
import entry

RECOMMENDED = {'mode': 'split1_pin'}

if __name__ == '__main__':
    entry.run(RECOMMENDED)
