# causal_features 单卡（RTX 5060 8GB / Windows / torch 2.11.0+cu128）优化报告

## 假设

固定计算为 `build_layers` 生成的三层因果 `CausalConv1d`+SiLU（核 5/5/3、种子 703），按块长逐块输出，块间必须保留每层 `kernel-1` 的历史，reset 清空，会话内连续请求等价于按时间拼接输入。由此提出两条假设：(a) 状态局部性——唯一跨块状态是长度 `kernel-1` 的前缀窗口，每个输出点只依赖 `[t-k+1,t]`，因此把多个块合并成一次更长的因果 pass 与逐块计算数值等价（参考实现自身“拼历史→卷积→丢前缀”的恒等式即证明）；(b) 临界路径——首块只依赖前 `chunk` 个样本，因此“先算并发布块 0、再把剩余整段算完”应降低首输出延迟，而逐块管线化主要改善后续块的平滑度。

## 交付物（均在 backend/ 内）

`cf_engine.py` 是统一数值核心 `_seg_fwd`（历史拼接 + `F.conv1d` + SiLU，历史存最后 k 个样本、会话起点用 replicate pad，与参考逐位一致）加 10 种调度模式：`chunk_ref, chunk_pipe, batch_full, batch_full_pin, split1, split2, split1_pin, split1_graph, split1_compile, split1_pin_graph`；`run_worker` 复刻参考适配器协议（同 7 个共享内存对象、0/1/2/3 电平码去重、先数据后元数据、退出 unlink）。`worker.py` 为推荐入口（`--repository/--config`，模式 `split1_pin`），`variants/<name>/worker.py` 为独立变体子包，另有 `configs/`、`examples/launch.py`、`ir/`（worker 图 6 算子/3 个 `chunk_persistent` 状态、model 图 9 算子）、`tests/test_ir.py`、`bench/{common,run_suite}.py`、`notes/experiment_log.md`、`README.md`。

## 证据

- **IR 真跑验证 PASS**：`tests/test_ir.py` 用 `SequentialExecutor` 执行两张图，与经适配器采集的参考后端输出逐块比较，`max|d| = 0.0`（execute-011）；工作区隔离运行对 CPU oracle 为 5.96e-08。分析见 `notes/ir_analysis_worker.txt`、`notes/ir_analysis_model.txt`：每个 conv 独占自己的 `hist_i`，跨块仅“自身↔自身”有依赖，`find_pipeline_stages` 给出 6/9 个阶段。
- **独立验证**：verify-016 `candidate_run_passed`，6/6 请求数值匹配（5.2e-8…8.2e-8），清理已验证；verify-013 复现同一结论。
- **独立测量（dev 形状成对扫描）**：benchmark-017 候选在 50/100/200 req/s 全部通过门限，最高通过 200 req/s（本次最高档）；参考最高 100 req/s（200 时外部队列涨到 35）。首输出中位：参考 1.515–1.573 ms，候选 0.561–0.639 ms（约 2.7×）。块间隔中位：参考 0.54–0.56 ms，候选 0.007–0.010 ms。benchmark-014 给出同向结论（候选 0.59–1.01 ms，参考 1.51–1.59 ms）。
- **自建扫描**（`bench/results/*.json`，全部 PASS）：dev 首输出中位/排空（ms）参考 1.433/7.33，`chunk_ref` 1.072/5.70，`chunk_pipe` 1.155/4.37，`batch_full` 0.532/0.57，`batch_full_pin` 0.790/0.84，`split1` 0.608/1.18，`split2` 0.583/1.10，`split1_pin` 0.560/1.16。可持续上限（1/排空）：参考 136 req/s（1224 chunk/s），`split1_pin` 862，`batch_full` 1768。large（C128/H256/T16384/chunk512）：参考 3.913 ms / 33.0 ms / 30 req/s（970 chunk/s），`split1_pin` 1.967 ms / 9.80 ms / 102 req/s（3267 chunk/s）。

## 失败与权衡

- **无效数据**：首版 `common.bench_rate` 把 `perf_counter()` 与 `perf_counter_ns()` 相减，keep-up 恒为 1.0；该列作废，重写为 `run_suite.bench_rate`（乘 1e9 并预热输入池）后才使用。此前旧数字只用于排空时间与达成速率，不用于 keep-up 结论。
- **超时切断**：`run2.py`/`run3.py` 在约 180–233 s 被墙钟上限切断，`split1_graph`、`split1_pin_graph`、`split1_compile` 已启动但未产生结果 JSON（`bench/logs/split1_graph_*.log` 存在、`bench/results/split1_graph.json` 缺失）。
- **平滑度**：benchmark-014 的 50 req/s 窗口候选 `smoothness_gate_passed=false`（1.34% 间隔 >20 ms、p95 19.5 ms），benchmark-017 同窗口通过（0.89% 超预算、p95 19.6 ms 但未触发门限），故该窗口仍是脆弱点，指向冷启动路径（首个请求时才分配 pinned 缓冲与 CUDA event）。
- **权衡**：dev 上 `batch_full` 两指标均优于 `split1_pin`（0.532/0.57 vs 0.560/1.16，可持续上限 1768 vs 862 req/s），但 large 未测；`split1_pin` 在两个已测形状上都优于参考且首输出最优，故作为推荐，代价是 dev 可持续上限只有 `batch_full` 的一半。pinned staging 在 dev 反而变慢（0.790 vs 0.532 ms），只在 large 体现价值。

## 未完成（诚实清单）

1. 队列中 3 行（`split1_graph`、`split1_pin_graph`、`split1_compile`）非终态：无结果 JSON、未测量。
2. 实际测到的不同变体是最低要求以下的 8 个（含锚点），低于“≥10 个已测量变体”的要求。
3. 推荐变体在 benchmark-014 的 50 req/s 窗口平滑度门未通过；冷启动路径（预分配 pinned 缓冲/event）尚未修改。
4. large 形状只有参考与 `split1_pin` 两个数据点，按形状自适应选择模式的策略未实现、未测量。
5. 单卡任务，多 GPU/设备放置类变体不适用。

我未修改任何只读文件（参考、适配器、`flashrt/ir`、共享运行时仅被导入）；未使用“下次会话/留待将来”一类交接措辞；上述未测行没有标为 `blocked`（不满足三类环境证据），因此本会话按定义门检查（Terminal statuses）仍未完成，我不声称完成。