"""Optimized standalone backend for the causal_features task.

Entry point (same CLI as the research reference)::

    python worker.py --repository <fixed source dir> --config <config.json>

Semantics are identical to ``causal_features.reference``: three fixed
``CausalConv1d`` layers (5, 5, 3) each followed by SiLU, per-layer causal
history carried across requests, explicit reset, one request in flight.

Key differences from the sequential reference (all exact rewrites of the same
causal computation, no future-input access):

* A request already delivers the *whole* (C, T) feature frame, so the three
  convolutions are evaluated once over the full session segment instead of
  once per output chunk.  This removes O(chunks) kernel launches and O(chunks)
  device synchronisations while producing the same causal windows.
* The reference's ``F.pad(x, (k-1, 0), replicate)`` followed by slicing the
  first ``k-1`` outputs is an exact no-op once history is joined: joining the
  stored ``k-1`` history samples already provides those windows.  We therefore
  call the underlying convolution directly (only the very first chunk of a
  session needs the replicate tail, which we materialise explicitly).
* Per-layer history is kept on the device between requests (no cat/clone per
  chunk), and layer input buffers are preallocated.
* The input frame is consumed as a read-only view of shared memory (ring
  capacity is one frame and only one request may be in flight, so the adapter
  cannot overwrite it before the GPU copy finishes), and the result is staged
  through a pinned buffer with a single device synchronisation instead of one
  CPU round trip per chunk.
* Output data is still published one configured chunk at a time, tail chunk
  zero-padded and flagged by its valid length, strictly before its metadata.

The backend writes only after ``ready`` and always unlinks its shared memory in
``finally`` (termination, reset-only sessions and interrupted reception).
"""
import argparse
import json
import os
import signal
import sys
import time
from pathlib import Path

import numpy as np


def _bootstrap_paths(repository):
    """Make both ``causal_features`` and ``flashrt`` importable.

    The independent controller supplies module paths and the pinned FlashRT
    package is importable in its runtime.  For local execution from any working
    directory we additionally put the repo root and the app package parent on
    sys.path (harmless duplicates).
    """
    here = Path(__file__).resolve()
    candidates = [str(Path(repository).resolve())]
    if len(here.parents) > 2:
        candidates.append(str(here.parents[2]))  # .../flashrt/apps
    if len(here.parents) > 4:
        candidates.append(str(here.parents[4]))  # repository root
    for candidate in candidates:
        if candidate not in sys.path:
            sys.path.insert(0, candidate)


class BatchedCausalPipeline:
    """Exact causal network evaluated over one whole session segment."""

    def __init__(self, repository, config, torch, F, build_layers):
        self.config = dict(config)
        self.device = torch.device(config['device'])
        self.layers = build_layers(repository, config, self.device)
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        self.length = int(config['length'])
        self.chunk = int(config['chunk'])

        widths = [self.channels, self.hidden, self.hidden]
        self.jbufs = []
        for layer, cin in zip(self.layers, widths):
            h = int(layer._time_causal_padding[0])
            self.jbufs.append(torch.empty(
                (1, cin, self.length + h), dtype=torch.float32, device=self.device))
        self.in_gpu = torch.empty(
            (1, self.channels, self.length), dtype=torch.float32, device=self.device)
        try:
            self.pinned = torch.empty(
                (self.channels, self.length), dtype=torch.float32, pin_memory=True)
        except Exception:  # pinned allocation unavailable -> plain staging buffer
            self.pinned = torch.empty(
                (self.channels, self.length), dtype=torch.float32)
        self.pad = np.zeros((self.channels, self.chunk), dtype=np.float32)
        self.meta = np.zeros(3, dtype=np.int64)
        self.histories = [None] * len(self.layers)
        self._F = F
        self._torch = torch

    def reset(self):
        self.histories = [None] * len(self.layers)

    def warmup(self):
        """Populate CUDA workspaces/allocator before the ready handshake."""
        with self._torch.inference_mode():
            self.pinned.zero_()
            self.compute(self.pinned.numpy())
        self.reset()

    def compute(self, features):
        """Run the causal network; returns the full (C, T) output as numpy."""
        torch = self._torch
        F = self._F
        src = torch.from_numpy(features)
        self.in_gpu[0].copy_(src)
        value = self.in_gpu
        for index, layer in enumerate(self.layers):
            h = int(layer._time_causal_padding[0])
            joined = self.jbufs[index]
            history = self.histories[index]
            if history is None:
                # Session start: the reference's replicate pad of first sample.
                joined[:, :, :h].copy_(value[:, :, :1].expand(-1, -1, h))
            else:
                joined[:, :, :h].copy_(history)
            joined[:, :, h:].copy_(value)
            out = layer.conv(joined)  # valid convolution == pad+slice reference
            self.histories[index] = joined[:, :, -h:].clone()
            value = F.silu(out, inplace=True)
        self.pinned.copy_(value[0], non_blocking=True)
        torch.cuda.synchronize()
        return self.pinned.numpy()

    def publish(self, output, request_id, buffers):
        """Publish data chunk first, metadata second, in configured order."""
        out_buffer = buffers['output']
        meta_buffer = buffers['metadata']
        chunk = self.chunk
        meta = self.meta
        for index, position in enumerate(range(0, self.length, chunk)):
            valid = min(chunk, self.length - position)
            if valid == chunk:
                out_buffer.write(output[:, position:position + chunk])
            else:
                self.pad.fill(0.0)
                self.pad[:, :valid] = output[:, position:position + valid]
                out_buffer.write(self.pad)
            meta[0] = request_id
            meta[1] = index
            meta[2] = valid
            meta_buffer.write(meta)


def _install_signal_handlers():
    def _abort(signum, frame):
        del signum, frame
        raise KeyboardInterrupt

    for name in ('SIGTERM', 'SIGBREAK'):
        sig = getattr(signal, name, None)
        if sig is None:
            continue
        try:
            signal.signal(sig, _abort)
        except (ValueError, OSError):
            pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    repository = args.repository.resolve()
    _bootstrap_paths(repository)

    import torch
    import torch.nn.functional as F
    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(1)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    pipeline = BatchedCausalPipeline(repository, config, torch, F, build_layers)
    pipeline.warmup()
    _install_signal_handlers()

    buffers = open_buffers(config, create=True)
    consumed = 0
    last_command = 0
    active = False
    debug = bool(os.environ.get('CAUSAL_FEATURES_DEBUG'))
    try:
        print(json.dumps({'ready': True, 'device': str(config['device'])}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    pipeline.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0001)
                continue
            num = buffers['input'].num
            if num <= consumed:
                time.sleep(0.00005)
                continue
            if num != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            # Ring capacity is one frame and only one request may be in flight;
            # once num == consumed + 1 the producer has finished writing it.
            features = buffers['input'].tensor[consumed % buffers['input'].max_len]
            request_id = consumed
            consumed += 1
            started = time.perf_counter()
            with torch.inference_mode():
                output = pipeline.compute(features)
            computed = time.perf_counter()
            pipeline.publish(output, request_id, buffers)
            if debug:
                published = time.perf_counter()
                print(json.dumps({
                    'request': request_id,
                    'compute_ms': round((computed - started) * 1e3, 3),
                    'publish_ms': round((published - computed) * 1e3, 3),
                }), file=sys.stderr, flush=True)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
