# causal_features backend — hypotheses, evidence, trade-offs

## Task restated
Fixed three-layer causal conv net (C→H→H→C, kernels 5/5/3, SiLU after each),
weights seeded 703 via `causal_features.model.build_layers`. A request is one
full `(C, T)` float32 frame; outputs must be published in configured `chunk`
slices (data before metadata, request id / chunk index / valid length). Session
state (each layer's trailing `k-1` inputs) must survive between requests and be
cleared by reset. Two contract cases: 16/32/1043/chunk127 and
128/256/16384/chunk512.

## Reference cost model (what to remove)
`ReferencePipeline.step` runs every layer with
`joined = cat(history, chunk)` → `layer(joined)` = replicate-pad `k-1` →
conv → slice off `k-1` outputs → SiLU, then `.cpu().numpy()` per chunk.
Observations:
* pad+slice is an exact no-op once history is joined: a valid conv over
  `[history(k-1) | chunk]` already yields exactly `chunk` causal outputs.
  Only the first chunk of a session needs replicate padding of its first
  sample (materialised as a `k-1` history tail).
* The whole request is already available in the input ring (`(C,T)` is one
  frame), so per-chunk execution adds O(chunks) launches plus one device
  synchronisation per chunk for no semantic benefit.
* History is per layer and is the layer *input* tail, so a whole-segment pass
  per layer with `cat(history_i, value_i)` is exactly the concatenated-session
  network (causal, never reads future samples).

## Implemented optimisation (`worker.py`)
1. One GPU pass per request: for each layer `conv([history | value])` directly
   on the underlying `nn.Conv1d` (same weights, no pad/slice), SiLU in place.
   Histories stay on the GPU between requests; reset sets them to `None`.
2. Layer inputs are copied into preallocated GPU buffers (no per-chunk cats).
3. Input frame read as a shared-memory view (ring capacity is one frame and
   one request is in flight, so it cannot be overwritten before the GPU copy);
   result staged through one pinned buffer with a single `cuda.synchronize()`.
4. Output still published chunk-by-chunk, tail zero-padded and tagged with its
   valid length, data write strictly before the metadata write.
5. Control loop mirrors the reference level-channel semantics (1 start,
   3 reset, 2 terminate; only value changes are acknowledged), with `finally`
   unlink so termination and interrupted reception clean up all 7 objects.
6. Startup warmup under `inference_mode` removes cold-request kernel/allocator
   discovery cost before the `ready` handshake.

## IR evidence (`ir_graph.py`)
Original `flashrt.ir` graph: 3 EXPOSED ops, one `chunk_persistent` state object
per layer (`history_0..2`, the `k-1` trailing layer inputs), data edges
0→1→2. `validate()` passes; `find_pipeline_stages` = 3 stages (one per layer,
i.e. the only cross-device coupling would be the per-layer history);
`analyze_cross_chunk_dependencies` = 3 state groups, all layer pairs
cross-chunk independent. `SequentialExecutor` chunk-by-chunk run vs CPU
full-sequence oracle: max abs diff 5.2e-8, reset reproduces bitwise → PASS.
This validates that the state dependency is *inside* each layer only and that
whole-segment batching is a legal reordering on one device (single GPU).

## Local end-to-end evidence (`selftest.py`, six-request sequence)
Sequence: 3 requests in session 1 (continuation + identical input resubmitted
without reset), double reset on the level channel, 3 requests in session 2
(identical input after reset reproduces request 0 bitwise), then one more
request where only the first chunk is received before terminate (interrupted
receive). CPU full-sequence oracle, atol=3e-5/rtol=3e-4.

Measured (RTX 5060, warm requests 1..5, paired with research reference):
* small C16/H32/T1043/chunk127: candidate median wall 1.68 ms vs reference
  6.15 ms (~3.7×); candidate max chunk gap 0.05 ms vs reference 11.1 ms.
* large C128/H256/T16384/chunk512: candidate median 9.57 ms vs reference
  29.27 ms (~3.1×); candidate max chunk gap 0.6 ms vs reference 14.1 ms.
* cold first request: small 2.2 ms vs 160 ms; large 18 ms vs 184 ms.
* max |candidate − CPU oracle|: 8.2e-8 (small), 2.3e-7 (large); repeat after
  reset max abs diff 0.0. Cleanup: `closed` line, 0 lingering shm objects in
  every run including the interrupted receive.

## Trade-offs / remaining gaps
* Whole-request batching raises first-chunk latency to the cost of one full
  pass (~1–2 ms large) but removes per-chunk launch/sync costs and keeps every
  observed chunk gap far below the 20 ms budget; all outputs are still causal.
* Wall time now includes adapter-side shared-memory copies (input write, output
  read), so further backend-only gains are limited (~8 MB in + 8 MB out for the
  large case).
* Only one GPU is used; the IR's three stages are intentionally co-located
  because history is per-layer and the assignment forbids multi-GPU work.

## Addendum: final cadence smoothing and official evidence
The burst variant is kept as `worker_burst.py` (verified in verify-010 and
benchmarked in benchmark-011: it passed the rate gate at 200 req/s but the
50 req/s row had 4.7% over-budget gaps because the sweep counts the ~18.5 ms
idle time between a burst request and the next scheduled request as a chunk
gap).  The final `worker.py` spreads each request's chunk publications over an
adaptive window (`choose_spread`, <=4 ms, <= half of the observed request
period minus service), using `time.sleep(0)` deadlines because Windows
millisecond sleep granularity would overshoot.  Computation, ordering and
numerics are unchanged: official verify-013 still matches all six requests
(max abs diff <= 8.2e-8) and cleans up all 7 shared-memory objects.
Official paired benchmark-015 (small dev config, 1 s windows, 20 ms budget):
candidate passes rate and smoothness gates at 50/100/200 req/s with
over_budget_fraction 0.0 and highest_tested_passing_rate 200; the reference
passes 50/100 but its rate gate fails at 200 (highest 100), with smoothness
0.0 over-budget everywhere.  First-output median stays ~1.55-1.59 ms.
benchmark-014 was an earlier paired attempt in which the reference controller
stalled before launching its backend (empty backend dir/logs) and was killed at
180 s; the retry benchmark-015 is the valid paired evidence.  The official
sweep only exercises the 16/32/1043/127 config; the 128/256/16384/512 config
was verified against the CPU oracle locally (execute-009, max abs 2.3e-7,
candidate 9.57 ms vs reference 29.27 ms median pre-smoothing) but was not part
of the official sweep.
