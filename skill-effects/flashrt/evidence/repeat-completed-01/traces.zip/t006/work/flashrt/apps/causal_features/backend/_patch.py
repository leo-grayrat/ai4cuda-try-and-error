"""One-shot in-place tweak: make selftest defaults env-configurable so that
``workspace.execute`` (which passes no CLI arguments) can run the large-case
sweep and the reference comparison."""
from pathlib import Path

path = Path(__file__).resolve().parent / 'selftest.py'
text = path.read_text(encoding='utf-8')
edits = [
    ("parser.add_argument('--sizes', default='small',",
     "parser.add_argument('--sizes', default=os.environ.get('CF_SIZES', 'small'),"),
    ("parser.add_argument('--reference', action='store_true',",
     "parser.add_argument('--reference', action='store_true',\n"
     "                        default=bool(os.environ.get('CF_REFERENCE')),"),
    ("parser.add_argument('--no-oracle', action='store_true')",
     "parser.add_argument('--no-oracle', action='store_true',\n"
     "                        default=bool(os.environ.get('CF_NO_ORACLE')))"),
]
for old, new in edits:
    assert old in text, old
    text = text.replace(old, new)
path.write_text(text, encoding='utf-8')
print('patched', path)
