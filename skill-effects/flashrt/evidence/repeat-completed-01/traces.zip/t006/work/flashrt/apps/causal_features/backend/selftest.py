"""Local end-to-end harness for the optimized causal_features backend.

Launches a backend process (candidate worker and/or the research reference),
drives the *fixed* ``causal_features.adapter.FeatureAdapter`` protocol, compares
the six-request sequence with the CPU full-sequence oracle, checks the
shared-memory cleanup (including after an interrupted receive), and reports
per-request / per-chunk timings (including the maximum inter-chunk gap that
matters for the 20 ms chunk-gap budget).

Usage (from the repo root)::

    python flashrt/apps/causal_features/backend/selftest.py --sizes small,large --reference
    python flashrt/apps/causal_features/backend/selftest.py --sizes large --no-oracle
"""
import argparse
import json
import os
import queue
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

import numpy as np


def _bootstrap():
    here = Path(__file__).resolve()
    repo_root = here.parents[4]
    apps_dir = here.parents[2]
    for candidate in (str(repo_root), str(apps_dir)):
        if candidate not in sys.path:
            sys.path.insert(0, candidate)
    return repo_root


def _drain(stream, sink):
    try:
        for line in iter(stream.readline, ''):
            sink.put(line)
    finally:
        sink.put(None)


def _launch(cmd, env, cwd, ready_timeout):
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        cwd=str(cwd), env=env, text=True, bufsize=1,
    )
    out_q = queue.Queue()
    err_q = queue.Queue()
    threading.Thread(target=_drain, args=(proc.stdout, out_q), daemon=True).start()
    threading.Thread(target=_drain, args=(proc.stderr, err_q), daemon=True).start()
    deadline = time.monotonic() + ready_timeout
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            proc.kill()
            raise TimeoutError('Backend did not print ready')
        try:
            line = out_q.get(timeout=min(remaining, 0.5))
        except queue.Empty:
            if proc.poll() is not None:
                raise RuntimeError(
                    f'Backend died before ready:\n{"".join(_collect(err_q))}')
            continue
        if line is None:
            raise RuntimeError(
                f'Backend exited before ready:\n{"".join(_collect(err_q))}')
        stripped = line.strip()
        if stripped.startswith('{'):
            payload = json.loads(stripped)
            if payload.get('ready'):
                return proc, out_q, err_q


def _collect(q):
    lines = []
    while True:
        try:
            item = q.get_nowait()
        except queue.Empty:
            break
        if item is not None:
            lines.append(item)
    return lines


def _shm_names(config):
    prefix = config['prefix']
    names = [prefix + '__ctrl']
    for suffix in ('_input', '_output', '_metadata'):
        names.append(prefix + suffix + '__meta')
        names.append(prefix + suffix + '__tensor')
    return names


def _check_cleanup(config, timeout_s=15.0):
    from multiprocessing import shared_memory
    pending = set(_shm_names(config))
    deadline = time.monotonic() + timeout_s
    while pending and time.monotonic() < deadline:
        still = set()
        for name in pending:
            try:
                handle = shared_memory.SharedMemory(name=name, create=False)
            except FileNotFoundError:
                continue
            except Exception:
                still.add(name)
                continue
            handle.close()
            still.add(name)
        pending = still
        if pending:
            time.sleep(0.05)
    return sorted(pending)


def _make_requests(config, seed):
    c, t = int(config['channels']), int(config['length'])
    rng = np.random.default_rng(seed)
    a1 = rng.standard_normal((c, t), dtype=np.float32)
    a2 = rng.standard_normal((c, t), dtype=np.float32)
    a3 = rng.standard_normal((c, t), dtype=np.float32)
    a4 = rng.standard_normal((c, t), dtype=np.float32)
    a5 = rng.standard_normal((c, t), dtype=np.float32)
    session_one = [a1, a2, a2.copy()]     # continuation + repeated input
    session_two = [a1, a3, a4]            # reset then continuation
    ops = [('submit', f) for f in session_one]
    ops += [('reset', None), ('reset', None)]  # repeated reset on level channel
    ops += [('submit', f) for f in session_two]
    ops += [('interrupt', a5)]
    return ops, [session_one, session_two]


def _drive(config, ops, timeout_s=60.0):
    from causal_features.adapter import FeatureAdapter
    adapter = FeatureAdapter(config)
    records = []
    partial = None
    try:
        adapter.start()
        for kind, payload in ops:
            if kind == 'reset':
                adapter.reset()
                continue
            if kind == 'interrupt':
                request_id, _ = adapter.submit(payload)
                data, observed = adapter.receive(timeout_s=timeout_s)
                partial = {'request_id': request_id, 'chunks_consumed': 1,
                           'valid': int(data.shape[-1]), 'stamp': observed}
                break
            started = time.perf_counter_ns()
            request_id, published = adapter.submit(payload)
            chunks, stamps = [], []
            while True:
                data, observed = adapter.receive(timeout_s=timeout_s)
                stamps.append(observed)
                chunks.append(np.array(data, dtype=np.float32, copy=True))
                if adapter.pending is None:
                    break
            records.append({
                'request_id': request_id,
                'output': np.concatenate(chunks, axis=-1),
                'stamps': stamps,
                'submit_ns': started,
                'published_ns': published,
            })
        adapter.terminate()
    finally:
        adapter.close()
    return records, partial


def _oracle_segments(repository, config, sessions):
    from causal_features.model import full_sequence_oracle
    segments = []
    for session in sessions:
        joined = np.ascontiguousarray(np.concatenate(session, axis=-1))
        full = full_sequence_oracle(repository, config, joined)
        offset = 0
        for features in session:
            width = features.shape[-1]
            segments.append(full[:, offset:offset + width])
            offset += width
    return segments


def _summarize(records):
    walls, max_gaps = [], []
    for record in records:
        stamps = record['stamps']
        walls.append((stamps[-1] - record['submit_ns']) / 1e6)
        gaps = np.diff(np.asarray(stamps)) / 1e6
        max_gaps.append(float(gaps.max()) if gaps.size else 0.0)
    return {
        'requests': len(records),
        'chunks_per_request': len(records[0]['stamps']) if records else 0,
        'wall_ms': [round(v, 3) for v in walls],
        'median_wall_ms': round(float(np.median(walls)), 3) if walls else None,
        'max_chunk_gap_ms': round(max(max_gaps), 3) if max_gaps else None,
        'all_gaps_under_20ms': bool(max_gaps) and max(max_gaps) < 20.0,
    }


def _run_one(label, cmd, env, cwd, config, ops, sessions, repository,
             with_oracle):
    proc, out_q, err_q = _launch(cmd, env, cwd, ready_timeout=180)
    records, partial, error = [], None, None
    try:
        records, partial = _drive(config, ops)
    except Exception as exc:  # keep backend evidence before re-raising
        error = f'{type(exc).__name__}: {exc}'
    try:
        proc.wait(timeout=60)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
    time.sleep(0.2)
    lingering = _check_cleanup(config)
    stdout_tail = _collect(out_q)
    stderr_text = ''.join(_collect(err_q))
    result = {
        'label': label,
        'error': error,
        'returncode': proc.returncode,
        'closed_line': any('"closed"' in line for line in stdout_tail),
        'lingering_shm': lingering,
        'interrupted_receive': partial,
        'stderr': stderr_text.strip(),
        'timing': _summarize(records),
    }
    if error is not None:
        return result
    if with_oracle:
        expected = _oracle_segments(repository, config, sessions)
        atol, rtol = 3e-5, 3e-4
        max_abs, ok = 0.0, True
        for record, target in zip(records, expected):
            diff = float(np.max(np.abs(record['output'] - target)))
            max_abs = max(max_abs, diff)
            ok = ok and bool(np.allclose(record['output'], target,
                                         atol=atol, rtol=rtol))
        result['oracle'] = {
            'max_abs_error': max_abs,
            'allclose_atol_3e-5_rtol_3e-4': ok,
        }
        result['repeat_after_reset_max_abs'] = float(
            np.max(np.abs(records[3]['output'] - records[0]['output'])))
    return result


def _write_config(config, backend_dir):
    out_dir = backend_dir / 'configs'
    out_dir.mkdir(exist_ok=True)
    path = out_dir / (config['prefix'] + '.json')
    path.write_text(json.dumps(config, indent=2), encoding='utf-8')
    return path


def main():
    repository = _bootstrap()
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=repository)
    parser.add_argument('--sizes', default=os.environ.get('CF_SIZES', 'small'),
                        help='comma separated subset of small,large')
    parser.add_argument('--reference', action='store_true',
                        default=bool(os.environ.get('CF_REFERENCE')),
                        help='also benchmark the research reference backend')
    parser.add_argument('--no-oracle', action='store_true',
                        default=bool(os.environ.get('CF_NO_ORACLE')))
    parser.add_argument('--seed', type=int, default=2027)
    args = parser.parse_args()
    repository = args.repository.resolve()

    backend_dir = Path(__file__).resolve().parent
    app_dir = backend_dir.parent
    env = dict(os.environ)
    paths = [str(repository), str(app_dir.parent)]
    if env.get('PYTHONPATH'):
        paths.append(env['PYTHONPATH'])
    env['PYTHONPATH'] = os.pathsep.join(paths)

    configs = {
        'small': dict(device='cuda:0', channels=16, hidden=32, length=1043,
                      chunk=127, weight_seed=703),
        'large': dict(device='cuda:0', channels=128, hidden=256, length=16384,
                      chunk=512, weight_seed=703),
    }
    summaries = []
    for size in [s.strip() for s in args.sizes.split(',') if s.strip()]:
        base = configs[size]
        ops, sessions = _make_requests(base, args.seed)
        candidate = dict(base, prefix='cf_cand_' + uuid.uuid4().hex[:10])
        summaries.append(_run_one(
            f'candidate:{size}',
            [sys.executable, str(backend_dir / 'worker.py'),
             '--repository', str(repository),
             '--config', str(_write_config(candidate, backend_dir))],
            env, repository, candidate, ops, sessions, repository,
            not args.no_oracle))
        if args.reference:
            reference = dict(base, prefix='cf_ref_' + uuid.uuid4().hex[:10])
            summaries.append(_run_one(
                f'reference:{size}',
                [sys.executable, '-m', 'causal_features.reference',
                 '--repository', str(repository),
                 '--config', str(_write_config(reference, backend_dir))],
                env, repository, reference, ops, sessions, repository,
                not args.no_oracle))
    print(json.dumps(summaries, indent=2))
    failed = [s for s in summaries if s['error'] is not None
              or s['lingering_shm'] or not s['closed_line']]
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
