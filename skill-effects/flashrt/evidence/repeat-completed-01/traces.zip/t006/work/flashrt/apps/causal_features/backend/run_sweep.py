"""Convenience runner: paired candidate/reference sweep, both contract sizes.

``workspace.execute`` cannot pass CLI arguments, so this wrapper sets argv and
calls the selftest entry point.  Equivalent to::

    python selftest.py --sizes small,large --reference
"""
import sys

import selftest

if __name__ == '__main__':
    sys.argv = [sys.argv[0], '--sizes', 'small,large', '--reference']
    selftest.main()
