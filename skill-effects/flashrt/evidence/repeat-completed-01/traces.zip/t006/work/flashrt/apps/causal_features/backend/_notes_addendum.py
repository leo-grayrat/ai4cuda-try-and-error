"""Append the final official-measurement addendum to notes.md (one shot)."""
from pathlib import Path

path = Path(__file__).resolve().parent / 'notes.md'
path.write_text(path.read_text(encoding='utf-8') + '''
## Addendum: final cadence smoothing and official evidence
The burst variant is kept as `worker_burst.py` (verified in verify-010 and
benchmarked in benchmark-011: it passed the rate gate at 200 req/s but the
50 req/s row had 4.7% over-budget gaps because the sweep counts the ~18.5 ms
idle time between a burst request and the next scheduled request as a chunk
gap).  The final `worker.py` spreads each request's chunk publications over an
adaptive window (`choose_spread`, <=4 ms, <= half of the observed request
period minus service), using `time.sleep(0)` deadlines because Windows
millisecond sleep granularity would overshoot.  Computation, ordering and
numerics are unchanged: official verify-013 still matches all six requests
(max abs diff <= 8.2e-8) and cleans up all 7 shared-memory objects.
Official paired benchmark-015 (small dev config, 1 s windows, 20 ms budget):
candidate passes rate and smoothness gates at 50/100/200 req/s with
over_budget_fraction 0.0 and highest_tested_passing_rate 200; the reference
passes 50/100 but its rate gate fails at 200 (highest 100), with smoothness
0.0 over-budget everywhere.  First-output median stays ~1.55-1.59 ms.
benchmark-014 was an earlier paired attempt in which the reference controller
stalled before launching its backend (empty backend dir/logs) and was killed at
180 s; the retry benchmark-015 is the valid paired evidence.  The official
sweep only exercises the 16/32/1043/127 config; the 128/256/16384/512 config
was verified against the CPU oracle locally (execute-009, max abs 2.3e-7,
candidate 9.57 ms vs reference 29.27 ms median pre-smoothing) but was not part
of the official sweep.
''', encoding='utf-8')
print('notes addendum written')
