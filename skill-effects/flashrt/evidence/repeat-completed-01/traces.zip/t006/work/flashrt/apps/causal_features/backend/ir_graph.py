"""IR expression and validation of the causal_features state dependencies.

Uses only the original ``flashrt.ir`` tools.  The chunk-periodic graph has one
EXPOSED operator per causal convolution layer, each owning a ``chunk_persistent``
history state object (the ``k-1`` trailing *inputs* of that layer).  The data
edges layer0 -> layer1 -> layer2 are within-chunk; the history states create the
cross-chunk dependency chain.  ``SequentialExecutor`` executes this per-layer
state graph chunk by chunk and the result must equal the CPU full-sequence
oracle, so the state-dependency expression is validated numerically, not just
structurally.

Run: ``python backend/ir_graph.py [--repository ROOT]`` from the repo root or
the app directory.  Prints the IR summary plus PASS/FAIL evidence.
"""
import argparse
import json
import sys
from pathlib import Path


def _bootstrap():
    here = Path(__file__).resolve()
    repo_root = here.parents[4]
    apps_dir = here.parents[2]
    for candidate in (str(repo_root), str(apps_dir)):
        if candidate not in sys.path:
            sys.path.insert(0, candidate)
    return repo_root


import numpy as np
import torch
import torch.nn.functional as F

from causal_features.model import build_layers, full_sequence_oracle
from flashrt.ir import (
    IREdge,
    IRGraph,
    IROperator,
    OpType,
    SequentialExecutor,
    StateObject,
    StreamMode,
    TensorPort,
    analyze_cross_chunk_dependencies,
    find_pipeline_stages,
    summarize_graph,
)


class CausalConvLayerOp(IROperator):
    """One causal conv + SiLU layer with its own persistent input history."""

    def __init__(self, name, layer, state_name):
        history_len = int(layer._time_causal_padding[0])
        super().__init__(
            name=name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')],
            outputs=[TensorPort('y')],
            state_reads=[state_name],
            state_writes=[state_name],
            stream_mode=StreamMode.STREAMING,
            config={'history_len': history_len},
        )
        self.layer = layer
        self.state_name = state_name
        self.history_len = history_len

    @torch.inference_mode()
    def execute(self, inputs, context, state):
        del context
        value = inputs['x']
        if value.dim() == 2:
            value = value.unsqueeze(0)
        history = state.get(self.state_name)  # initialised to None on reset
        if history is None:
            history = value[:, :, :1].expand(-1, -1, self.history_len)
        joined = torch.cat([history, value], dim=-1)
        out = self.layer.conv(joined)
        state.set(self.state_name, joined[:, :, -self.history_len:].clone())
        return {'y': F.silu(out)}


def build_graph(repository, config, device='cpu'):
    layers = build_layers(repository, config, device)
    graph = IRGraph(name='causal_features')
    op_names = []
    for index, layer in enumerate(layers):
        state_name = f'history_{index}'
        graph.add_state(StateObject(
            name=state_name,
            description=f'causal conv layer {index} trailing input samples',
            scope='chunk_persistent',
        ))
        op_name = f'conv_layer_{index}'
        graph.add_operator(CausalConvLayerOp(op_name, layer, state_name))
        op_names.append(op_name)
    for src, dst in zip(op_names, op_names[1:]):
        graph.add_edge(IREdge(src_op=src, src_port='y', dst_op=dst, dst_port='x'))
    graph.external_inputs = [TensorPort('x')]
    graph.external_outputs = [TensorPort('y')]
    graph.chunk_ops = list(op_names)
    return graph, layers


@torch.inference_mode()
def _run_session(executor, features, config):
    names = [f'history_{i}' for i in range(3)]
    executor.init_state({name: None for name in names})
    pieces = []
    for position in range(0, int(config['length']), int(config['chunk'])):
        chunk = features[:, position:position + int(config['chunk'])]
        out = executor.run_chunk(
            {'x': torch.from_numpy(np.ascontiguousarray(chunk)).unsqueeze(0)})
        pieces.append(out['y'].squeeze(0).numpy())
    return np.concatenate(pieces, axis=-1)


def check(repository, config):
    graph, _layers = build_graph(repository, config, 'cpu')
    errors = graph.validate()
    executor = SequentialExecutor(graph)  # raises on invalid graph
    rng = np.random.default_rng(703)
    length = int(config['length'])
    features = rng.standard_normal(
        (int(config['channels']), length), dtype=np.float32)
    first = _run_session(executor, features, config)
    second = _run_session(executor, features, config)  # implicit reset
    oracle = full_sequence_oracle(repository, config, features)

    atol, rtol = 3e-5, 3e-4
    ok_ir = bool(np.allclose(first, oracle, atol=atol, rtol=rtol))
    ok_reset = bool(np.array_equal(first, second))
    max_abs = float(np.max(np.abs(first - oracle)))

    dep_info = analyze_cross_chunk_dependencies(graph)
    stages = find_pipeline_stages(graph)
    print(summarize_graph(graph))
    print('cross-chunk state groups:',
          json.dumps({k: sorted(v) for k, v in dep_info.state_groups.items()}))
    print('pipeline stages:', [s.operators for s in stages])
    print('structural validation errors:', errors)
    print('max |IR - CPU oracle|:', max_abs)
    print('IR matches oracle (atol=3e-5, rtol=3e-4):', ok_ir)
    print('reset reproduces first session bitwise:', ok_reset)
    passed = (not errors and ok_ir and ok_reset and len(stages) == 3
              and len(dep_info.state_groups) == 3)
    print('IR CHECK:', 'PASS' if passed else 'FAIL')
    return passed


def main():
    repository = _bootstrap()
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=repository)
    args = parser.parse_args()
    config = {
        'device': 'cpu',
        'channels': 16,
        'hidden': 32,
        'length': 1043,
        'chunk': 127,
        'weight_seed': 703,
        'prefix': 'cf_ir_check',
    }
    sys.exit(0 if check(args.repository.resolve(), config) else 1)


if __name__ == '__main__':
    main()
