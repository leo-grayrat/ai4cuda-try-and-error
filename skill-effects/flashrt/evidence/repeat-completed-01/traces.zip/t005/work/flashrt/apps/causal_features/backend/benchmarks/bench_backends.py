"""Paired reference/candidate measurement for causal_features.

Targets (defaults from the task): latency to first output, and maximum
sustainable output rate with the inter-chunk-gap distribution as the smoothness
side condition.  The app's natural chunk-period budget is 20 ms.

For each (size, backend, variant) we report, over N requests on one continuous
session (random inputs, no reset -- the harness only resets between sessions):
  * first-chunk latency (ms): t_first_chunk - t_input_published
  * inter-chunk gap (ms): median / p95 / fraction above the 20 ms budget
  * request completion (ms) and implied output rate n_chunks / completion
  * back-to-back offered load: chunks/s achieved when the consumer submits the
    next request immediately after draining the previous one (the queue never
    grows, so this is the achievable offered-load ceiling of the pair).
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "tests"))

import common  # noqa: E402

BUDGET_MS = 20.0
N_REQUESTS = 6
WARMUP = 2


def stats(values):
    arr = np.asarray(values, dtype=np.float64)
    if arr.size == 0:
        return {"median": float("nan"), "p95": float("nan"), "max": float("nan")}
    return {
        "median": float(np.median(arr)),
        "p95": float(np.percentile(arr, 95)),
        "max": float(arr.max()),
    }


def measure(kind, size_name, size, env=None, n=N_REQUESTS, warmup=WARMUP):
    cfg = common.make_config("cf_bench_%d" % np.random.default_rng().integers(1 << 30), size=size)
    n_chunks = common.chunk_count(cfg)
    backend = common.Backend(cfg, kind=kind, extra_env=env)
    label = f"{kind}/{size_name}/{cfg['channels']}x{cfg['hidden']}T{cfg['length']}c{cfg['chunk']}"
    try:
        lat, gaps, totals, chunk_counts = [], [], [], []
        for index in range(warmup + n):
            features = common.input_fixture(cfg["length"], cfg["channels"], 1000 + index)
            request_id, published = backend.submit(features)
            observed = []
            for _ in range(n_chunks):
                data, stamp = backend.adapter.receive(timeout_s=120)
                observed.append(stamp)
            end = time.perf_counter_ns()
            if index >= warmup:
                lat.append((observed[0] - published) / 1e6)
                gaps.extend((observed[i] - observed[i - 1]) / 1e6 for i in range(1, n_chunks))
                totals.append((end - published) / 1e6)
                chunk_counts.append(n_chunks)
        # offered-load ceiling: consume as fast as possible, no idle gap
        t0 = time.perf_counter_ns()
        emitted = 0
        for index in range(n):
            features = common.input_fixture(cfg["length"], cfg["channels"], 5000 + index)
            backend.submit(features)
            for _ in range(n_chunks):
                backend.adapter.receive(timeout_s=120)
            emitted += n_chunks
        elapsed_ms = (time.perf_counter_ns() - t0) / 1e6
        result = {
            "label": label,
            "kind": kind,
            "size": size_name,
            "env": env or {},
            "config": cfg,
            "chunks_per_request": n_chunks,
            "first_chunk_latency_ms": stats(lat),
            "chunk_gap_ms": stats(gaps),
            "gap_fraction_over_budget": float(np.mean(np.asarray(gaps) > BUDGET_MS)) if gaps else 0.0,
            "request_completion_ms": stats(totals),
            "completion_output_rate_chunks_s": float(np.median([c * 1e3 / t for c, t in zip(chunk_counts, totals)])),
            "implied_rate_from_median_gap_chunks_s": float(1e3 / np.median(gaps)) if gaps else float("nan"),
            "offered_load_ceiling_chunks_s": emitted * 1e3 / elapsed_ms,
            "reference_stderr_tail": "",
        }
        result["reference_stderr_tail"] = "\n".join(backend._err[-5:])
    finally:
        backend.close()
    print(f"{label}: first={result['first_chunk_latency_ms']['median']:.3f}/"
          f"{result['first_chunk_latency_ms']['p95']:.3f} ms, "
          f"gap={result['chunk_gap_ms']['median']:.3f}/{result['chunk_gap_ms']['p95']:.3f} ms "
          f"over20ms={result['gap_fraction_over_budget']:.3f}, "
          f"completion={result['request_completion_ms']['median']:.3f} ms, "
          f"rate={result['offered_load_ceiling_chunks_s']:.1f} chunks/s", flush=True)
    return result


def main():
    sizes = {"dev": common.SMALL, "large": common.DEV}
    results = []
    plan = [
        ("reference", None),
        ("candidate", {"CAUSAL_ENGINE_MODE": "bulk"}),
        ("candidate", {"CAUSAL_ENGINE_MODE": "chunked"}),
        ("candidate", {"CAUSAL_ENGINE_MODE": "eager"}),
    ]
    for size_name, size in sizes.items():
        for kind, env in plan:
            results.append(measure(kind, size_name, size, env=env))
    out_dir = HERE / "results"
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = out_dir / f"bench_{stamp}.json"
    payload = {
        "timestamp": stamp,
        "hardware": "RTX 5060 8GB laptop",
        "generated": {"budget_ms": BUDGET_MS, "n_requests": N_REQUESTS, "warmup": WARMUP},
        "results": results,
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print("wrote", path, flush=True)
    print(json.dumps({r["label"]: {"first_ms": r["first_chunk_latency_ms"]["median"],
                                   "gap_p95_ms": r["chunk_gap_ms"]["p95"],
                                   "rate_chunks_s": round(r["offered_load_ceiling_chunks_s"], 1)}
                      for r in results}, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
