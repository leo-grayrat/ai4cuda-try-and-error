"""Fix repo-root discovery in the IR harness (cwd is the repo root)."""
from pathlib import Path

path = Path(__file__).resolve().parent.parent / "ir" / "graph_builder.py"
src = path.read_text(encoding="utf-8")
old = '''    root = Path(__file__).resolve().parents[4]
    sys.path.insert(0, str(root / "flashrt" / "apps" / "causal_features" / "backend" / "tests"))'''
new = '''    root = Path.cwd()
    for candidate in Path(__file__).resolve().parents:
        if (candidate / "flashrt" / "apps" / "causal_features").is_dir():
            root = candidate
            break
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests"))'''
assert old in src
path.write_text(src.replace(old, new), encoding="utf-8")
print("patched", path)
