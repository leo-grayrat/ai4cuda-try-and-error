import pathlib, re
root = pathlib.Path('.')
pat = re.compile(r'backend-file|backend_file|run_local_reference|verify_local_ir|causal_features')
hits = []
for p in root.rglob('*'):
    if not p.is_file() or p.suffix not in {'.py', '.md', '.json', '.yaml', '.txt'}:
        continue
    if any(part in {'.git', 'node_modules', '__pycache__'} for part in p.parts):
        continue
    try:
        txt = p.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        continue
    for m in pat.finditer(txt):
        line = txt.count('\n', 0, m.start()) + 1
        hits.append(f'{p}:{line}: {m.group(0)}')
print(len(hits))
print('\n'.join(hits[:80]))
print('--- template backend ---')
t = pathlib.Path('flashrt/apps/_template')
print(sorted(str(x) for x in t.rglob('*')) if t.exists() else 'none')
