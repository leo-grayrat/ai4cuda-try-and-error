"""Final IR harness fix (drop unused external ports, tolerate analysis errors)
and immediately execute the harness in-process so one tool call finishes it."""
from __future__ import annotations

import importlib.util
from pathlib import Path

path = Path(__file__).resolve().parent.parent / "ir" / "graph_builder.py"
src = path.read_text(encoding="utf-8")

old_ports = '''    graph.external_inputs = [TensorPort("features", shape_hint=("C", "length"))]
    graph.external_outputs = [TensorPort("chunk", shape_hint=("C", "chunk"))]'''
new_ports = '''    # No external ports: the chunk enters through chunk_input (ctx.chunk) and
    # leaves through chunk_sink (ctx.output), so the executor needs no ext I/O.
    graph.external_inputs = []
    graph.external_outputs = []'''
assert old_ports in src
src = src.replace(old_ports, new_ports)

old_summary = '''    print("\\n=== model-level graph ===", flush=True)
    print(summarize_graph(model_graph), flush=True)
    print("=== worker-level graph ===", flush=True)
    print(summarize_graph(worker_graph), flush=True)'''
new_summary = '''    for label, graph in (("model", model_graph), ("worker", worker_graph)):
        print(f"\\n=== {label}-level graph ===", flush=True)
        try:
            print(summarize_graph(graph), flush=True)
        except Exception as exc:
            print(f"summarize_graph failed: {exc!r}", flush=True)'''
assert old_summary in src
src = src.replace(old_summary, new_summary)
path.write_text(src, encoding="utf-8")
print("patched", path, flush=True)

spec = importlib.util.spec_from_file_location("cf_ir_graph_builder", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
raise SystemExit(module.main())
