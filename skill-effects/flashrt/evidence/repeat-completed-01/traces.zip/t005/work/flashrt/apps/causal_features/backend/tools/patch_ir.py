"""Make the IR harness defensive and fix its chunk/request reassembly."""
from pathlib import Path

path = Path(__file__).resolve().parent.parent / "ir" / "graph_builder.py"
src = path.read_text(encoding="utf-8")

old_edge = '''        graph.add_edge(IREdge(previous, "y" if previous != "chunk_input" else "x",
                              layer.name, "x",
                              StreamingInfo(StreamingPattern.FIXED_RATIO,
                                            src_chunk_size=1, dst_chunk_size=1,
                                            description="one chunk in, one chunk out")))'''
new_edge = '''        try:
            streaming = StreamingInfo(StreamingPattern.FIXED_RATIO, src_chunk_size=1,
                                      dst_chunk_size=1,
                                      description="one chunk in, one chunk out")
        except Exception:  # older/newer StreamingPattern spellings
            streaming = None
        graph.add_edge(IREdge(previous, "y" if previous != "chunk_input" else "x",
                              layer.name, "x", streaming))'''
assert old_edge in src
src = src.replace(old_edge, new_edge)

start = src.index("def main():")
new_main = '''def main():
    root = Path(__file__).resolve().parents[4]
    sys.path.insert(0, str(root / "flashrt" / "apps" / "causal_features" / "backend" / "tests"))
    import common
    from causal_features.model import build_layers, full_sequence_oracle

    config = common.make_config("cf_ir", size=common.SMALL)
    layers = build_layers(root, config, "cuda")
    kernels = [int(layer.conv.weight.shape[-1]) for layer in layers]
    weights = [(layer.conv.weight.detach().contiguous(),
                layer.conv.bias.detach().contiguous()) for layer in layers]
    model_graph = build_model_graph(kernels, config["channels"])
    worker_graph = build_worker_graph(model_graph)
    for name, graph in (("model", model_graph), ("worker", worker_graph)):
        try:
            graph.validate()
            print(f"{name} graph structural validation: ok", flush=True)
        except Exception as exc:
            print(f"{name} graph structural validation: {exc!r}", flush=True)

    chunk = int(config["chunk"])
    a = common.input_fixture(config["length"], config["channels"], 11)
    b = common.input_fixture(config["length"], config["channels"], 22)
    executor = SequentialExecutor(model_graph)
    ctx = Context(weights, None)

    def run_session(requests):
        executor.init_state(_fresh_state(model_graph))
        assembled = []
        for request in requests:
            buf = np.zeros((config["channels"], config["length"]), dtype=np.float32)
            for start in range(0, config["length"], chunk):
                piece = request[:, start:start + chunk]
                ctx.chunk = torch.from_numpy(np.ascontiguousarray(piece)).unsqueeze(0).cuda()
                ctx.output = None
                executor.run_chunk({}, ctx)
                out = ctx.output[0].cpu().numpy()
                buf[:, start:start + piece.shape[-1]] = out[:, :piece.shape[-1]]
            assembled.append(buf)
        return np.concatenate(assembled, axis=-1)

    verdict = True
    expected = full_sequence_oracle(root, config, np.concatenate([a, b], axis=-1))
    got = run_session([a, b])
    ok = np.allclose(got, expected, atol=3e-5, rtol=3e-4)
    verdict &= ok
    print(f"IR two-request session (continuation) vs CPU oracle: {'ok' if ok else 'FAIL'} "
          f"max|err|={np.abs(got - expected).max():.3e}", flush=True)

    expected_a = full_sequence_oracle(root, config, a)
    got_a = run_session([a])
    ok_reset = np.allclose(got_a, expected_a, atol=3e-5, rtol=3e-4)
    verdict &= ok_reset
    print(f"IR after reset reproduces the first session: {'ok' if ok_reset else 'FAIL'} "
          f"max|err|={np.abs(got_a - expected_a).max():.3e}", flush=True)

    print("\\n=== model-level graph ===", flush=True)
    print(summarize_graph(model_graph), flush=True)
    print("=== worker-level graph ===", flush=True)
    print(summarize_graph(worker_graph), flush=True)
    for label, fn in (("cross-chunk dependencies", analyze_cross_chunk_dependencies),
                      ("pipeline stages", find_pipeline_stages),
                      ("streaming overlaps", find_streaming_overlaps)):
        try:
            print(f"{label}: {fn(model_graph)!r}", flush=True)
        except Exception as exc:
            print(f"{label}: {exc!r}", flush=True)
    print("PASS" if verdict else "FAIL", flush=True)
    return 0 if verdict else 1


if __name__ == "__main__":
    raise SystemExit(main())
'''
src = src[:start] + new_main
path.write_text(src, encoding="utf-8")
print("patched", path)
