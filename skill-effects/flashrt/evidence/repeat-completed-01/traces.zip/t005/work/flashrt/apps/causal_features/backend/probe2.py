import inspect
import flashrt.ir as ir
from flashrt.ir import graph as G, executor as E, ops_base as OB
for obj in [G.IRGraph.__init__, G.IRGraph.add_operator, G.IRGraph.add_edge, G.IRGraph.add_state,
            G.IRGraph.__init__, G.IROperator.__init__, G.IROperator.execute, G.IROperator.should_run,
            G.IREdge.__init__, G.StateObject.__init__, G.TensorPort.__init__,
            E.SequentialExecutor.__init__, E.SequentialExecutor.init_state, E.SequentialExecutor.run_preamble,
            E.SequentialExecutor.run_chunk, OB.ir_operator]:
    try:
        print(obj.__qualname__, inspect.signature(obj))
    except Exception as e:
        print(obj, 'ERR', e)
print('---graph attrs---')
print([n for n in dir(G.IRGraph) if not n.startswith('_')])
print('---exec attrs---')
print([n for n in dir(E.SequentialExecutor) if not n.startswith('_')])
print('---StreamingInfo---')
print(inspect.signature(G.StreamingInfo.__init__) if hasattr(G.StreamingInfo,'__init__') else G.StreamingInfo)
print('analysis', [n for n in dir(ir.analysis) if not n.startswith('_')])
for f in [ir.summarize_graph, ir.find_pipeline_stages, ir.analyze_cross_chunk_dependencies]:
    print(f.__name__, inspect.signature(f))
