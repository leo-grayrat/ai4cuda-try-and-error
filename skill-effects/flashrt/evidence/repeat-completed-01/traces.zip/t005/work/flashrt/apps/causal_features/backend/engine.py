"""Optimized engine for the fixed causal_features task.

Reference semantics (causal_features/model.py + reference.py), restated as an
exact per-layer state machine:

* each layer is ``CausalConv1d`` = ``conv1d(pad(x, (k-1, 0), mode="replicate"))``;
* the reference keeps, per layer, the last ``k-1`` *pre-activation inputs* and
  re-runs ``cat(history, chunk)`` through the layer, keeping the last ``L``
  outputs.  Because ``pad`` is replicate and the reference slices at
  ``history_len``, the operation is exactly a valid convolution over
  ``[last (k-1) inputs, chunk]`` where the missing session-start context is a
  replication of the sequence's first sample.

So a layer needs one persistent state object of shape ``(1, Cin, k-1)`` that
always holds "the last min(t, k-1) inputs, left-filled with x[0]".  Reset clears
it (``cold=True`` -> the first chunk rebuilds the fill from its own first
sample, which is what the reference's replicate padding does).

Deployment: the whole per-segment computation is captured once in a CUDA graph
(3 convs + 3 SiLU + history update + copies => one graph replay per segment
instead of ~12 Python-level kernel launches).  Two scheduling variants:

``bulk``    chunk 0 first (low latency to first output), then the remaining
            T-chunk samples as one long conv pass per layer (efficient: 3
            launches total for the whole suffix).  Default.
``chunked`` every chunk through its own captured graph (uniform cadence).
``eager``   no graphs; plain PyTorch per chunk (fallback / reference-shaped).

All device work is enqueued ahead of the host publish loop, so the GPU keeps
running while the host copies finished chunks into shared memory.
"""
from __future__ import annotations

import math
import os

import numpy as np
import torch
import torch.nn.functional as F

_KNOWN_MODES = ("bulk", "chunked", "eager")


class _Plan:
    """Static buffers + captured CUDA graph for one fixed segment length."""

    def __init__(self, engine, length: int, cold: bool):
        self.length = int(length)
        self.cold = bool(cold)
        dev = engine.device
        self.in_stage = torch.zeros(1, engine.channels, self.length, device=dev, dtype=torch.float32)
        self.in_stage_pin = torch.zeros(1, engine.channels, self.length, dtype=torch.float32, pin_memory=True)
        self.in_bufs = []
        for weight, _ in engine.weights:
            cin = int(weight.shape[1])
            k = int(weight.shape[-1])
            self.in_bufs.append(torch.zeros(1, cin, k - 1 + self.length, device=dev, dtype=torch.float32))
        self.out = torch.zeros(1, engine.channels, self.length, device=dev, dtype=torch.float32)
        self.graph = None

    def body(self, engine):
        """Capturable body: token-free of host syncs, reads engine.hist."""
        n = len(engine.weights)
        for index, (weight, bias) in enumerate(engine.weights):
            k = engine.kernels[index]
            pad = k - 1
            buf = self.in_bufs[index]
            if index == 0:
                # The chunk (or long suffix) enters through the pinned staging
                # buffer; later layers are fed by the previous layer's output.
                buf[:, :, pad:pad + self.length].copy_(self.in_stage)
            if self.cold:
                # Reference uses replicate padding at the sequence start: fill
                # the (k-1) history slots with the layer input's first sample.
                buf[:, :, :pad].copy_(buf[:, :, pad:pad + 1])
            else:
                buf[:, :, :pad].copy_(engine.hist[index])
            value = F.silu(F.conv1d(buf, weight, bias))
            # history = last k-1 entries of [history, chunk] (pre-activation).
            engine.hist[index].copy_(buf[:, :, buf.shape[-1] - pad:])
            if index + 1 < n:
                nxt = self.in_bufs[index + 1]
                nxt[:, :, nxt.shape[-1] - self.length:].copy_(value)
            else:
                self.out.copy_(value)


class CausalEngine:
    """Fixed three-layer causal conv stack, streaming over chunks."""

    def __init__(self, repository, config, mode: str | None = None):
        from causal_features.model import build_layers

        mode = (mode or os.environ.get("CAUSAL_ENGINE_MODE") or "bulk").strip().lower()
        self.mode = mode if mode in _KNOWN_MODES else "bulk"
        self.device = torch.device(config.get("device", "cuda"))
        self.channels = int(config["channels"])
        self.chunk = int(config["chunk"])
        self.length = int(config["length"])
        self.weight_seed = int(config.get("weight_seed", 703))
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cuda.matmul.allow_tf32 = False
        self.layers = build_layers(repository, config, self.device)
        self.weights = [
            (layer.conv.weight.detach().contiguous(), layer.conv.bias.detach().contiguous())
            for layer in self.layers
        ]
        self.kernels = [int(w.shape[-1]) for w, _ in self.weights]
        self.hist = [
            torch.zeros(1, int(w.shape[1]), int(w.shape[-1]) - 1, device=self.device, dtype=torch.float32)
            for w, _ in self.weights
        ]
        self.cold = True
        self.n_chunks = max(1, math.ceil(self.length / self.chunk))
        self.chunk_lengths = [
            min(self.chunk, self.length - i * self.chunk) for i in range(self.n_chunks)
        ]
        self.cuda = self.device.type == "cuda"
        self._use_graph = self.cuda and self.mode != "eager"
        self._plans: dict[tuple[int, bool], _Plan] = {}
        self._events: list[torch.cuda.Event] = []
        self._in_pins: list[torch.Tensor] = []
        self._out_pins: list[torch.Tensor] = []
        self._segments: list[dict] = []
        if self._use_graph:
            try:
                self._build()
            except Exception as exc:  # capture is an optimization, never a requirement
                print(f"graph capture disabled: {exc!r}", flush=True)
                self._use_graph = False
        if not self._use_graph:
            self._plans = {}
            self._segments = []
            self._events = []

    # ------------------------------------------------------------------ setup
    def _build(self):
        lengths = {self.chunk_lengths[0]}
        if self.mode == "chunked":
            lengths.update(self.chunk_lengths)
        else:
            if self.n_chunks > 1:
                lengths.add(self.length - self.chunk)
        for length in sorted(lengths):
            self._plans[(length, True)] = _Plan(self, length, True)
            self._plans[(length, False)] = _Plan(self, length, False)
        stream = torch.cuda.Stream()
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for plan in self._plans.values():
                for _ in range(2):
                    plan.body(self)
        torch.cuda.current_stream().wait_stream(stream)
        for plan in self._plans.values():
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                plan.body(self)
            plan.graph = graph
        torch.cuda.synchronize()
        # Captures polluted history; every session starts cold anyway.
        self.cold = True
        if self.mode == "chunked":
            offsets = []
            for i, length in enumerate(self.chunk_lengths):
                offsets.append((i * self.chunk, length, i, i))
            self._segments = [
                {"offset": off, "length": length, "first_chunk": a, "last_chunk": b}
                for off, length, a, b in offsets
            ]
        else:
            if self.n_chunks == 1:
                self._segments = [{"offset": 0, "length": self.chunk_lengths[0], "first_chunk": 0, "last_chunk": 0}]
            else:
                self._segments = [
                    {"offset": 0, "length": self.chunk, "first_chunk": 0, "last_chunk": 0},
                    {"offset": self.chunk, "length": self.length - self.chunk,
                     "first_chunk": 1, "last_chunk": self.n_chunks - 1},
                ]
        for seg in self._segments:
            length = seg["length"]
            seg["in_pin"] = torch.zeros(1, self.channels, length, dtype=torch.float32, pin_memory=True)
            seg["out_pin"] = torch.empty(self.channels, length, dtype=torch.float32, pin_memory=True)
            seg["event"] = torch.cuda.Event()
            self._events.append(seg["event"])

    # ------------------------------------------------------------------ reset
    def reset(self):
        self.cold = True

    # ------------------------------------------------------------- main entry
    @torch.inference_mode()
    def run_request(self, values, publish):
        """Consume one (C, T) sequence, publishing chunks in order.

        ``publish(chunk_index, valid_length, data)`` receives a host array of
        shape (C, valid_length) in increasing chunk order.
        """
        values = np.ascontiguousarray(values, dtype=np.float32)
        if values.shape != (self.channels, self.length):
            raise ValueError(f"input shape {values.shape} != {(self.channels, self.length)}")
        if self._use_graph:
            self._run_graph(values, publish)
        else:
            self._run_eager(values, publish)

    # ------------------------------------------------------------- graph path
    def _run_graph(self, values, publish):
        segments = self._segments
        plans = [self._plans[(seg["length"], self.cold if i == 0 else False)]
                 for i, seg in enumerate(segments)]
        main = torch.cuda.current_stream()

        def stage_and_launch(index):
            seg = segments[index]
            length = seg["length"]
            # pageable shared-memory input -> pinned staging -> device
            np.copyto(seg["in_pin"].numpy()[0, :, :length],
                      values[:, seg["offset"]:seg["offset"] + length])
            plans[index].in_stage.copy_(seg["in_pin"], non_blocking=True)
            plans[index].graph.replay()
            seg["out_pin"].copy_(plans[index].out[0], non_blocking=True)
            seg["event"].record()

        def publish_segment(seg):
            seg["event"].synchronize()
            pin = seg["out_pin"]
            for chunk_index in range(seg["first_chunk"], seg["last_chunk"] + 1):
                valid = self.chunk_lengths[chunk_index]
                start = (chunk_index - seg["first_chunk"]) * self.chunk
                publish(chunk_index, valid, pin[:, start:start + valid].numpy())

        # First segment alone, published immediately: latency to first output
        # is one chunk's convs plus one device->host copy, nothing else.
        stage_and_launch(0)
        self.cold = False
        publish_segment(segments[0])
        # Remaining segments, two deep so the GPU keeps running while the host
        # copies finished chunks into shared memory.
        pending = []
        for index in range(1, len(segments)):
            stage_and_launch(index)
            pending.append(segments[index])
            if len(pending) >= 2:
                publish_segment(pending.pop(0))
        for seg in pending:
            publish_segment(seg)

    # ------------------------------------------------------------- eager path
    def _run_eager(self, values, publish):
        x = torch.from_numpy(values).unsqueeze(0).to(self.device)
        cold = self.cold
        history = [None if cold else h.clone() for h in self.hist]
        for chunk_index, valid in enumerate(self.chunk_lengths):
            start = chunk_index * self.chunk
            value = x[:, :, start:start + valid]
            for index, (weight, bias) in enumerate(self.weights):
                k = self.kernels[index]
                pad = k - 1
                if history[index] is None:
                    joined = F.pad(value, (pad, 0), mode="replicate")
                else:
                    joined = torch.cat([history[index], value], dim=-1)
                result = F.silu(F.conv1d(joined, weight, bias))
                history[index] = joined[:, :, joined.shape[-1] - pad:].clone()
                value = result
            publish(chunk_index, valid, value[0].cpu().numpy())
        self.hist = history
        self.cold = False
