import ast, pathlib, torch
src = pathlib.Path('flashrt/layers/audio.py').read_text(encoding='utf-8')
node = next(n for n in ast.parse(src).body if isinstance(n, ast.ClassDef) and n.name == 'CausalConv1d')
print(ast.get_source_segment(src, node))
print('TORCH', torch.__version__, 'CUDA', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')
try:
    import triton; print('TRITON', triton.__version__)
except Exception as e:
    print('NO TRITON', repr(e))
import flashrt.ir as ir
print('IR exports', [n for n in dir(ir) if not n.startswith('_')])
print('cwd', pathlib.Path.cwd())
p = pathlib.Path('flashrt/apps/causal_features')
print(sorted(str(x) for x in p.rglob('*')))
ev = pathlib.Path('evidence')
print('evidence?', ev.exists(), sorted(str(x) for x in ev.glob('*'))[:30] if ev.exists() else '')
