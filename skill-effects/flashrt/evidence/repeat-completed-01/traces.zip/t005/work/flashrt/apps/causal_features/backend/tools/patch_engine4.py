"""Final scheduler: publish chunk 0 as soon as it lands (lowest latency to
first output), then feed the remaining segments with a 2-deep lookahead."""
from pathlib import Path

path = Path(__file__).resolve().parent.parent / "engine.py"
src = path.read_text(encoding="utf-8")
start = src.index("    def _run_graph(self, values, publish):")
end = src.index("    # ------------------------------------------------------------- eager path")
new = '''    def _run_graph(self, values, publish):
        segments = self._segments
        plans = [self._plans[(seg["length"], self.cold if i == 0 else False)]
                 for i, seg in enumerate(segments)]
        main = torch.cuda.current_stream()

        def stage_and_launch(index):
            seg = segments[index]
            length = seg["length"]
            # pageable shared-memory input -> pinned staging -> device
            np.copyto(seg["in_pin"].numpy()[0, :, :length],
                      values[:, seg["offset"]:seg["offset"] + length])
            plans[index].in_stage.copy_(seg["in_pin"], non_blocking=True)
            plans[index].graph.replay()
            seg["out_pin"].copy_(plans[index].out[0], non_blocking=True)
            seg["event"].record()

        def publish_segment(seg):
            seg["event"].synchronize()
            pin = seg["out_pin"]
            for chunk_index in range(seg["first_chunk"], seg["last_chunk"] + 1):
                valid = self.chunk_lengths[chunk_index]
                start = (chunk_index - seg["first_chunk"]) * self.chunk
                publish(chunk_index, valid, pin[:, start:start + valid].numpy())

        # First segment alone, published immediately: latency to first output
        # is one chunk's convs plus one device->host copy, nothing else.
        stage_and_launch(0)
        self.cold = False
        publish_segment(segments[0])
        # Remaining segments, two deep so the GPU keeps running while the host
        # copies finished chunks into shared memory.
        pending = []
        for index in range(1, len(segments)):
            stage_and_launch(index)
            pending.append(segments[index])
            if len(pending) >= 2:
                publish_segment(pending.pop(0))
        for seg in pending:
            publish_segment(seg)

'''
src = src[:start] + new + src[end:]
path.write_text(src, encoding="utf-8")
print("patched", path)
