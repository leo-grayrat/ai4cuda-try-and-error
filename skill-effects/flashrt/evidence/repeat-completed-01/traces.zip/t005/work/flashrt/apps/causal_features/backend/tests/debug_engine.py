import sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))
import common  # noqa

from causal_features.model import build_layers, full_sequence_oracle, ReferencePipeline
from engine import CausalEngine

cfg = common.make_config("cf_dbg")
root = common.repo_root()
x = common.input_fixture(cfg['length'], cfg['channels'], 11)
oracle = full_sequence_oracle(root, cfg, x)

def collect(publish_fn):
    rows = []
    engine.run_request(x, lambda i, v, d: rows.append((i, v, np.array(d, copy=True))))
    out = np.zeros((cfg['channels'], cfg['length']), dtype=np.float32)
    for i, v, d in rows:
        out[:, i * cfg['chunk']: i * cfg['chunk'] + v] = d[:, :v]
    return out

# (a) manual reference-shaped torch math on GPU
layers = build_layers(root, cfg, 'cuda')
@torch.inference_mode()
def manual():
    v = torch.from_numpy(x).unsqueeze(0).cuda()
    hist = [None] * 3
    rows = []
    for p in range(0, cfg['length'], cfg['chunk']):
        val = v[:, :, p:p + cfg['chunk']]
        for i, layer in enumerate(layers):
            joined = val if hist[i] is None else torch.cat([hist[i], val], -1)
            res = layer(joined)
            res = res[:, :, joined.shape[-1] - val.shape[-1]:]
            hist[i] = joined[:, :, joined.shape[-1] - layer._time_causal_padding[0]:].clone()
            val = F.silu(res)
        rows.append(val[0].cpu().numpy())
    return np.concatenate(rows, -1)

for label, arr in [('reference_pipeline_cuda', None), ('manual_torch', manual())]:
    if arr is None:
        pipe = ReferencePipeline(root, cfg)
        arr = np.concatenate([pipe.step(x[:, p:p + cfg['chunk']]) for p in range(0, cfg['length'], cfg['chunk'])], -1)
    err = np.abs(arr - oracle)
    print(f'{label}: max={err.max():.3e} mean={err.mean():.3e}')

for mode in ('eager', 'chunked', 'bulk'):
    engine = CausalEngine(root, cfg, mode=mode)
    out = collect(None)
    err = np.abs(out - oracle)
    print(f'engine[{mode}]: max={err.max():.3e} mean={err.mean():.3e} capture_graph={engine._use_graph}')
    if err.max() > 1e-4:
        for c in range(min(3, engine.n_chunks)):
            s, e = c * cfg['chunk'], min((c + 1) * cfg['chunk'], cfg['length'])
            block = err[:, s:e]
            print(f'   chunk {c}: max={block.max():.3e} first5={np.abs(block[:, :5]).max():.3e} rest={np.abs(block[:, 5:]).max():.3e}')
        print('   out[0,:6]=', out[0, :6])
        print('   orc[0,:6]=', oracle[0, :6])
