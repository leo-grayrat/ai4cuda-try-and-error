"""Shared harness utilities: launch a backend, drive it through the adapter."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import numpy as np

DEV = (128, 256, 16384, 512, 703, "cuda")  # C, H, T, chunk, seed, device
SMALL = (16, 32, 1043, 127, 703, "cuda")


def repo_root() -> Path:
    try:
        from flashrt.paths import repo_root as _root

        return Path(_root())
    except Exception:
        return Path(__file__).resolve().parents[4]


def backend_file() -> Path:
    return Path(__file__).resolve().parents[1] / "worker.py"


def make_config(prefix, size=SMALL, device=None):
    channels, hidden, length, chunk, seed, dev = size
    return {
        "prefix": prefix,
        "channels": int(channels),
        "hidden": int(hidden),
        "length": int(length),
        "chunk": int(chunk),
        "weight_seed": int(seed),
        "device": device or dev,
    }


def input_fixture(length, channels, seed):
    rng = np.random.default_rng(seed)
    return rng.standard_normal((channels, length), dtype=np.float32) * 0.5


class Backend:
    """One backend subprocess plus an adapter talking to it."""

    def __init__(self, config, kind="candidate", extra_env=None):
        from causal_features.adapter import FeatureAdapter

        self.config = dict(config)
        self.kind = kind
        self.root = repo_root()
        self.tmp = tempfile.mkdtemp(prefix="cf_cfg_")
        self.cfg_path = Path(self.tmp) / "config.json"
        self.cfg_path.write_text(json.dumps(self.config), encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONPATH"] = str(self.root) + os.pathsep + env.get("PYTHONPATH", "")
        env["CUDA_VISIBLE_DEVICES"] = env.get("CUDA_VISIBLE_DEVICES", "0")
        env.pop("CAUSAL_ENGINE_MODE", None)
        env.update(extra_env or {})
        if kind == "reference":
            cmd = [sys.executable, "-u", "-m", "causal_features.reference",
                   "--repository", str(self.root), "--config", str(self.cfg_path)]
        else:
            cmd = [sys.executable, "-u", str(backend_file()),
                   "--repository", str(self.root), "--config", str(self.cfg_path)]
        self.lines = []
        creation = 0
        if os.name == "nt":
            creation = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        else:
            creation = 0
        self.proc = subprocess.Popen(
            cmd, cwd=str(self.root), env=env, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, bufsize=1,
            creationflags=creation if os.name == "nt" else 0,
            preexec_fn=None if os.name == "nt" else os.setsid,
        )
        self._out = []
        self._err = []
        self._t = threading.Thread(target=self._drain, args=(self.proc.stdout, self._out), daemon=True)
        self._te = threading.Thread(target=self._drain, args=(self.proc.stderr, self._err), daemon=True)
        self._t.start()
        self._te.start()
        self._wait_ready()
        self.adapter = FeatureAdapter(self.config)
        self.adapter.start()

    def _drain(self, stream, sink):
        for line in stream:
            sink.append(line.rstrip("\n"))

    def _wait_ready(self, timeout=180.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            for line in list(self._out):
                if '"ready"' in line:
                    return
            if self.proc.poll() is not None:
                raise RuntimeError(f"backend exited early rc={self.proc.returncode} out={self._out} err={self._err}")
            time.sleep(0.01)
        raise TimeoutError(f"backend not ready: out={self._out} err={self._err}")

    def submit(self, features):
        return self.adapter.submit(features)

    def drain(self, request_chunks, timeout_s=120.0):
        out = []
        for _ in range(request_chunks):
            data, observed_ns = self.adapter.receive(timeout_s=timeout_s)
            out.append((data.copy(), observed_ns))
        return out

    def reset(self):
        self.adapter.reset()

    def close(self):
        try:
            self.adapter.terminate()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=20)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass
            try:
                self.proc.wait(timeout=10)
            except Exception:
                pass
        for thread in (self._t, self._te):
            thread.join(timeout=5)
        try:
            self.adapter.close()
        except Exception:
            pass
        if self.proc.poll() is None:
            raise RuntimeError("backend process is still alive after cleanup")


def chunk_count(config):
    return max(1, -(-int(config["length"]) // int(config["chunk"])))


def collect_session(backend, requests, config, label):
    """Drive one session (no reset in between) and return per-request outputs."""
    n = chunk_count(config)
    out = []
    for request_index, features in enumerate(requests):
        backend.submit(features)
        chunks = backend.drain(n)
        out.append(np.concatenate([c[0] for c in chunks], axis=-1)[:, : config["length"]])
        print(f"  {label} request {request_index}: {len(chunks)} chunks, "
              f"first-chunk {chunks[0][1]} ns", flush=True)
    return out


def oracle_for(repository, config, requests):
    """CPU full-sequence oracle over the concatenation of a session's inputs."""
    from causal_features.model import full_sequence_oracle

    joined = np.concatenate(requests, axis=-1)
    full = full_sequence_oracle(repository, config, joined)
    out, start = [], 0
    for features in requests:
        width = features.shape[-1]
        out.append(full[:, start:start + width])
        start += width
    return out
