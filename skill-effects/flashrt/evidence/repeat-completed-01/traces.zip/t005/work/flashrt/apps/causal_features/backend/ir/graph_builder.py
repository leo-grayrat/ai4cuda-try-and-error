"""Phase 1-2 IR: explicit causal-conv graph + executable validation.

Run from the repo root:  python flashrt/apps/causal_features/backend/ir/graph_builder.py

Graphs
------
``build_model_graph``  fine-grained per-layer graph of the exposed model:
    chunk_input -> causal_conv_0 -> causal_conv_1 -> causal_conv_2 -> chunk_sink
Each layer is an EXPOSED, STREAMING operator that reads and writes exactly one
``chunk_persistent`` StateObject (its pre-activation history).  The layer
operators' implementations are the reference math (replicate-pad + conv + SiLU,
history = last k-1 inputs), so executing the graph *is* executing the model.

``build_worker_graph``  the worker-level view: one COMPOSITE operator carrying
the model graph (1 chunk in -> 1 chunk out, rate preserving) plus the output
publication operator.

Validation (__main__) instantiates SequentialExecutor, runs real inputs chunk
by chunk over two consecutive sessions, and compares against the CPU
full-sequence oracle (causal_features.model.full_sequence_oracle) before
printing the analysis summary.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from flashrt.ir import (IREdge, IRGraph, IROperator, OpType, SequentialExecutor,
                        StateObject, StreamMode, StreamingInfo, StreamingPattern,
                        TensorPort, analyze_cross_chunk_dependencies,
                        find_pipeline_stages, find_streaming_overlaps,
                        summarize_graph)
from flashrt.ir import ir_operator


class CausalConvLayer(IROperator):
    """One CausalConv1d + SiLU with its own cross-chunk history state."""

    def __init__(self, index: int, kernel: int, channels_in: int):
        self.index = index
        self.kernel = kernel
        self.pad = kernel - 1
        self.state_name = f"layer{index}_history"
        super().__init__(
            name=f"causal_conv_{index}",
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("x", shape_hint=("C", "chunk"))],
            outputs=[TensorPort("y", shape_hint=("C", "chunk"))],
            state_reads=[self.state_name],
            state_writes=[self.state_name],
            stream_mode=StreamMode.STREAMING,
            config={"kernel": kernel, "channels_in": channels_in},
        )

    def execute(self, inputs, ctx, state):
        history = state.get(self.state_name)
        weight, bias = ctx.weights[self.index]
        x = inputs["x"]
        # Reference: CausalConv1d pads (k-1, 0) with mode="replicate" and the
        # caller drops the outputs that belong to the retained history.
        joined = F.pad(x, (self.pad, 0), mode="replicate") if history is None \
            else torch.cat([history, x], dim=-1)
        y = F.silu(F.conv1d(joined, weight, bias))
        state.set(self.state_name, joined[:, :, joined.shape[-1] - self.pad:].clone())
        return {"y": y}


@ir_operator(name="chunk_input", op_type=OpType.EXPOSED,
             outputs=[TensorPort("x", shape_hint=("C", "chunk"))],
             stream_mode=StreamMode.STREAMING)
def chunk_input(inputs, ctx, state):
    return {"x": ctx.chunk}


@ir_operator(name="chunk_sink", op_type=OpType.EXPOSED,
             inputs=[TensorPort("y", shape_hint=("C", "chunk"))],
             stream_mode=StreamMode.STREAMING)
def chunk_sink(inputs, ctx, state):
    ctx.output = inputs["y"]
    return {}


def build_model_graph(kernels, channels):
    graph = IRGraph(name="causal_features_model")
    graph.add_operator(chunk_input)
    layers = []
    previous = "chunk_input"
    current = channels
    for index, kernel in enumerate(kernels):
        layer = CausalConvLayer(index, kernel, current)
        graph.add_state(StateObject(layer.state_name,
                                    description=f"last {kernel - 1} pre-activation inputs "
                                                f"of layer {index} + SiLU state",
                                    scope="chunk_persistent"))
        graph.add_operator(layer)
        try:
            streaming = StreamingInfo(StreamingPattern.FIXED_RATIO, src_chunk_size=1,
                                      dst_chunk_size=1,
                                      description="one chunk in, one chunk out")
        except Exception:  # older/newer StreamingPattern spellings
            streaming = None
        graph.add_edge(IREdge(previous, "y" if previous != "chunk_input" else "x",
                              layer.name, "x", streaming))
        layers.append(layer)
        previous = layer.name
        current = int(graph.operators[layer.name].config["channels_in"])
    graph.add_operator(chunk_sink)
    graph.add_edge(IREdge(previous, "y", "chunk_sink", "y"))
    graph.external_inputs = [TensorPort("features", shape_hint=("C", "length"))]
    graph.external_outputs = [TensorPort("chunk", shape_hint=("C", "chunk"))]
    for op in ("chunk_input", *(layer.name for layer in layers), "chunk_sink"):
        graph.chunk_ops.append(op)
    return graph


def build_worker_graph(model_graph):
    worker = IRGraph(name="causal_features_worker")
    stack = IROperator(
        name="causal_stack",
        op_type=OpType.COMPOSITE,
        inputs=[TensorPort("features")],
        outputs=[TensorPort("chunk")],
        state_reads=[state.name for state in model_graph.state_objects.values()],
        state_writes=[state.name for state in model_graph.state_objects.values()],
        stream_mode=StreamMode.STREAMING,
        sub_graph=model_graph.name,
    )
    worker.add_operator(stack)
    for state in model_graph.state_objects.values():
        worker.add_state(state)
    worker.sub_graphs[model_graph.name] = model_graph
    worker.external_inputs = [TensorPort("features", shape_hint=("C", "length"))]
    worker.external_outputs = [TensorPort("chunk", shape_hint=("C", "chunk"))]
    worker.chunk_ops.append(stack.name)
    return worker


class Context:
    def __init__(self, weights, chunk):
        self.weights = weights
        self.chunk = chunk
        self.output = None


def _fresh_state(graph):
    return {state.name: None for state in graph.state_objects.values()}


def main():
    root = Path.cwd()
    for candidate in Path(__file__).resolve().parents:
        if (candidate / "flashrt" / "apps" / "causal_features").is_dir():
            root = candidate
            break
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests"))
    import common
    from causal_features.model import build_layers, full_sequence_oracle

    config = common.make_config("cf_ir", size=common.SMALL)
    layers = build_layers(root, config, "cuda")
    kernels = [int(layer.conv.weight.shape[-1]) for layer in layers]
    weights = [(layer.conv.weight.detach().contiguous(),
                layer.conv.bias.detach().contiguous()) for layer in layers]
    model_graph = build_model_graph(kernels, config["channels"])
    worker_graph = build_worker_graph(model_graph)
    for name, graph in (("model", model_graph), ("worker", worker_graph)):
        try:
            graph.validate()
            print(f"{name} graph structural validation: ok", flush=True)
        except Exception as exc:
            print(f"{name} graph structural validation: {exc!r}", flush=True)

    chunk = int(config["chunk"])
    a = common.input_fixture(config["length"], config["channels"], 11)
    b = common.input_fixture(config["length"], config["channels"], 22)
    executor = SequentialExecutor(model_graph)
    ctx = Context(weights, None)

    def run_session(requests):
        executor.init_state(_fresh_state(model_graph))
        assembled = []
        for request in requests:
            buf = np.zeros((config["channels"], config["length"]), dtype=np.float32)
            for start in range(0, config["length"], chunk):
                piece = request[:, start:start + chunk]
                ctx.chunk = torch.from_numpy(np.ascontiguousarray(piece)).unsqueeze(0).cuda()
                ctx.output = None
                executor.run_chunk({}, ctx)
                out = ctx.output[0].cpu().numpy()
                buf[:, start:start + piece.shape[-1]] = out[:, :piece.shape[-1]]
            assembled.append(buf)
        return np.concatenate(assembled, axis=-1)

    verdict = True
    expected = full_sequence_oracle(root, config, np.concatenate([a, b], axis=-1))
    got = run_session([a, b])
    ok = np.allclose(got, expected, atol=3e-5, rtol=3e-4)
    verdict &= ok
    print(f"IR two-request session (continuation) vs CPU oracle: {'ok' if ok else 'FAIL'} "
          f"max|err|={np.abs(got - expected).max():.3e}", flush=True)

    expected_a = full_sequence_oracle(root, config, a)
    got_a = run_session([a])
    ok_reset = np.allclose(got_a, expected_a, atol=3e-5, rtol=3e-4)
    verdict &= ok_reset
    print(f"IR after reset reproduces the first session: {'ok' if ok_reset else 'FAIL'} "
          f"max|err|={np.abs(got_a - expected_a).max():.3e}", flush=True)

    print("\n=== model-level graph ===", flush=True)
    print(summarize_graph(model_graph), flush=True)
    print("=== worker-level graph ===", flush=True)
    print(summarize_graph(worker_graph), flush=True)
    for label, fn in (("cross-chunk dependencies", analyze_cross_chunk_dependencies),
                      ("pipeline stages", find_pipeline_stages),
                      ("streaming overlaps", find_streaming_overlaps)):
        try:
            print(f"{label}: {fn(model_graph)!r}", flush=True)
        except Exception as exc:
            print(f"{label}: {exc!r}", flush=True)
    print("PASS" if verdict else "FAIL", flush=True)
    return 0 if verdict else 1


if __name__ == "__main__":
    raise SystemExit(main())
