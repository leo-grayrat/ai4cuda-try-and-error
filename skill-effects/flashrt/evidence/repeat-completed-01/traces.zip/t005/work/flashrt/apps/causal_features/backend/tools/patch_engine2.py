"""Replace _run_graph with a generic segment scheduler (bulk and chunked)."""
from pathlib import Path

path = Path(__file__).resolve().parent.parent / "engine.py"
src = path.read_text(encoding="utf-8")
start = src.index("    def _run_graph(self, values, publish):")
end = src.index("    def _launch(self, seg, plan, values, values_offset):")
new = '''    def _run_graph(self, values, publish):
        segments = self._segments
        cold = self.cold
        # Enqueue every segment first: the host publish loop below then runs
        # while the GPU is still working on later segments.
        for index, seg in enumerate(segments):
            plan = self._plans[(seg["length"], cold if index == 0 else False)]
            self._launch(seg, plan, values, seg["offset"])
            if index == 0:
                self.cold = False
        for seg in segments:
            seg["event"].synchronize()
            pin = seg["out_pin"]
            for chunk_index in range(seg["first_chunk"], seg["last_chunk"] + 1):
                valid = self.chunk_lengths[chunk_index]
                start = (chunk_index - seg["first_chunk"]) * self.chunk
                publish(chunk_index, valid, pin[:, start:start + valid].numpy())

'''
src = src[:start] + new + src[end:]
path.write_text(src, encoding="utf-8")
print("patched", path)
