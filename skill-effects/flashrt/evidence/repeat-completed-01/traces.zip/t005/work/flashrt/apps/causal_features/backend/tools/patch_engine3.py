"""Scheduler rework: host staging up front, lookahead enqueue, copy-stream
prefetch of later segments, publish as soon as each segment's event fires."""
from pathlib import Path

path = Path(__file__).resolve().parent.parent / "engine.py"
src = path.read_text(encoding="utf-8")
start = src.index("    def _run_graph(self, values, publish):")
end = src.index("    # ------------------------------------------------------------- eager path")
new = '''    def _run_graph(self, values, publish):
        segments = self._segments
        plans = [self._plans[(seg["length"], self.cold if i == 0 else False)]
                 for i, seg in enumerate(segments)]
        # 1. Host staging for every segment (pageable shared input -> pinned).
        #    Done before any GPU work so it is never on the latency path.
        for seg in segments:
            length = seg["length"]
            np.copyto(seg["in_pin"].numpy()[0, :, :length],
                      values[:, seg["offset"]:seg["offset"] + length])
        if getattr(self, "_copy_stream", None) is None:
            self._copy_stream = torch.cuda.Stream()
            self._prefetch = torch.cuda.Event()
        main = torch.cuda.current_stream()
        # 2. For the two-segment schedule the long suffix copy is prefetched on
        #    a side stream, overlapping it with the first chunk's convs.
        if len(segments) == 2:
            self._copy_stream.wait_stream(main)
            with torch.cuda.stream(self._copy_stream):
                plans[1].in_stage.copy_(segments[1]["in_pin"], non_blocking=True)
                self._prefetch.record(self._copy_stream)
        # 3. Enqueue with a bounded lookahead, publishing each segment as soon
        #    as its device->host copy has landed; the GPU stays busy meanwhile.
        enqueued = 0
        lookahead = 3
        for index, seg in enumerate(segments):
            while enqueued < len(segments) and enqueued < index + lookahead:
                plan = plans[enqueued]
                if enqueued == 1 and len(segments) == 2:
                    main.wait_event(self._prefetch)
                elif not (enqueued == 1 and len(segments) == 2):
                    plan.in_stage.copy_(segments[enqueued]["in_pin"], non_blocking=True)
                plan.graph.replay()
                seg_out = segments[enqueued]["out_pin"]
                seg_out.copy_(plan.out[0], non_blocking=True)
                segments[enqueued]["event"].record()
                enqueued += 1
            seg["event"].synchronize()
            pin = seg["out_pin"]
            for chunk_index in range(seg["first_chunk"], seg["last_chunk"] + 1):
                valid = self.chunk_lengths[chunk_index]
                start = (chunk_index - seg["first_chunk"]) * self.chunk
                publish(chunk_index, valid, pin[:, start:start + valid].numpy())
        self.cold = False

'''
src = src[:start] + new + src[end:]
path.write_text(src, encoding="utf-8")
print("patched", path)
