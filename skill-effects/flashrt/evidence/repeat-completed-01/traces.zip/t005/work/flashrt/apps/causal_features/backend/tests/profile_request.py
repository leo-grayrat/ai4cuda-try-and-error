"""Where does the large-case per-request time go?  Times each engine phase."""
import sys, time
from pathlib import Path
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))
import common  # noqa
from engine import CausalEngine

cfg = common.make_config("cf_prof", size=common.DEV)
root = common.repo_root()
x = common.input_fixture(cfg["length"], cfg["channels"], 11)
eng = CausalEngine(root, cfg, mode="bulk")
segments = eng._segments
plans = [eng._plans[(s["length"], False)] for s in segments]
main = torch.cuda.current_stream()


def t(fn, label, n=1):
    start = time.perf_counter()
    fn()
    torch.cuda.synchronize() if n == 0 else None
    return (time.perf_counter() - start) * 1e3


def once():
    marks = {}
    s = time.perf_counter()
    np.copyto(segments[0]["in_pin"].numpy()[0, :, :segments[0]["length"]],
              x[:, 0:segments[0]["length"]])
    marks["stage0_cpu"] = (time.perf_counter() - s) * 1e3
    s = time.perf_counter()
    np.copyto(segments[1]["in_pin"].numpy()[0, :, :segments[1]["length"]],
              x[:, segments[1]["offset"]:segments[1]["offset"] + segments[1]["length"]])
    marks["stage1_cpu"] = (time.perf_counter() - s) * 1e3
    s = time.perf_counter()
    plans[0].in_stage.copy_(segments[0]["in_pin"], non_blocking=True)
    plans[0].graph.replay()
    segments[0]["out_pin"].copy_(plans[0].out[0], non_blocking=True)
    segments[0]["event"].record()
    marks["launch0_enqueue"] = (time.perf_counter() - s) * 1e3
    s = time.perf_counter()
    segments[0]["event"].synchronize()
    marks["sync0"] = (time.perf_counter() - s) * 1e3
    s = time.perf_counter()
    plans[1].in_stage.copy_(segments[1]["in_pin"], non_blocking=True)
    plans[1].graph.replay()
    segments[1]["out_pin"].copy_(plans[1].out[0], non_blocking=True)
    segments[1]["event"].record()
    marks["launch1_enqueue"] = (time.perf_counter() - s) * 1e3
    s = time.perf_counter()
    segments[1]["event"].synchronize()
    marks["sync1"] = (time.perf_counter() - s) * 1e3
    return marks

for _ in range(3):
    once()
for _ in range(3):
    print({k: round(v, 3) for k, v in once().items()}, flush=True)

# raw conv cost of the bulk segment (3 convs over the suffix), measured alone
buf = plans[1].in_bufs
with torch.inference_mode():
    s = time.perf_counter()
    for _ in range(5):
        plans[1].graph.replay()
    torch.cuda.synchronize()
    print("bulk replay total ms", round((time.perf_counter() - s) * 1e3 / 5, 3), flush=True)
    s = time.perf_counter()
    for _ in range(5):
        plans[0].graph.replay()
    torch.cuda.synchronize()
    print("chunk replay total ms", round((time.perf_counter() - s) * 1e3 / 5, 3), flush=True)
    s = time.perf_counter()
    for _ in range(5):
        plans[1].out_pin.copy_(plans[1].out[0], non_blocking=True)
    torch.cuda.synchronize()
    print("bulk d2h ms", round((time.perf_counter() - s) * 1e3 / 5, 3), flush=True)
    s = time.perf_counter()
    for _ in range(5):
        plans[1].in_stage.copy_(segments[1]["in_pin"], non_blocking=True)
    torch.cuda.synchronize()
    print("bulk h2d ms", round((time.perf_counter() - s) * 1e3 / 5, 3), flush=True)
