"""Phase-4 deployment verification: reference vs candidate vs CPU oracle.

Six consecutive requests in one worker lifetime, mirroring the research
verification sequence:
  session A (no reset): A, B, A   (continuation, then repeated input)
  reset
  session B (after reset, same request the session started with): A, C, B
The last chunk of every request is a short tail chunk (1043 = 8*127 + 27).

Tolerance (from CONTRACT.zh.md): atol=3e-5, rtol=3e-4 -- float32 accumulation
order differences between the CPU full-sequence oracle and a CUDA conv
implementation; a different computation would exceed it by orders of magnitude.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import common  # noqa: E402

ATOL = 3e-5
RTOL = 3e-4


def close(a, b):
    err = np.abs(a - b)
    ok = np.allclose(a, b, atol=ATOL, rtol=RTOL)
    return ok, float(err.max()), float(err.mean())


def main():
    config = common.make_config("cf_verify_%d" % (np.random.default_rng().integers(1 << 30)))
    root = common.repo_root()
    a = common.input_fixture(config["length"], config["channels"], 11)
    b = common.input_fixture(config["length"], config["channels"], 22)
    c = common.input_fixture(config["length"], config["channels"], 33)
    sessions = [[a, b, a], [a, c, b]]
    oracle = [common.oracle_for(root, config, s) for s in sessions]

    results = {}
    for kind in ("reference", "candidate"):
        backend = common.Backend(config, kind=kind)
        try:
            outs = []
            for s_idx, requests in enumerate(sessions):
                if s_idx:
                    backend.reset()
                print(f"{kind}: session {s_idx}", flush=True)
                outs.append(common.collect_session(backend, requests, config, kind))
            results[kind] = outs
            stderr = "\n".join(backend._err)
            if stderr.strip():
                print(f"{kind} stderr:\n{stderr}", flush=True)
        finally:
            backend.close()

    verdict = True
    for kind in ("reference", "candidate"):
        for s_idx, session in enumerate(sessions):
            for r_idx, expected in enumerate(oracle[s_idx]):
                got = results[kind][s_idx][r_idx]
                ok, mx, mean = close(got, expected)
                verdict &= ok
                print(f"{kind} session {s_idx} request {r_idx} vs CPU oracle: "
                      f"{'ok' if ok else 'FAIL'} max|err|={mx:.3e} mean|err|={mean:.3e}", flush=True)
                print(f"  shape={got.shape} tail_chunk_valid={config['length'] - (common.chunk_count(config) - 1) * config['chunk']}", flush=True)
    # candidate vs reference on every request
    for s_idx in range(len(sessions)):
        for r_idx in range(3):
            ok, mx, mean = close(results["candidate"][s_idx][r_idx], results["reference"][s_idx][r_idx])
            verdict &= ok
            print(f"candidate vs reference s{s_idx} r{r_idx}: {'ok' if ok else 'FAIL'} "
                  f"max|err|={mx:.3e} mean|err|={mean:.3e}", flush=True)
    # reset reproducibility: request 0 and request 3 are the same input on a fresh session
    ok, mx, _ = close(results["candidate"][1][0], results["candidate"][0][0])
    verdict &= ok
    print(f"reset reproducibility (same input, fresh session): {'ok' if ok else 'FAIL'} max|err|={mx:.3e}", flush=True)
    # repeated input inside a session must differ (state really continued)
    differs = not np.allclose(results["candidate"][0][2], results["candidate"][0][0], atol=1e-6)
    verdict &= differs
    print(f"repeated input without reset continues state: {'ok' if differs else 'FAIL'}", flush=True)
    print("PASS" if verdict else "FAIL", flush=True)
    return 0 if verdict else 1


if __name__ == "__main__":
    raise SystemExit(main())
