"""Apply surgical fixes to engine.py (kept out of the runtime path)."""
from pathlib import Path

path = Path(__file__).resolve().parent.parent / "engine.py"
src = path.read_text(encoding="utf-8")

old_dead = """        for length in sorted({self.chunk_lengths[0], *self.chunk_lengths[1:]}):
            pass
        lengths = {self.chunk_lengths[0]}"""
new_dead = """        lengths = {self.chunk_lengths[0]}"""
assert old_dead in src
src = src.replace(old_dead, new_dead)

old_body = """            buf = self.in_bufs[index]
            if self.cold:"""
new_body = """            buf = self.in_bufs[index]
            if index == 0:
                # The chunk (or long suffix) enters through the pinned staging
                # buffer; later layers are fed by the previous layer's output.
                buf[:, :, pad:pad + self.length].copy_(self.in_stage)
            if self.cold:"""
assert old_body in src
src = src.replace(old_body, new_body)

old_d2h = """        torch.Tensor.copy_(seg["out_pin"], plan.out[0], non_blocking=True)"""
new_d2h = """        seg["out_pin"].copy_(plan.out[0], non_blocking=True)"""
assert old_d2h in src
src = src.replace(old_d2h, new_d2h)

old_hist = """        self.hist = [h if h is not None else t for h, t in zip(history, self.hist)]
        self.cold = False"""
new_hist = """        self.hist = history
        self.cold = False"""
assert old_hist in src
src = src.replace(old_hist, new_hist)

path.write_text(src, encoding="utf-8")
print("patched", path)
