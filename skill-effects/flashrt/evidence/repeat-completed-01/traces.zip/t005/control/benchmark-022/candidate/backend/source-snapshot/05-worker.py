"""Standalone optimized backend for the causal_features task.

Usage (same surface as the research reference):

    python -m causal_features.backend.worker --repository <repo> --config <json>

or, as the independent runner does it, ``--backend-file`` pointing at this
file.  Control opcodes and shared-memory layout are exactly those of
``causal_features/adapter.py`` / ``causal_features/reference.py``:
1 = start, 3 = reset, 2 = terminate, level-valued channel (repeat of the same
opcode is a no-op), output payload published before its metadata.
"""
import argparse
import json
import os
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=str, required=True)
    parser.add_argument("--config", type=str, required=True)
    args = parser.parse_args()

    repository = os.path.abspath(args.repository)
    here = os.path.dirname(os.path.abspath(__file__))
    for path in (repository, here):
        if path not in sys.path:
            sys.path.insert(0, path)

    import numpy as np
    import torch
    from causal_features.adapter import open_buffers, close_buffers
    from engine import CausalEngine

    config = json.loads(open(args.config, encoding="utf-8").read())
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    engine = CausalEngine(repository, config)
    buffers = open_buffers(config, create=True)
    channels, chunk = int(config["channels"]), int(config["chunk"])
    padded = np.zeros((channels, chunk), dtype=np.float32)
    consumed, last_command, active = 0, 0, False

    def publish(chunk_index, valid, data):
        padded[:, :valid] = data[:, :valid]
        if valid < chunk:
            padded[:, valid:] = 0.0
        buffers["output"].write(padded)
        buffers["metadata"].write(np.array([request_id, chunk_index, valid], dtype=np.int64))

    try:
        print(json.dumps({"ready": True, "device": config.get("device"), "mode": engine.mode}), flush=True)
        while True:
            opcode = buffers["control"].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers["control"].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    buffers["control"].commit()
                elif opcode == 1:
                    active = True
                    buffers["control"].commit()
                elif opcode != 0:
                    raise ValueError(f"Unknown control opcode: {opcode}")
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers["input"].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError("Input overwritten before processing")
            request_id = consumed
            consumed = next_cursor
            engine.run_request(features[0], publish)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({"closed": True}), flush=True)


if __name__ == "__main__":
    main()
