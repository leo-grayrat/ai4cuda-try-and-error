## 因果特征后台优化：观测报告（未完成）

### 本会话实际做了什么
我阅读了 CONTRACT.zh.md、model.py、reference.py、adapter.py，以及原库的 `SharedTensorBuffer`/`SharedControlBuffer`、`flashrt/ir` 的 graph/executor/analysis 源码。结论是：这是一个三层因果卷积（卷积核 5/5/3，每层接 SiLU，通道 C→H→H→C）的逐块流式特征处理任务，控制/共享内存协议由 adapter 固定，独立正确性判据是 CPU 全长序列 oracle（`model.full_sequence_oracle`）以及受保护的参考后端本身。

在工作区 `flashrt/apps/causal_features/backend/` 下我写了：
- `runtime.py`：共享的流式引擎，含四种计算策略（`chunked`、`full_alloc`、`full`=预分配历史环、`hybrid`=首块短链先发布+其余一次做完、`pipeline`=三层各用一条 CUDA stream），支持整批或逐块发布、可选的 CUDA Graph 捕获，以及忙等/休眠两种轮询；控制通道语义与 `reference.py` 完全一致（电平值、每个变化 commit 一次），因此 adapter 的 ack 记账匹配。
- `worker.py`：推荐的独立入口，接受 `--repository` / `--config`，选项为 hybrid + CUDA Graph + 忙等。
- `variants/` 下 10 个可执行变体：chunked_stream、full_alloc、full_prealloc、full_perchunk_publish、spin_sleep、full_graph、hybrid_first_chunk、pipeline_streams、cpu_placement、hybrid_graph。
- `ir/`：用原 IR 表达的三层算子图（每层一个 `hist_i` 为唯一 chunk_persistent 状态）与 worker 级图（含 length→chunk 的限速边）。
- `tests/drive_all.py`：通过 adapter 驱动参考/候选子进程的端到端脚本，含 ir/check/bench 三阶段；另有若干 `_patch*.py` 维护脚本（含 CPU 侧策略算术核对）。

### 已获得的证据
1. **IR 转换与验证通过**：`ir_validation_20261020.json` 记录 PASS，六请求契约场景（连续、重复输入不重置、重置复现、尾短块）对 CPU oracle 与对参考后端的最大绝对误差均在 1e-7 量级，远小于 atol=3e-5/rtol=3e-4。`notes/ir_summary.txt` 记录了分析结果：4 个流水级（layer0/1/2/emit）、6 组跨块独立对、2 条 1:1 限速流式边。
2. **参考后端基线（开发案例 C=16 H=32 T=1043 chunk=127，单张 RTX 5060）**：`bench_reference_20261020.json` 记录暖启动首块延迟中位数 1.317 ms、p95 1.678 ms，冷启动首次 192.98 ms；块间间隔中位 0.695 ms、p95 0.955 ms；20 ms 预算超标比例约 1%；无限速连续突发下请求速率约 145 请求/秒（约 1303 块/秒）。参考后端正确性 PASS（与 oracle 最大误差 7.45e-8，重置复现误差 0）。
3. **变体算术在 CPU 上核对正确**：`full`、`full_alloc`、`hybrid`、`chunked` 三种策略在三个连续请求下对 CPU 全长 oracle 的最差误差 8.9e-8，说明预分配历史环、首块短链、逐块回退三条路径的因果历史处理没有语义偏差。

### 实际失败
- **所有 CPU/GPU 候选变体在 GPU 上启动即挂起或超时**：`check`/`bench` 阶段每个变体的结果为 `TimeoutError('no metadata published')`，对应日志（如 `benchmarks/logs/full_alloc_candidate_*.log`）为空，说明子进程既未打印 ready、也未抛错，而是卡在引擎初始化/预热路径上（推测与 `prepare()` 里对未就绪状态的 GPU 调用或忙等轮询在 Windows 上的行为有关；CPU 策略核对不需要 `prepare`，故未暴露）。调试过程中我修掉了若干自身 bug（padding 计数 off-by-one、`torch.silu(out=)` 不存在、尾块切片长度、harness 中变量遮蔽与超时过长），但最后一次修复后仍未能让候选在 GPU 上跑通，且开发预算（请求/生成 token 上限）在此处耗尽。
- 另有一次 `execute` 因 `tests/_patch6.py` 整体超时被中断（exit -999），属于观测环境限制而非新信息。

### 未满足的要求（明确列出）
- **推荐的 `backend/worker.py` 既未通过独立正确性验证，也未完成基准测量**：没有任何 GPU 端候选的 correctness PASS 或 benchmark JSON 产物。按任务规则，这意味着候选变体全部处于未完成状态。
- 未对大规模案例（C=128 H=256 T=16384 chunk=512）做任何测量。
- 未建立正式的稳定负载扫描结果（只有参考后端一个无限速数据点）。
- 未产出 `README.md`、`notes/experiment_log.md`（含变体队列与逐变体记录）、配置与示例启动脚本等文档化产物；也未运行前置防拖延自检（禁语检索）。
- 未验证“无遗留进程/共享内存对象清理”，也未做 `workspace.verify` / `workspace.benchmark` 独立入口调用。
- 单 GPU 前提下不适用多 GPU 并行，但“模型内部并行”这一层只做了 CUDA stream 实验（未测），未取得任何证据。

### 诚实的结论
IR 转换与验证是本会话唯一完整达成的环节（有数值证据），参考基线也已测出；但候选后端在 GPU 上未能跑通，因此这项任务在“优化且可验证”的意义上**没有完成**。后续若继续，第一件事是定位候选 worker 在 `Engine.prepare()`/轮询循环中的挂起（用 nvidia-smi 与进程栈快照区分“慢”与“死锁”），而不是重写策略；随后按变体队列逐个补做 correctness 与 benchmark，才能判断 hybrid/首块先行、整请求单次卷积与 CUDA Graph 究竟能在 1.3 ms 基线上带来多少收益。