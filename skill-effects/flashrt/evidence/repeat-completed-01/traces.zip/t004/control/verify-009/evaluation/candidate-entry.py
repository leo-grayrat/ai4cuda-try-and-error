"""Standalone backend entry (recommended variant).

Launch surface (identical to the reference worker's two arguments):

    python flashrt/apps/causal_features/backend/worker.py \
        --repository <repo root> --config <config.json>

Variant: ``hybrid_first_chunk`` with CUDA-graph captured conv chains --
chunk 0 is published from a short 3-conv chain as soon as it is available,
the remaining chunks are produced by one longer chain and published in one
batch, and the polling loop busy-spins so the adapter's acknowledgement and
input publication are seen with ~microsecond delay.
"""
import sys
from pathlib import Path

_BACKEND = str(Path(__file__).resolve().parent)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)

from runtime import run_worker  # noqa: E402

OPTIONS = {
    "name": "recommended_hybrid_graph",
    "strategy": "hybrid",
    "publish": "batched",
    "graph": True,
    "poll_sleep": 0.0,
}

if __name__ == "__main__":
    run_worker(OPTIONS)
