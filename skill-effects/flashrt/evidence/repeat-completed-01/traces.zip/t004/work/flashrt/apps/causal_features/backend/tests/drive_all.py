"""End-to-end driver for the causal_features backend.

Stages (``--stage``):

  ir      Phase 2: run the IR graph through ``SequentialExecutor`` and compare
          it numerically with the *reference backend* driven through the
          unchanged adapter, then print ``summarize_graph`` analysis.
  check   Phase 4 correctness: every variant entry vs the CPU full-sequence
          oracle and vs the reference backend, over the six-request contract
          scenario (continuation, repeated input without reset, reset +
          reproduction, tail chunk).
  bench   Phase 4 measurement: latency-to-first-output distribution and a
          finite offered-load sweep (inter-chunk-gap distribution, 20 ms
          chunk-gap budget) for the reference and every variant.
  all     ir + check + bench.

Everything is driven through ``causal_features.adapter``; both the reference and
the candidate backends are launched as subprocesses and always terminated.
"""
import argparse
import json
import math
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import numpy as np


def find_repo():
    for parent in Path(__file__).resolve().parents:
        if (parent / "flashrt" / "apps" / "causal_features" / "adapter.py").exists():
            return parent
    raise SystemExit("repository root not found")


REPO = find_repo()
APPS = REPO / "flashrt" / "apps"
BACKEND = APPS / "causal_features" / "backend"
RESULTS = BACKEND / "benchmarks" / "results"
CONFIGS = BACKEND / "configs"
LOGS = BACKEND / "benchmarks" / "logs"
for d in (RESULTS, CONFIGS, LOGS):
    d.mkdir(parents=True, exist_ok=True)
sys.path[:0] = [str(REPO), str(APPS)]

from causal_features.adapter import FeatureAdapter  # noqa: E402
from causal_features.model import full_sequence_oracle  # noqa: E402

ATOL, RTOL = 3e-5, 3e-4  # contract tolerance: CPU vs GPU float32 summation order
DEV = dict(channels=16, hidden=32, length=1043, chunk=127, seed=703)
BIG = dict(channels=128, hidden=256, length=16384, chunk=512, seed=703)

VARIANTS = [
    ("chunked_stream", "variants/chunked_stream.py"),
    ("full_alloc", "variants/full_alloc.py"),
    ("full_prealloc", "variants/full_prealloc.py"),
    ("full_perchunk_publish", "variants/full_perchunk_publish.py"),
    ("spin_sleep", "variants/spin_sleep.py"),
    ("full_graph", "variants/full_graph.py"),
    ("hybrid_first_chunk", "variants/hybrid_first_chunk.py"),
    ("pipeline_streams", "variants/pipeline_streams.py"),
    ("cpu_placement", "variants/cpu_placement.py"),
    ("hybrid_graph", "variants/hybrid_graph.py"),
    ("recommended", "worker.py"),
]


def make_config(shapes, prefix, device="cuda"):
    return dict(channels=shapes["channels"], hidden=shapes["hidden"],
                length=shapes["length"], chunk=shapes["chunk"],
                weight_seed=shapes["seed"], device=device, prefix=prefix)


def write_config(cfg, name):
    path = CONFIGS / f"{name}_{cfg['prefix']}.json"
    path.write_text(json.dumps(cfg), encoding="utf-8")
    return path


def child_env():
    env = os.environ.copy()
    parts = [str(REPO), str(APPS)]
    if env.get("PYTHONPATH"):
        parts.append(env["PYTHONPATH"])
    env["PYTHONPATH"] = os.pathsep.join(parts)
    env["PYTHONUNBUFFERED"] = "1"
    return env


def launch(cmd, log_path):
    log = open(log_path, "w", encoding="utf-8")
    flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    proc = subprocess.Popen(cmd, cwd=str(REPO), env=child_env(),
                            stdout=subprocess.PIPE, stderr=log,
                            creationflags=flags)
    return proc, log


def wait_ready(proc, log_path):
    line = proc.stdout.readline()
    if not line:
        raise RuntimeError(f"backend exited before ready; log: {log_path}")
    return json.loads(line.decode("utf-8", "replace").strip())


def stop(proc, adapter, log):
    try:
        if adapter is not None:
            try:
                adapter.terminate()
            finally:
                adapter.close()
    finally:
        try:
            proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        log.close()


def start_backend(entry, cfg, tag):
    cfg_path = write_config(cfg, tag)
    log_path = LOGS / f"{tag}_{cfg['prefix']}.log"
    if entry == "reference":
        cmd = [sys.executable, "-m", "causal_features.reference",
               "--repository", str(REPO), "--config", str(cfg_path)]
    else:
        cmd = [sys.executable, str(BACKEND / entry),
               "--repository", str(REPO), "--config", str(cfg_path)]
    proc, log = launch(cmd, log_path)
    ready = wait_ready(proc, log_path)
    adapter = FeatureAdapter(cfg)
    return proc, log, adapter, ready, log_path


def drive(adapter, steps, fast_poll=True, timeout_s=20):
    adapter.start()
    out = []
    for step in steps:
        if step.get("reset"):
            adapter.reset()
        rid, t_in = adapter.submit(step["input"])
        chunks, obs = [], []
        while True:
            if fast_poll:
                meta = adapter.buffers["metadata"]
                deadline = time.perf_counter() + timeout_s
                while meta.num <= adapter.consumed:
                    if time.perf_counter() > deadline:
                        raise TimeoutError("no metadata published")
            chunk, t_obs = adapter.receive(timeout_s=timeout_s)
            chunks.append(chunk)
            obs.append(t_obs)
            if adapter.pending is None:
                break
        out.append(dict(request_id=rid, t_in=t_in, obs=obs, chunks=chunks,
                        data=np.concatenate(chunks, axis=-1)))
    return out


def session_expected(steps, shapes):
    """CPU full-sequence oracle per request, honouring session continuation."""
    hist = None
    expected = []
    for step in steps:
        if step.get("reset"):
            hist = None
        cur = step["input"] if hist is None else np.concatenate(
            [hist, step["input"]], axis=-1)
        cfg = dict(weight_seed=shapes["seed"], channels=shapes["channels"],
                   hidden=shapes["hidden"])
        y = full_sequence_oracle(str(REPO), cfg, cur)
        expected.append(y[:, -step["input"].shape[-1]:])
        hist = cur
    return expected


def compare(got, want):
    diff = np.abs(got - want)
    denom = np.maximum(np.abs(want), 1e-12)
    ok = bool(np.all(diff <= ATOL + RTOL * np.abs(want)))
    return ok, float(diff.max()), float((diff / denom).max())


def contract_scenario(shapes, seed=11):
    rng = np.random.default_rng(seed)
    c, t = shapes["channels"], shapes["length"]
    a = rng.standard_normal((c, t), dtype=np.float32)
    b = rng.standard_normal((c, t), dtype=np.float32) * 0.5
    cc = (np.arange(c * t, dtype=np.float32).reshape(c, t) % 97.0) / 97.0 - 0.5
    return [dict(reset=False, input=a),   # 0 fresh session
            dict(reset=False, input=b),   # 1 continuation
            dict(reset=False, input=a),   # 2 repeated input, still continuing
            dict(reset=True, input=a),    # 3 reset -> must reproduce request 0
            dict(reset=False, input=b),   # 4 continuation after the reset
            dict(reset=True, input=cc)]   # 5 reset + tail (short) chunk


# ---------------------------------------------------------------------------
# stages
# ---------------------------------------------------------------------------
def stage_ir(shapes):
    import torch
    import torch.nn.functional as F
    from flashrt.ir import SequentialExecutor, summarize_graph
    from causal_features.model import build_layers
    from causal_features.backend.ir.graph_builder import (ChunkContext,
                                                          build_model_graph,
                                                          build_worker_graph)

    cfg = dict(weight_seed=shapes["seed"], channels=shapes["channels"],
               hidden=shapes["hidden"])
    graph_cfg = dict(chunk=shapes["chunk"], length=shapes["length"])
    data_layers = build_layers(str(REPO), cfg, "cpu")

    def fresh_layers():
        return build_layers(str(REPO), cfg, "cpu")

    steps = contract_scenario(shapes)
    expected = session_expected(steps, shapes)

    # reference backend output through the adapter (the oracle of record)
    cfg_full = make_config(shapes, "ir" + uuid.uuid4().hex[:8])
    proc, log, adapter, ready, log_path = start_backend("reference", cfg_full,
                                                        "ir_reference")
    try:
        ref = drive(adapter, steps)
    finally:
        stop(proc, adapter, log)

    # executor run of the model graph
    (BACKEND / 'notes').mkdir(parents=True, exist_ok=True)
    graph = build_model_graph(graph_cfg, kernels=(5, 5, 3))
    worker_graph = build_worker_graph(graph_cfg, kernels=(5, 5, 3))
    print("worker_graph validate:", worker_graph.validate() or "OK",
          flush=True)
    executor = SequentialExecutor(graph)
    history = [None, None, None]
    executor.init_state({f"hist_{i}": None for i in range(3)})
    ctx = ChunkContext(fresh_layers(), shapes["chunk"], shapes["length"])
    per_request = []
    session_of = []
    for step in steps:
        if step.get("reset"):
            history = [None, None, None]
            executor.init_state({f"hist_{i}": None for i in range(3)})
            ctx = ChunkContext(fresh_layers(), shapes["chunk"], shapes["length"])
        ctx.collected = []
        frame = torch.from_numpy(step["input"]).unsqueeze(0)
        for j in range(0, shapes["length"], shapes["chunk"]):
            ctx.chunk_index = j // shapes["chunk"]
            executor.run_chunk({"x": frame[:, :, j:j + shapes["chunk"]]}, ctx)
        got = torch.cat([y for _, y in ctx.collected], dim=-1)[0].detach().numpy()
        per_request.append(got)
        session_of.append(ctx.collected[0][1].shape[-1])

    verdicts = []
    for idx, (cand, exp, run) in enumerate(zip(per_request, expected, ref)):
        ok_o, ma_o, mr_o = compare(cand, exp)
        ok_r, ma_r, mr_r = compare(cand, run["data"])
        verdicts.append((idx, ok_o and ok_r, ma_o, mr_o, ma_r, mr_r))
    print(f"IR validation (fixture: six-request contract scenario, "
          f"C={shapes['channels']} H={shapes['hidden']} T={shapes['length']} "
          f"chunk={shapes['chunk']})", flush=True)
    for idx, ok, ma_o, mr_o, ma_r, mr_r in verdicts:
        print(f"  request {idx}: oracle max_abs={ma_o:.3e} max_rel={mr_o:.3e} "
              f"| reference max_abs={ma_r:.3e} max_rel={mr_r:.3e} "
              f"{'OK' if ok else 'MISMATCH'}", flush=True)
    ir_pass = all(v[1] for v in verdicts)
    print(f"IR VALIDATION: {'PASS' if ir_pass else 'FAIL'} "
          f"(atol={ATOL}, rtol={RTOL})", flush=True)
    summary = summarize_graph(graph, op_latencies={
        "layer0_chunk": 6e-6, "layer1_chunk": 6e-6, "layer2_chunk": 6e-6,
        "emit_chunk": 3e-5})
    (BACKEND / "notes" / "ir_summary.txt").write_text(summary, encoding="utf-8")
    print(summary, flush=True)
    return ir_pass


def check_entry(entry, shapes, tag, print_only=False):
    steps = contract_scenario(shapes)
    expected = session_expected(steps, shapes)
    base = "chk" + uuid.uuid4().hex[:8]
    out = {}
    for kind, ent in (("reference", "reference"), ("candidate", entry)):
        cfg = make_config(shapes, f"{base}_{kind}")
        proc, log, adapter, ready, log_path = start_backend(ent, cfg, f"{tag}_{kind}")
        try:
            runs = drive(adapter, steps)
            out[kind] = dict(runs=runs, ready=ready, log=str(log_path))
        finally:
            stop(proc, adapter, log)
    ref = out["reference"]["runs"]
    cand = out["candidate"]["runs"]
    rows = []
    ok_all = True
    for idx, (c, e, r) in enumerate(zip(cand, expected, ref)):
        ok_o, ma_o, mr_o = compare(c["data"], e)
        ok_r, ma_r, mr_r = compare(c["data"], r["data"])
        ok = ok_o and ok_r
        ok_all = ok_all and ok
        rows.append(dict(request=idx, ok=ok, vs_oracle_max_abs=ma_o,
                         vs_oracle_max_rel=mr_o, vs_reference_max_abs=ma_r,
                         vs_reference_max_rel=mr_r, chunks=len(c["chunks"])))
    # reset must reproduce the first output bit-for-bit-ish
    repro = float(np.abs(cand[3]["data"] - cand[0]["data"]).max())
    print(f"[{tag}] correctness: {len(rows)} requests, "
          f"{'PASS' if ok_all else 'FAIL'} "
          f"(worst vs oracle {max(r['vs_oracle_max_abs'] for r in rows):.3e}, "
          f"worst vs reference {max(r['vs_reference_max_abs'] for r in rows):.3e}, "
          f"reset-reproduction {repro:.3e})", flush=True)
    return dict(verdict="PASS" if ok_all else "FAIL", requests=rows,
                reset_reproduce_max_abs=repro,
                reference_ready=out["reference"]["ready"],
                candidate_ready=out["candidate"]["ready"],
                reference_log=out["reference"]["log"],
                candidate_log=out["candidate"]["log"])


def bench_entry(entry, shapes, tag, n_lat=12, n_sweep=12,
                offered=(0.0, 0.005, 0.010, 0.020)):
    cfg = make_config(shapes, "ben" + uuid.uuid4().hex[:8])
    proc, log, adapter, ready, log_path = start_backend(entry, cfg, f"bench_{tag}")
    try:
        rng = np.random.default_rng(5)
        lat_steps = [dict(reset=(i == 0),
                          input=rng.standard_normal((shapes["channels"],
                                                     shapes["length"]),
                                                    dtype=np.float32))
                     for i in range(n_lat)]
        runs = drive(adapter, lat_steps)
        lat = [(r["obs"][0] - r["t_in"]) / 1e6 for r in runs]
        gaps = [(r["obs"][k + 1] - r["obs"][k]) / 1e6
                for r in runs for k in range(len(r["obs"]) - 1)]
        sweep = []
        for offer in offered:
            steps = [dict(reset=(i == 0),
                          input=rng.standard_normal((shapes["channels"],
                                                     shapes["length"]),
                                                    dtype=np.float32))
                     for i in range(n_sweep)]
            t0 = time.perf_counter()
            lat_s, gap_s = [], []
            for step in steps:
                if step.get("reset"):
                    adapter.reset()
                rid, t_in = adapter.submit(step["input"])
                obs = []
                while True:
                    meta = adapter.buffers["metadata"]
                    deadline = time.perf_counter() + 20
                    while meta.num <= adapter.consumed:
                        if time.perf_counter() > deadline:
                            raise TimeoutError("no metadata published")
                    chunk, t_obs = adapter.receive(timeout_s=20)
                    obs.append(t_obs)
                    if adapter.pending is None:
                        break
                lat_s.append((obs[0] - t_in) / 1e6)
                gap_s.extend((obs[k + 1] - obs[k]) / 1e6
                             for k in range(len(obs) - 1))
                if offer:
                    time.sleep(offer)
            span = (time.perf_counter() - t0) - offer * (n_sweep - 1)
            chunks = sum(math.ceil(shapes["length"] / shapes["chunk"])
                         for _ in steps)
            sweep.append(dict(offered_gap_s=offer,
                              request_rate=round(n_sweep / span, 2),
                              chunk_rate=round(chunks / span, 1),
                              lat_median=float(np.median(lat_s)),
                              lat_p95=float(np.percentile(lat_s, 95)),
                              gap_median=float(np.median(gap_s)),
                              gap_p95=float(np.percentile(gap_s, 95)),
                              gap_over_20ms=float(np.mean(np.array(gap_s) > 20.0))))
    finally:
        stop(proc, adapter, log)
    res = dict(variant=tag, entry=entry, shapes=shapes, ready=ready,
               log=str(log_path), device=str(ready.get("device")),
               latency_ms=dict(median=float(np.median(lat)),
                               p95=float(np.percentile(lat, 95)),
                               cold_first=lat[0],
                               warm_median=float(np.median(lat[1:])),
                               warm_p95=float(np.percentile(lat[1:], 95)),
                               samples=lat),
               gaps_ms=dict(median=float(np.median(gaps)),
                            p95=float(np.percentile(gaps, 95)),
                            over_20ms=float(np.mean(np.array(gaps) > 20.0))),
               sweep=sweep,
               max_request_rate=round(n_sweep / ((runs[-1]["t_in"] - runs[0]["t_in"]) / 1e9), 2))
    print(f"[{tag}] warm latency median={res['latency_ms']['warm_median']:.3f}ms "
          f"p95={res['latency_ms']['warm_p95']:.3f}ms cold={lat[0]:.3f}ms | "
          f"gap median={res['gaps_ms']['median']:.3f} p95={res['gaps_ms']['p95']:.3f} "
          f">20ms={res['gaps_ms']['over_20ms']:.2f} | "
          f"chunk_rate(offer=0)={sweep[0]['chunk_rate']} /s "
          f"req_rate={sweep[0]['request_rate']} /s", flush=True)
    return res


def save(name, payload):
    path = RESULTS / f"{name}_{time.strftime('%Y%m%d')}.json"
    path.write_text(json.dumps(payload, indent=1, default=float), encoding="utf-8")
    print(f"  -> {path}", flush=True)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="all")
    ap.add_argument("--only", default="")
    args = ap.parse_args()
    shapes = dict(DEV)
    report = {}
    if args.stage in ("ir", "all"):
        report["ir_pass"] = stage_ir(shapes)
        save("ir_validation", report["ir_pass"])
    entries = [v for v in VARIANTS if not args.only or v[0] in args.only.split(",")]
    if args.stage in ("check", "all"):
        for name, entry in [("reference", "reference")] + entries:
            try:
                res = check_entry(entry, shapes, name)
            except Exception as exc:
                print(f"[{name}] correctness ERROR: {exc!r}", flush=True)
                res = dict(verdict="ERROR", error=repr(exc))
            report.setdefault("correctness", {})[name] = res
            save(f"correctness_{name}", res)
    if args.stage in ("bench", "all"):
        for name, entry in [("reference", "reference")] + entries:
            try:
                res = bench_entry(entry, shapes, name)
            except Exception as exc:
                print(f"[{name}] benchmark ERROR: {exc!r}", flush=True)
                res = dict(variant=name, error=repr(exc))
            report.setdefault("benchmark", {})[name] = res
            save(f"bench_{name}", res)
    print(json.dumps({"stage": args.stage, "done": True}), flush=True)


if __name__ == "__main__":
    main()
