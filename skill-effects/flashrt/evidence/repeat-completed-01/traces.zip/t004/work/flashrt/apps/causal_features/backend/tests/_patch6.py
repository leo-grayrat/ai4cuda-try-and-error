"""Fix the short-tail staging slice in the chunked strategy, verify CPU
arithmetic for all strategies, then run GPU correctness and benchmark stages."""
import py_compile
import sys
from pathlib import Path

import numpy as np

B = Path(__file__).resolve().parents[1]
P = B / "runtime.py"
s = P.read_text(encoding="utf-8")
old = "self.cpu_chunk.copy_(cur[0, :, :v], non_blocking=True)"
assert old in s
P.write_text(s.replace(old, "self.cpu_chunk[:, :v].copy_(cur[0, :, :v], "
                              "non_blocking=True)"), encoding="utf-8")
py_compile.compile(str(P), doraise=True)
print("patched chunked tail", flush=True)

sys.path.insert(0, str(B))
sys.path.insert(0, str(B / "tests"))
from causal_features.model import full_sequence_oracle  # noqa: E402
from runtime import Engine  # noqa: E402

cfg = dict(weight_seed=703, channels=16, hidden=32, length=1043, chunk=127,
           device="cpu")
x = np.random.default_rng(3).standard_normal((16, 1043), dtype=np.float32)
for strategy in ("full", "full_alloc", "hybrid", "chunked"):
    eng = Engine(".", cfg, sys.modules["causal_features.model"], {
        "strategy": strategy, "force_device": "cpu", "prepare": False})
    worst = 0.0
    for repeat, data in enumerate((x, x * 0.5, x)):
        eng.handle(data, repeat, None)
        got = np.concatenate([eng.stage[j, :, :eng.meta[j, 2]]
                              for j in range(eng.nchunks)], axis=-1)
        exp = full_sequence_oracle(".", cfg, np.concatenate(
            [x, x * 0.5, x][:repeat + 1], axis=-1))[:, -1043:]
        worst = max(worst, float(np.abs(got - exp).max()))
    print(f"  {strategy}: worst max_abs = {worst:.3e}", flush=True)
    eng.reset()

import drive_all  # noqa: E402

for stage in ("check", "bench"):
    sys.argv = ["drive_all", "--stage", stage]
    drive_all.main()
