"""Chunk-streaming runtime shared by the causal_features deployment variants.

All variants honour the unchanged adapter contract in
``flashrt/apps/causal_features/adapter.py``:

  * one ``(C, T)`` float32 request frame on the input ring buffer per request,
  * ``ceil(T / chunk)`` output frames of shape ``(C, chunk)`` plus one
    ``int64`` metadata frame ``[request_id, chunk_index, valid]`` per chunk,
  * payload published strictly before its metadata,
  * control opcodes 1 = start, 3 = reset, 2 = terminate, level valued and
    acknowledged by exactly one ``commit()`` per observed *change* (identical
    semantics to ``reference.py``, so the adapter's ack accounting matches).

Only *how* the per-chunk convolution chain of ``causal_features.model`` is
executed and *when* its results are published changes.  The arithmetic is the
same causal conv + SiLU chain, so outputs must match the CPU full-sequence
oracle of ``model.full_sequence_oracle`` up to float32 accumulation-order noise.
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


def import_task_modules(repository):
    """Import the fixed adapter and computation spec.

    The controller supplies module paths; we additionally make the repository
    root and ``<repository>/flashrt/apps`` importable so the same worker also
    runs standalone from the repo root.
    """
    repo = Path(repository).resolve()
    for candidate in (repo, repo / "flashrt" / "apps"):
        p = str(candidate)
        if candidate.is_dir() and p not in sys.path:
            sys.path.insert(0, p)
    import causal_features.adapter as adapter_mod  # noqa: E402
    import causal_features.model as model_mod  # noqa: E402

    return adapter_mod, model_mod


class Chain:
    """Causal conv+SiLU chain over a *fixed* input length.

    Per layer ``i`` a buffer of ``kernel_i - 1 + length`` samples holds
    ``[last (kernel_i-1) samples of that layer's input stream][current input]``
    -- exactly the history ``ReferencePipeline.histories`` keeps.  A conv over
    that buffer with no extra padding yields precisely the ``length`` causal
    outputs the reference produces for the chunk, so no per-chunk re-slicing or
    ``torch.cat`` is needed on the hot path.
    """

    def __init__(self, engine, length):
        self.e = engine
        self.length = int(length)
        dev = engine.device
        self.buf = [
            torch.zeros(1, engine.in_ch[i], engine.kernel[i] + self.length,
                        device=dev, dtype=torch.float32)
            for i in range(engine.nlayers)
        ]
        self.x = torch.zeros(1, engine.channels, self.length, device=dev,
                             dtype=torch.float32)
        self.out = torch.zeros(1, engine.channels, self.length, device=dev,
                               dtype=torch.float32)
        self.graph = None
        self.cold = True

    def copy_history_from(self, other):
        """Hand the per-layer history over from ``other`` (same kernel sizes)."""
        for i in range(self.e.nlayers):
            k = self.e.kernel[i]
            if k > 0:
                self.buf[i][:, :, :k].copy_(other.buf[i][:, :, :k])
        self.cold = other.cold

    def _warm(self):
        """Kernel body for a warm session: the pad region already holds the
        history of the previous chunk/request."""
        e = self.e
        cur = self.x
        last = e.nlayers - 1
        for i in range(e.nlayers):
            k = e.kernel[i]
            buf = self.buf[i]
            buf[:, :, k:].copy_(cur)
            y = F.conv1d(buf, e.weight[i], e.bias[i])
            if k > 0:
                buf[:, :, :k].copy_(buf[:, :, self.length:self.length + k])
            if i == last:
                self.out.copy_(F.silu(y))
                cur = self.out
            else:
                cur = F.silu(y)
        return cur

    def _cold(self, x):
        """Fresh session: left-replicate padding of the first sample, as
        ``CausalConv1d.forward`` does when no history exists yet."""
        e = self.e
        cur = x
        for i in range(e.nlayers):
            k = e.kernel[i]
            xin = F.pad(cur, (k, 0), mode="replicate") if k > 0 else cur
            y = F.conv1d(xin, e.weight[i], e.bias[i])
            if k > 0:
                self.buf[i][:, :, :k].copy_(xin[:, :, -(k):])
            cur = F.silu(y)
        self.cold = False
        return cur

    def run(self, x):
        if self.cold:
            out = self._cold(x)
            self.cold = False
            return out
        if self.graph is not None:
            self.x.copy_(x)
            self.graph.replay()
            return self.out
        self.x.copy_(x)
        return self._warm()

    def capture(self):
        e = self.e
        if e.device.type != "cuda":
            return False
        saved = [self.buf[i][:, :, :e.kernel[i]].clone()
                 for i in range(e.nlayers) if e.kernel[i] > 1]
        saved_out, saved_x = self.out.clone(), self.x.clone()
        try:
            side = torch.cuda.Stream()
            side.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(side):
                for _ in range(2):
                    self._warm()
            torch.cuda.current_stream().wait_stream(side)
            g = torch.cuda.CUDAGraph()
            with torch.cuda.graph(g):
                self._warm()
            self.graph = g
        except Exception as exc:  # pragma: no cover - platform dependent
            print(json.dumps({"graph_capture_failed": repr(exc)}), file=sys.stderr,
                  flush=True)
            self.graph = None
        finally:
            idx = 0
            for i in range(e.nlayers):
                if e.kernel[i] > 1:
                    self.buf[i][:, :, :e.kernel[i]].copy_(saved[idx])
                    idx += 1
            self.out.copy_(saved_out)
            self.x.copy_(saved_x)
        return self.graph is not None


class Engine:
    """One worker-side engine: request framing, compute strategy, publishing."""

    def __init__(self, repository, config, model_mod, opts):
        self.opts = dict(opts)
        self.config = config
        self.channels = int(config["channels"])
        self.hidden = int(config["hidden"])
        self.length = int(config["length"])
        self.chunk = int(config["chunk"])
        self.nchunks = int(math.ceil(self.length / self.chunk))
        device = config.get("device", "cuda")
        if isinstance(device, int):
            device = f"cuda:{device}"
        self.device = torch.device(self.opts.get("force_device", device))
        self.strategy = self.opts.get("strategy", "hybrid")
        self.publish_mode = self.opts.get("publish", "batched")
        if self.nchunks == 1 and self.strategy in ("hybrid", "pipeline"):
            self.strategy = "full"

        layers = model_mod.build_layers(repository, config, self.device)
        self.kernel = [int(layer._time_causal_padding[0]) for layer in layers]
        self.weight = [layer.conv.weight.detach().contiguous() for layer in layers]
        self.bias = [layer.conv.bias.detach().contiguous() for layer in layers]
        self.nlayers = len(layers)
        self.in_ch = [int(w.shape[1]) for w in self.weight]
        del layers

        cuda = self.device.type == "cuda"
        self.cpu_in = torch.zeros(self.channels, self.length,
                                  dtype=torch.float32, pin_memory=cuda)
        self.host_in = self.cpu_in.numpy()
        self.stage = np.zeros((self.nchunks, self.channels, self.chunk),
                              dtype=np.float32)
        self.meta = np.zeros((self.nchunks, 3), dtype=np.int64)
        for j in range(self.nchunks):
            self.meta[j, 1] = j
            self.meta[j, 2] = min(self.chunk, self.length - j * self.chunk)

        if self.strategy == "full":
            self.chain_full = Chain(self, self.length)
            self.cpu_out = torch.zeros(self.channels, self.length,
                                       dtype=torch.float32, pin_memory=cuda)
        elif self.strategy == "hybrid":
            self.chain0 = Chain(self, self.chunk)
            self.chain_rest = Chain(self, self.length - self.chunk)
            self.cpu_out = torch.zeros(self.channels, self.length - self.chunk,
                                       dtype=torch.float32, pin_memory=cuda)
            self.cpu_first = torch.zeros(self.channels, self.chunk,
                                         dtype=torch.float32, pin_memory=cuda)
        else:
            self.cpu_out = torch.zeros(self.channels, self.length,
                                       dtype=torch.float32, pin_memory=cuda)
        self.host_out = self.cpu_out.numpy()

        if self.strategy == "pipeline":
            self.out_full = torch.zeros(1, self.channels, self.length,
                                        device=self.device, dtype=torch.float32)
            self.streams = [torch.cuda.Stream() for _ in range(self.nlayers)]
            self.events = [[torch.cuda.Event() for _ in range(self.nchunks)]
                           for _ in range(self.nlayers)]
        if self.strategy == "chunked":
            self.cpu_chunk = torch.zeros(self.channels, self.chunk,
                                         dtype=torch.float32, pin_memory=cuda)
            self.host_chunk = self.cpu_chunk.numpy()

        self.hist = [None] * self.nlayers
        if self.opts.get("prepare", True):
            self.prepare()

    # -- session / host staging -------------------------------------------
    def reset(self):
        self.hist = [None] * self.nlayers
        for name in ("chain_full", "chain0", "chain_rest"):
            chain = getattr(self, name, None)
            if chain is not None:
                chain.cold = True

    def to_gpu(self, feats):
        if self.device.type == "cpu":
            return torch.from_numpy(np.ascontiguousarray(feats)).unsqueeze(0)
        np.copyto(self.host_in, feats)
        x = torch.empty(1, self.channels, self.length, device=self.device,
                        dtype=torch.float32)
        x.copy_(self.cpu_in, non_blocking=True)
        return x

    def sync(self):
        if self.device.type == "cuda":
            torch.cuda.current_stream().synchronize()

    # -- reference-equivalent chunk step ----------------------------------
    def layer_step(self, i, x):
        k = self.kernel[i]
        hist = self.hist[i]
        if hist is None:
            xin = F.pad(x, (k, 0), mode="replicate") if k > 0 else x
        else:
            xin = torch.cat([hist, x], dim=-1)
        y = F.conv1d(xin, self.weight[i], self.bias[i])
        self.hist[i] = xin[:, :, -(k):].clone() if k > 0 else None
        return F.silu(y)

    # -- staging / publishing ---------------------------------------------
    def _stage(self, host, request_id, j0, j1):
        """Copy host columns for chunks [j0, j1) into the output frames."""
        for j in range(j0, j1):
            p = (j - j0) * self.chunk
            v = min(self.chunk, self.length - j * self.chunk)
            np.copyto(self.stage[j, :, :v], host[:, p:p + v])
            self.meta[j, 0] = request_id

    def _write(self, buffers, j0, j1):
        """Payload first, then metadata, for the staged frames [j0, j1)."""
        if buffers is None or j1 <= j0:
            return
        n = j1 - j0
        payload = self.stage[j0:j1] if n > 1 else self.stage[j0]
        metadata = self.meta[j0:j1] if n > 1 else self.meta[j0]
        buffers["output"].write(payload)
        buffers["metadata"].write(metadata)

    # -- strategies --------------------------------------------------------
    def handle(self, feats, request_id, buffers):
        return getattr(self, "_handle_" + self.strategy)(feats, request_id, buffers)

    def _handle_full(self, feats, request_id, buffers):
        x = self.to_gpu(feats)
        out = self.chain_full.run(x)
        self.cpu_out.copy_(out[0], non_blocking=True)
        self.sync()
        if self.publish_mode == "batched":
            self._stage(self.host_out, request_id, 0, self.nchunks)
            self._write(buffers, 0, self.nchunks)
        else:
            for j in range(self.nchunks):
                self._stage(self.host_out, request_id, j, j + 1)
                self._write(buffers, j, j + 1)

    def _handle_full_alloc(self, feats, request_id, buffers):
        cur = self.to_gpu(feats)
        for i in range(self.nlayers):
            k = self.kernel[i]
            hist = self.hist[i]
            if hist is None:
                xin = F.pad(cur, (k, 0), mode="replicate") if k > 0 else cur
            else:
                xin = torch.cat([hist, cur], dim=-1)
            y = F.conv1d(xin, self.weight[i], self.bias[i])
            self.hist[i] = xin[:, :, -(k):].clone() if k > 0 else None
            cur = F.silu(y)
        self.cpu_out.copy_(cur[0], non_blocking=True)
        self.sync()
        self._stage(self.host_out, request_id, 0, self.nchunks)
        self._write(buffers, 0, self.nchunks)

    def _handle_hybrid(self, feats, request_id, buffers):
        x = self.to_gpu(feats)
        # Cross-request continuation: the end-of-request history lives in the
        # remainder chain, chunk 0 must start from it.
        if not self.chain0.cold:
            self.chain0.copy_history_from(self.chain_rest)
        first = self.chain0.run(x[:, :, :self.chunk])
        self.cpu_first.copy_(first[0], non_blocking=True)
        self.sync()
        self._stage(self.cpu_first.numpy(), request_id, 0, 1)
        self._write(buffers, 0, 1)
        self.chain_rest.copy_history_from(self.chain0)
        rest = self.chain_rest.run(x[:, :, self.chunk:])
        self.cpu_out.copy_(rest[0], non_blocking=True)
        self.sync()
        self._stage(self.host_out, request_id, 1, self.nchunks)
        self._write(buffers, 1, self.nchunks)

    def _handle_chunked(self, feats, request_id, buffers):
        x = self.to_gpu(feats)
        for j in range(self.nchunks):
            p = j * self.chunk
            v = min(self.chunk, self.length - p)
            cur = x[:, :, p:p + v]
            for i in range(self.nlayers):
                cur = self.layer_step(i, cur)
            self.cpu_chunk[:, :v].copy_(cur[0, :, :v], non_blocking=True)
            self.sync()
            np.copyto(self.stage[j, :, :v], self.host_chunk[:, :v])
            self.meta[j, 0] = request_id
            self._write(buffers, j, j + 1)

    def _handle_pipeline(self, feats, request_id, buffers):
        x = self.to_gpu(feats)
        main = torch.cuda.current_stream()
        self.streams[0].wait_stream(main)
        for j in range(self.nchunks):
            p = j * self.chunk
            v = min(self.chunk, self.length - p)
            cur = x[:, :, p:p + v]
            for i in range(self.nlayers):
                with torch.cuda.stream(self.streams[i]):
                    if j > 0:
                        self.streams[i].wait_event(self.events[i][j - 1])
                    if i > 0:
                        self.streams[i].wait_event(self.events[i - 1][j])
                    cur = self.layer_step(i, cur)
                    self.events[i][j].record(self.streams[i])
            with torch.cuda.stream(self.streams[self.nlayers - 1]):
                self.out_full[:, :, p:p + v].copy_(cur)
        main.wait_stream(self.streams[self.nlayers - 1])
        self.cpu_out.copy_(self.out_full[0], non_blocking=True)
        self.sync()
        self._stage(self.host_out, request_id, 0, self.nchunks)
        self._write(buffers, 0, self.nchunks)

    # -- warm-up ------------------------------------------------------------
    def prepare(self):
        dummy = np.zeros((self.channels, self.length), dtype=np.float32)
        for _ in range(2):
            self.handle(dummy, -1, None)
        self.reset()
        want_graph = bool(self.opts.get("graph", False))
        for name in ("chain_full", "chain0", "chain_rest"):
            chain = getattr(self, name, None)
            if chain is not None and want_graph:
                chain.capture()
        self.handle(dummy, -1, None)  # hot plans + hot graphs
        self.reset()


def run_worker(opts):
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()

    adapter_mod, model_mod = import_task_modules(args.repository)
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    opts = dict(opts)
    opts.update(config.get("backend_opts") or {})

    torch.set_num_threads(int(opts.get("threads", 2)))
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    engine = Engine(args.repository, config, model_mod, opts)
    buffers = adapter_mod.open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    ctrl = buffers["control"]._arr
    in_num = buffers["input"].num_arr
    poll_sleep = float(opts.get("poll_sleep", 0.0))
    try:
        print(json.dumps({"ready": True, "device": str(engine.device),
                          "variant": opts.get("name", ""),
                          "strategy": engine.strategy,
                          "publish": engine.publish_mode,
                          "graph": [bool(getattr(engine, n).graph)
                                    for n in ("chain_full", "chain0", "chain_rest")
                                    if getattr(engine, n, None) is not None]}),
              flush=True)
        while True:
            while int(ctrl[0]) == last_command:
                if poll_sleep:
                    time.sleep(poll_sleep)
            opcode = int(ctrl[0])
            last_command = opcode
            if opcode == 2:
                buffers["control"].commit()
                break
            if opcode == 3:
                engine.reset()
                active = False
                buffers["control"].commit()
            elif opcode == 1:
                active = True
                buffers["control"].commit()
            elif opcode != 0:
                raise ValueError(f"Unknown control opcode: {opcode}")
            if not active:
                continue
            # Wait for the request frame while still watching control, so a
            # reset sent between requests is always acknowledged.
            while True:
                if int(ctrl[0]) != last_command:
                    break
                if int(in_num[0]) > consumed:
                    break
                if poll_sleep:
                    time.sleep(poll_sleep)
            if int(ctrl[0]) != last_command:
                continue
            next_cursor, features = buffers["input"].read(consumed, 1)
            if features is None:
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError("Input overwritten before processing")
            request_id = consumed
            consumed = next_cursor
            engine.handle(features[0], request_id, buffers)
    finally:
        adapter_mod.close_buffers(buffers, unlink=True)
        print(json.dumps({"closed": True}), flush=True)
