"""Deployment variants explored for the causal_features task.

Each module is a standalone worker entry:

    python flashrt/apps/causal_features/backend/variants/<name>.py \
        --repository <repo root> --config <config.json>
"""
