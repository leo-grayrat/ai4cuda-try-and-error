"""IR conversion of the causal_features streaming convolution chain."""
