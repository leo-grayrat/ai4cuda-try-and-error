"""Fix the shadowed `ref` loop variable in stage_ir, then rerun IR validation."""
import py_compile
import sys
from pathlib import Path

P = Path(__file__).resolve().parent / "drive_all.py"
s = P.read_text(encoding="utf-8")
pairs = [
    ("    for idx, (cand, exp, ref) in enumerate(zip(per_request, expected, ref)):",
     "    for idx, (cand, exp, run) in enumerate(zip(per_request, expected, ref)):"),
    ('        ok_r, ma_r, mr_r = compare(cand, ref[idx]["data"])',
     '        ok_r, ma_r, mr_r = compare(cand, run["data"])'),
]
for old, new in pairs:
    assert old in s, old
    s = s.replace(old, new)
P.write_text(s, encoding="utf-8")
py_compile.compile(str(P), doraise=True)
print("patched shadow", flush=True)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import drive_all

sys.argv = ["drive_all", "--stage", "ir"]
drive_all.main()
