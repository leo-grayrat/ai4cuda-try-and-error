"""full_prealloc: one whole-request pass over preallocated per-layer history
buffers (no per-request torch.cat/clone), batched publish."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "full_prealloc", "strategy": "full", "publish": "batched",
                "poll_sleep": 0.0})
