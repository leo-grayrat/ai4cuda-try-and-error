"""hybrid_graph: hybrid_first_chunk + CUDA graphs on both chains (stacked
latency + launch-overhead levers)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "hybrid_graph", "strategy": "hybrid", "publish": "batched",
                "graph": True, "poll_sleep": 0.0})
