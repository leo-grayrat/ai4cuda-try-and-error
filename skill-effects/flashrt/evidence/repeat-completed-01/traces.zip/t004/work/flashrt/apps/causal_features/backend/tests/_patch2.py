"""Fix the tensor->numpy detach in drive_all.py, then run its IR validation stage."""
import py_compile
import sys
from pathlib import Path

P = Path(__file__).resolve().parent / "drive_all.py"
s = P.read_text(encoding="utf-8")
old = "        got = torch.cat([y for _, y in ctx.collected], dim=-1)[0].numpy()"
new = "        got = torch.cat([y for _, y in ctx.collected], dim=-1)[0].detach().numpy()"
assert old in s, "patch anchor missing"
P.write_text(s.replace(old, new), encoding="utf-8")
py_compile.compile(str(P), doraise=True)
print("patched detach", flush=True)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import drive_all

sys.argv = ["drive_all", "--stage", "ir"]
drive_all.main()
