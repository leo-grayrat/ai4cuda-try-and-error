"""chunked_stream: reference-equivalent per-chunk compute + per-chunk publish,
with busy-spin polling (isolates IPC/polling overhead only)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "chunked_stream", "strategy": "chunked", "poll_sleep": 0.0})
