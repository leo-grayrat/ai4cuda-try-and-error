"""hybrid_first_chunk: publish chunk 0 from a short 3-conv chain immediately,
then run the remaining chunks in one pass (latency-first streaming publish)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "hybrid_first_chunk", "strategy": "hybrid",
                "publish": "batched", "poll_sleep": 0.0})
