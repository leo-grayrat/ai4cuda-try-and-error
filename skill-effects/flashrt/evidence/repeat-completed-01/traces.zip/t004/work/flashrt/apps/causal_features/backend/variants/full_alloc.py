"""full_alloc: one whole-request pass (allocation based, no preallocated chain),
batched publish. Isolates 'one pass instead of 32' from buffer reuse."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "full_alloc", "strategy": "full_alloc", "poll_sleep": 0.0})
