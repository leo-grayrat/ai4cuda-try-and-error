"""IR graph builders for the causal_features task.

Two graphs:

``build_model_graph(config)``
    The fine-grained per-chunk graph of the exposed model: one
    ``LayerChunkStep`` per conv layer (each holding its own history ring) plus
    the output publisher.  This is the graph validated by
    ``tests/drive_all.py`` against the reference backend and analysed with
    ``summarize_graph``.

``build_worker_graph(config)``
    The worker-level graph: request ingest (batch), the composite conv chain,
    and the streaming emit, with an explicit rate-conversion edge
    (``length`` samples -> ``chunk`` samples).
"""
from flashrt.ir import (IREdge, IRGraph, OpType, StateObject, StreamingInfo,
                        StreamingPattern, StreamMode, TensorPort)

from .ops import ChunkEmit, LayerChunkStep, RequestIngest


def build_model_graph(config, kernels=(5, 5, 3)):
    graph = IRGraph(name="causal_features_model")
    for index in range(len(kernels)):
        graph.add_state(StateObject(
            name=f"hist_{index}",
            description=(f"last {kernels[index] - 1} samples of layer {index}'s "
                         "input stream (the convolution history)"),
            scope="chunk_persistent"))
    ops = [LayerChunkStep(i, kernels[i]) for i in range(len(kernels))]
    emit = ChunkEmit()
    for op in ops + [emit]:
        graph.add_operator(op)
    for a, b in zip(ops, ops[1:]):
        graph.add_edge(IREdge(a.name, "y", b.name, "x",
                              streaming=StreamingInfo(
                                  pattern=StreamingPattern.FIXED_RATE,
                                  src_chunk_size=config["chunk"],
                                  dst_chunk_size=config["chunk"],
                                  description="1:1 chunk cadence between layers")))
    graph.add_edge(IREdge(ops[-1].name, "y", emit.name, "y"))
    graph.chunk_ops = [op.name for op in ops] + [emit.name]
    graph.external_inputs = [TensorPort("x_chunk")]
    graph.external_outputs = []
    graph.edges = [e for e in graph.edges]
    # the first layer's chunk input comes from outside the graph
    return graph


def build_worker_graph(config, kernels=(5, 5, 3)):
    graph = build_model_graph(config, kernels)
    graph.name = "causal_features_worker"
    ingest = RequestIngest()
    graph.add_state(StateObject(
        name="session_stream",
        description="concatenated request frames of the current session",
        scope="chunk_persistent"))
    graph.add_operator(ingest)
    chain = IRGraph(name="conv_chain", operators=dict(graph.operators),
                    edges=list(graph.edges),
                    state_objects=dict(graph.state_objects),
                    chunk_ops=list(graph.chunk_ops))
    graph.sub_graphs["conv_chain"] = chain
    chain_op = graph.operators[graph.chunk_ops[0]]
    chain_op.sub_graph = "conv_chain"
    chain_op.op_type = OpType.COMPOSITE
    graph.preamble_ops = [ingest.name]
    graph.sub_graphs["ingest"] = IRGraph(name="ingest")
    graph.add_edge(IREdge(ingest.name, "request", graph.chunk_ops[0], "x",
                          streaming=StreamingInfo(
                              pattern=StreamingPattern.FIXED_RATE,
                              src_chunk_size=config["length"],
                              dst_chunk_size=config["chunk"],
                              description="one request frame is cut into "
                                          "ceil(length/chunk) chunks")))
    graph.external_inputs = [TensorPort("frame")]
    graph.external_outputs = []
    # the first chain op consumes the per-chunk slice through the streaming edge
    first = graph.operators[graph.chunk_ops[0]]
    if not any(p.name == "x" for p in first.inputs):
        first.inputs.append(TensorPort("x"))
    return graph


class ChunkContext:
    """Execution context for the IR validation run (CPU torch, reference math)."""

    def __init__(self, layers, chunk, length):
        import torch
        import torch.nn.functional as F
        self._torch, self._F = torch, F
        self.layers = layers
        self.chunk = chunk
        self.length = length
        self.chunk_index = -1
        self.collected = []

    @staticmethod
    def concat(a, b):
        import torch
        return torch.cat([a, b], dim=-1)

    def layer_step(self, index, x, hist):
        torch, F = self._torch, self._F
        layer = self.layers[index]
        k = layer._time_causal_padding[0]
        joined = x if hist is None else torch.cat([hist, x], dim=-1)
        result = layer(joined)
        if hist is not None:
            result = result[:, :, hist.shape[-1]:]
        new_hist = joined[:, :, -k:].clone()
        return F.silu(result), new_hist

    def emit(self, chunk_index, y):
        self.collected.append((chunk_index, y))
