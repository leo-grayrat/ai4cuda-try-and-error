"""cpu_placement: device-placement experiment -- the whole chain is co-located
on the CPU (2 threads) instead of the GPU, removing H2D/D2H round trips."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "cpu_placement", "strategy": "full", "publish": "batched",
                "force_device": "cpu", "graph": False, "poll_sleep": 0.0})
