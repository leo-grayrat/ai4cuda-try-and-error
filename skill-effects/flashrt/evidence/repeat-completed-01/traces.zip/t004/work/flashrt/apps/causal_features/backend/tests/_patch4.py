"""Off-by-one fix: CausalConv1d._time_causal_padding[0] is the *padding* count
(kernel_size-1), so every place that used `k - 1` as a pad/count must use `k`.
Then verify the engine arithmetic on CPU against the full-sequence oracle for
every strategy, and run the GPU correctness + benchmark stages."""
import py_compile
import sys
from pathlib import Path

import numpy as np

B = Path(__file__).resolve().parents[1]
P = B / "runtime.py"
s = P.read_text(encoding="utf-8")
before = s
s = s.replace("kernel[i] - 1", "kernel[i]")
s = s.replace("k - 1", "k")
s = s.replace("k > 1", "k > 0")
P.write_text(s, encoding="utf-8")
py_compile.compile(str(P), doraise=True)
assert before != s
print("patched off-by-one", flush=True)

sys.path.insert(0, str(B))
import torch
from causal_features.model import full_sequence_oracle
from runtime import Engine

cfg = dict(weight_seed=703, channels=16, hidden=32, length=1043, chunk=127,
           device="cpu")
x = np.random.default_rng(3).standard_normal((16, 1043), dtype=np.float32)
want = full_sequence_oracle(".", cfg, x)
for strategy in ("full", "full_alloc", "hybrid", "chunked"):
    eng = Engine(".", cfg, sys.modules["causal_features.model"], {
        "strategy": strategy, "force_device": "cpu", "prepare": False})
    for repeat in range(2):  # second request continues the session
        eng.handle(x if repeat == 0 else x * 0.5, repeat, None)
        got = np.concatenate([eng.stage[j, :, :eng.meta[j, 2]]
                              for j in range(eng.nchunks)], axis=-1)
        exp = full_sequence_oracle(".", cfg, x if repeat == 0
                                   else np.concatenate([x, x * 0.5], axis=-1)
                                   )[:, -1043:]
        print(f"  {strategy} req{repeat}: max_abs={np.abs(got - exp).max():.3e}",
              flush=True)
    eng.reset()
print("CPU strategy arithmetic OK", flush=True)
