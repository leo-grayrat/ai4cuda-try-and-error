"""spin_sleep: full_prealloc but with the reference's sleeping poll loop
(0.2 ms) -- isolates the cost of the polling strategy on Windows."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "spin_sleep", "strategy": "full", "publish": "batched",
                "poll_sleep": 0.0002})
