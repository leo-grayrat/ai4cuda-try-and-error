"""Shorten harness waits (a dead worker must not burn 120s), then run the GPU
correctness stage for every variant."""
import py_compile
import sys
from pathlib import Path

P = Path(__file__).resolve().parent / "drive_all.py"
s = P.read_text(encoding="utf-8")
pairs = [
    ("def drive(adapter, steps, fast_poll=True, timeout_s=120):",
     "def drive(adapter, steps, fast_poll=True, timeout_s=20):"),
    ("                    deadline = time.perf_counter() + 120",
     "                    deadline = time.perf_counter() + 20"),
    ("                    chunk, t_obs = adapter.receive(timeout_s=120)",
     "                    chunk, t_obs = adapter.receive(timeout_s=20)"),
]
for old, new in pairs:
    assert old in s, old
    s = s.replace(old, new)
P.write_text(s, encoding="utf-8")
py_compile.compile(str(P), doraise=True)
print("patched timeouts", flush=True)

sys.argv = ["drive_all", "--stage", "check"]
import drive_all  # noqa: E402

drive_all.main()
