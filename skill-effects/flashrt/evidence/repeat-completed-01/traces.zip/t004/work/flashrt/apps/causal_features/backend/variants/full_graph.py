"""full_graph: full_prealloc + CUDA graph capture of the 3-conv chain, so the
per-request GPU launch cost collapses to one graph replay."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "full_graph", "strategy": "full", "publish": "batched",
                "graph": True, "poll_sleep": 0.0})
