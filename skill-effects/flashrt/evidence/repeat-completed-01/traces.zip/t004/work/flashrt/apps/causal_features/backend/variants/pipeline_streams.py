"""pipeline_streams: the three conv layers run on three CUDA streams so layer L
of chunk N+1 overlaps layer L+1 of chunk N (cross-chunk pipeline stages)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "pipeline_streams", "strategy": "pipeline", "poll_sleep": 0.0})
