"""full_perchunk_publish: full preallocated pass but chunks are staged and
published one at a time (isolates publish granularity / gap smoothness)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime import run_worker  # noqa: E402
if __name__ == "__main__":
    run_worker({"name": "full_perchunk_publish", "strategy": "full",
                "publish": "perchunk", "poll_sleep": 0.0})
