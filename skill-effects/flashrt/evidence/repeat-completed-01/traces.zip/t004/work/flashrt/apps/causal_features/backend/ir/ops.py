"""IR operators for the causal_features streaming convolution chain.

The exposed computation is the 3-layer causal conv + SiLU chain of
``causal_features.model`` executed once per chunk.  Each layer owns exactly one
convolution history ring, so the layer history objects are the only
``chunk_persistent`` state in the graph and they are disjoint across layers.
"""
from flashrt.ir import IROperator, OpType, StreamMode, TensorPort


class LayerChunkStep(IROperator):
    """One causal conv layer for one chunk; mutates its own history state."""

    def __init__(self, index, kernel):
        self.index = int(index)
        self.kernel = int(kernel)
        name = f"layer{self.index}_chunk"
        super().__init__(
            name=name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("x")],
            outputs=[TensorPort("y")],
            state_reads=[f"hist_{self.index}"],
            state_writes=[f"hist_{self.index}"],
            stream_mode=StreamMode.STREAMING,
            config={"kernel": self.kernel},
        )

    def execute(self, inputs, ctx, state):
        hist = state.get(f"hist_{self.index}")
        y, new_hist = ctx.layer_step(self.index, inputs["x"], hist)
        state.set(f"hist_{self.index}", new_hist)
        return {"y": y}


class ChunkEmit(IROperator):
    """Publish one output chunk (adapter output ring: payload then metadata)."""

    def __init__(self):
        super().__init__(
            name="emit_chunk",
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("y")],
            outputs=[],
            stream_mode=StreamMode.STREAMING,
        )

    def execute(self, inputs, ctx, state):
        ctx.emit(ctx.chunk_index, inputs["y"])
        return {}


class RequestIngest(IROperator):
    """Whole-request input frame read from the adapter input ring buffer."""

    def __init__(self):
        super().__init__(
            name="request_ingest",
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("frame")],
            outputs=[TensorPort("request")],
            state_writes=["session_stream"],
            stream_mode=StreamMode.BATCH,
        )

    def execute(self, inputs, ctx, state):
        frame = inputs["frame"]
        stream = state.get("session_stream")
        joined = frame if stream is None else ctx.concat(stream, frame)
        state.set("session_stream", joined)
        return {"request": joined}
