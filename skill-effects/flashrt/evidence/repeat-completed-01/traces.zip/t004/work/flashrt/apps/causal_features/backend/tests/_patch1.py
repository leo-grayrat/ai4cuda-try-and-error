"""Local maintenance script: apply two small fixes to drive_all.py and smoke
test the IR graph (CPU only) before any GPU run."""
import py_compile
import sys
from pathlib import Path

P = Path(__file__).resolve().parent / "drive_all.py"
s = P.read_text(encoding="utf-8")
before = s
s = s.replace("            adapter.start()  # level-valued: keep the worker active\n", "")
s = s.replace("    graph = build_model_graph(graph_cfg, kernels=(5, 5, 3))",
              "    (BACKEND / 'notes').mkdir(parents=True, exist_ok=True)\n"
              "    graph = build_model_graph(graph_cfg, kernels=(5, 5, 3))", 1)
P.write_text(s, encoding="utf-8")
py_compile.compile(str(P), doraise=True)
print("patched:", before != s)

sys.path[:0] = ["flashrt/apps"]
import numpy as np
import torch
from causal_features.backend.ir.graph_builder import (ChunkContext, build_model_graph,
                                                     build_worker_graph)
from causal_features.model import build_layers, full_sequence_oracle
from flashrt.ir import SequentialExecutor, summarize_graph

cfg = dict(weight_seed=703, channels=16, hidden=32)
gcfg = dict(chunk=127, length=1043)
g = build_model_graph(gcfg)
print("model validate:", g.validate() or "OK")
wg = build_worker_graph(gcfg)
print("worker validate:", wg.validate() or "OK")
ex = SequentialExecutor(g)
ex.init_state({f"hist_{i}": None for i in range(3)})
ctx = ChunkContext(build_layers(".", cfg, "cpu"), 127, 1043)
rng = np.random.default_rng(0)
x = rng.standard_normal((16, 1043), dtype=np.float32)
frame = torch.from_numpy(x).unsqueeze(0)
for j in range(0, 1043, 127):
    ctx.chunk_index = j // 127
    ex.run_chunk({"x": frame[:, :, j:j + 127]}, ctx)
got = torch.cat([y for _, y in ctx.collected], dim=-1)[0].numpy()
want = full_sequence_oracle(".", cfg, x)
print("chunks:", len(ctx.collected), "max_abs_diff:", float(np.abs(got - want).max()))
print("analysis stages:", [st.operators for st in
                           __import__("flashrt.ir", fromlist=["find_pipeline_stages"]).find_pipeline_stages(g)])
print(summarize_graph(g).split("## Cross-Chunk Independent Pairs")[1][:400])
