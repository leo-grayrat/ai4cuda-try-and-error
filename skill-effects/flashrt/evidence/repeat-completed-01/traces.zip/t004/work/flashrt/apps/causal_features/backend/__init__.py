"""Optimized single-GPU streaming backend for the causal_features task.

The adapter (``causal_features.adapter``) and the fixed computation
(``causal_features.model``) are imported from the task package; nothing in the
shared/reference trees is modified.  ``worker.py`` is the recommended entry.
"""
