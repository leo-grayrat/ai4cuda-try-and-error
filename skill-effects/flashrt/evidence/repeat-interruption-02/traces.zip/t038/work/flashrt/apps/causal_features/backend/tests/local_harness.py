"""Local end-to-end harness: drive reference and candidate backends through the
shared adapter, compare every chunk against the CPU full-sequence oracle, and
report latency-to-first-output and inter-chunk-gap distributions.

Usage (from repo root, via workspace.execute):
    python <this file> --case small --seg 0
    python <this file> --case large --seg 0

Writes a JSON result under benchmarks/results/ and prints it.  All backend
subprocesses are terminated in a finally block.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]
APP_PARENT = REPO / "flashrt" / "apps"
for p in (str(REPO), str(APP_PARENT)):
    if p not in sys.path:
        sys.path.insert(0, p)

from causal_features.adapter import FeatureAdapter  # noqa: E402
from causal_features.model import full_sequence_oracle  # noqa: E402

CASES = {
    "small": dict(channels=16, hidden=32, length=1043, chunk=127),
    "large": dict(channels=128, hidden=256, length=16384, chunk=512),
}


def make_features(case, length, seed):
    rng = np.random.RandomState(seed)
    return rng.standard_normal((case["channels"], length)).astype(np.float32)


def request_sequence(case):
    t = case["length"]
    a = make_features(case, t, 11)
    b = make_features(case, t, 22)
    c = make_features(case, t, 33)
    return [
        ("request", "A", a),
        ("request", "B", b),
        ("request", "B(repeat,no reset)", b),
        ("reset", None, None),
        ("request", "A(after reset)", a),
        ("request", "C", c),
    ]


def launch(kind, config, seg):
    fd, cfg_path = tempfile.mkstemp(suffix=".json", prefix="cf_cfg_")
    with os.fdopen(fd, "w") as f:
        json.dump(config, f)
    env = os.environ.copy()
    env["PYTHONPATH"] = str(APP_PARENT) + os.pathsep + str(REPO) + os.pathsep + env.get("PYTHONPATH", "")
    env.pop("RANK", None)
    env.pop("WORLD_SIZE", None)
    env["CF_SEG_CHUNKS"] = str(seg)
    if kind == "reference":
        cmd = [sys.executable, "-m", "causal_features.reference",
               "--repository", str(REPO), "--config", cfg_path]
    else:
        cmd = [sys.executable,
               str(REPO / "flashrt/apps/causal_features/backend/worker.py"),
               "--repository", str(REPO), "--config", cfg_path]
    err_path = REPO / "flashrt/apps/causal_features/backend/benchmarks/results" / f"{kind}_stderr.log"
    err_path.parent.mkdir(parents=True, exist_ok=True)
    err = open(err_path, "w")
    proc = subprocess.Popen(cmd, cwd=str(REPO), env=env,
                            stdout=subprocess.PIPE, stderr=err, text=True)
    ready_line = proc.stdout.readline()
    if not ready_line.strip():
        err.close()
        proc.kill()
        raise RuntimeError(f"{kind} backend did not report ready")
    return proc, err, cfg_path


def run_requests(kind, case, seg):
    prefix = f"cf_{kind}_{os.getpid()}_{int(time.time()*1e6)%1000000}"
    config = dict(case, weight_seed=703, device="cuda:0", prefix=prefix)
    proc, err, cfg_path = launch(kind, config, seg)
    adapter = None
    results = {}
    timings = []
    try:
        adapter = FeatureAdapter(config)
        adapter.start()
        for kind_ev, label, arr in request_sequence(case):
            if kind_ev == "reset":
                adapter.reset()
                results[label] = None
                continue
            _, published_ns = adapter.submit(arr)
            out_pieces = []
            recv_ns = []
            while adapter.pending is not None:
                out, observed = adapter.receive(timeout_s=60)
                out_pieces.append(out)
                recv_ns.append(observed)
            full = np.concatenate(out_pieces, axis=1)[:, : arr.shape[1]]
            results[label] = full
            timings.append({
                "request": label,
                "t_first_out_ms": (recv_ns[0] - published_ns) / 1e6,
                "chunks": len(recv_ns),
                "gaps_ms": [float(g) for g in np.diff(recv_ns) / 1e6],
                "span_ms": (recv_ns[-1] - recv_ns[0]) / 1e6 if len(recv_ns) > 1 else 0.0,
            })
        adapter.terminate()
    finally:
        try:
            proc.terminate()
            proc.wait(timeout=20)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
        err.close()
        try:
            os.unlink(cfg_path)
        except OSError:
            pass
    return results, timings


def correctness(case, results):
    """Compare each request against the CPU oracle over the session prefix."""
    seq = np.zeros((case["channels"], 0), dtype=np.float32)
    out = {}
    worst = 0.0
    ok = True
    t = case["length"]
    for kind_ev, label, arr in request_sequence(case):
        if kind_ev == "reset":
            seq = np.zeros((case["channels"], 0), dtype=np.float32)
            continue
        seq = np.concatenate([seq, arr], axis=1)
        oracle = full_sequence_oracle(REPO, dict(case, weight_seed=703, device="cpu"),
                                      seq)[:, -t:]
        cand = results[label]
        if cand is None:
            ok = False
            continue
        diff = np.abs(cand - oracle)
        tol = 3e-5 + 3e-4 * np.abs(oracle)
        good = bool((diff <= tol).all())
        ok = ok and good
        worst = max(worst, float(diff.max()))
        out[label] = {"max_abs": float(diff.max()), "pass": good, "shape": list(cand.shape)}
    a0 = results.get("A")
    a1 = results.get("A(after reset)")
    reproduced = bool(a0 is not None and a1 is not None and np.array_equal(a0, a1))
    return out, worst, ok, reproduced


def summarize(timings):
    first = np.array([t["t_first_out_ms"] for t in timings])
    gaps = np.concatenate([t["gaps_ms"] for t in timings]) if timings else np.array([])
    return {
        "t_first_out_ms_median": float(np.median(first)),
        "t_first_out_ms_p95": float(np.percentile(first, 95)),
        "t_first_out_ms_all": [float(x) for x in first],
        "chunk_gap_ms_median": float(np.median(gaps)) if gaps.size else None,
        "chunk_gap_ms_p95": float(np.percentile(gaps, 95)) if gaps.size else None,
        "chunk_gap_ms_max": float(gaps.max()) if gaps.size else None,
        "chunk_gap_over_20ms_fraction": float((gaps > 20.0).mean()) if gaps.size else None,
        "num_chunks": int(gaps.size + len(timings)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", choices=sorted(CASES), default="small")
    ap.add_argument("--seg", type=int, default=0)
    ap.add_argument("--reference", action="store_true")
    ap.add_argument("--tag", default="")
    args = ap.parse_args()
    case = CASES[args.case]

    payload = {"case": args.case, "seg": args.seg, "config": case}
    ref_timings = None
    ref_results = None
    try:
        if args.reference or args.tag == "reference":
            ref_results, ref_timings = run_requests("reference", case, 0)
            payload["reference"] = {"summary": summarize(ref_timings)}
    except Exception as exc:  # keep going so candidate numbers still print
        payload["reference_error"] = repr(exc)

    cand_results, cand_timings = run_requests("candidate", case, args.seg)
    corr, worst, ok, reproduced = correctness(case, cand_results)
    payload["candidate"] = {
        "summary": summarize(cand_timings),
        "correctness": corr,
        "worst_abs": worst,
        "reset_reproduced_bitwise": reproduced,
    }
    if ref_timings is not None:
        payload["reference"]["summary"] = summarize(ref_timings)
        ref_corr, ref_worst, ref_ok, _ = correctness(case, ref_results)
        payload["reference"]["correctness"] = ref_corr
        payload["reference"]["worst_abs"] = ref_worst
    payload["verdict"] = "PASS" if (ok and reproduced) else "FAIL"

    out_dir = REPO / "flashrt/apps/causal_features/backend/benchmarks/results"
    out_dir.mkdir(parents=True, exist_ok=True)
    name = f"{args.tag or 'candidate'}_seg{args.seg}_{args.case}.json"
    (out_dir / name).write_text(json.dumps(payload, indent=2))
    print(json.dumps(payload, indent=2))
    print("VERDICT:", payload["verdict"])
    return 0 if payload["verdict"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
