"""IR operators for the fixed three-layer causal convolution stack.

The reference ``ReferencePipeline.step`` runs one chunk through three
``CausalConv1d`` + SiLU stages.  Each stage keeps its own pre-convolution
history of length ``kernel_size - 1``.  Those histories are the only
state that crosses chunk boundaries, so the IR declares one
``chunk_persistent`` ``StateObject`` per stage.

The operators below are byte-for-byte equivalent to the reference's
per-stage computation:

    joined = cat(history, x) if history else x
    out    = layer(joined)                # CausalConv1d: replicate-pad left
    out    = out[..., len(history):]       # drop the re-emitted history
    history' = joined[..., -pad:].clone()
    y      = silu(out)

This is exactly ``ReferencePipeline.step``'s body, so an IR run reproduces
the reference outputs (validated numerically in ``tests/run_ir_validation.py``).
"""
from __future__ import annotations

import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort


class CausalConvStage(IROperator):
    """One causal convolution + SiLU stage with its own persistent history."""

    def __init__(self, index: int, in_channels: int, out_channels: int, kernel_size: int):
        self.index = index
        self.pad = kernel_size - 1
        self.history_name = f"history_{index}"
        super().__init__(
            name=f"layer_{index}",
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("x", shape_hint=("batch", in_channels, "time"))],
            outputs=[TensorPort("y", shape_hint=("batch", out_channels, "time"))],
            # The stage reads and mutates its own history in place.
            state_reads=[self.history_name],
            state_writes=[self.history_name],
            stream_mode=StreamMode.STREAMING,
            config={
                "in_channels": in_channels,
                "out_channels": out_channels,
                "kernel_size": kernel_size,
                "causal_padding": self.pad,
            },
        )

    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.index]
        value = inputs["x"]
        history = state.get(self.history_name)
        if history is None:
            joined = value
            emitted = 0
        else:
            joined = torch.cat([history, value], dim=-1)
            emitted = history.shape[-1]
        result = layer(joined)
        if emitted:
            result = result[:, :, emitted:]
        # ``joined`` always holds at least ``pad`` samples for this task
        # (chunk >= kernel-1), matching the reference's ``-pad:`` slice.
        state.set(self.history_name, joined[:, :, -self.pad:].clone())
        return {"y": F.silu(result)}
