"""IR conversion for the causal_features three-layer causal convolution stack."""

from .graph_builder import build_chunk_graph, LAYER_SPECS
from .ops import CausalConvStage

__all__ = ["build_chunk_graph", "LAYER_SPECS", "CausalConvStage"]
