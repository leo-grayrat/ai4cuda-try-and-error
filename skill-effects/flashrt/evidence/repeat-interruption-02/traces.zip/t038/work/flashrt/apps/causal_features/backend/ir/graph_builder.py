"""Build the chunk-periodic IR graph for the causal_features app.

Worker level and model level coincide here: the whole application is one
exposed three-stage causal convolution stack, so the worker graph is the
chunk graph.  Three ``EXPOSED`` operators (the convolution stages) are
chained by data edges; each owns a disjoint ``chunk_persistent`` history
state.  Disjoint state is what makes cross-chunk pipelining legal in
principle (stage i of chunk N+1 can overlap stage i+1 of chunk N), and it
is what the analysis tools surface below.
"""
from __future__ import annotations

from flashrt.ir import IREdge, IRGraph, StateObject, StreamingInfo, StreamingPattern, TensorPort

from .ops import CausalConvStage

# (in_channels, out_channels, kernel_size) per stage, matching model.build_layers.
LAYER_SPECS = (
    ("channels", "hidden", 5),
    ("hidden", "hidden", 5),
    ("hidden", "channels", 3),
)


def _dims(config):
    channels, hidden = config["channels"], config["hidden"]
    return [(channels, hidden, 5), (hidden, hidden, 5), (hidden, channels, 3)]


def build_chunk_graph(config) -> IRGraph:
    """Return the validated chunk-periodic IR graph for this task."""
    graph = IRGraph(name="causal_features_chunk")
    dims = _dims(config)

    ops = []
    for index, (cin, cout, kernel) in enumerate(dims):
        graph.add_state(
            StateObject(
                name=f"history_{index}",
                description=(
                    f"pre-convolution history of stage {index} "
                    f"(kernel={kernel}, length={kernel - 1})"
                ),
                scope="chunk_persistent",
            )
        )
        ops.append(CausalConvStage(index, cin, cout, kernel))

    for op in ops:
        graph.add_operator(op)

    # Within-chunk data flow.  Rate is 1:1: every stage emits one sample per
    # input sample, so the streaming edges carry no rate conversion.
    for src, dst in ((ops[0], ops[1]), (ops[1], ops[2])):
        graph.add_edge(
            IREdge(
                src.name,
                "y",
                dst.name,
                "x",
                streaming=StreamingInfo(
                    pattern=StreamingPattern.FIXED_RATE,
                    src_chunk_size=1,
                    dst_chunk_size=1,
                    description="sample-for-sample causal dependency",
                ),
            )
        )

    graph.external_inputs = [TensorPort("x", shape_hint=("batch", config["channels"], "time"))]
    graph.external_outputs = [TensorPort("y", shape_hint=("batch", config["channels"], "time"))]
    graph.chunk_ops = [op.name for op in ops]
    return graph
