"""Development sweep: candidate backend over batching granularities and both
official configurations, with CPU-oracle correctness on every request.

Run without arguments (workspace.execute supplies none).  Results are written
under benchmarks/results/.
"""
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[5]
for p in (str(REPO), str(REPO / "flashrt" / "apps")):
    if p not in sys.path:
        sys.path.insert(0, p)

from flashrt.apps.causal_features.backend.tests.local_harness import (  # noqa: E402
    CASES,
    correctness,
    run_requests,
    summarize,
)


def main():
    combos = [("small", 0), ("small", 1), ("small", 4), ("large", 0), ("large", 4)]
    payload = {}
    for case_name, seg in combos:
        case = CASES[case_name]
        results, timings = run_requests("candidate", case, seg)
        corr, worst, ok, reproduced = correctness(case, results)
        summary = summarize(timings)
        key = f"{case_name}_seg{seg}"
        payload[key] = {
            "summary": summary,
            "worst_abs": worst,
            "reset_reproduced_bitwise": reproduced,
            "correctness": corr,
            "verdict": "PASS" if ok and reproduced else "FAIL",
        }
        print(key, json.dumps({"summary": summary, "worst_abs": worst,
                               "reproduced": reproduced, "verdict": payload[key]["verdict"]}))
    out = REPO / "flashrt/apps/causal_features/backend/benchmarks/results/dev_sweep.json"
    out.write_text(json.dumps(payload, indent=2))
    print("wrote", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
