"""Run the IR analysis tools on the validated chunk graph and print the summary.

Also measures a per-stage latency on the assigned GPU for the large
configuration (C=128, H=256, T=16384) so ``summarize_graph`` can report a
critical path and per-stage bottleneck.  Latencies are for one batched
whole-request forward of each stage (the deployment strategy this
workspace promotes), not per 512-sample chunk.
"""
import json
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[5]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from flashrt.ir import summarize_graph
from flashrt.apps.causal_features.model import build_layers
from flashrt.apps.causal_features.backend.ir.graph_builder import build_chunk_graph


def measure_latencies(config, device="cuda:0", iters=30):
    layers = build_layers(REPO, config, device)
    t = config["length"]
    activations = [torch.randn((1, config["channels"], t), device=device)]
    # Build the per-stage activations once so each stage is timed on its
    # real input distribution/shape.
    with torch.inference_mode():
        value = activations[0]
        for layer in layers:
            value = torch.nn.functional.silu(layer(value))
            activations.append(value)
        torch.cuda.synchronize()
        lat = {}
        for index, layer in enumerate(layers):
            x = activations[index]
            # warm
            for _ in range(3):
                layer(x)
            torch.cuda.synchronize()
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(iters):
                layer(x)
            end.record()
            torch.cuda.synchronize()
            lat[f"layer_{index}"] = start.elapsed_time(end) / 1000.0 / iters
    return lat


def main():
    config = {
        "channels": 128,
        "hidden": 256,
        "length": 16384,
        "chunk": 512,
        "weight_seed": 703,
        "device": "cuda:0",
    }
    graph = build_chunk_graph(config)
    errors = graph.validate()
    print("graph.validate errors:", errors)
    latencies = measure_latencies(config)
    print("measured per-stage (batched whole-request) latency seconds:", json.dumps(latencies))
    print(summarize_graph(graph, op_latencies=latencies))


if __name__ == "__main__":
    main()
