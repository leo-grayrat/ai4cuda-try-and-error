"""Phase 2 IR validation for causal_features.

Runs the SequentialExecutor over the chunk-periodic IR graph on a real
six-request sequence (continuation, repeated input without reset, an
explicit reset, and the short tail chunk that T=1043/127 produces) and
compares it against the sequential reference pipeline and the CPU
full-sequence oracle.

Tolerances: atol=3e-5, rtol=3e-4 (task contract).  For the CPU reference
pipeline comparison the same kernels run, so the difference is pure
accumulation order (~1e-7); the contract tolerance covers both.

Prints PASS/FAIL and output hashes.  In-process, no subprocess.
"""
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

REPO = Path(__file__).resolve().parents[5]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from flashrt.ir import SequentialExecutor
from flashrt.apps.causal_features.model import (
    ReferencePipeline,
    build_layers,
    full_sequence_oracle,
)
from flashrt.apps.causal_features.backend.ir.graph_builder import build_chunk_graph

ATOL = 3e-5
RTOL = 3e-4


def make_config():
    return {
        "channels": 16, "hidden": 32, "length": 1043, "chunk": 127,
        "weight_seed": 703, "device": "cpu",
    }


def make_events(config):
    rng = np.random.RandomState(20240607)
    c, t = config["channels"], config["length"]
    a = rng.standard_normal((c, t)).astype(np.float32)
    b = rng.standard_normal((c, t)).astype(np.float32)
    c_req = rng.standard_normal((c, t)).astype(np.float32)
    return [
        ("request", "A", a),
        ("request", "B", b),
        ("request", "B(repeat,no reset)", b),
        ("reset", None, None),
        ("request", "A(after reset)", a),
        ("request", "C", c_req),
    ]


def drive_ir(config, events):
    layers = build_layers(REPO, config, "cpu")
    ctx = SimpleNamespace(layers=layers)
    executor = SequentialExecutor(build_chunk_graph(config))
    init = {f"history_{i}": None for i in range(3)}
    executor.init_state(init)
    session = np.zeros((config["channels"], 0), dtype=np.float32)
    records = []
    for kind, label, arr in events:
        if kind == "reset":
            executor.init_state(dict(init))
            session = np.zeros((config["channels"], 0), dtype=np.float32)
            records.append(("reset", None, None))
            continue
        session = np.concatenate([session, arr], axis=1)
        pieces = []
        with torch.inference_mode():
            for pos in range(0, arr.shape[1], config["chunk"]):
                piece = np.ascontiguousarray(arr[:, pos:pos + config["chunk"]])
                out = executor.run_chunk(
                    {"x": torch.from_numpy(piece).unsqueeze(0)}, ctx
                )["y"]
                pieces.append(out.squeeze(0).numpy())
        ir_out = np.concatenate(pieces, axis=1)[:, : arr.shape[1]]
        oracle = full_sequence_oracle(REPO, config, session)[:, -arr.shape[1]:]
        records.append((label, ir_out, oracle))
    return records


def drive_reference(config, events):
    pipeline = ReferencePipeline(REPO, config)
    records = []
    for kind, label, arr in events:
        if kind == "reset":
            pipeline.reset()
            records.append(("reset", None))
            continue
        pieces = [
            pipeline.step(arr[:, pos:pos + config["chunk"]])
            for pos in range(0, arr.shape[1], config["chunk"])
        ]
        records.append((label, np.concatenate(pieces, axis=1)[:, : arr.shape[1]]))
    return records


def digest(arrays):
    h = hashlib.sha256()
    for a in arrays:
        if a is not None:
            h.update(np.ascontiguousarray(a, dtype=np.float32).tobytes())
    return h.hexdigest()


def main():
    config = make_config()
    events = make_events(config)
    ir_records = drive_ir(config, events)
    ref_records = drive_reference(config, events)

    ok = True
    per_request = []
    for (label, ir_out, oracle), (rlabel, ref_out) in zip(ir_records, ref_records):
        if label == "reset":
            print(f"[reset] {rlabel}")
            continue
        d_oracle = np.abs(ir_out - oracle)
        d_ref = np.abs(ir_out - ref_out)
        good = bool(
            (d_oracle <= ATOL + RTOL * np.abs(oracle)).all()
            and (d_ref <= ATOL + RTOL * np.abs(ref_out)).all()
        )
        ok = ok and good
        per_request.append({
            "request": label,
            "max_abs_vs_oracle": float(d_oracle.max()),
            "max_abs_vs_reference_pipeline": float(d_ref.max()),
            "pass": good,
            "shape": list(ir_out.shape),
        })
        print(f"[{label}] max|IR-oracle|={d_oracle.max():.3e} "
              f"max|IR-ref|={d_ref.max():.3e} -> {'OK' if good else 'MISMATCH'}")

    reset_reproduced = bool(np.array_equal(ir_records[0][1], ir_records[4][1]))
    ok = ok and reset_reproduced
    print(f"[reset reproduction] bitwise_identical={reset_reproduced}")

    payload = {
        "tolerance": {"atol": ATOL, "rtol": RTOL},
        "config": config,
        "per_request": per_request,
        "reset_reproduced_bitwise": reset_reproduced,
        "ir_output_sha256": digest([r[1] for r in ir_records]),
        "oracle_output_sha256": digest([r[2] for r in ir_records]),
        "reference_pipeline_sha256": digest([r[1] for r in ref_records]),
        "verdict": "PASS" if ok else "FAIL",
    }
    print(json.dumps(payload, indent=2))
    print("VERDICT:", payload["verdict"])
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
