"""Optimized standalone backend for the causal_features task.

Launched exactly like the reference:

    python <this file> --repository <repo root> --config <config.json>

It creates the same seven shared-memory objects through
``causal_features.adapter.open_buffers(..., create=True)`` and speaks the
same level-valued control protocol (1 start / 3 reset / 2 terminate).

Optimization idea
-----------------
The researcher reference feeds one config chunk at a time and performs a
GPU->CPU synchronisation per chunk per layer.  The computation is a causal
convolution stack, so it is shift-invariant along time: feeding
``cat(history, segment)`` through a layer and dropping the re-emitted
history produces *exactly* the same samples as advancing chunk by chunk
with that history (the replicate padding applied by ``CausalConv1d`` sits
before the history and is sliced away).  Therefore a request -- or any
contiguous segment of it -- can be evaluated as one batched forward with
one device synchronisation, while the persistent per-layer histories keep
the cross-request continuation semantics intact.

``CF_SEG_CHUNKS`` optionally limits how many config chunks are batched
together before their outputs are published (0 = whole request).  It never
changes the emitted samples; it only trades first-chunk latency against
kernel-launch count.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path


def _parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    return parser.parse_args()


def main():
    args = _parse_args()
    sys.path.insert(0, str(args.repository.resolve()))

    import numpy as np
    import torch
    import torch.nn.functional as F

    from causal_features.adapter import close_buffers, open_buffers
    from causal_features.model import build_layers

    config = json.loads(args.config.read_text(encoding="utf-8"))

    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = config["device"]
    channels = int(config["channels"])
    length = int(config["length"])
    chunk = int(config["chunk"])
    num_chunks = (length + chunk - 1) // chunk

    seg_chunks = int(os.environ.get("CF_SEG_CHUNKS", "0")) or num_chunks

    layers = build_layers(args.repository, config, device)
    pads = [int(layer._time_causal_padding[0]) for layer in layers]
    n_layers = len(layers)
    histories = [None] * n_layers

    # Warm the CUDA context and convolution kernels for every time length we
    # may feed before announcing readiness.  This is pure setup (it touches
    # no shared state) and removes one-time lazy-init cost from the first
    # measured request.
    with torch.inference_mode():
        warm_lengths = sorted({min(chunk, length), min(length, seg_chunks * chunk)})
        for warm_len in warm_lengths:
            warm = torch.zeros((1, channels, max(1, warm_len)), device=device, dtype=torch.float32)
            for _ in range(3):
                cursor = warm
                for layer in layers:
                    cursor = F.silu(layer(cursor))
            del warm
        torch.cuda.synchronize()

    buffers = open_buffers(config, create=True)
    consumed = 0
    last_command = 0
    active = False
    try:
        print(json.dumps({"ready": True, "device": device}), flush=True)
        while True:
            opcode = buffers["control"].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers["control"].commit()
                    break
                if opcode == 3:
                    histories = [None] * n_layers
                    active = False
                    buffers["control"].commit()
                elif opcode == 1:
                    active = True
                    buffers["control"].commit()
                elif opcode != 0:
                    raise ValueError(f"Unknown control opcode: {opcode}")
            if not active:
                time.sleep(0.0002)
                continue

            next_cursor, features = buffers["input"].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError("Input overwritten before processing")
            request_id = consumed
            consumed = next_cursor

            for seg_start in range(0, num_chunks, seg_chunks):
                seg_stop = min(num_chunks, seg_start + seg_chunks)
                pos0 = seg_start * chunk
                pos1 = min(length, seg_stop * chunk)
                segment = np.ascontiguousarray(features[0, :, pos0:pos1])

                with torch.inference_mode():
                    value = torch.from_numpy(segment).unsqueeze(0).to(device)
                    for index, layer in enumerate(layers):
                        history = histories[index]
                        if history is None:
                            joined = value
                            emitted = 0
                        else:
                            joined = torch.cat([history, value], dim=-1)
                            emitted = history.shape[-1]
                        result = layer(joined)
                        if emitted:
                            result = result[:, :, emitted:]
                        histories[index] = joined[:, :, -pads[index]:].clone()
                        value = F.silu(result)
                    segment_out = value.squeeze(0).cpu().numpy()

                for index in range(seg_start, seg_stop):
                    position = index * chunk
                    valid = min(chunk, length - position)
                    if valid == chunk:
                        payload = segment_out[:, position - pos0:position - pos0 + chunk]
                    else:
                        payload = np.zeros((channels, chunk), dtype=np.float32)
                        payload[:, :valid] = segment_out[:, position - pos0:position - pos0 + valid]
                    # Payload first, metadata second -- the adapter requires
                    # the data to be visible before the descriptor.
                    buffers["output"].write(payload)
                    buffers["metadata"].write(
                        np.array([request_id, index, valid], dtype=np.int64)
                    )
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({"closed": True}), flush=True)


if __name__ == "__main__":
    main()
