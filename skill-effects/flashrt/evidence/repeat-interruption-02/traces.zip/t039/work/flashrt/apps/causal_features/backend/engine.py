"""Streaming engine for causal_features.

The reference worker advances three causal ``CausalConv1d`` layers one chunk at
a time, concatenating each layer's (kernel-1)-sample history in front of the
chunk, convolving, slicing the history columns off and keeping the new tail.

Two facts make that equivalent to a much cheaper schedule:

* ``CausalConv1d`` pads the *left* with ``kernel-1`` replicated samples, so a
  fresh stream is identical to a stream whose prefix is ``kernel-1`` copies of
  its first sample followed by a padding-free convolution.
* A layer's output over a segment depends only on the segment plus the last
  ``kernel-1`` samples before it.  So a request may be split into *any*
  partition of segments (1 segment, 2 segments, one per chunk, ...) and every
  partition yields the same numbers, bit-for-bit in the same accumulation
  order, because the arithmetic per output column is unchanged.

The engine therefore keeps one in-place prefix tensor per layer and lets each
strategy choose the segment partition.  ``chunk_stream`` reproduces the
reference cadence, ``bulk`` convolves the whole request once, and ``hybrid``
convolves chunk 0 alone (to publish early) then the remainder.
"""
import math

import numpy as np
import torch
import torch.nn.functional as F


class LayerStreams:
    """Three causal conv layers plus their cross-chunk prefix state."""

    def __init__(self, layers):
        self.layers = list(layers)
        self.hold = [layer._time_causal_padding[0] for layer in self.layers]
        self.weight = [layer.conv.weight for layer in self.layers]
        self.bias = [layer.conv.bias for layer in self.layers]
        self.prefix = [None] * len(self.layers)
        self.depth = len(self.layers)

    def reset(self):
        self.prefix = [None] * len(self.layers)

    def push(self, index, value):
        """Feed one segment through layer ``index``; return that layer's output."""
        prefix, hold = self.prefix[index], self.hold[index]
        if prefix is None:
            head = value[:, :, :1].expand(-1, -1, hold)
            history = 0
        else:
            head, history = prefix, prefix.shape[-1]
        joined = torch.cat((head, value), dim=-1)
        out = F.conv1d(joined, self.weight[index], self.bias[index])
        if history:
            out = out[:, :, history:]
        out = F.silu(out)
        if prefix is None:
            self.prefix[index] = joined[:, :, -hold:].clone()
        else:
            prefix.copy_(joined[:, :, -hold:])
        return out

    def push_graphable(self, index, value):
        """``push`` with a pre-existing, in-place prefix (no rebinding)."""
        prefix, hold = self.prefix[index], self.hold[index]
        joined = torch.cat((prefix, value), dim=-1)
        out = F.silu(F.conv1d(joined, self.weight[index], self.bias[index])[:, :, hold:])
        prefix.copy_(joined[:, :, -hold:])
        return out

    def seed_prefix(self, value):
        """Replace every layer prefix with the replicate-pad of ``value``."""
        for index in range(self.depth):
            hold, prefix = self.hold[index], self.prefix[index]
            prefix.copy_(value[:, :, :1].expand(-1, -1, hold))


class Backend:
    """Adapter-compatible streaming worker with selectable segment schedules."""

    def __init__(self, layers, config, device, strategy='hybrid'):
        self.streams = LayerStreams(layers)
        self.device = torch.device(device)
        self.channels = int(config['channels'])
        self.length = int(config['length'])
        self.chunk = int(config['chunk'])
        self.count = math.ceil(self.length / self.chunk)
        self.strategy = strategy
        self.buffers = None
        self.graph = None
        self.side = torch.cuda.Stream(device=self.device)
        self.meta = np.zeros((3,), dtype=np.int64)
        pinned = dict(dtype=torch.float32, pin_memory=True)
        self.pin_in = torch.empty((self.channels, self.length), **pinned)
        self.pin_in_np = self.pin_in.numpy()
        head = min(self.chunk, self.length)
        self.head_len = head
        self.rest_len = self.length - head
        self.pin_head = torch.empty((self.channels, head), **pinned)
        self.pin_head_np = self.pin_head.numpy()
        self.pin_rest = torch.empty((self.channels, max(1, self.rest_len)), **pinned)
        self.pin_rest_np = self.pin_rest.numpy()
        self.pin_out = torch.empty((self.channels, self.length), **pinned)
        self.dev_in = torch.empty((1, self.channels, self.length), device=self.device)
        self.dev_head = torch.empty((1, self.channels, head), device=self.device)
        self.dev_rest = torch.empty((1, self.channels, max(1, self.rest_len)),
                                    device=self.device)

    # ------------------------------------------------------------------ setup
    def attach(self, buffers):
        self.buffers = buffers

    def reset(self):
        self.streams.reset()

    def _valid(self, index):
        start = index * self.chunk
        return min(self.chunk, self.length - start)

    # -------------------------------------------------------------- transport
    def _load(self, features):
        np.copyto(self.pin_in_np, features[0])

    def _load_split(self, features):
        np.copyto(self.pin_head_np, features[0, :, :self.head_len])
        if self.rest_len > 0:
            np.copyto(self.pin_rest_np[:, :self.rest_len], features[0, :, self.head_len:])

    def _h2d(self, device, pinned, length):
        device[:, :, :length].copy_(pinned[:, :length], non_blocking=True)

    def emit(self, device_values, request_id, index):
        """Publish one chunk: data first (device -> shm), metadata second."""
        valid = self._valid(index)
        out = self.buffers['output']
        slot = out.num % out.max_len
        target = torch.from_numpy(out.tensor[slot])
        target[:, :valid].copy_(device_values[0, :, :valid])
        self.meta[0], self.meta[1], self.meta[2] = request_id, index, valid
        meta = self.buffers['metadata']
        position = meta.num % meta.max_len
        meta.tensor[position] = self.meta
        meta.num_arr[0] = int(meta.num) + 1
        out.num_arr[0] = int(out.num) + 1

    def emit_range(self, values, request_id, first):
        """Publish chunks ``first..`` taken from a (1,C,L) device tensor."""
        for index in range(first, self.count):
            start = index * self.chunk
            self.emit(values[:, :, start - first * self.chunk:
                             start - first * self.chunk + self._valid(index)],
                      request_id, index)

    # ------------------------------------------------------------- strategies
    def run(self, features, request_id):
        getattr(self, '_' + self.strategy)(features, request_id)

    def _chunk_stream(self, features, request_id):
        self._load(features)
        self._h2d(self.dev_in, self.pin_in, self.length)
        values = self.dev_in
        for index in range(self.count):
            start = index * self.chunk
            segment = values[:, :, start:start + self._valid(index)]
            for layer in range(self.streams.depth):
                segment = self.streams.push(layer, segment)
            self.emit(segment, request_id, index)

    def _bulk(self, features, request_id):
        self._load(features)
        self._h2d(self.dev_in, self.pin_in, self.length)
        values = self.dev_in
        for layer in range(self.streams.depth):
            values = self.streams.push(layer, values)
        self.emit_range(values, request_id, 0)

    def _hybrid(self, features, request_id):
        self._load_split(features)
        self._h2d(self.dev_head, self.pin_head, self.head_len)
        values = self.dev_head
        for layer in range(self.streams.depth):
            values = self.streams.push(layer, values)
        self.emit(values, request_id, 0)
        if self.rest_len <= 0:
            return
        self._h2d(self.dev_rest, self.pin_rest, self.rest_len)
        values = self.dev_rest
        for layer in range(self.streams.depth):
            values = self.streams.push(layer, values)
        self.emit_range(values, request_id, 1)

    def _hybrid_pipe(self, features, request_id):
        self._load_split(features)
        main = torch.cuda.current_stream(self.device)
        with torch.cuda.stream(self.side):
            if self.rest_len > 0:
                self._h2d(self.dev_rest, self.pin_rest, self.rest_len)
                ready = torch.cuda.Event()
                ready.record(self.side)
        self._h2d(self.dev_head, self.pin_head, self.head_len)
        values = self.dev_head
        for layer in range(self.streams.depth):
            values = self.streams.push(layer, values)
        self.emit(values, request_id, 0)
        if self.rest_len <= 0:
            return
        main.wait_event(ready)
        values = self.dev_rest
        for layer in range(self.streams.depth):
            values = self.streams.push(layer, values)
        self.emit_range(values, request_id, 1)

    # ------------------------------------------------------- cuda-graph replay
    def warm_graph(self):
        """Capture the remainder-segment pass so a request replays in one launch."""
        if self.rest_len <= 0:
            return False
        dummy = torch.zeros((1, self.channels, self.length), device=self.device)
        for _ in range(2):
            self.reset()
            self._hybrid(dummy, 0)
        torch.cuda.synchronize()
        self.reset()
        # Prime prefixes and allocator state exactly as a real request will.
        self._h2d(self.dev_head, self.pin_head, self.head_len)
        head = self.dev_head
        for layer in range(self.streams.depth):
            head = self.streams.push(layer, head)
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        self.streams.depth_before = None
        with torch.cuda.graph(graph):
            values = self.dev_rest
            for layer in range(self.streams.depth):
                values = self.streams.push_graphable(layer, values)
            self.pin_out[:, :self.rest_len].copy_(values[0, :, :self.rest_len],
                                                  non_blocking=True)
        torch.cuda.synchronize()
        self.graph = graph
        self.reset()
        return True

    def _hybrid_graph(self, features, request_id):
        if self.graph is None and not self.warm_graph():
            return self._hybrid(features, request_id)
        self._load_split(features)
        self._h2d(self.dev_head, self.pin_head, self.head_len)
        values = self.dev_head
        for layer in range(self.streams.depth):
            values = self.streams.push(layer, values)
        self.emit(values, request_id, 0)
        if self.rest_len <= 0:
            return
        self._h2d(self.dev_rest, self.pin_rest, self.rest_len)
        self.graph.replay()
        torch.cuda.synchronize()
        host = self.pin_out_np
        for index in range(1, self.count):
            start = (index - 1) * self.chunk
            valid = self._valid(index)
            self.emit_host(host[:, start:start + valid], request_id, index, valid)
