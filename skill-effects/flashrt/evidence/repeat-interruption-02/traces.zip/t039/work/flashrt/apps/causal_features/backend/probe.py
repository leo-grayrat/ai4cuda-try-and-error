import pathlib
base = pathlib.Path(r'E:\Project\Git\Research\ai4cuda-try-and-error\skill-effects\flashrt')
print((base / 'run_local_reference.py').read_text(encoding='utf-8'))
