本任务在单张 RTX 5060 8GB、Windows、PyTorch 2.11.0+cu128 上优化 branch_features：两条因果卷积分支各自保存四份历史，按当前输入通道均值做 sigmoid 门控后合并并加 0.1 残差。参考实现严格按块、先 A 后 B、每块同步回 CPU；适配器契约（控制码 1/3/2、原 SharedTensorBuffer、先数据后元数据、尾部有效长度、reset 清空全部历史）保持不变。

假设与 IR 证据：我把暴露计算建成 worker 图（branch_a、branch_b、gate_merge，3 算子/2 条 1:1 流式边）和模型图（7 算子/6 边，四个 chunk_persistent 历史对象）。用原 SequentialExecutor 对真实输入执行并与参考逐块比较：与 CUDA 参考逐元素完全一致（最大绝对差 0.0），与 CPU 全序列 oracle 最大差 2.384e-7，容差 atol=3e-5、rtol=3e-4，结论 PASS，日志在 backend/tests/ir_validation.log、脚本在 backend/tests/test_ir.py。summarize_graph 显示三条流水阶段 [branch_a]、[branch_b]、[gate_merge]，两分支无共享持久状态，跨块独立对为 branch_a||branch_b 等；因此参考的“先算 A 再算 B”不是数据依赖，可合并计算。该分析直接支撑“整请求批处理 + 两分支融合 + 合并按块输出”的路线。

实现：推荐入口 backend/worker.py（策略 batch_fused_graph）。把 a0/b0 融合成一次 16→64、核长 5 的卷积（3 抽头核左侧补零），把 a1/b1 融合成一次分组 64→32、核长 5 的卷积（每分支一组，a1 的 3 抽头核补零），数学上只是同一组乘加的重排；四份历史与 first-request 标志放在静态显存缓冲中，整个前向（含历史更新）被 CUDA graph 捕获；输入用 pinned 暂存，重放后先拷回第一块并立即发布，再拷回其余部分连续发出九块；输入轮询改为自旋（每 1024 次让出一次），避免固定 0.2 ms 睡眠延迟。历史在首个请求/重置后用首样本复制来精确复现 CausalConv1d 的 replicate 左填充，跨请求则沿用上一请求的真实末样本。

官方证据：workspace.verify（evidence/verify-010）完成 6 个完整请求（连续会话、不 reset 重复输入、reset、尾短块），全部 numerical_match，最大绝对差 2.384e-7，cleanup_verified=true。workspace.benchmark（evidence/benchmark-012）成对扫描：参考最高通过 100 req/s，候选最高通过 200 req/s；候选 100 req/s 首输出中位 1.015 ms（参考 1.583 ms）、块间隔中位 0.0094 ms（参考 1.080 ms）；200 req/s 首输出中位 1.012 ms、间隔中位 0.0096 ms；所有窗口块间隔超 20 ms 比例在 100/200 为 0。总结数据在 backend/benchmarks/results/official_summary.json。

失败与权衡：第一次官方 benchmark（evidence/benchmark-011）的候选控制器在共享 GPU 锁等待中超时，未创建会话、未启动后端、无任何数字，我将其记为无效而非结果；重试成功。候选在 50 req/s 窗口有 2.0% 的块间隔超过 20 ms（p95 19.68 ms），该窗口 smoothness gate 未过；200 req/s 的 p95 首输出 6.64 ms 也差于参考 1.83 ms，原因是单个冷启动离群点，而中位数、可持续速率和间隔分布均显著更好。整请求批处理把首输出推迟到整段算完，但整段仅约 1 ms，仍快于参考；CPU 融合版本中位首输出 0.54 ms 但 p95 3.87 ms 且不使用 GPU；逐块 graph 版本首输出更低但可持续速率更差，均如实记录。

补充测量：我用 tests/local_variant_sweep.py 通过共享适配器跑通全部 10 个入口（推荐入口加 9 个变体），每个都做 12 次连续请求、reset 和重复请求，并与 CPU 全序列 oracle 比较，全部 correct=true、最大差≤2.98e-7；结果在 benchmarks/results/local_variant_sweep.json。因此“只算一条路径”“缓存互相替代”等问题均被数值检验排除。

未完成项（如实列出）：只有 worker.py 经过独立控制器验证与基准；其余 9 个变体只有本地子进程适配器 E2E 证据，未逐个经过 workspace.verify/benchmark；50 req/s 的 smoothness 门限未过；IR 只做了结构分析，未测逐算子延迟和数值关键路径；按 IR 合法的双 GPU 分支流水在本单卡任务中未实现、未测量。上游“10 个变体都要控制器测量”和“所有队列项终态”的要求在本观察的 48 请求上限下未全部满足，我没有把它声称为完成。

规则核对：所有代码/文档只写在 backend/ 内，未改共享或参考文件；没有用 blocked/discarded 规避任何条目，也没有成本理由跳过队列（10 个入口都实际跑过，只是证据层级不同）；报告、README 和日志中未使用任何“下次会话/以后再补”类措辞。所有未达项已在上文点名，剩余证据指针为 evidence/verify-010、evidence/benchmark-012、backend/tests/ir_validation.log、backend/benchmarks/results/official_summary.json 与 local_variant_sweep.json。