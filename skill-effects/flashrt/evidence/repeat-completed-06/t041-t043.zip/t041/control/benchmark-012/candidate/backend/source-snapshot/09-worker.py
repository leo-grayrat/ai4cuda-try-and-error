"""Recommended standalone backend entry (fused whole-request CUDA graph).

Usage:
    python flashrt/apps/branch_features/backend/worker.py \
        --repository <repo-root> --config <config.json>
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from entry import run  # noqa: E402

if __name__ == '__main__':
    run('batch_fused_graph')
