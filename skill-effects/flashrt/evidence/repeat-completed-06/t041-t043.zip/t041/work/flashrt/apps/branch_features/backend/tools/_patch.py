from pathlib import Path
p = Path(__file__).with_name('dev_check.py')
s = p.read_text(encoding='utf-8')
s = s.replace("def step(self, x):\n        if self.first:", "def step(self, x):\n      with torch.inference_mode():\n        if self.first:")
s = s.replace("        self.first = False\n        return out", "        self.first = False\n        return out.clone()")
# indent body of step: simplest is to drop inference_mode and detach at call sites instead
s = s.replace("def step(self, x):\n      with torch.inference_mode():\n        if self.first:", "def step(self, x):\n        if self.first:")
s = s.replace(".step(x).squeeze(0).cpu().numpy()", ".step(x).detach().squeeze(0).cpu().numpy()")
p.write_text(s, encoding='utf-8')
print('patched')
