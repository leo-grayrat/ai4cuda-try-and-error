from pathlib import Path
base = Path(__file__).resolve().parent.parent
ops = base / 'ir' / 'ops.py'
s = ops.read_text(encoding='utf-8')
s += '''

@ir_operator(
    name='silu_b',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('x')],
    outputs=[TensorPort('y')],
    stream_mode=StreamMode.STREAMING,
)
def silu_b(inputs, ctx, state):
    return {'y': F.silu(inputs['x'])}
'''
ops.write_text(s, encoding='utf-8')
gb = base / 'ir' / 'graph_builder.py'
s = gb.read_text(encoding='utf-8')
s = s.replace('from .ops import CausalConvOp, GateMergeOp, silu', 'from .ops import CausalConvOp, GateMergeOp, silu, silu_b')
s = s.replace("""    g.add_operator(silu)  # single shared Silu object cannot be registered twice
    # the decorator binds one object; clone for the second use
    silu_b = type(silu)()
    silu_b.name = 'silu_b'
    g.add_operator(silu_b)""", """    g.add_operator(silu)
    g.add_operator(silu_b)""")
gb.write_text(s, encoding='utf-8')
(base / '__init__.py').write_text('', encoding='utf-8')
(base / 'ir' / '__init__.py').write_text('from .graph_builder import build_model_graph, build_worker_graph\n', encoding='utf-8')
(base / 'tests').mkdir(exist_ok=True)
(base / 'tests' / '__init__.py').write_text('', encoding='utf-8')
print('patched3')
