from pathlib import Path
p = Path(__file__).resolve().parent.parent / 'backend_runtime.py'
s = p.read_text(encoding='utf-8')
s = s.replace("        self.starts = list(range(0, self.T, self.chunk))\n        self.reset()\n",
              "        self.starts = list(range(0, self.T, self.chunk))\n")
s = s.replace("        self.layers = build_layers(repository, config, device)\n        super().__init__(repository, config, device)\n\n    def reset(self):\n        self.hist",
              "        self.layers = build_layers(repository, config, device)\n        super().__init__(repository, config, device)\n        self.reset()\n\n    def reset(self):\n        self.hist")
s = s.replace("                print(f'[branch_features] cuda graph unavailable: {exc}', flush=True)\n                self.graph = None\n\n    def reset(self):\n        self.first.fill_(1)",
              "                print(f'[branch_features] cuda graph unavailable: {exc}', flush=True)\n                self.graph = None\n        self.reset()\n\n    def reset(self):\n        self._first_request = True\n        self.first.fill_(1)")
s = s.replace("        with torch.cuda.graph(self.graph):\n            self.out, self.sa0, self.sb0 = self._forward()\n\n    def reset(self):\n        self.first.fill_(1)",
              "        with torch.cuda.graph(self.graph):\n            self.out, self.sa0, self.sb0 = self._forward()\n        self.reset()\n\n    def reset(self):\n        self._first_request = True\n        self.first.fill_(1)")
p.write_text(s, encoding='utf-8')
print('patched2')
