"""Phase-2 IR validation for branch_features.

Runs the fine-grained IR graph through SequentialExecutor and compares every
output chunk against (a) the sequential reference pipeline driven on the same
inputs and (b) the CPU full-sequence oracle.  A reset in the middle checks
that the four history state objects are cleared consistently.

Tolerance: atol=3e-5, rtol=3e-4.  Justification: the reference and the
oracle already differ only by CPU-vs-GPU float32 summation order
(measured ~2e-7); the tolerance covers a different convolution algorithm
being selected for a different input length while forbidding any semantic
change.
"""
import json
import sys
from pathlib import Path

import numpy as np

p = Path(__file__).resolve()
REPO = next(a for a in p.parents if (a / 'flashrt' / 'layers' / 'audio.py').is_file())
sys.path.insert(0, str(REPO))

import torch  # noqa: E402

from flashrt.ir import SequentialExecutor, summarize_graph  # noqa: E402
from flashrt.apps.branch_features.backend.ir.graph_builder import (  # noqa: E402
    HISTORIES, build_model_graph, build_worker_graph)
from branch_features.model import (ReferencePipeline, build_layers,  # noqa: E402
                                   full_sequence_oracle)

ATOL, RTOL = 3e-5, 3e-4


class Ctx:
    def __init__(self, layers):
        self.layers = layers


def run_executor(executor, ctx, features):
    outs = []
    C, T = features.shape
    chunk = ctx.chunk
    with torch.inference_mode():
        for pos in range(0, T, chunk):
            out = executor.run_chunk({'x': torch.from_numpy(features[None, :, pos:pos + chunk].copy()).cuda()}, ctx)
            outs.append(out['y'].detach().squeeze(0).cpu().numpy())
    return outs


def main():
    config = {'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
              'weight_seed': 703, 'device': 'cuda'}
    rng = np.random.default_rng(11)
    req1 = rng.standard_normal((16, 1043), dtype=np.float32)
    req2 = rng.standard_normal((16, 1043), dtype=np.float32)

    ref = ReferencePipeline(str(REPO), config)
    layers = ref.layers
    graph = build_model_graph(config)
    executor = SequentialExecutor(graph)
    executor.init_state({name: None for name in HISTORIES})
    ctx = Ctx(layers)
    ctx.chunk = config['chunk']

    # Reference chunk outputs for the same sequence of calls.
    ref_chunks = []
    for req in (req1, req2):
        chunks = []
        for pos in range(0, 1043, 127):
            chunks.append(ref.step(req[:, pos:pos + 127]))
        ref_chunks.append(chunks)
    ref.reset()
    ref_chunks.append([ref.step(req1[:, pos:pos + 127]) for pos in range(0, 1043, 127)])

    ir_chunks = []
    ir_chunks.append(run_executor(executor, ctx, req1))
    ir_chunks.append(run_executor(executor, ctx, req2))
    executor.init_state({name: None for name in HISTORIES})  # reset
    ctx.chunk = config['chunk']
    ir_chunks.append(run_executor(executor, ctx, req1))

    oracle_first = full_sequence_oracle(str(REPO), config, np.concatenate([req1, req2], axis=-1))
    oracle_reset = full_sequence_oracle(str(REPO), config, req1)
    oracle_chunks = [np.split(oracle_first, [1043], axis=-1),
                     None,
                     [np.split(oracle_reset, [1043], axis=-1)[0]]]
    oracle_chunks = [np.split(oracle_first, [1043], axis=-1)[0],
                     np.split(oracle_first, [1043], axis=-1)[1],
                     np.split(oracle_reset, [1043], axis=-1)[0]]

    ok = True
    max_ref = 0.0
    max_oracle = 0.0
    for r in range(3):
        joined_ir = np.concatenate(ir_chunks[r], axis=-1)
        joined_ref = np.concatenate(ref_chunks[r], axis=-1)
        d_ref = float(np.abs(joined_ir - joined_ref).max())
        d_or = float(np.abs(joined_ir - oracle_chunks[r]).max())
        max_ref = max(max_ref, d_ref)
        max_oracle = max(max_oracle, d_or)
        good = np.allclose(joined_ir, joined_ref, atol=ATOL, rtol=RTOL) and \
            np.allclose(joined_ir, oracle_chunks[r], atol=ATOL, rtol=RTOL)
        ok = ok and good
        print(f'request {r}: max|ir-reference|={d_ref:.3e} max|ir-oracle|={d_or:.3e} within_tol={good}')

    model_summary = summarize_graph(graph)
    worker_summary = summarize_graph(build_worker_graph(config))
    log = []
    log.append('IR validation: ' + ('PASS' if ok else 'FAIL'))
    log.append(f'max|ir-reference|={max_ref:.3e} max|ir-oracle|={max_oracle:.3e} '
               f'atol={ATOL} rtol={RTOL}')
    log.append('')
    log.append('=== worker-level summary ===')
    log.append(worker_summary)
    log.append('=== model-level summary ===')
    log.append(model_summary)
    (p.parent / 'ir_validation.log').write_text('\n'.join(log), encoding='utf-8')
    print('\n'.join(log[:2]))
    print(worker_summary)
    print('PASS' if ok else 'FAIL')
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
