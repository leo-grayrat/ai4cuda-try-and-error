"""Variant entry: whole-request unfused convolutions captured in a CUDA graph."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from entry import run  # noqa: E402

if __name__ == '__main__':
    run('batch_unfused_graph')
