"""Variant entry: fused graph, direct pageable host-to-device input copy."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from entry import run  # noqa: E402

if __name__ == '__main__':
    run('batch_fused_graph_direct_h2d')
