"""Variant entry: fused graph, one device-to-host copy before emitting chunks."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from entry import run  # noqa: E402

if __name__ == '__main__':
    run('batch_fused_graph_single_copy')
