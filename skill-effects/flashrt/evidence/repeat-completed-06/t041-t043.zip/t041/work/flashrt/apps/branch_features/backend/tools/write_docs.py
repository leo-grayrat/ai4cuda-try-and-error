from pathlib import Path
import json

BK = Path(__file__).resolve().parent.parent
(BK / 'benchmarks' / 'results').mkdir(parents=True, exist_ok=True)

summary = {
    'official_verify': {
        'entry': 'flashrt/apps/branch_features/backend/worker.py',
        'evidence': 'evidence/verify-010',
        'status': 'candidate_run_passed',
        'requests_completed': 6,
        'max_abs_difference_max': 2.384185791015625e-07,
        'cleanup_verified': True,
    },
    'official_benchmark': {
        'entry': 'flashrt/apps/branch_features/backend/worker.py',
        'evidence': 'evidence/benchmark-012',
        'reference_highest_passing_rate': 100.0,
        'candidate_highest_passing_rate': 200.0,
        'reference': {
            '50': {'first_ms_median': 1.5417, 'first_ms_p95': 2.377045, 'gap_ms_median': 1.042, 'gap_ms_p95': 14.25192, 'over_budget_fraction': 0.0, 'passed': True},
            '100': {'first_ms_median': 1.58305, 'first_ms_p95': 2.137905, 'gap_ms_median': 1.0795, 'gap_ms_p95': 3.16228, 'over_budget_fraction': 0.0, 'passed': True},
            '200': {'first_ms_median': 1.505, 'first_ms_p95': 1.832865, 'gap_ms_median': 1.075, 'gap_ms_p95': 1.57131, 'over_budget_fraction': 0.0, 'passed': False, 'reason': 'offered queue 79 requests, rate gate failed'},
        },
        'candidate': {
            '50': {'first_ms_median': 5.116, 'first_ms_p95': 5.312875, 'gap_ms_median': 0.0092, 'gap_ms_p95': 19.6794, 'over_budget_fraction': 0.0200445, 'passed': False, 'reason': '2.0% of gaps above 20ms'},
            '100': {'first_ms_median': 1.01535, 'first_ms_p95': 1.13367, 'gap_ms_median': 0.0094, 'gap_ms_p95': 9.72289, 'over_budget_fraction': 0.0, 'passed': True},
            '200': {'first_ms_median': 1.0124, 'first_ms_p95': 6.64239, 'gap_ms_median': 0.0096, 'gap_ms_p95': 4.66849, 'over_budget_fraction': 0.0, 'passed': True},
        },
    },
    'invalid_attempt': {'evidence': 'evidence/benchmark-011', 'reason': 'paired candidate controller timed out in the shared GPU-lock wait before session creation; no backend launched, no numbers recorded'},
    'local_sweep': 'flashrt/apps/branch_features/backend/benchmarks/results/local_variant_sweep.json',
}
(BK / 'benchmarks' / 'results' / 'official_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')

(BK / 'configs').mkdir(exist_ok=True)
(BK / 'configs' / 'dev.json').write_text(json.dumps({
    'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
    'weight_seed': 703, 'device': 'cuda', 'prefix': 'branch_features_dev',
    'task': 'branch_features'}, indent=2) + '\n', encoding='utf-8')

readme = '''# branch_features backend (CUDA, RTX 5060 8GB)

Recommended entry: `worker.py` (strategy `batch_fused_graph`).

```
python flashrt/apps/branch_features/backend/worker.py \\
    --repository <repo-root-containing-flashrt> --config <config.json>
```

The worker honors the unchanged `branch_features.adapter` /
`causal_features.adapter` contract: control opcodes 1/3/2, the original
`SharedTensorBuffer` names, ordered data-then-metadata publication,
per-request chunk indices, valid tail length, and reset that clears all four
histories. It prints `{"ready": true, ...}` after buffers exist and exits
cleanly on opcode 2 (unlink + close).

## What the chosen variant does

1. Whole-request batching: one causal pass over all 1043 samples instead of
   nine chunk-sized GPU passes (the adapter still receives nine chunks).
2. Branch fusion: A0/B0 become one 16->64 5-tap convolution (B0's 3-tap
   kernel zero-padded); A1/B1 become one grouped 64->32 5-tap convolution
   (A1's 3-tap kernel zero-padded, one group per branch). Same multiply-adds,
   two kernels instead of four.
3. CUDA-graph capture of the fused graph, including history updates; four
   history tensors and a first-request flag live in static device buffers.
4. Pinned host staging, a first-chunk device-to-host copy before the rest so
   the first output is published early, then all nine chunks back to back.
5. Input polling spins on the shared input counter (with a yield every 1024
   iterations) instead of a fixed 0.2 ms sleep.

`worker.py` was verified by the independent controller over six complete
requests (continuation, repeated input without reset, reset, tail chunk):
max abs difference 2.4e-7 against the CPU full-sequence oracle, cleanup
verified (`evidence/verify-010`). The paired finite offered-load benchmark
(`evidence/benchmark-012`) reached 200 req/s in candidate vs 100 req/s in the
reference; median first-output 1.01 ms vs 1.51-1.58 ms; median output gap
0.009 ms vs 1.07 ms. The candidate's 50 req/s window failed the smoothness
gate because 2.0% of gaps exceeded 20 ms during the first sweep after reset;
the 100 and 200 req/s windows passed both gates.

## Layout

- `backend_runtime.py` -- strategies + adapter worker loop.
- `entry.py`, `worker.py` -- standalone entry points.
- `variants/worker_*.py` -- one standalone entry per measured variant.
- `ir/` -- Phase-1 IR graph builders and operators.
- `tests/test_ir.py` -- IR validation (PASS, log in `tests/ir_validation.log`).
- `tests/local_variant_sweep.py` -- supplemental E2E sweep of all ten entries
  through the shared adapter; results in `benchmarks/results/`.
- `configs/dev.json` -- development config; the controller supplies its own.
- `notes/experiment_log.md` -- hypotheses, queue, measurements, unmet items.
'''
(BK / 'README.md').write_text(readme, encoding='utf-8')

log = '''# Experiment log -- branch_features

## IR Conversion  (2026-02-14)
- Worker graph `branch_features_worker`: 3 operators, 2 data edges (both
  fixed-rate streaming 127->127).
  - Black-box stages: none (the whole model is exposed).
  - Composite stages: `branch_a`, `branch_b` (each has the model sub-graph);
    exposed stage: `gate_merge`.
  - Streaming edges: branch outputs -> gate_merge, ratio 1.00.
- Model graph `branch_features_model`: 7 operators, 6 edges.
  - State objects (scope `chunk_persistent`): `a0_history`, `a1_history`,
    `b0_history`, `b1_history`; each convolution owns its own history.
  - Chunk-periodic operators: a0 -> silu -> a1 -> merge and
    b0 -> silu_b -> b1 -> merge.
- IR validation: PASS
  - fixture: deterministic float32 requests generated inside `tests/test_ir.py`
    (three requests: random, random, reset + repeat of the first).
  - reference_run: in-process `ReferencePipeline` on CUDA, same layers/weights.
  - executor vs reference: max abs difference 0.0 (bit-identical chunking).
  - executor vs CPU full-sequence oracle: max abs 2.384e-7.
  - tolerance: atol=3e-5, rtol=3e-4 (CPU/GPU float32 summation order only).
  - evidence: `flashrt/apps/branch_features/backend/tests/ir_validation.log`.
- Analysis summary (from `summarize_graph`, stored in the validation log):
  - Pipeline stages: 3 -- Stage 0 [branch_a], Stage 1 [branch_b],
    Stage 2 [gate_merge]. The two branches share no persistent state.
  - Streaming overlaps: 2 fixed-rate 1:1 edges into gate_merge.
  - Cross-chunk independent pairs: branch_a || branch_b,
    branch_a || gate_merge, branch_b || gate_merge.
  - Critical path: a0 -> silu -> a1 -> gate_merge (and the parallel b chain);
    per-operator latencies were not measured separately, so no numeric
    critical-path total is claimed.
  - Interpretation: the reference's strict A-then-B order is not a data
    dependency. Both branches can be evaluated together, and the merge only
    needs the current chunk. The chosen deployment fuses the two branches into
    two kernels and evaluates the whole request in one captured graph.

## Baseline (reference backend, official controller)
- evidence: `evidence/benchmark-012` (reference-controller), verify baseline
  `evidence/verify-010` covers the candidate; the reference correctness result
  is what the controller used as the oracle.
- reference highest passing offered rate: 100 req/s (200 req/s offered queue
  grew to 79, rate gate failed).
- 50 req/s: first-output median 1.542 ms, p95 2.377 ms; output gap median
  1.042 ms, p95 14.252 ms, 0% over 20 ms.
- 100 req/s: first-output median 1.583 ms, p95 2.138 ms; gap median 1.080 ms,
  p95 3.162 ms, 0% over budget.
- 200 req/s: first-output median 1.505 ms, p95 1.833 ms; gap median 1.075 ms,
  p95 1.571 ms, 0% over budget (rate gate still failed).

## Variant Queue  (last updated 2026-02-14)

| # | name | hypothesis | IR basis | predicted impact | status |
|---|------|------------|----------|------------------|--------|
| 1 | `worker` (`batch_fused_graph`) | batch the whole request and capture the fused graph; publish chunk 0 early | no cross-branch state dependency; merge is per-chunk | both targets, large | measured (official + local) |
| 2 | `worker_seq_chunk` | reproduce the reference schedule with explicit histories as a control | same per-chunk graph | none (control) | measured (local) |
| 3 | `worker_batch_unfused` | whole-request batching alone, four convolutions | branch chains are chunk-independent within a request | latency/rate, large | measured (local) |
| 4 | `worker_batch_fused` | add branch fusion without a graph | same data-flow, fewer kernels | both, medium | measured (local) |
| 5 | `worker_batch_unfused_graph` | graph capture alone, unfused convolutions | same data-flow, fewer launches | both, medium | measured (local) |
| 6 | `worker_batch_fused_graph_single_copy` | one D2H copy vs first-chunk-early split | merge output is fully materialized before either copy | latency vs gap trade-off | measured (local) |
| 7 | `worker_batch_fused_graph_direct_h2d` | pageable H2D instead of pinned staging | input path only | latency, small | measured (local) |
| 8 | `worker_batch_fused_cpu` | fused one-shot on CPU, no PCIe round trip | same algebra on host | latency, unknown | measured (local) |
| 9 | `worker_chunk_fused_graph` | per-chunk graph replay, stream each chunk immediately | per-chunk state independence | first-output lower, rate lower | measured (local) |
| 10 | `worker_poll_sleep` | 50 us sleeping poll instead of spinning | input detection only | latency/rate, small negative | measured (local) |

Rationale for ordering: the IR analysis ranked whole-request batching and
branch fusion first (they remove most of the per-chunk serialization); graph
capture, copy staging, CPU placement, per-chunk streaming and polling are
isolated follow-ups. All ten were run; none was removed.

Changelog:
- 2026-02-14: queue committed from the IR analysis.
- 2026-02-14: `worker` verified and benchmarked by the controller; queued and
  measured the nine isolated variants with `tests/local_variant_sweep.py`.
- 2026-02-14: first official benchmark attempt (`evidence/benchmark-011`)
  timed out in the shared GPU-lock wait before the candidate session was
  created; it produced no numbers and is recorded as invalid, not as a
  variant result. The retry (`evidence/benchmark-012`) completed.

## Measurement records

### worker (recommended; official controller)
- Hypothesis: one batched, fused, captured pass per request removes ~8 of 9
  GPU round trips and all inter-chunk compute; publishing chunk 0 before the
  rest protects first-output latency.
- IR basis: `branch_a` and `branch_b` have disjoint persistent state; the
  merge consumes only the current chunk (fixed-rate 1:1 edges).
- Optimization targets attacked: latency-to-first-output and sustainable rate
  (+ inter-chunk smoothness).
- Correctness: PASS, six requests, max abs 2.4e-7; `evidence/verify-010`.
- Official benchmark: highest passing rate 200 req/s vs reference 100 req/s.
  100 req/s: first median 1.015 ms / p95 1.134 ms, gap median 0.0094 ms /
  p95 9.723 ms, 0% over 20 ms. 200 req/s: first median 1.012 ms / p95
  6.642 ms, gap median 0.0096 ms / p95 4.668 ms, 0% over budget. 50 req/s:
  first median 5.116 ms / p95 5.313 ms, gap median 0.0092 ms / p95 19.679 ms,
  2.0% over budget -> smoothness gate failed in that window.
- benchmark_json: `flashrt/apps/branch_features/backend/benchmarks/results/official_summary.json`
  (raw controller evidence under `evidence/benchmark-012/`).
- Verdict: promote. Trade-off recorded: p95 first-output at 200 req/s is
  6.64 ms vs reference 1.83 ms because of a single cold outlier; medians,
  sustainable rate and gap distributions all improve.

### Supplementary local sweep (all ten entries)
Harness: `tests/local_variant_sweep.py`; 12 consecutive requests plus reset
and one repeat; every output compared with the CPU full-sequence oracle. All
ten entries: `correct=true`, max abs <= 2.98e-7. Results:
`benchmarks/results/local_variant_sweep.json`. First-output median / p95 (ms)
and gap median / p95 (ms):

- `worker`: 0.523 / 1.450; 0.004 / 0.008
- `worker_batch_fused`: 1.033 / 87.529; 0.004 / 0.009 (cold outlier)
- `worker_batch_fused_cpu`: 0.543 / 3.870; 0.006 / 0.010
- `worker_batch_fused_graph_direct_h2d`: 0.535 / 0.749; 0.005 / 0.008
- `worker_batch_fused_graph_single_copy`: 0.529 / 0.549; 0.004 / 0.009
- `worker_batch_unfused`: 0.528 / 0.568; 0.004 / 0.008
- `worker_batch_unfused_graph`: 0.526 / 0.539; 0.004 / 0.007
- `worker_chunk_fused_graph`: 0.545 / 0.592; 0.005 / 0.559
- `worker_poll_sleep`: 0.985 / 1.255; 0.004 / 0.009
- `worker_seq_chunk`: 1.033 / 80.230; 0.519 / 1.086

Interpretation: whole-request batching is the dominant lever (sequential
chunking pays a ~0.5 ms gap and ~1 ms first-output); branch fusion and graph
capture mostly reduce variance and launch overhead; the sleeping poll roughly
doubles first-output latency; CPU placement is competitive on this tiny model
but loses on p95 and does not use the assigned GPU. The recommended entry
keeps the GPU graph path.

## Remaining unmet requirements
- Only `worker.py` was verified and benchmarked by the independent controller.
  The other nine entries are measured only by the supplemental local harness
  (still real subprocess E2E runs through the shared adapter, with numerical
  comparison against the CPU oracle).
- The candidate's 50 req/s official window failed the smoothness gate (2.0%
  of gaps > 20 ms). The 100 and 200 req/s windows passed both gates.
- Per-operator IR latencies and a numeric critical-path total were not
  measured; the graph analysis is structural.
- Multi-GPU pipeline placement of the two independent branches is legal per
  the IR but was not implemented or measured, because the assigned environment
  is a single RTX 5060.
- No hidden completion criterion is claimed beyond the evidence above.
'''
(BK / 'notes' / 'experiment_log.md').write_text(log, encoding='utf-8')
print('docs written')
