"""Microbenchmark: CUDA-graph fused whole-request runner vs sequential GPU reference."""
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

p = Path(__file__).resolve()
REPO = next(a for a in p.parents if (a / 'flashrt' / 'layers' / 'audio.py').is_file())
sys.path.insert(0, str(REPO))
from branch_features.model import build_layers, ReferencePipeline  # noqa: E402

C, H, T, CH = 16, 32, 1043, 127
cfg = {'channels': C, 'hidden': H, 'length': T, 'chunk': CH, 'weight_seed': 703, 'device': 'cuda'}


def fused_weights(layers):
    a0, a1, b0, b1 = layers['a0'], layers['a1'], layers['b0'], layers['b1']
    w0 = torch.cat([a0.conv.weight, F.pad(b0.conv.weight, (2, 0))], 0)
    b0 = torch.cat([a0.conv.bias, b0.conv.bias], 0)
    w1 = torch.cat([F.pad(a1.conv.weight, (2, 0)), b1.conv.weight], 0)
    b1 = torch.cat([a1.conv.bias, b1.conv.bias], 0)
    return w0.detach(), b0.detach(), w1.detach(), b1.detach()


class GraphRunner:
    def __init__(self, layers, device='cuda'):
        self.w0, self.b0, self.w1, self.b1 = fused_weights(layers)
        self.x = torch.zeros(1, C, T, device=device)
        self.ha0 = torch.zeros(1, C, 4, device=device)
        self.hb0 = torch.zeros(1, C, 4, device=device)
        self.ha1 = torch.zeros(1, H, 4, device=device)
        self.hb1 = torch.zeros(1, H, 4, device=device)
        self.first = torch.zeros(1, dtype=torch.int64, device=device)
        self.out = torch.empty(1, C, T, device=device)
        for _ in range(3):
            self._fwd()
        torch.cuda.synchronize()
        self.g = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.g):
            self.out = self._fwd()
        torch.cuda.synchronize()
        self.pin = torch.empty(C, T, dtype=torch.float32, pin_memory=True)

    def _fwd(self):
        x = self.x
        rep0 = x[:, :, :1].expand(-1, -1, 4)
        ha0 = torch.where(self.first > 0, rep0, self.ha0)
        hb0 = torch.where(self.first > 0, rep0, self.hb0)
        y0 = F.conv1d(torch.cat([ha0, x], -1), self.w0, self.b0)
        sa0, sb0 = F.silu(y0[:, :H]), F.silu(y0[:, H:])
        rep1 = sa0[:, :, :1].expand(-1, -1, 4)
        rep2 = sb0[:, :, :1].expand(-1, -1, 4)
        ha1 = torch.where(self.first > 0, rep1, self.ha1)
        hb1 = torch.where(self.first > 0, rep2, self.hb1)
        y1 = F.conv1d(torch.cat([torch.cat([ha1, sa0], -1),
                                 torch.cat([hb1, sb0], -1)], 1), self.w1, self.b1, groups=2)
        gate = torch.sigmoid(x.mean(1, keepdim=True))
        out = gate * y1[:, :C] + (1 - gate) * y1[:, C:] + 0.1 * x
        self.ha0.copy_(x[:, :, -4:])
        self.hb0.copy_(x[:, :, -4:])
        self.ha1.copy_(sa0[:, :, -4:])
        self.hb1.copy_(sb0[:, :, -4:])
        return out

    def reset(self):
        self.first.fill_(1)
        self.ha0.zero_(); self.hb0.zero_(); self.ha1.zero_(); self.hb1.zero_()

    def run(self, x, first):
        self.first.fill_(1 if first else 0)
        self.x.copy_(x)
        self.g.replay()
        self.pin.copy_(self.out[0], non_blocking=True)
        torch.cuda.synchronize()
        return self.pin.numpy()


def main():
    layers = build_layers(str(REPO), cfg, 'cuda')
    gr = GraphRunner(layers)
    rng = np.random.default_rng(3)
    xs = [torch.from_numpy(rng.standard_normal((1, C, T), dtype=np.float32)).cuda() for _ in range(16)]
    gr.reset()
    for i, x in enumerate(xs):
        gr.run(x, i == 0)
    n = 500
    t0 = time.perf_counter()
    for i in range(n):
        gr.run(xs[i % len(xs)], i == 0)
    dt = (time.perf_counter() - t0) / n
    print(f'graph whole-request E2E (H2D+replay+D2H sync): {dt*1e6:.1f} us')
    # reference sequential pipeline on GPU
    ref = ReferencePipeline(str(REPO), cfg)
    xnp = xs[0][0].cpu().numpy()
    for _ in range(2):
        ref.reset()
        for pos in range(0, T, CH):
            ref.step(xnp[:, pos:pos + CH])
    m = 50
    t0 = time.perf_counter()
    for _ in range(m):
        ref.reset()
        for pos in range(0, T, CH):
            ref.step(xnp[:, pos:pos + CH])
    print(f'reference sequential 9-chunk request: {(time.perf_counter()-t0)/m*1e3:.3f} ms')
    # batch unfused GPU, no graph
    w = fused_weights(layers)
    xg = torch.from_numpy(xnp).unsqueeze(0).cuda()
    def unfused():
        y0 = F.conv1d(torch.cat([xg[:, :, :1].expand(-1, -1, 4), xg], -1), w[0], w[1])
        sa0, sb0 = F.silu(y0[:, :H]), F.silu(y0[:, H:])
        y1 = F.conv1d(torch.cat([torch.cat([sa0[:, :, :1].expand(-1, -1, 4), sa0], -1),
                                 torch.cat([sb0[:, :, :1].expand(-1, -1, 4), sb0], -1)], 1),
                      w[2], w[3], groups=2)
        g = torch.sigmoid(xg.mean(1, keepdim=True))
        return g * y1[:, :C] + (1 - g) * y1[:, C:] + 0.1 * xg
    for _ in range(3):
        unfused()
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(n):
        unfused()
    torch.cuda.synchronize()
    print(f'unfused whole-request GPU async: {(time.perf_counter()-t0)/n*1e6:.1f} us')


if __name__ == '__main__':
    main()
