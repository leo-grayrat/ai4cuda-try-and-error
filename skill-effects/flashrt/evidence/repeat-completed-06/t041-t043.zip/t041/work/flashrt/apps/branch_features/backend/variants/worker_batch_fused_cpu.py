"""Variant entry: fused whole-request computation entirely on the CPU."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from entry import run  # noqa: E402

if __name__ == '__main__':
    run('batch_fused_cpu')
