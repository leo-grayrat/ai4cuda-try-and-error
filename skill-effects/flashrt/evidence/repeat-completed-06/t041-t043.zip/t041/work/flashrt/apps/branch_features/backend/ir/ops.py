"""IR operators for the two-branch causal feature graph.

Each operator carries its own implementation and declares exactly the
persistent history object it touches.  The four convolution histories are
independent state objects, which is what makes the two branches visible as
independent pipeline stages in ``flashrt.ir.analysis``.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort, ir_operator


class CausalConvOp(IROperator):
    """One causal convolution with its own chunk-persistent input history."""

    def __init__(self, name: str, layer_name: str, history: str, in_ch: int, out_ch: int,
                 kernel: int):
        super().__init__(
            name=name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('x', (1, in_ch, 'chunk'))],
            outputs=[TensorPort('y', (1, out_ch, 'chunk'))],
            state_reads=[history],
            state_writes=[history],
            stream_mode=StreamMode.STREAMING,
        )
        self.layer_name = layer_name
        self.history = history
        self.kernel = kernel

    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.layer_name]
        history = state.get(self.history)
        x = inputs['x']
        joined = x if history is None else torch.cat([history, x], dim=-1)
        out = layer(joined)
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        keep = self.kernel - 1
        state.set(self.history, joined[:, :, -keep:].clone())
        return {'y': out}


@ir_operator(
    name='silu',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('x')],
    outputs=[TensorPort('y')],
    stream_mode=StreamMode.STREAMING,
)
def silu(inputs, ctx, state):
    return {'y': F.silu(inputs['x'])}


class GateMergeOp(IROperator):
    """gate = sigmoid(mean_channels(x)); out = gate*A + (1-gate)*B + 0.1*x."""

    def __init__(self):
        super().__init__(
            name='gate_merge',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('x'), TensorPort('a'), TensorPort('b')],
            outputs=[TensorPort('y')],
            stream_mode=StreamMode.STREAMING,
        )

    def execute(self, inputs, ctx, state):
        x = inputs['x']
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return {'y': gate * inputs['a'] + (1 - gate) * inputs['b'] + 0.1 * x}


@ir_operator(
    name='silu_b',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('x')],
    outputs=[TensorPort('y')],
    stream_mode=StreamMode.STREAMING,
)
def silu_b(inputs, ctx, state):
    return {'y': F.silu(inputs['x'])}
