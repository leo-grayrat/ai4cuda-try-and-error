# branch_features backend (CUDA, RTX 5060 8GB)

Recommended entry: `worker.py` (strategy `batch_fused_graph`).

```
python flashrt/apps/branch_features/backend/worker.py \
    --repository <repo-root-containing-flashrt> --config <config.json>
```

The worker honors the unchanged `branch_features.adapter` /
`causal_features.adapter` contract: control opcodes 1/3/2, the original
`SharedTensorBuffer` names, ordered data-then-metadata publication,
per-request chunk indices, valid tail length, and reset that clears all four
histories. It prints `{"ready": true, ...}` after buffers exist and exits
cleanly on opcode 2 (unlink + close).

## What the chosen variant does

1. Whole-request batching: one causal pass over all 1043 samples instead of
   nine chunk-sized GPU passes (the adapter still receives nine chunks).
2. Branch fusion: A0/B0 become one 16->64 5-tap convolution (B0's 3-tap
   kernel zero-padded); A1/B1 become one grouped 64->32 5-tap convolution
   (A1's 3-tap kernel zero-padded, one group per branch). Same multiply-adds,
   two kernels instead of four.
3. CUDA-graph capture of the fused graph, including history updates; four
   history tensors and a first-request flag live in static device buffers.
4. Pinned host staging, a first-chunk device-to-host copy before the rest so
   the first output is published early, then all nine chunks back to back.
5. Input polling spins on the shared input counter (with a yield every 1024
   iterations) instead of a fixed 0.2 ms sleep.

`worker.py` was verified by the independent controller over six complete
requests (continuation, repeated input without reset, reset, tail chunk):
max abs difference 2.4e-7 against the CPU full-sequence oracle, cleanup
verified (`evidence/verify-010`). The paired finite offered-load benchmark
(`evidence/benchmark-012`) reached 200 req/s in candidate vs 100 req/s in the
reference; median first-output 1.01 ms vs 1.51-1.58 ms; median output gap
0.009 ms vs 1.07 ms. The candidate's 50 req/s window failed the smoothness
gate because 2.0% of gaps exceeded 20 ms during the first sweep after reset;
the 100 and 200 req/s windows passed both gates.

## Layout

- `backend_runtime.py` -- strategies + adapter worker loop.
- `entry.py`, `worker.py` -- standalone entry points.
- `variants/worker_*.py` -- one standalone entry per measured variant.
- `ir/` -- Phase-1 IR graph builders and operators.
- `tests/test_ir.py` -- IR validation (PASS, log in `tests/ir_validation.log`).
- `tests/local_variant_sweep.py` -- supplemental E2E sweep of all ten entries
  through the shared adapter; results in `benchmarks/results/`.
- `configs/dev.json` -- development config; the controller supplies its own.
- `notes/experiment_log.md` -- hypotheses, queue, measurements, unmet items.
