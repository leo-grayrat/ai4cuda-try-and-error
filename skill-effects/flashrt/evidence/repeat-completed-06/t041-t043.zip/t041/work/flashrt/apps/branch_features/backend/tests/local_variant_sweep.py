"""Supplemental E2E sweep: every variant entry driven through the shared adapter.

For each entry: launch subprocess, run 12 consecutive requests (session
continuation), reset, run one more (reset reproduction), compare every output
against the CPU full-sequence oracle, and record first-output latency plus
output-gap distributions. Official controller evidence lives in evidence/.
"""
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve()
REPO = next(a for a in HERE.parents if (a / 'flashrt' / 'layers' / 'audio.py').is_file())
BK = HERE.parent.parent
sys.path.insert(0, str(REPO))
from branch_features.model import full_sequence_oracle  # noqa: E402
from causal_features.adapter import FeatureAdapter  # noqa: E402

C, H, T, CH = 16, 32, 1043, 127
ATOL, RTOL = 3e-5, 3e-4
BASE = {'channels': C, 'hidden': H, 'length': T, 'chunk': CH,
        'weight_seed': 703, 'device': 'cuda', 'task': 'branch_features'}


def run_entry(entry: Path, inputs):
    config = dict(BASE, prefix='flashrt_local_' + uuid.uuid4().hex)
    cfg_path = BK / 'benchmarks' / 'results' / f'config_{entry.stem}.json'
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(json.dumps(config), encoding='utf-8')
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = '0'
    env['PYTHONPATH'] = str(REPO) + os.pathsep + env.get('PYTHONPATH', '')
    out = open(BK / 'benchmarks' / 'results' / f'{entry.stem}.log', 'w', encoding='utf-8')
    proc = subprocess.Popen([sys.executable, '-u', str(entry), '--repository', str(REPO),
                             '--config', str(cfg_path)], cwd=str(REPO), env=env,
                            stdout=out, stderr=subprocess.STDOUT)
    adapter = None
    firsts, gaps, got = [], [], []
    try:
        adapter = FeatureAdapter(config)
        adapter.start()
        for req in inputs:
            _, published = adapter.submit(req)
            chunks, stamps = [], []
            for _ in range(len(range(0, T, CH))):
                values, stamp = adapter.receive()
                chunks.append(values)
                stamps.append(stamp)
            firsts.append((stamps[0] - published) / 1e6)
            gaps.extend(np.diff(stamps) / 1e6)
            got.append(np.concatenate(chunks, axis=-1))
        adapter.reset()
        _, published = adapter.submit(inputs[0])
        chunks, stamps = [], []
        for _ in range(len(range(0, T, CH))):
            values, stamp = adapter.receive()
            chunks.append(values)
            stamps.append(stamp)
        got.append(np.concatenate(chunks, axis=-1))
        firsts.append((stamps[0] - published) / 1e6)
    finally:
        try:
            if adapter is not None:
                adapter.terminate()
        except Exception:
            pass
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        if adapter is not None:
            adapter.close()
        out.close()
    # oracle: continuation session, then reset request
    cat = np.concatenate(inputs, axis=-1)
    oracle = full_sequence_oracle(str(REPO), BASE, cat)
    bounds = [i * T for i in range(1, len(inputs))] or []
    segs = np.split(oracle, bounds, axis=-1) if bounds else [oracle]
    oracle_reset = full_sequence_oracle(str(REPO), BASE, inputs[0])
    ok, maxd = True, 0.0
    for g, e in list(zip(got[:-1], segs)) + [(got[-1], oracle_reset)]:
        d = float(np.abs(g - e).max())
        maxd = max(maxd, d)
        ok = ok and np.allclose(g, e, atol=ATOL, rtol=RTOL)
    return {'variant': entry.stem, 'correct': bool(ok), 'max_abs': maxd,
            'first_ms_median': float(np.median(firsts)),
            'first_ms_p95': float(np.percentile(firsts, 95)),
            'gap_ms_median': float(np.median(gaps)),
            'gap_ms_p95': float(np.percentile(gaps, 95)),
            'gap_over_20ms_fraction': float(np.mean(np.array(gaps) > 20.0))}


def main():
    rng = np.random.default_rng(2024)
    inputs = [rng.standard_normal((C, T), dtype=np.float32) for _ in range(12)]
    entries = [BK / 'worker.py'] + sorted((BK / 'variants').glob('worker_*.py')) + [
        Path(sys.argv[1])] if len(sys.argv) > 1 else [BK / 'worker.py'] + sorted(
        (BK / 'variants').glob('worker_*.py'))
    rows = []
    for entry in entries:
        try:
            row = run_entry(entry, inputs)
        except Exception as exc:
            row = {'variant': entry.stem, 'error': f'{type(exc).__name__}: {exc}'}
        rows.append(row)
        print(json.dumps(row), flush=True)
    (BK / 'benchmarks' / 'results' / 'local_variant_sweep.json').write_text(
        json.dumps(rows, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
