"""Development diagnostic: environment probe + fused whole-request numerics."""
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

p = Path(__file__).resolve()
REPO = next(a for a in p.parents if (a / 'flashrt' / 'layers' / 'audio.py').is_file())
sys.path.insert(0, str(REPO))

from branch_features.model import build_layers, full_sequence_oracle  # noqa: E402


def make_fused(layers):
    a0, a1, b0, b1 = layers['a0'], layers['a1'], layers['b0'], layers['b1']
    w0 = torch.cat([a0.conv.weight, F.pad(b0.conv.weight, (2, 0))], dim=0)
    bb0 = torch.cat([a0.conv.bias, b0.conv.bias], dim=0)
    w1 = torch.cat([F.pad(a1.conv.weight, (2, 0)), b1.conv.weight], dim=0)
    bb1 = torch.cat([a1.conv.bias, b1.conv.bias], dim=0)
    return w0, bb0, w1, bb1


class FusedWhole:
    def __init__(self, layers, device):
        self.device = device
        w0, b0, w1, b1 = make_fused(layers)
        self.w0, self.b0, self.w1, self.b1 = w0.to(device), b0.to(device), w1.to(device), b1.to(device)
        self.reset()

    def reset(self):
        self.first = True
        self.ha0 = torch.zeros(1, 16, 4, device=self.device)
        self.ha1 = torch.zeros(1, 32, 4, device=self.device)
        self.hb0 = torch.zeros(1, 16, 4, device=self.device)
        self.hb1 = torch.zeros(1, 32, 4, device=self.device)

    def step(self, x):
        if self.first:
            ha0 = x[:, :, :1].expand(-1, -1, 4)
            hb0 = x[:, :, :1].expand(-1, -1, 4)
        else:
            ha0, hb0 = self.ha0, self.hb0
        inp0 = torch.cat([ha0, x], dim=-1)
        y0 = F.conv1d(inp0, self.w0, self.b0)
        sa0 = F.silu(y0[:, :32])
        sb0 = F.silu(y0[:, 32:])
        if self.first:
            ha1 = sa0[:, :, :1].expand(-1, -1, 4)
            hb1 = sb0[:, :, :1].expand(-1, -1, 4)
        else:
            ha1, hb1 = self.ha1, self.hb1
        inp1 = torch.cat([torch.cat([ha1, sa0], -1), torch.cat([hb1, sb0], -1)], dim=1)
        y1 = F.conv1d(inp1, self.w1, self.b1, groups=2)
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        out = gate * y1[:, :16] + (1 - gate) * y1[:, 16:] + 0.1 * x
        self.ha0 = x[:, :, -4:].contiguous()
        self.hb0 = x[:, :, -4:].contiguous()
        self.ha1 = sa0[:, :, -4:].contiguous()
        self.hb1 = sb0[:, :, -4:].contiguous()
        self.first = False
        return out.clone()


def main():
    print(json.dumps({'torch': torch.__version__, 'cuda': torch.cuda.is_available(),
                      'device': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
                      'repo': str(REPO)}))
    config = {'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
              'weight_seed': 703, 'device': 'cuda'}
    layers = build_layers(str(REPO), config, 'cuda')
    fw = FusedWhole(layers, 'cuda')
    rng = np.random.default_rng(7)
    req1 = rng.standard_normal((16, 1043), dtype=np.float32)
    req2 = rng.standard_normal((16, 1043), dtype=np.float32)
    req3 = req1.copy()
    got = []
    for r in (req1, req2, req3):
        x = torch.from_numpy(r.copy()).unsqueeze(0).cuda()
        got.append(fw.step(x).detach().squeeze(0).cpu().numpy())
    cat = np.concatenate([req1, req2, req3], axis=-1)
    oracle = full_sequence_oracle(str(REPO), config, cat)
    exp = np.split(oracle, [1043, 2086], axis=-1)
    for i, (g, e) in enumerate(zip(got, exp)):
        d = np.abs(g - e)
        print(f'request {i}: max_abs={d.max():.3e} allclose={np.allclose(g, e, atol=3e-5, rtol=3e-4)}')
    fw.reset()
    x = torch.from_numpy(req1.copy()).unsqueeze(0).cuda()
    g0 = fw.step(x).detach().squeeze(0).cpu().numpy()
    print('reset reproduces first request:', np.allclose(g0, got[0], atol=3e-5, rtol=3e-4))
    if torch.cuda.is_available():
        torch.cuda.synchronize()
        n = 300
        t0 = time.perf_counter()
        for _ in range(n):
            fw.step(x)
        torch.cuda.synchronize()
        print(f'gpu fused whole-request step: {(time.perf_counter()-t0)/n*1e6:.1f} us')
    cpu_layers = build_layers(str(REPO), config, 'cpu')
    w0, b0, w1, b1 = make_fused(cpu_layers)
    xc = torch.from_numpy(req1.copy()).unsqueeze(0)
    torch.set_num_threads(4)
    def cpu_step():
        y0 = F.conv1d(torch.cat([xc[:, :, :1].expand(-1, -1, 4), xc], -1), w0, b0)
        sa0, sb0 = F.silu(y0[:, :32]), F.silu(y0[:, 32:])
        y1 = F.conv1d(torch.cat([torch.cat([sa0[:, :, :1].expand(-1, -1, 4), sa0], -1),
                                 torch.cat([sb0[:, :, :1].expand(-1, -1, 4), sb0], -1)], 1), w1, b1, groups=2)
        g = torch.sigmoid(xc.mean(1, keepdim=True))
        return g * y1[:, :16] + (1 - g) * y1[:, 16:] + 0.1 * xc
    for _ in range(5):
        cpu_step()
    n = 100
    t0 = time.perf_counter()
    for _ in range(n):
        cpu_step()
    print(f'cpu fused whole-request step: {(time.perf_counter()-t0)/n*1e6:.1f} us')


if __name__ == '__main__':
    main()
