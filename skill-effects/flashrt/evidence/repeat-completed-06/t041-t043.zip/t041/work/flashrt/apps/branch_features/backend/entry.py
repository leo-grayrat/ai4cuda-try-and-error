"""Shared standalone-entry plumbing for every branch_features variant."""
import argparse
import json
import sys
from pathlib import Path


def run(mode: str, spin: bool = True) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    repository = str(args.repository.resolve())
    sys.path.insert(0, repository)
    here = str(Path(__file__).resolve().parent)
    if here not in sys.path:
        sys.path.insert(0, here)
    from backend_runtime import serve
    config = json.loads(args.config.read_text(encoding='utf-8'))
    serve(repository, config, mode, config.get('device', 'cuda'), spin=spin)
