"""IR graph builders for the branch_features task.

``build_model_graph`` is the executable fine-grained graph (validated with
``SequentialExecutor``).  ``build_worker_graph`` is the stage-level view used
for pipeline / co-location analysis: the two branch chains touch disjoint
persistent histories and can therefore run on different devices.
"""
from __future__ import annotations

from flashrt.ir import (IRGraph, IREdge, IROperator, OpType, StateObject,
                        StreamMode, StreamingInfo, StreamingPattern, TensorPort)

from .ops import CausalConvOp, GateMergeOp, silu, silu_b

HISTORIES = {
    'a0_history': 'path A: last 4 raw-input samples for the 5-tap input conv',
    'a1_history': 'path A: last 2 SiLU(A0) samples for the 3-tap output conv',
    'b0_history': 'path B: last 2 raw-input samples for the 3-tap input conv',
    'b1_history': 'path B: last 4 SiLU(B0) samples for the 5-tap output conv',
}


def build_model_graph(config: dict) -> IRGraph:
    C, H = int(config['channels']), int(config['hidden'])
    g = IRGraph(name='branch_features_model')
    for name, desc in HISTORIES.items():
        g.add_state(StateObject(name=name, description=desc, scope='chunk_persistent'))
    g.external_inputs = [TensorPort('x', (1, C, 'chunk'))]
    g.external_outputs = [TensorPort('y', (1, C, 'chunk'))]

    g.add_operator(CausalConvOp('a0', 'a0', 'a0_history', C, H, 5))
    g.add_operator(silu)
    g.add_operator(silu_b)
    g.add_operator(CausalConvOp('a1', 'a1', 'a1_history', H, C, 3))
    g.add_operator(CausalConvOp('b0', 'b0', 'b0_history', C, H, 3))
    g.add_operator(CausalConvOp('b1', 'b1', 'b1_history', H, C, 5))
    g.add_operator(GateMergeOp())

    stream = StreamingInfo(pattern=StreamingPattern.FIXED_RATE,
                           src_chunk_size=int(config['chunk']),
                           dst_chunk_size=int(config['chunk']),
                           description='chunk-by-chunk causal feature flow')
    g.add_edge(IREdge('a0', 'y', 'silu', 'x', streaming=stream))
    g.add_edge(IREdge('silu', 'y', 'a1', 'x', streaming=stream))
    g.add_edge(IREdge('b0', 'y', 'silu_b', 'x', streaming=stream))
    g.add_edge(IREdge('silu_b', 'y', 'b1', 'x', streaming=stream))
    g.add_edge(IREdge('a1', 'y', 'gate_merge', 'a', streaming=stream))
    g.add_edge(IREdge('b1', 'y', 'gate_merge', 'b', streaming=stream))

    g.chunk_ops = ['a0', 'silu', 'a1', 'b0', 'silu_b', 'b1', 'gate_merge']
    return g


def build_worker_graph(config: dict) -> IRGraph:
    """Stage-level graph; branch A and branch B own disjoint histories."""
    C = int(config['channels'])
    g = IRGraph(name='branch_features_worker')
    for name, desc in HISTORIES.items():
        g.add_state(StateObject(name=name, description=desc, scope='chunk_persistent'))
    branch_a = IROperator(
        name='branch_a', op_type=OpType.COMPOSITE,
        inputs=[TensorPort('x')], outputs=[TensorPort('a')],
        state_reads=['a0_history', 'a1_history'],
        state_writes=['a0_history', 'a1_history'],
        stream_mode=StreamMode.STREAMING, sub_graph='branch_features_model')
    branch_b = IROperator(
        name='branch_b', op_type=OpType.COMPOSITE,
        inputs=[TensorPort('x')], outputs=[TensorPort('b')],
        state_reads=['b0_history', 'b1_history'],
        state_writes=['b0_history', 'b1_history'],
        stream_mode=StreamMode.STREAMING, sub_graph='branch_features_model')
    merge = IROperator(
        name='gate_merge', op_type=OpType.EXPOSED,
        inputs=[TensorPort('x'), TensorPort('a'), TensorPort('b')],
        outputs=[TensorPort('y')], stream_mode=StreamMode.STREAMING)
    for op in (branch_a, branch_b, merge):
        g.add_operator(op)
    g.sub_graphs['branch_features_model'] = build_model_graph(config)
    stream = StreamingInfo(pattern=StreamingPattern.FIXED_RATE,
                           src_chunk_size=int(config['chunk']),
                           dst_chunk_size=int(config['chunk']),
                           description='both branches stream current chunk to the merge')
    g.add_edge(IREdge('branch_a', 'a', 'gate_merge', 'a', streaming=stream))
    g.add_edge(IREdge('branch_b', 'b', 'gate_merge', 'b', streaming=stream))
    g.external_inputs = [TensorPort('x', (1, C, 'chunk'))]
    g.external_outputs = [TensorPort('y', (1, C, 'chunk'))]
    g.chunk_ops = ['branch_a', 'branch_b', 'gate_merge']
    return g
