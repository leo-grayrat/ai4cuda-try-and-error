"""Variant entry: per-chunk fused CUDA graph, streaming each chunk immediately."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from entry import run  # noqa: E402

if __name__ == '__main__':
    run('chunk_fused_graph')
