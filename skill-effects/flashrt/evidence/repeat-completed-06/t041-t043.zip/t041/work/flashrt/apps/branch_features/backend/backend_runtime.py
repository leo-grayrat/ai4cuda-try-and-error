"""Reusable streaming strategies for the branch_features backend.

The adapter contract (chunk cadence, metadata, reset semantics) and the
reference computation are unchanged; only the way the four causal convolutions
are scheduled changes.  Every strategy consumes one complete (C, T) request and
emits the configured number of (C, chunk) output chunks through the callback,
so the worker loop is strategy independent.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import torch
import torch.nn.functional as F


Emit = Callable[[np.ndarray, int], None]


def _fused_weights(layers):
    """Concatenate the two branches into two convolutions.

    Branch A is 5-tap -> 3-tap, branch B is 3-tap -> 5-tap.  A 3-tap kernel is
    exactly a 5-tap kernel with two leading zero taps, and the two second-stage
    convolutions can share one grouped convolution (one group per branch).
    This is a pure regrouping of the same multiply-adds.
    """
    a0, a1, b0, b1 = layers['a0'], layers['a1'], layers['b0'], layers['b1']
    w0 = torch.cat([a0.conv.weight, F.pad(b0.conv.weight, (2, 0))], dim=0).detach()
    bb0 = torch.cat([a0.conv.bias, b0.conv.bias], dim=0).detach()
    w1 = torch.cat([F.pad(a1.conv.weight, (2, 0)), b1.conv.weight], dim=0).detach()
    bb1 = torch.cat([a1.conv.bias, b1.conv.bias], dim=0).detach()
    return w0, bb0, w1, bb1


class BaseStrategy:
    def __init__(self, repository: str, config: dict, device: str):
        self.repository = repository
        self.config = config
        self.C = int(config['channels'])
        self.H = int(config['hidden'])
        self.T = int(config['length'])
        self.chunk = int(config['chunk'])
        self.device = torch.device(device)
        self.starts = list(range(0, self.T, self.chunk))

    def reset(self) -> None:
        raise NotImplementedError

    def process(self, features: np.ndarray, emit: Emit) -> None:
        raise NotImplementedError


# ---------------------------------------------------------------- sequential
class SequentialChunkGPU(BaseStrategy):
    """Reference scheduling, re-expressed with explicit per-layer histories."""

    def __init__(self, repository, config, device='cuda'):
        from branch_features.model import build_layers
        self.layers = build_layers(repository, config, device)
        super().__init__(repository, config, device)
        self.reset()

    def reset(self):
        self.hist = {n: None for n in self.layers}

    def _conv(self, name, x):
        layer, history = self.layers[name], self.hist[name]
        joined = x if history is None else torch.cat([history, x], dim=-1)
        out = layer(joined)
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        self.hist[name] = joined[:, :, -layer._time_causal_padding[0]:].clone()
        return out

    @torch.inference_mode()
    def process(self, features, emit):
        values = torch.from_numpy(features.copy()).unsqueeze(0).to(self.device)
        for index, pos in enumerate(self.starts):
            x = values[:, :, pos:pos + self.chunk]
            a = self._conv('a1', F.silu(self._conv('a0', x)))
            b = self._conv('b1', F.silu(self._conv('b0', x)))
            gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
            out = (gate * a + (1 - gate) * b + 0.1 * x).squeeze(0)
            emit(out.cpu().numpy(), index)


# ------------------------------------------------------------- whole request
class WholeRequestGPU(BaseStrategy):
    """One batched pass over the whole request (optionally fused)."""

    def __init__(self, repository, config, device='cuda', fuse=True, graph=True,
                 pinned_h2d=True, split_first_copy=True):
        from branch_features.model import build_layers
        self.layers = build_layers(repository, config, device)
        self.fuse = fuse
        self.use_graph = graph
        self.pinned_h2d = pinned_h2d
        self.split_first_copy = split_first_copy
        if fuse:
            self.w0, self.b0, self.w1, self.b1 = [t.to(device) for t in _fused_weights(self.layers)]
        super().__init__(repository, config, device)
        dev = self.device
        self.x = torch.zeros(1, self.C, self.T, device=dev)
        self.ha0 = torch.zeros(1, self.C, 4, device=dev)
        self.hb0 = torch.zeros(1, self.C, 4, device=dev)
        self.ha1 = torch.zeros(1, self.H, 4, device=dev)
        self.hb1 = torch.zeros(1, self.H, 4, device=dev)
        self.first = torch.zeros(1, dtype=torch.int64, device=dev)
        self.out = torch.empty(1, self.C, self.T, device=dev)
        try:
            self.pin_out = torch.empty(self.C, self.T, dtype=torch.float32, pin_memory=True)
            self.pin_in = torch.empty(self.C, self.T, dtype=torch.float32, pin_memory=True) if pinned_h2d else None
        except RuntimeError:
            self.pin_out = torch.empty(self.C, self.T, dtype=torch.float32)
            self.pin_in = None
        self.graph = None
        if self.use_graph:
            try:
                for _ in range(3):
                    self._forward()
                torch.cuda.synchronize()
                self.graph = torch.cuda.CUDAGraph()
                with torch.cuda.graph(self.graph):
                    self.out = self._forward()
                torch.cuda.synchronize()
            except Exception as exc:  # pragma: no cover - fallback path
                print(f'[branch_features] cuda graph unavailable: {exc}', flush=True)
                self.graph = None
        self.reset()

    def reset(self):
        self._first_request = True
        self.first.fill_(1)
        self.ha0.zero_(); self.hb0.zero_(); self.ha1.zero_(); self.hb1.zero_()

    def _forward(self):
        x = self.x
        rep0 = x[:, :, :1].expand(-1, -1, 4)
        ha0 = torch.where(self.first > 0, rep0, self.ha0)
        hb0 = torch.where(self.first > 0, rep0, self.hb0)
        if self.fuse:
            y0 = F.conv1d(torch.cat([ha0, x], -1), self.w0, self.b0)
            sa0, sb0 = F.silu(y0[:, :self.H]), F.silu(y0[:, self.H:])
            rep1 = sa0[:, :, :1].expand(-1, -1, 4)
            rep2 = sb0[:, :, :1].expand(-1, -1, 4)
            ha1 = torch.where(self.first > 0, rep1, self.ha1)
            hb1 = torch.where(self.first > 0, rep2, self.hb1)
            y1 = F.conv1d(torch.cat([torch.cat([ha1, sa0], -1),
                                     torch.cat([hb1, sb0], -1)], 1),
                          self.w1, self.b1, groups=2)
            a, b = y1[:, :self.C], y1[:, self.C:]
        else:
            a0 = self.layers['a0'](torch.cat([ha0, x], -1))[:, :, 4:]
            b0 = self.layers['b0'](torch.cat([hb0, x], -1))[:, :, 4:]
            sa0, sb0 = F.silu(a0), F.silu(b0)
            rep1 = sa0[:, :, :1].expand(-1, -1, 4)
            rep2 = sb0[:, :, :1].expand(-1, -1, 4)
            ha1 = torch.where(self.first > 0, rep1, self.ha1)
            hb1 = torch.where(self.first > 0, rep2, self.hb1)
            a = self.layers['a1'](torch.cat([ha1, sa0], -1))[:, :, 4:]
            b = self.layers['b1'](torch.cat([hb1, sb0], -1))[:, :, 4:]
        gate = torch.sigmoid(x.mean(1, keepdim=True))
        out = gate * a + (1 - gate) * b + 0.1 * x
        self.ha0.copy_(x[:, :, -4:])
        self.hb0.copy_(x[:, :, -4:])
        self.ha1.copy_(sa0[:, :, -4:])
        self.hb1.copy_(sb0[:, :, -4:])
        return out

    @torch.inference_mode()
    def process(self, features, emit):
        self.first.fill_(1 if self._first_request else 0)
        if self.pin_in is not None:
            self.pin_in.copy_(torch.from_numpy(features))
            self.x.copy_(self.pin_in, non_blocking=True)
        else:
            self.x.copy_(torch.from_numpy(features))
        if self.graph is not None:
            self.graph.replay()
        else:
            self.out = self._forward()
        if self.split_first_copy:
            first_len = min(self.chunk, self.T)
            self.pin_out[:, :first_len].copy_(self.out[0, :, :first_len], non_blocking=True)
            torch.cuda.synchronize()
            emit(self.pin_out.numpy()[:, :first_len], 0)
            if self.T > first_len:
                self.pin_out[:, first_len:].copy_(self.out[0, :, first_len:], non_blocking=True)
                torch.cuda.synchronize()
            for index in range(1, len(self.starts)):
                pos = self.starts[index]
                valid = min(self.chunk, self.T - pos)
                emit(self.pin_out.numpy()[:, pos:pos + valid], index)
        else:
            self.pin_out.copy_(self.out[0], non_blocking=True)
            torch.cuda.synchronize()
            data = self.pin_out.numpy()
            for index, pos in enumerate(self.starts):
                valid = min(self.chunk, self.T - pos)
                emit(data[:, pos:pos + valid], index)
        self._first_request = False

    def reset_public(self):
        self.reset()


class WholeRequestCPU(WholeRequestGPU):
    """Same batched algebra on the CPU (no PCIe round trip)."""

    def __init__(self, repository, config, device='cpu', fuse=True, **_):
        super().__init__(repository, config, device='cpu', fuse=fuse, graph=False,
                         pinned_h2d=False, split_first_copy=False)
        self.pin_out = torch.empty(self.C, self.T, dtype=torch.float32)

    def process(self, features, emit):
        self.first.fill_(1 if self._first_request else 0)
        with torch.inference_mode():
            self.x.copy_(torch.from_numpy(features))
            out = self._forward()[0].numpy()
        for index, pos in enumerate(self.starts):
            valid = min(self.chunk, self.T - pos)
            emit(out[:, pos:pos + valid], index)
        self._first_request = False


# ------------------------------------------------------- per-chunk graph path
class ChunkGraphGPU(BaseStrategy):
    """Stream every chunk as soon as it is computed (9 small graph replays)."""

    def __init__(self, repository, config, device='cuda'):
        from branch_features.model import build_layers
        self.layers = build_layers(repository, config, device)
        self.w0, self.b0, self.w1, self.b1 = [t.to(device) for t in _fused_weights(self.layers)]
        super().__init__(repository, config, device)
        dev = self.device
        self.x = torch.zeros(1, self.C, self.chunk, device=dev)
        self.ha0 = torch.zeros(1, self.C, 4, device=dev)
        self.hb0 = torch.zeros(1, self.C, 4, device=dev)
        self.ha1 = torch.zeros(1, self.H, 4, device=dev)
        self.hb1 = torch.zeros(1, self.H, 4, device=dev)
        self.first = torch.zeros(1, dtype=torch.int64, device=dev)
        self.out = torch.empty(1, self.C, self.chunk, device=dev)
        self.sa0 = torch.empty(1, self.H, self.chunk, device=dev)
        self.sb0 = torch.empty(1, self.H, self.chunk, device=dev)
        self.pin = torch.empty(self.C, self.chunk, dtype=torch.float32, pin_memory=True)
        for _ in range(3):
            self._forward()
        torch.cuda.synchronize()
        self.graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.graph):
            self.out, self.sa0, self.sb0 = self._forward()
        self.reset()

    def reset(self):
        self._first_request = True
        self.first.fill_(1)
        self.ha0.zero_(); self.hb0.zero_(); self.ha1.zero_(); self.hb1.zero_()

    def _forward(self):
        x = self.x
        rep0 = x[:, :, :1].expand(-1, -1, 4)
        ha0 = torch.where(self.first > 0, rep0, self.ha0)
        hb0 = torch.where(self.first > 0, rep0, self.hb0)
        y0 = F.conv1d(torch.cat([ha0, x], -1), self.w0, self.b0)
        sa0, sb0 = F.silu(y0[:, :self.H]), F.silu(y0[:, self.H:])
        rep1 = sa0[:, :, :1].expand(-1, -1, 4)
        rep2 = sb0[:, :, :1].expand(-1, -1, 4)
        ha1 = torch.where(self.first > 0, rep1, self.ha1)
        hb1 = torch.where(self.first > 0, rep2, self.hb1)
        y1 = F.conv1d(torch.cat([torch.cat([ha1, sa0], -1),
                                 torch.cat([hb1, sb0], -1)], 1),
                      self.w1, self.b1, groups=2)
        gate = torch.sigmoid(x.mean(1, keepdim=True))
        out = gate * y1[:, :self.C] + (1 - gate) * y1[:, self.C:] + 0.1 * x
        self._sa0_out, self._sb0_out = sa0, sb0
        return out, sa0, sb0

    @torch.inference_mode()
    def process(self, features, emit):
        self.first.fill_(1 if self._first_request else 0)
        for index, pos in enumerate(self.starts):
            valid = min(self.chunk, self.T - pos)
            self.x.zero_()
            self.x[0, :, :valid].copy_(torch.from_numpy(features[:, pos:pos + valid]))
            self.graph.replay()
            self.pin.copy_(self.out[0], non_blocking=True)
            torch.cuda.synchronize()
            emit(self.pin.numpy()[:, :valid], index)
            # advance history with the real (unpadded) samples of this chunk
            self.ha0.copy_(self.x[:, :, valid - 4:valid])
            self.hb0.copy_(self.x[:, :, valid - 4:valid])
            self.ha1.copy_(self.sa0[:, :, valid - 4:valid])
            self.hb1.copy_(self.sb0[:, :, valid - 4:valid])
            self.first.fill_(0)
        self._first_request = False


# ------------------------------------------------------------------ factory
MODES = {
    'chunk_seq_gpu': lambda repo, cfg, dev: SequentialChunkGPU(repo, cfg, dev),
    'batch_unfused_gpu': lambda repo, cfg, dev: WholeRequestGPU(repo, cfg, dev, fuse=False),
    'batch_unfused_graph': lambda repo, cfg, dev: WholeRequestGPU(repo, cfg, dev, fuse=False, graph=True),
    'batch_fused_gpu': lambda repo, cfg, dev: WholeRequestGPU(repo, cfg, dev, fuse=True, graph=False),
    'batch_fused_graph': lambda repo, cfg, dev: WholeRequestGPU(repo, cfg, dev, fuse=True, graph=True),
    'batch_fused_graph_single_copy': lambda repo, cfg, dev: WholeRequestGPU(
        repo, cfg, dev, fuse=True, graph=True, split_first_copy=False),
    'batch_fused_graph_direct_h2d': lambda repo, cfg, dev: WholeRequestGPU(
        repo, cfg, dev, fuse=True, graph=True, pinned_h2d=False),
    'batch_fused_cpu': lambda repo, cfg, dev: WholeRequestCPU(repo, cfg, dev),
    'chunk_fused_graph': lambda repo, cfg, dev: ChunkGraphGPU(repo, cfg, dev),
}


def make_strategy(mode: str, repository: str, config: dict, device: str):
    if mode not in MODES:
        raise ValueError(f'unknown strategy {mode!r}')
    return MODES[mode](repository, config, device)


# ------------------------------------------------------------- worker loop
def serve(repository: str, config: dict, mode: str, device: str | None = None,
          spin: bool = True) -> None:
    import json
    from branch_features.adapter import open_buffers, close_buffers

    device = device or config.get('device', 'cuda')
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    strategy = make_strategy(mode, repository, config, device)
    buffers = open_buffers(config, create=True)
    C, chunk, T = int(config['channels']), int(config['chunk']), int(config['length'])
    starts = list(range(0, T, chunk))
    padded = np.zeros((C, chunk), dtype=np.float32)
    meta = np.zeros((3,), dtype=np.int64)
    consumed, last_command, active = 0, 0, False
    in_buf, out_buf, meta_buf, ctrl = (buffers['input'], buffers['output'],
                                       buffers['metadata'], buffers['control'])

    def emit(values, index):
        valid = values.shape[-1]
        pos = starts[index]
        if valid < chunk:
            padded[:, :] = 0.0
        padded[:, :valid] = values
        out_buf.write(padded)
        meta[0], meta[1], meta[2] = request_id, index, valid
        meta_buf.write(meta)

    request_id = 0
    try:
        print(json.dumps({'ready': True, 'device': device, 'task': 'branch_features',
                          'strategy': mode}), flush=True)
        while True:
            opcode = ctrl.recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    ctrl.commit()
                    break
                if opcode == 3:
                    strategy.reset()
                    active = False
                    ctrl.commit()
                elif opcode == 1:
                    active = True
                    ctrl.commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0001)
                continue
            # Wait for the next request without adding a fixed poll period.
            spins = 0
            while True:
                if ctrl.recv() != last_command:
                    break
                if in_buf.num > consumed:
                    break
                spins += 1
                if spin:
                    if (spins & 0x3FF) == 0:
                        time.sleep(0)
                else:
                    time.sleep(0.00005)
            if ctrl.recv() != last_command:
                continue
            next_cursor, features = in_buf.read(consumed, 1)
            if features is None:
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id, consumed = consumed, next_cursor
            strategy.process(features[0], emit)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)
