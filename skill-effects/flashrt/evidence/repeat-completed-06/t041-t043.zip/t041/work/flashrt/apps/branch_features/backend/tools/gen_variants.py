from pathlib import Path

here = Path(__file__).resolve().parent.parent
v = here / 'variants'
v.mkdir(exist_ok=True)
(v / '__init__.py').write_text('', encoding='utf-8')
HEAD = '''"""Variant entry: {desc}."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from entry import run  # noqa: E402

if __name__ == '__main__':
    run({mode!r}{spin})
'''
variants = {
    'worker_seq_chunk': ('reference-equivalent per-chunk GPU execution', 'chunk_seq_gpu', ''),
    'worker_batch_unfused': ('whole-request batched pass, four separate convolutions', 'batch_unfused_gpu', ''),
    'worker_batch_unfused_graph': ('whole-request unfused convolutions captured in a CUDA graph', 'batch_unfused_graph', ''),
    'worker_batch_fused': ('whole-request batched pass, branch-fused convolutions, eager', 'batch_fused_gpu', ''),
    'worker_batch_fused_graph_single_copy': ('fused graph, one device-to-host copy before emitting chunks', 'batch_fused_graph_single_copy', ''),
    'worker_batch_fused_graph_direct_h2d': ('fused graph, direct pageable host-to-device input copy', 'batch_fused_graph_direct_h2d', ''),
    'worker_batch_fused_cpu': ('fused whole-request computation entirely on the CPU', 'batch_fused_cpu', ''),
    'worker_chunk_fused_graph': ('per-chunk fused CUDA graph, streaming each chunk immediately', 'chunk_fused_graph', ''),
    'worker_poll_sleep': ('fused graph with 50us sleeping input poll instead of spinning', 'batch_fused_graph', ', spin=False'),
}
for name, (desc, mode, spin) in variants.items():
    (v / f'{name}.py').write_text(HEAD.format(desc=desc, mode=mode, spin=spin), encoding='utf-8')
print('wrote', len(variants), 'variants')
