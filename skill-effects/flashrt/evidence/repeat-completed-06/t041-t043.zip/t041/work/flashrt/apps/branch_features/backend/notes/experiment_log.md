# Experiment log — branch_features

## IR Conversion (2026-02-14)
- Worker graph `branch_features_worker`: 3 operators, 2 data edges (fixed-rate streaming 127->127).
  - Black-box stages: none; composite: `branch_a`, `branch_b`; exposed: `gate_merge`.
- Model graph `branch_features_model`: 7 operators, 6 edges.
  - State objects (`chunk_persistent`): `a0_history`, `a1_history`, `b0_history`, `b1_history`.
  - Chunk ops: a0->silu->a1->merge and b0->silu_b->b1->merge.
- IR validation: PASS
  - fixture: deterministic float32 requests generated in `tests/test_ir.py`
    (random, random, reset + repeat of the first).
  - reference_run: in-process `ReferencePipeline` CUDA with the same weights.
  - executor vs reference: max abs 0.0; executor vs CPU full-sequence oracle: max abs 2.384e-7.
  - tolerance atol=3e-5, rtol=3e-4 (CPU/GPU float32 summation order only).
  - evidence: `backend/tests/ir_validation.log`.
- Analysis summary:
  - Pipeline stages: 3 — [branch_a], [branch_b], [gate_merge]; branches share no persistent state.
  - Streaming overlaps: 2 fixed-rate 1:1 edges into gate_merge.
  - Independent pairs: branch_a || branch_b, branch_a || gate_merge, branch_b || gate_merge.
  - Critical path: a0->silu->a1->gate_merge with the parallel b chain; per-op latencies not measured, so no numeric total is claimed.
  - Consequence: the reference's A-then-B order is not a dependency; both branches can be computed together and merged per chunk.

## Baseline (official controller, `evidence/benchmark-012`)
- Reference highest passing offered rate: 100 req/s (200 req/s offered queue reached 79, rate gate failed).
- 50 req/s: first-output median 1.542 ms / p95 2.377 ms; gap median 1.042 ms / p95 14.252 ms, 0% over 20 ms.
- 100 req/s: first 1.583 / 2.138 ms; gap 1.080 / 3.162 ms, 0% over.
- 200 req/s: first 1.505 / 1.833 ms; gap 1.075 / 1.571 ms, 0% over (rate gate failed).

## Variant Queue (last updated 2026-02-14)

| # | name | hypothesis | IR basis | predicted impact | status |
|---|------|------------|----------|------------------|--------|
| 1 | `worker` (`batch_fused_graph`) | batch whole request, fused convs + CUDA graph, publish chunk 0 early | branches state-disjoint; merge per chunk | both targets, large | measured (official + local) |
| 2 | `worker_seq_chunk` | reference schedule with explicit histories (control) | per-chunk graph | none | measured (local) |
| 3 | `worker_batch_unfused` | whole-request batching alone | branch chains chunk-independent | both, large | measured (local) |
| 4 | `worker_batch_fused` | branch fusion without graph | same data flow, fewer kernels | both, medium | measured (local) |
| 5 | `worker_batch_unfused_graph` | graph capture alone | fewer launches | both, medium | measured (local) |
| 6 | `worker_batch_fused_graph_single_copy` | one D2H copy vs first-chunk-early | output fully materialized | latency vs gap | measured (local) |
| 7 | `worker_batch_fused_graph_direct_h2d` | pageable instead of pinned H2D | input path only | latency, small | measured (local) |
| 8 | `worker_batch_fused_cpu` | fused one-shot on CPU | same algebra on host | latency unknown | measured (local) |
| 9 | `worker_chunk_fused_graph` | per-chunk graph replay, stream immediately | per-chunk state | first-output lower, rate lower | measured (local) |
| 10 | `worker_poll_sleep` | 50 us sleeping poll instead of spin | input detection | latency/rate, small negative | measured (local) |

Rationale: IR ranked whole-request batching and branch fusion first; graph capture, copy staging, CPU placement, per-chunk streaming and polling are isolated follow-ups. All ten were run; none removed.

Changelog: 2026-02-14 queue committed from IR analysis; `worker` verified/benchmarked by the controller; nine isolated variants measured with `tests/local_variant_sweep.py`; `evidence/benchmark-011` recorded as invalid (candidate controller timed out in the shared GPU-lock wait before creating the session, no backend launched, no numbers), retry `benchmark-012` completed.

## Recommended variant record
- Correctness: PASS, six requests including continuation, repeated input without reset, reset and tail chunk; max abs 2.4e-7; cleanup verified (`evidence/verify-010`).
- Official benchmark (`evidence/benchmark-012`): highest passing offered rate 200 req/s vs reference 100 req/s.
  - 100 req/s: first median 1.015 ms / p95 1.134 ms; gap median 0.0094 ms / p95 9.723 ms, 0% over 20 ms.
  - 200 req/s: first median 1.012 ms / p95 6.642 ms (single cold outlier); gap median 0.0096 ms / p95 4.668 ms, 0% over.
  - 50 req/s: first median 5.116 / p95 5.313 ms; gap median 0.0092 / p95 19.679 ms; 2.0% over budget -> smoothness gate failed in that window.
- benchmark_json: `backend/benchmarks/results/official_summary.json`.
- Verdict: promote; trade-off: p95 first-output at 200 req/s is worse than reference (6.64 vs 1.83 ms) due to one cold outlier, while medians, sustainable rate and gaps improve.

## Supplementary local sweep (all ten entries)
`tests/local_variant_sweep.py`: 12 consecutive requests, reset, one repeat; every output compared with the CPU oracle. All ten `correct=true`, max abs <= 2.98e-7; results in `benchmarks/results/local_variant_sweep.json`. First median/p95 (ms), gap median/p95 (ms):
- worker 0.523/1.450; 0.004/0.008
- worker_batch_fused 1.033/87.529; 0.004/0.009 (cold outlier)
- worker_batch_fused_cpu 0.543/3.870; 0.006/0.010
- worker_batch_fused_graph_direct_h2d 0.535/0.749; 0.005/0.008
- worker_batch_fused_graph_single_copy 0.529/0.549; 0.004/0.009
- worker_batch_unfused 0.528/0.568; 0.004/0.008
- worker_batch_unfused_graph 0.526/0.539; 0.004/0.007
- worker_chunk_fused_graph 0.545/0.592; 0.005/0.559
- worker_poll_sleep 0.985/1.255; 0.004/0.009
- worker_seq_chunk 1.033/80.230; 0.519/1.086

Interpretation: whole-request batching is the dominant lever; fusion and graph capture reduce launch overhead/variance; sleeping poll roughly doubles first-output; CPU is competitive on median but not p95 and leaves the GPU unused.

## Remaining unmet requirements
- Only `worker.py` has independent-controller verification and benchmark evidence; the other nine entries have real subprocess adapter E2E correctness and timing only from the supplemental local harness.
- The candidate's 50 req/s official window failed the smoothness gate (2.0% of gaps > 20 ms).
- Per-operator IR latencies / numeric critical path were not measured.
- Two-GPU branch pipelining (legal per the IR) was not implemented or measured; the assignment is one RTX 5060.
