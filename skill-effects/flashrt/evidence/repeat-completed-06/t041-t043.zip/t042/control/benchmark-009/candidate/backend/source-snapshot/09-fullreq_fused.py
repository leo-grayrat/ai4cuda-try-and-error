"""fullreq_fused variant entry (see ../../branch_engine.py)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import branch_engine  # noqa: E402

if __name__ == '__main__':
    branch_engine.main('fullreq_fused')
