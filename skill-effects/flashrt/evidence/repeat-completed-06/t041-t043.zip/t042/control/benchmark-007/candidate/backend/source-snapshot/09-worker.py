"""Recommended backend entry: fused two-branch convolutions, whole-request pass,
CUDA-graph replay and pinned staging.

Usage (from the repository root):
    python flashrt/apps/branch_features/backend/worker.py \
        --repository <repo root> --config <config.json>

Accepts exactly the supplied adapter contract: it creates the shared buffers
described by branch_features.adapter.open_buffers, honours control opcodes
1 (start/continue), 2 (terminate), 3 (reset) with the same level-valued
semantics as the reference worker, and publishes output chunks with the same
(C, chunk) payload plus int64 [request_id, chunk_index, valid] metadata.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import branch_engine  # noqa: E402

VARIANT = 'fullreq_fused_graph'

if __name__ == '__main__':
    branch_engine.main(VARIANT)
