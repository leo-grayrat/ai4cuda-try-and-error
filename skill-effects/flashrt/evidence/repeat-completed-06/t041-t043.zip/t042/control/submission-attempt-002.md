## 结论

推荐入口是 `flashrt/apps/branch_features/backend/worker.py`（变体 `fullreq_fused_graph`）。在最后一次代码改动之后，我又用独立控制器复核了它：`evidence/verify-023` 为 PASS，6 个完整请求逐块比较，最大绝对误差 ≤ 2.4e-07，进程清理已确认；`evidence/benchmark-024` 是一次先参考、后候选的配对有限负载扫描。候选侧首块输出延迟中位数 0.543–0.544 ms（p95 0.587–0.781 ms），可持续速率上限 200 req/s，块间间隔中位数 0.0083–0.0087 ms；同次运行的参考后端首块延迟中位数 1.505–1.571 ms（p95 2.03–2.57 ms），上限只有 100 req/s（200 req/s 时积压 70 个请求），块间间隔中位数 0.57–1.05 ms。也就是说首块延迟降低约 65%，速率上限翻倍，请求内部块间隔缩小两个数量级。

## 假设与证据

我先把参考实现（`branch_features/reference.py` 与 `branch_features/model.py`）转成 IR：模型级图 `branch_features_model` 有 6 个算子、7 条数据边、4 个 `chunk_persistent` 历史（`hist_a0` 4 步、`hist_a1` 2 步、`hist_b0` 2 步、`hist_b1` 4 步），工作级图 `branch_features_worker` 为 ingest → branch_a/branch_b → merge → publish。用 `SequentialExecutor` 实跑并与受保护的 CPU 全序列 oracle 对比，首个请求、无 reset 的续接请求（对照拼接序列 oracle 的尾段）、reset 后复现三个场景误差为 7.15e-07 / 8.35e-07 / 7.15e-07，容差 1e-5（参考自身浮点重结合就有 8.3e-07，而丢掉一份历史会造成 O(1) 偏移，故该容差不掩盖状态错误），判定 PASS，原始文本见 `notes/ir_analysis.txt`。分析结果：6 个阶段（每个卷积独占私有历史）、15 组跨块独立算子对、0 条速率转换边（1 输入块对应 1 输出块）、结构关键路径 `input_ingest→conv_a0→conv_a1→gate_merge`。

据此把两条杠杆分开测量。其一，“整请求一次前向”取代参考的九次分块前向：适配器一次交付完整 `(C, T)` 序列，参考的分块节奏不是数据依赖，实测把上限从 100 提到 200 req/s、首块降到 1.09 ms（`variants/fullreq_4conv.py`）。其二，“分支融合”：a0(k=5) 与 b0(k=3) 读同一输入，把 k=3 核左补两个零后堆成一次分组卷积；a1/b1 组成块对角卷积，零乘积精确，数学恒等；实测请求内部块间隔减半到 0.556 ms，但上限仍是 100 req/s（`variants/chunkwise_fused.py`）。两者叠加后首块 1.04 ms、上限 200 req/s（`variants/fullreq_fused.py`）；同数学的 CPU 版给出 0.99 ms（`variants/fullreq_fused_cpu.py`），说明剩余约 1 ms 几乎全是调度与搬运开销而非卷积计算量，于是最后一步改成 CUDA 图重放加锁页中转（reset 后首次与稳态各一张图，一次 H2D、一次 D2H、九次共享内存发布），首块降到 0.543 ms。每个变体都有独立实现、独立 PASS 验证与独立记录（`benchmarks/results/*_RTX5060-8GB_2026-10-20.json`，并附 `verify-*`、`benchmark-*` 的控制器证据副本）。

## 失败与权衡

`benchmark-009` 中参考侧触发控制器 180 s 超时（exitcode -999、stdout 为空），该次配对无效：我只记录候选侧数字，并把对照基准改为 `benchmark-007/011/013/015` 的锚点，此事写在日志里。必须诚实记录的一处回退是 50 req/s 低负载的平滑性门：`benchmark-024` 中候选在 50 req/s 返回 `smoothness_gate_passed=false`，约 6.0% 的间隔超过 20 ms，但这些间隔正是 20 ms 的请求提交节拍本身（请求内部块间隔只有 0.0083 ms），参考之所以在该负载通过，是因为它自己十余毫秒的计算恰好填满节拍窗口。100 和 200 req/s 下候选过预算比例均为 0。我没有通过人为拖慢后端来修饰这条判定。

## 未完成的要求

上游清单要求至少 10 个不同部署变体，本次只测到 5 个候选变体加参考锚点，**该下限未达到**。未实现或未测量的方向包括：两条 CUDA 流上两分支真正并发（IR 判定二者独立，但单卡上两条约 20 µs 级核链的重叠排序低于已测杠杆）、先算前 127 步即发布首块的混合方案、把尾部 27 步单独成图以避免补齐拷贝；`CONTRACT.zh.md` 提到的“缓存”方向只保持了历史复用的语义，没有做显式缓存重排实验。多 GPU 要求在本单卡任务下不适用。以上是清单层面未完成的项，不是“被更优变体支配”的结论。

## 交接前自检

“Implementation and debugging cost are never valid rationale”：队列 6 行全部 `measured`，每行都有对应结果文件与验证记录。“Read-only areas are not a blocker — vendor the file into your workspace”：本会话未需 vendoring，`reference/`、`adapter.py`、`flashrt/ir/`、`flashrt/layers/` 未改动，权重与卷积类由 `branch_engine.py::_load_layers` 复用原实现。“Terminal statuses”：队列见 `notes/experiment_log.md`，无 `planned`/`in_progress`，也无 `blocked`/`discarded` 行，故“What `blocked` means (strict)”与“Adversarial self-framing (required)”不适用。“Forbidden session-handoff language”：词表扫描在 `README.md`、`notes/experiment_log.md`、`notes/design.md`、`notes/ir_analysis.txt` 上命中为空（`dev_docfix.py` 输出 `forbidden_phrase_hits: []`）。最后说明：`workspace.finish` 只记录本报告并尝试产物入库，不代表上游每条完成标准都已达成。