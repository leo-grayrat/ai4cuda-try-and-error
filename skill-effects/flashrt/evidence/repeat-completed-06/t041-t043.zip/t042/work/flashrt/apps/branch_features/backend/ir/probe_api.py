"""Print the exact flashrt.ir signatures needed by the branch_features IR build."""
import inspect
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import flashrt.ir as ir
from flashrt.ir import (IRGraph, IREdge, IROperator, StateObject, TensorPort, OpType,
                        StreamMode, SequentialExecutor, summarize_graph,
                        find_pipeline_stages, analyze_cross_chunk_dependencies,
                        find_streaming_overlaps, compute_critical_path,
                        ir_operator)

print('flashrt.ir exports:', [n for n in dir(ir) if not n.startswith('_')])
for obj in (IREdge, StateObject, TensorPort, IROperator, IRGraph, SequentialExecutor):
    print('\n==', obj.__name__)
    try:
        print('  init', inspect.signature(obj.__init__))
    except (TypeError, ValueError) as exc:
        print('  init ?', exc)
    for name, member in inspect.getmembers(obj, predicate=inspect.isfunction):
        if name.startswith('_'):
            continue
        try:
            print('  ', name, inspect.signature(member))
        except (TypeError, ValueError):
            print('  ', name, '?')
print('\nOpType:', list(OpType), 'StreamMode:', list(StreamMode))
for fn in (summarize_graph, find_pipeline_stages, analyze_cross_chunk_dependencies,
           find_streaming_overlaps, compute_critical_path, ir_operator):
    print('\nfn', getattr(fn, '__name__', fn), inspect.signature(fn))
