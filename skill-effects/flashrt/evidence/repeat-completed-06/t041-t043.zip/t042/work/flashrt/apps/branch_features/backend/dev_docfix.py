"""Align the experiment-log analysis section with the actual summarize_graph
output, append the final re-run evidence, copy the last evidence JSONs, and run
the forbidden-phrase scan over the docs.
"""
import json
import shutil
from pathlib import Path

BACKEND = Path(__file__).resolve().parent
RUN_ROOT = BACKEND.parents[4]
STAMP = '2026-10-20'
log_path = BACKEND / 'notes' / 'experiment_log.md'
log = log_path.read_text(encoding='utf-8')

analysis_old_start = log.index('- Analysis summary')
analysis_old_end = log.index('## Variant Queue')
analysis_new = '''- Analysis summary (raw `summarize_graph` output kept in `notes/ir_analysis.txt`):
  - Pipeline stages: 6 stages, one operator each (`input_ingest`, `conv_a0`,
    `conv_b0`, `conv_a1`, `conv_b1`, `gate_merge`). `find_pipeline_stages`
    partitions by shared persistent state, and each convolution owns a private
    history, so no two convolutions are forced onto one device.
  - Cross-chunk independent pairs: 15, from
    `analyze_cross_chunk_dependencies` - every operator pair that shares no
    history, e.g. `conv_a0 || conv_b0`, `conv_a1 || conv_b1`,
    `conv_a0 || conv_b1`, plus `input_ingest`/`gate_merge` against all four
    convolutions.
  - Streaming overlaps: 0 rate-conversion opportunities - one input chunk maps
    to exactly one output chunk (ratio 1:1), so there is no metadata to attach.
  - Critical path through one chunk: `input_ingest -> conv_a0 -> conv_a1 ->
    gate_merge`, the single longest of the 7 data edges. No `op_latencies` were
    supplied to `compute_critical_path`, so this is the structural chain; the
    measured per-chunk cost (1.07 ms unfused, 0.556 ms fused) is dominated by
    launch/sync overhead rather than by any single operator's arithmetic.
  - Consequence used by the deployment variants: because the four histories are
    the only cross-chunk state and each is merely the left context of the
    convolution that owns it, the reference's nine-pass cadence is not a data
    dependency; and because `conv_a0`/`conv_b0` read the same input, the two
    branches can be evaluated by one wider kernel.

'''
log = log[:analysis_old_start] + analysis_new + log[analysis_old_end:]

extra = '''
- ''' + STAMP + ''': final independent re-run after the documentation artifacts were
  added to the backend directory: `verify-019` = PASS (6 requests, max|diff| <=
  2.4e-07) and `benchmark-020` reproduced the recommended variant (first-output
  median 0.543-0.554 ms, ceiling 200 req/s, gap median 0.0088-0.0093 ms) against
  a freshly measured reference in the same run (first-output median 1.527-2.109
  ms, ceiling 100 req/s, gap median 1.066-1.571 ms). Records:
  `benchmarks/results/verify-019_result.json`,
  `benchmarks/results/benchmark-020_candidate_result.json`,
  `benchmarks/results/benchmark-020_reference_result.json`.

## Recommended entry at handoff

`backend/worker.py` (= variant `fullreq_fused_graph`). Independently verified
(`evidence/verify-019`) and independently measured (`evidence/benchmark-020`):
first-output latency median 0.543-0.554 ms / p95 0.61-1.03 ms versus the
reference's 1.53-2.11 ms / 1.98-2.63 ms, rate ceiling 200 req/s versus
100 req/s, intra-request chunk gap median 0.009 ms versus 1.07 ms.
'''
log = log.rstrip() + '\n' + extra
log_path.write_text(log, encoding='utf-8')
print('log updated:', log_path.stat().st_size, 'bytes')

control = RUN_ROOT / 'control'
copied = []
for name in ('verify-019', 'benchmark-020'):
    for sub in (('evaluation',) if name.startswith('verify') else ('candidate', 'reference')):
        src = control / name / sub / 'result.json'
        if src.exists():
            dst = BACKEND / 'benchmarks' / 'results' / f'{name}_{sub}_result.json'
            shutil.copyfile(src, dst)
            copied.append(dst.name)
print('copied:', copied)

records = json.loads((BACKEND / 'benchmarks' / 'results' /
                      f'fullreq_fused_graph_RTX5060-8GB_{STAMP}.json').read_text(encoding='utf-8'))
records['rerun_evidence'] = 'evidence/verify-019, evidence/benchmark-020'
records['rerun_loads'] = {
    '50': {'first_output_ms': {'median': 0.5544, 'p95': 1.0278},
           'output_gap_ms': {'median': 0.0093, 'p95': 20.060, 'over_budget_fraction': 0.0624}},
    '100': {'first_output_ms': {'median': 0.5459, 'p95': 0.6228},
            'output_gap_ms': {'median': 0.0091, 'p95': 9.998, 'over_budget_fraction': 0.0}},
    '200': {'first_output_ms': {'median': 0.5430, 'p95': 0.6108},
            'output_gap_ms': {'median': 0.0088, 'p95': 4.970, 'over_budget_fraction': 0.0}}}
(BACKEND / 'benchmarks' / 'results' / f'fullreq_fused_graph_RTX5060-8GB_{STAMP}.json').write_text(
    json.dumps(records, indent=2), encoding='utf-8')
print('recommended record updated')

FORBIDDEN = ["next session", "future session", "follow-on session", "pick this up later",
             "i'll come back", "come back to it", "beyond this session's scope",
             "deferred to a later session", "a future agent can",
             "out of scope for this session", "left for follow-up", "tbd", "todo"]
docs = [BACKEND / 'README.md', BACKEND / 'notes' / 'experiment_log.md',
        BACKEND / 'notes' / 'design.md', BACKEND / 'notes' / 'ir_analysis.txt']
hits = []
for doc in docs:
    low = doc.read_text(encoding='utf-8').lower()
    for phrase in FORBIDDEN:
        if phrase in low:
            hits.append((doc.name, phrase))
print('forbidden_phrase_hits:', hits)
print('backend tree:')
for path in sorted(BACKEND.rglob('*')):
    if path.is_file():
        print('  ', path.relative_to(BACKEND))
