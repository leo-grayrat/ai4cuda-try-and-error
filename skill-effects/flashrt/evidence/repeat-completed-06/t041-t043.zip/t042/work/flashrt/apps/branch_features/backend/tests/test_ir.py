"""Phase 2 IR validation: run the SequentialExecutor and compare with the
protected research reference.

The oracle is branch_features.model.full_sequence_oracle (CPU, whole sequence,
no chunk caches). Because every position of this pipeline depends only on
current/past inputs, the chunked reference and the full-sequence oracle agree up
to float32 re-association; the reference's cross-request histories make the
tail of a concatenated stream the correct oracle for a continuation request.

Tolerance 1e-5 absolute on outputs whose dynamic range is O(1..10): float32
convolution re-association alone accounts for ~1e-6 here (measured 8.3e-07 on
the reference itself), so 1e-5 leaves one decade of headroom without being able
to hide a real dependency/state bug (a dropped history shifts outputs by O(1)).
"""
import hashlib
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

import numpy as np
import torch

from branch_features.model import build_layers, full_sequence_oracle
from flashrt.ir import SequentialExecutor, summarize_graph

from ir.graph_builder import build_model_graph

TOL = 1e-5


class Ctx:
    def __init__(self, features):
        self.features = features
        self.values = {}


def run_request(executor, features, chunk):
    outs = []
    for pos in range(0, features.shape[-1], chunk):
        part = torch.from_numpy(np.ascontiguousarray(features[:, pos:pos + chunk])).unsqueeze(0)
        ctx = Ctx(part)
        with torch.no_grad():
            executor.run_chunk({'features': part}, ctx)
        outs.append(ctx.values['out'])
    return np.concatenate([o[0].numpy() for o in outs], axis=-1)


def digest(arr):
    return hashlib.sha256(np.round(arr, 5).astype(np.float32).tobytes()).hexdigest()[:16]


def main():
    repo = str(BACKEND.parents[3])
    config = {'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
              'weight_seed': 2024, 'device': 'cpu'}
    rng = np.random.default_rng(11)
    seq1 = rng.standard_normal((16, 1043)).astype(np.float32) * 3.0
    seq2 = rng.standard_normal((16, 1043)).astype(np.float32) * 3.0

    layers = build_layers(repo, config, 'cpu')
    graph = build_model_graph(layers)
    problems = graph.validate()

    executor = SequentialExecutor(graph)
    executor.init_state({name: None for name in ('hist_a0', 'hist_a1', 'hist_b0', 'hist_b1')})
    got1 = run_request(executor, seq1, 127)
    got2 = run_request(executor, seq2, 127)          # continuation, no reset
    executor.init_state({name: None for name in ('hist_a0', 'hist_a1', 'hist_b0', 'hist_b1')})
    got1b = run_request(executor, seq1, 127)         # after reset

    ref1 = full_sequence_oracle(repo, config, seq1)
    joined = full_sequence_oracle(repo, config, np.concatenate([seq1, seq2], axis=-1))
    ref2 = joined[:, seq1.shape[-1]:]

    diffs = {'req1_vs_oracle': float(np.abs(got1 - ref1).max()),
             'req2_continuation_vs_concat_oracle': float(np.abs(got2 - ref2).max()),
             'req1_after_reset_vs_oracle': float(np.abs(got1b - ref1).max())}
    ok = all(v <= TOL for v in diffs.values()) and not problems
    print('ir_graph_problems:', problems)
    print('ir_hashes:', {'executor_req1': digest(got1), 'oracle_req1': digest(ref1),
                         'executor_req2': digest(got2), 'oracle_req2': digest(ref2)})
    for key, val in diffs.items():
        print(f'  {key}: max_abs_diff={val:.3e} (tol={TOL:.0e})')
    print('IR VALIDATION:', 'PASS' if ok else 'FAIL')
    print()
    print(summarize_graph(graph))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
