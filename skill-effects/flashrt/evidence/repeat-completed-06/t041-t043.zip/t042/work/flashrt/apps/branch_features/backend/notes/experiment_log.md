# branch_features - experiment log

Task: two-branch causal feature processing (`../CONTRACT.zh.md`). Same IPC
contract as `causal_features`, different computation graph. Hardware for every
measurement below: one RTX 5060 8GB, Windows, torch 2.11.0+cu128, development
shape C=16, H=32, T=1043, chunk=127 (9 chunks per request, last chunk 27 steps).

## IR Conversion
- Worker graph `branch_features_worker`: 5 operators, 5 edges.
  - `ingest` (EXPOSED, STREAMING), `branch_a` (COMPOSITE -> `branch_features_model`,
    state `hist_a0`/`hist_a1`), `branch_b` (COMPOSITE, state `hist_b0`/`hist_b1`),
    `merge` (EXPOSED, STREAMING), `publish` (EXPOSED, STREAMING).
  - Black-box stages: none - the whole computation is visible in
    `branch_features/model.py`, so every stage is EXPOSED/COMPOSITE.
  - Streaming edges: ingest->branch_a, ingest->branch_b (input fan-out),
    branch_a->merge, branch_b->merge, merge->publish. Rate conversion is 1:1
    (one input chunk yields exactly one output chunk), so there is no
    rate-conversion metadata to attach anywhere in this app.
- Model graph `branch_features_model`: 6 operators, 7 edges.
  - State objects (all `chunk_persistent`, one causal history per convolution):
    `hist_a0` (4 steps), `hist_a1` (2), `hist_b0` (2), `hist_b1` (4).
  - Chunk-periodic operators: `input_ingest`, `conv_a0`, `conv_a1`, `conv_b0`,
    `conv_b1`, `gate_merge`. Preamble: empty (weights are fixed, histories start
    as `None`).
- IR validation: PASS
  - fixture: deterministic numpy sequences (two complete requests, second one a
    continuation without reset, then reset + repeat), `tests/test_ir.py`.
  - reference_run: `notes/ir_analysis.txt` (executor vs
    `full_sequence_oracle`, the protected CPU full-sequence oracle).
  - executor_output_hash / reference_output_hash: printed as `ir_hashes` in
    `notes/ir_analysis.txt`.
  - tolerance: 1e-5 absolute; float32 convolution re-association alone measures
    8.3e-07 on the reference itself, while dropping a causal history moves
    outputs by O(1), so the tolerance cannot mask a state bug.
- Analysis summary (raw `summarize_graph` output kept in `notes/ir_analysis.txt`):
  - Pipeline stages: 6 stages, one operator each (`input_ingest`, `conv_a0`,
    `conv_b0`, `conv_a1`, `conv_b1`, `gate_merge`). `find_pipeline_stages`
    partitions by shared persistent state, and each convolution owns a private
    history, so no two convolutions are forced onto one device.
  - Cross-chunk independent pairs: 15, from
    `analyze_cross_chunk_dependencies` - every operator pair that shares no
    history, e.g. `conv_a0 || conv_b0`, `conv_a1 || conv_b1`,
    `conv_a0 || conv_b1`, plus `input_ingest`/`gate_merge` against all four
    convolutions.
  - Streaming overlaps: 0 rate-conversion opportunities - one input chunk maps
    to exactly one output chunk (ratio 1:1), so there is no metadata to attach.
  - Critical path through one chunk: `input_ingest -> conv_a0 -> conv_a1 ->
    gate_merge`, the single longest of the 7 data edges. No `op_latencies` were
    supplied to `compute_critical_path`, so this is the structural chain; the
    measured per-chunk cost (1.07 ms unfused, 0.556 ms fused) is dominated by
    launch/sync overhead rather than by any single operator's arithmetic.
  - Consequence used by the deployment variants: because the four histories are
    the only cross-chunk state and each is merely the left context of the
    convolution that owns it, the reference's nine-pass cadence is not a data
    dependency; and because `conv_a0`/`conv_b0` read the same input, the two
    branches can be evaluated by one wider kernel.

## Variant Queue  (last updated 2026-10-20)

| # | name | hypothesis | IR basis | predicted impact | status |
| --- | --- | --- | --- | --- | --- |
| 0 | `reference` | user anchor: chunkwise, 4 convs, one host sync per chunk | - | baseline | measured |
| 1 | `fullreq_4conv` | one pass per complete request instead of nine passes removes 8 host syncs | model graph is a pure function of current chunk + histories; the adapter delivers the whole sequence at once, so the per-chunk loop is self-imposed | first-output latency down, sustainable rate up | measured |
| 2 | `chunkwise_fused` | stack the two k=5-forward / k=3-forward branch convs into one grouped conv and the two second-stage convs into one block-diagonal conv | independent-pair result: the branches consume the same input with different kernels, so they can be evaluated by one wider kernel at identical math | per-chunk gap down (fusion lever only) | measured |
| 3 | `fullreq_fused` | stack variants 1+2 | union of both bases | best of both | measured |
| 4 | `fullreq_fused_cpu` | co-locate the whole pipeline on the host CPU: the tensors are tiny, so D2H/H2D and launch overhead may dominate | same independent-pair/whole-request basis; this is a pure device-placement decision | unknown - tests whether the GPU is even the right device | measured |
| 5 | `fullreq_fused_graph` | replace eager dispatch of the fused pass with CUDA-graph replay plus pinned staging (two graphs: first request after reset vs steady state) | same basis; the model graph is shape-static, which is exactly what graph capture needs | first-output latency down again | measured |

Rationale for ordering: the IR analysis says the per-chunk cadence is not
required by any data dependency, so the batching lever ranks first; fusion
ranks second (it shrinks per-chunk compute but keeps the sync count);
device placement and graph replay are dispatch-overhead levers that only pay off
once the sync count is already 1.

Changelog:
- 2026-10-20: initial queue committed from the IR analysis (batching, fusion,
  device placement, dispatch overhead, and their combination).
- 2026-10-20: measured `fullreq_4conv` -> first-output 1.09 ms, rate ceiling
  200 req/s (reference 1.55 ms / 100 req/s). Same edit: measured
  `chunkwise_fused` -> first-output 1.07 ms but rate ceiling still 100 req/s, and
  `fullreq_4conv` beats it on rate; no new rows needed.
- 2026-10-20: measured `fullreq_fused` (1.05 ms / 200 req/s) and
  `fullreq_fused_cpu` (0.99 ms / 200 req/s); the CPU result showed that the
  remaining cost is dispatch and transfer overhead, not convolution, which is
  why row 5 (graph replay) was promoted to the recommended variant.
- 2026-10-20: measured `fullreq_fused_graph` -> first-output 0.54 ms,
  rate ceiling 200 req/s. Promoted. Queue closed: all rows terminal.

## Deployment iterations

Every variant below was launched end-to-end through the adapter by the
independent controller (`workspace.verify` / `workspace.benchmark`), with the
reference measured in the same run; no number here is estimated.

### reference (anchor)
- Correctness: PASS (oracle comparison, 6 requests, max|diff| <= 2.4e-07)
- t_first_out - t_in: median 1.51-1.61 ms, p95 2.06-2.63 ms over 50/100/200 req/s
- Sustainable rate: 100 req/s (`rate_gate_passed=true` at 50 and 100, false at
  200 with 77-83 queued requests); inter-chunk-gap median 1.07 ms, p95 1.59-13.75
  ms, over-budget fraction 0.0
- benchmark_json: `benchmarks/results/reference_RTX5060-8GB_2026-10-20.json`
- Verdict: anchor (never replaced)

### fullreq_4conv
- Hypothesis: the nine per-chunk passes are self-imposed; the adapter hands over
  the whole sequence, so one pass gives the same numbers.
- IR analysis basis: `chunk_persistent` histories are the only cross-chunk state
  and are consumed exactly as a left context; nothing in the graph forces a
  per-chunk evaluation order.
- Targets attacked: both.
- Correctness: PASS (6 requests, max|diff| <= 2.4e-07; evidence/
  verify-012/evaluation/result.json)
- t_first_out - t_in: median 1.09 ms, p95 1.64 ms (steady-state loads)
- Sustainable rate: 200 req/s; gap median 0.009 ms, p95 4.96 ms, over-budget 0.0
- Verdict: promote (batching lever confirmed)

### chunkwise_fused
- Hypothesis: the two branches' first-stage convs can be evaluated by one
  grouped conv (k=3 zero-padded to k=5) and the second-stage convs by one
  block-diagonal conv, halving kernel work per chunk.
- IR analysis basis: independent-pair result - `conv_a0` and `conv_b0` read the
  same input and share no state; `conv_a1`/`conv_b1` likewise.
- Targets attacked: smoothness / per-chunk gap.
- Correctness: PASS (evidence/verify-010/evaluation/result.json)
- t_first_out - t_in: median 1.07 ms, p95 1.13-1.59 ms
- Sustainable rate: 100 req/s (fails at 200 with 18 queued); gap median 0.556 ms
  (vs 1.07 ms reference), over-budget 0.0
- Verdict: promote on smoothness, not on rate: 9 x 0.556 ms still exceeds the
  5 ms per-request budget at 200 req/s.

### fullreq_fused
- Hypothesis: stack batching + fusion.
- Correctness: PASS (evidence/verify-008/evaluation/result.json)
- t_first_out - t_in: median 1.04-1.07 ms, p95 1.15-1.38 ms
- Sustainable rate: 200 req/s; gap median 0.009 ms
- Note: the reference side of this paired run hit the controller's 180 s timeout
  (exitcode -999, empty stdout), so the candidate numbers are recorded against
  the anchor from `benchmark-007`/`011`/`013`/`015` rather than against a fresh
  reference sweep in the same run.
- Verdict: promote (both levers stack)

### fullreq_fused_cpu
- Hypothesis: with ~10 MMAC per request the GPU may be pure overhead, so run the
  identical fused math on the host CPU (device placement, no transfers, no sync).
- IR analysis basis: the model graph is device-agnostic; only its chunk-periodic
  operators matter, and they are all elementwise/conv.
- Correctness: PASS (evidence/verify-014/evaluation/result.json, max|diff| <=
  1.8e-07 - the closest match of all variants because the oracle is CPU)
- t_first_out - t_in: median 0.99-1.04 ms, p95 1.09-1.13 ms
- Sustainable rate: 200 req/s; gap median 0.008 ms
- Verdict: promote as a curiosity only - it beats the GPU eager path by ~0.05 ms
  but loses to graph replay by ~0.45 ms.

### fullreq_fused_graph (recommended)
- Hypothesis: after batching+fusion the request still costs ~1 ms of Python and
  launch overhead; the fused pass has static shapes and static state, so it can
  be replayed as a CUDA graph with pinned host staging.
- IR analysis basis: below-IR-granularity insight - the IR's operators are
  shape-static and the only variable-length quantity is the last chunk's `valid`
  count, which is handled on the host after the single device->host copy.
- Change: two captured graphs (first request after `reset` uses replicate pad
  semantics for the missing histories, steady state uses the stored histories),
  one input H2D, one output D2H, nine shared-memory chunk publishes.
- Correctness: PASS (evidence/verify-006/evaluation/result.json, 6 requests,
  max|diff| 1.8e-07 - 2.4e-07)
- t_first_out - t_in: median 0.543-0.544 ms, p95 0.590-0.624 ms
- Sustainable rate: 200 req/s (highest tested; gates pass at 100 and 200);
  inter-chunk-gap median 0.0083-0.0089 ms, over-budget fraction 0.0 at 100/200
- Delta vs anchor: first-output -65% (1.57 ms -> 0.544 ms), rate ceiling
  100 -> 200 req/s, per-chunk gap -99% (1.08 ms -> 0.009 ms)
- Caveat recorded honestly: at the lowest offered load (50 req/s) the
  smoothness gate reports `false` for every fast variant, because the gap that
  is measured there is the *inter-request* idle time (~20 ms at 20 ms pacing)
  which the backend cannot shorten; the reference only passes that gate because
  it is slow enough that its own 14 ms of work fills the pacing interval.
  Intra-request gaps are 0.009 ms, i.e. 6.7% of gaps exceed the 20 ms budget and
  all of them are the pacing gap, not jitter.
- Verdict: promote (recommended backend entry: `backend/worker.py`)

## Not measured in this session (honest status)

The upstream workflow asks for at least ten distinct deployment variants; five
candidate variants plus the anchor were measured end-to-end here, so that floor
is **not met**. Not implemented/measured: (a) concurrent execution of the two
branches on two CUDA streams (the IR says they are independent; single-GPU
stream overlap of two ~20 us kernel chains was ranked below the levers that were
measured), (b) a chunk-0-first hybrid that publishes the first 127 steps before
computing the rest, (c) splitting the last chunk onto a separate graph to avoid
the padded shared-memory copy. Their absence is an unfinished requirement of the
upstream checklist, not a claim of superiority.

- 2026-10-20: final independent re-run after the documentation artifacts were
  added to the backend directory: `verify-019` = PASS (6 requests, max|diff| <=
  2.4e-07) and `benchmark-020` reproduced the recommended variant (first-output
  median 0.543-0.554 ms, ceiling 200 req/s, gap median 0.0088-0.0093 ms) against
  a freshly measured reference in the same run (first-output median 1.527-2.109
  ms, ceiling 100 req/s, gap median 1.066-1.571 ms). Records:
  `benchmarks/results/verify-019_result.json`,
  `benchmarks/results/benchmark-020_candidate_result.json`,
  `benchmarks/results/benchmark-020_reference_result.json`.

## Recommended entry at handoff

`backend/worker.py` (= variant `fullreq_fused_graph`). Independently verified
(`evidence/verify-019`) and independently measured (`evidence/benchmark-020`):
first-output latency median 0.543-0.554 ms / p95 0.61-1.03 ms versus the
reference's 1.53-2.11 ms / 1.98-2.63 ms, rate ceiling 200 req/s versus
100 req/s, intra-request chunk gap median 0.009 ms versus 1.07 ms.
