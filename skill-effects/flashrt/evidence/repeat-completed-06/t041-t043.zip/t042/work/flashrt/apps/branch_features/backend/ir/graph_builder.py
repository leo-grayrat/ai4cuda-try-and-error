"""Graph builders for the two-branch causal feature pipeline."""
from flashrt.ir import IRGraph, IREdge, OpType, StateObject, StreamMode, TensorPort

from .ops import CausalConvOp, gate_merge, input_ingest

HISTORIES = ('hist_a0', 'hist_a1', 'hist_b0', 'hist_b1')


def build_model_graph(layers):
    """Fine-grained per-chunk graph: four convs + gate/merge, one pass per chunk."""
    graph = IRGraph(name='branch_features_model')
    for name in HISTORIES:
        graph.add_state(StateObject(name, description=f'causal input history {name}',
                                    scope='chunk_persistent'))
    graph.external_inputs = [TensorPort('features', shape_hint=('C', 'T'))]
    graph.external_outputs = [TensorPort('out', shape_hint=('C', 'T'))]

    graph.add_operator(input_ingest)
    graph.add_operator(CausalConvOp('a0', layers['a0'], apply_silu=True))
    graph.add_operator(CausalConvOp('a1', layers['a1'], apply_silu=False))
    graph.add_operator(CausalConvOp('b0', layers['b0'], apply_silu=True))
    graph.add_operator(CausalConvOp('b1', layers['b1'], apply_silu=False))
    graph.add_operator(gate_merge)

    graph.add_edge(IREdge('input_ingest', 'features_out', 'conv_a0', 'features'))
    graph.add_edge(IREdge('conv_a0', 'out', 'conv_a1', 'features'))
    graph.add_edge(IREdge('input_ingest', 'features_out', 'conv_b0', 'features'))
    graph.add_edge(IREdge('conv_b0', 'out', 'conv_b1', 'features'))
    graph.add_edge(IREdge('conv_a1', 'out', 'gate_merge', 'branch_a'))
    graph.add_edge(IREdge('conv_b1', 'out', 'gate_merge', 'branch_b'))
    graph.add_edge(IREdge('input_ingest', 'features_out', 'gate_merge', 'features'))

    graph.preamble_ops = []
    graph.chunk_ops = ['input_ingest', 'conv_a0', 'conv_a1', 'conv_b0', 'conv_b1',
                       'gate_merge']
    return graph


def build_worker_graph(layers):
    """Worker-level view: ingest -> branch A / branch B -> merge -> publish.

    The two branches are COMPOSITE stages over the model graph; they touch
    disjoint chunk-persistent state, which is the parallelism the analysis
    tools report (and the scheduling freedom this app actually has).
    """
    graph = IRGraph(name='branch_features_worker')
    for name in HISTORIES:
        graph.add_state(StateObject(name, description=f'causal input history {name}',
                                    scope='chunk_persistent'))
    graph.external_inputs = [TensorPort('features', shape_hint=('C', 'T'))]
    graph.external_outputs = [TensorPort('out', shape_hint=('C', 'T'))]
    graph.sub_graphs['branch_features_model'] = build_model_graph(layers)

    from flashrt.ir import IROperator

    class _Stage(IROperator):
        def __init__(self, name, reads, op_type=OpType.COMPOSITE, sub_graph=None):
            super().__init__(name=name, op_type=op_type,
                             inputs=[TensorPort('features')],
                             outputs=[TensorPort('out')],
                             state_reads=list(reads), state_writes=list(reads),
                             stream_mode=StreamMode.STREAMING, sub_graph=sub_graph)

        def execute(self, inputs, ctx, state):
            return {'out': ctx.values.get('features')}

    graph.add_operator(_Stage('ingest', [], OpType.EXPOSED))
    graph.add_operator(_Stage('branch_a', ['hist_a0', 'hist_a1'], sub_graph='branch_features_model'))
    graph.add_operator(_Stage('branch_b', ['hist_b0', 'hist_b1'], sub_graph='branch_features_model'))
    graph.add_operator(_Stage('merge', [], OpType.EXPOSED))
    graph.add_operator(_Stage('publish', [], OpType.EXPOSED))
    graph.add_edge(IREdge('ingest', 'out', 'branch_a', 'features'))
    graph.add_edge(IREdge('ingest', 'out', 'branch_b', 'features'))
    graph.add_edge(IREdge('branch_a', 'out', 'merge', 'features'))
    graph.add_edge(IREdge('branch_b', 'out', 'merge', 'features'))
    graph.add_edge(IREdge('merge', 'out', 'publish', 'features'))
    graph.preamble_ops = []
    graph.chunk_ops = ['ingest', 'branch_a', 'branch_b', 'merge', 'publish']
    return graph
