"""Operators of the two-branch causal feature graph.

The reference (branch_features/reference.py + branch_features/model.py) is a
strictly sequential chain per chunk:

    values -> a0(k=5) -> SiLU -> a1(k=3) ---------------+
    values -> b0(k=3) -> SiLU -> b1(k=5) ------------+  |
    gate = sigmoid(mean_c(values)) ------------------+--+--> gate*A + (1-gate)*B + 0.1*values

Each of the four convolutions keeps its *own* input history
(``self.histories[name]`` in the reference), which is chunk-persistent state and
survives across requests until an explicit reset. Expressing those four
histories as four separate ``chunk_persistent`` StateObjects is what makes the
A and B chains visible to the IR analysis as mutually independent.
"""
import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort, ir_operator


class CausalConvOp(IROperator):
    """One reference convolution, with its private causal history.

    ``execute`` is a literal transcription of ``ReferencePipeline.convolution``:
    prepend the stored history, run the pinned CausalConv1d, drop the outputs
    that belong to the history region, and keep the last (k-1) inputs.
    """

    def __init__(self, tag, layer, apply_silu):
        self.hist = f'hist_{tag}'
        self.layer = layer
        self.apply_silu = apply_silu
        self.tail = layer._time_causal_padding[0]
        super().__init__(
            name=f'conv_{tag}',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('features', shape_hint=('C', 'T'))],
            outputs=[TensorPort('out', shape_hint=('H_or_C', 'T'))],
            state_reads=[self.hist],
            state_writes=[self.hist],
            stream_mode=StreamMode.STREAMING,
            config={'kernel': layer.conv.kernel_size[0], 'silu': apply_silu},
        )

    def execute(self, inputs, ctx, state):
        features = inputs.get('features')
        if features is None:
            features = ctx.values['features']
        history = state.get(self.hist)
        joined = features if history is None else torch.cat([history, features], dim=-1)
        out = self.layer(joined)
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        state.set(self.hist, joined[:, :, -self.tail:].clone())
        if self.apply_silu:
            out = F.silu(out)
        ctx.values[self.name] = out
        return {'out': out}


@ir_operator(
    name='gate_merge',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('features', shape_hint=('C', 'T')),
            TensorPort('branch_a', shape_hint=('C', 'T')),
            TensorPort('branch_b', shape_hint=('C', 'T'))],
    outputs=[TensorPort('out', shape_hint=('C', 'T'))],
    stream_mode=StreamMode.STREAMING,
)
def gate_merge(inputs, ctx, state):
    """gate*A + (1-gate)*B + 0.1*x with gate = sigmoid(mean over channels of x)."""
    features = inputs.get('features')
    if features is None:
        features = ctx.values['features']
    branch_a = inputs.get('branch_a')
    if branch_a is None:
        branch_a = ctx.values['conv_a1']
    branch_b = inputs.get('branch_b')
    if branch_b is None:
        branch_b = ctx.values['conv_b1']
    gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
    out = gate * branch_a + (1 - gate) * branch_b + 0.1 * features
    ctx.values['out'] = out
    return {'out': out}


@ir_operator(
    name='input_ingest',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('features', shape_hint=('C', 'T'))],
    outputs=[TensorPort('features_out', shape_hint=('C', 'T'))],
    stream_mode=StreamMode.STREAMING,
)
def input_ingest(inputs, ctx, state):
    """Adapter chunk -> graph port. Rate conversion 1 in-chunk : 1 out-chunk."""
    features = inputs.get('features')
    if features is None:
        features = ctx.features
    ctx.values['features'] = features
    return {'features_out': features}
