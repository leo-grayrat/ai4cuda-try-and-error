"""Numeric sanity check of the fused / batched variants against the CPU
full-sequence oracle, without the IPC harness.
"""
import sys
from pathlib import Path

backend = Path(__file__).resolve().parent
sys.path.insert(0, str(backend))

import numpy as np
import branch_engine
from branch_features.model import ReferencePipeline, full_sequence_oracle

repo = str(backend.parents[3])
print('repository =', repo, (Path(repo) / 'flashrt/layers/audio.py').exists())
config = {'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
          'weight_seed': 2024, 'device': 'cpu', 'prefix': 'devcheck'}
rng = np.random.default_rng(7)
seq1 = rng.standard_normal((16, 1043)).astype(np.float32) * 3.0
seq2 = rng.standard_normal((16, 1043)).astype(np.float32) * 3.0
oracle1 = full_sequence_oracle(repo, config, seq1)
oracle2 = full_sequence_oracle(repo, config, seq2)


def to_chunks(gen):
    return np.concatenate([out for _, out in gen], axis=-1)


for name, make in (
        ('chunkwise_4conv', lambda: branch_engine.FourConvComputer(repo, config, 'cpu', whole=False)),
        ('fullreq_4conv', lambda: branch_engine.FourConvComputer(repo, config, 'cpu', whole=True)),
        ('chunkwise_fused', lambda: branch_engine.FusedChunkComputer(repo, config, 'cpu')),
        ('fullreq_fused', lambda: branch_engine.FusedComputer(repo, config, 'cpu')),
):
    comp = make()
    o1 = to_chunks(comp.chunks(seq1))
    o2 = to_chunks(comp.chunks(seq2))
    comp.reset()
    r1 = to_chunks(comp.chunks(seq1))
    print(f'{name:18s} req1 maxdiff={np.abs(o1 - oracle1).max():.3e} '
          f'req2(cont) maxdiff={np.abs(o2 - oracle2).max():.3e} '
          f'req1-after-reset maxdiff={np.abs(r1 - oracle1).max():.3e} '
          f'shape={o1.shape}')

pipe = ReferencePipeline(repo, config)
ref1 = to_chunks((i, pipe.step(seq1[:, p:p + 127])) for i, p in enumerate(range(0, 1043, 127)))
ref2 = to_chunks((i, pipe.step(seq2[:, p:p + 127])) for i, p in enumerate(range(0, 1043, 127)))
print('reference chunked vs oracle:',
      float(np.abs(ref1 - oracle1).max()), float(np.abs(ref2 - oracle2).max()))
comp = branch_engine.FusedComputer(repo, config, 'cpu')
f1 = to_chunks(comp.chunks(seq1))
f2 = to_chunks(comp.chunks(seq2))
print('fused whole vs reference chunked (continuation):',
      float(np.abs(f1 - ref1).max()), float(np.abs(f2 - ref2).max()))
print('tail chunk valid steps =', 1043 - 8 * 127)
