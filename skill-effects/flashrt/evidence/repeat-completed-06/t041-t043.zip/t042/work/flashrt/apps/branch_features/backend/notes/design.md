# Design notes

## The two levers, and why they are independent

The adapter (`causal_features.adapter`, reused by `branch_features`) publishes a
*complete* `(channels, length)` sequence per request and then expects the answer
back in `chunk`-sized pieces. The reference worker computes chunk by chunk, so
every chunk pays a CUDA launch chain plus a `cudaStreamSynchronize` from
`.cpu()`. Nothing in the dependency graph requires that: the only cross-chunk
state is four causal input histories (`hist_a0` 4 steps, `hist_a1` 2,
`hist_b0` 2, `hist_b1` 4), and a history is exactly a left context. So

* batching the nine passes into one shrinks the *rate* limiter (9 syncs ->
  1 sync) and lowers first-output latency slightly;
* fusing the branches shrinks per-chunk *kernel work* (4 convs -> 2 convs) and
  therefore the inter-chunk gap, but leaves the sync count untouched.

Measured independently: batching alone takes the ceiling from 100 to 200 req/s
with a ~1.09 ms first output; fusion alone halves the chunk gap (1.07 -> 0.556
ms) but stays at 100 req/s. Stacking them gives 200 req/s at 1.04 ms.

## Why the graph replay wins the last 0.5 ms

After stacking, `fullreq_fused` still costs ~1.05 ms per request while the CPU
version of the same math costs ~1.00 ms. Since the GPU has ~10 MMAC of work to
do (~20 us), essentially all of that millisecond is dispatch and transfer
overhead. The fused pass has static shapes and static state tensors, so both
request shapes (fresh vs steady history) can be captured as CUDA graphs: the
replay plus one pinned H2D and one pinned D2H brings the request to 0.544 ms.

## Exactness of the transformations

* Left-padding a k=3 causal kernel with two zeros makes it a k=5 causal kernel;
  the added products are exact zeros, so stacking a0/b0 (identical input) into
  one grouped conv is exact. The same trick handles a1 (k=3) next to b1 (k=5);
  the block-diagonal zero blocks are exact zeros as well.
* Replacing the k-1 padding with a prepended replicate of the first frame is the
  same operation the pinned `CausalConv1d` performs (`F.pad(mode="replicate")`),
  and the first `hist_len` outputs are discarded, so the kept outputs see real
  samples only.
* The two captured graphs correspond to "no history yet" (replicate pad, as in
  the reference's `history is None` branch) and "history present".
