# branch_features backend

Two-branch causal feature processing (`../CONTRACT.zh.md`) for one RTX 5060
8GB, Windows, torch 2.11.0+cu128.

## Launch

From the repository root, with the pinned FlashRT environment:

```
python flashrt/apps/branch_features/backend/worker.py \
    --repository <repository root> --config <path to config.json>
```

`worker.py` accepts exactly the supplied adapter protocol: it creates the shared
buffers through `branch_features.adapter.open_buffers`, honours control opcodes
1 (start), 2 (terminate) and 3 (reset) with the reference's level-valued
semantics, and publishes `(channels, chunk)` float32 payloads plus
`int64[request_id, chunk_index, valid]` metadata, in chunk order, for every
request. It keeps the four causal histories across requests and clears all of
them on reset, so the unchanged frontend under `../frontend/` drives it as a
drop-in replacement for `../reference/`.

The config is the same JSON the reference reads (`channels`, `hidden`, `length`,
`chunk`, `weight_seed`, `prefix`, `device`).

## What it does differently

1. **One pass per request, not per chunk.** The adapter delivers the complete
   sequence; the reference's nine per-chunk passes are self-imposed. Only the
   four causal histories actually cross chunk boundaries.
2. **Branch fusion.** `a0` (C->H, k=5) and `b0` (C->H, k=3) consume the same
   input, so their kernels are stacked into one grouped conv with the k=3 kernel
   zero-padded on the left; `a1` (H->C, k=3) and `b1` (H->C, k=5) become one
   block-diagonal conv. Mathematically identical to the four separate
   convolutions.
3. **CUDA-graph replay + pinned staging.** Two captured graphs (first request
   after reset vs steady state), one H2D, one D2H, nine shared-memory publishes.

## Measured (RTX 5060 8GB, paired sweeps by the independent controller)

| variant | first-output median | p95 | rate ceiling | chunk-gap median |
| --- | --- | --- | --- | --- |
| reference | 1.51-1.61 ms | 2.06-2.63 ms | 100 req/s | 1.07 ms |
| `variants/fullreq_4conv.py` | 1.09 ms | 1.64 ms | 200 req/s | 0.009 ms |
| `variants/chunkwise_fused.py` | 1.07 ms | 1.13 ms | 100 req/s | 0.556 ms |
| `variants/fullreq_fused.py` | 1.04 ms | 1.15 ms | 200 req/s | 0.009 ms |
| `variants/fullreq_fused_cpu.py` | 0.99 ms | 1.09 ms | 200 req/s | 0.008 ms |
| **`worker.py`** (recommended) | **0.544 ms** | **0.624 ms** | **200 req/s** | **0.009 ms** |

All variants pass the six-request numerical verification against the protected
CPU full-sequence oracle (max|diff| <= 2.4e-07).

## Layout

- `worker.py` - recommended standalone entry (graph replayed fused pass).
- `branch_engine.py` - the variant-parameterised worker engine and the shared
  control/emission loop.
- `variants/` - one entry per measured variant.
- `ir/` - Phases 1-2 graph conversion (`ops.py`, `graph_builder.py`).
- `tests/test_ir.py` - IR validation against the CPU full-sequence oracle.
- `benchmarks/results/*.json` - per-variant measurement records with the
  controller evidence paths.
- `notes/experiment_log.md`, `notes/ir_analysis.txt`, `notes/design.md`.
- `dev_check.py`, `ir/probe_api.py` - diagnostics kept for reproducibility.
