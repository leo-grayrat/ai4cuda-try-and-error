"""Patch the no_grad omission in the IR validation template, then re-run the
finalize script end to end.
"""
import subprocess
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parent
target = BACKEND / 'dev_finalize.py'
text = target.read_text(encoding='utf-8')
old = "        executor.run_chunk({'features': part}, ctx)\n"
new = ("        with torch.no_grad():\n"
       "            executor.run_chunk({'features': part}, ctx)\n")
assert old in text, 'pattern not found'
target.write_text(text.replace(old, new), encoding='utf-8')
print('patched no_grad into the IR validation template')
proc = subprocess.run([sys.executable, '-u', str(target)], cwd=str(BACKEND.parents[3]))
print('finalize exit code:', proc.returncode)
