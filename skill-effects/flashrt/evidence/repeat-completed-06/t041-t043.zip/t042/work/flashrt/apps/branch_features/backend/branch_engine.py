"""Variant-parameterised worker engine for the two-branch causal feature task.

Task (see ../CONTRACT.zh.md):
  branch A : x -> causalconv(C->H,k=5) -> SiLU -> causalconv(H->C,k=3) = A
  branch B : x -> causalconv(C->H,k=3) -> SiLU -> causalconv(H->C,k=5) = B
  gate     : sigmoid(mean over channels of the *current* input features)
  out      : gate*A + (1-gate)*B + 0.1*x
Every position depends only on current/past inputs; each of the four convolutions
keeps its own input history, and all four histories persist across requests until
an explicit reset.

Optimisation axes implemented here (all measured through the adapter):
  * "fuse"     : both first-stage convs (k=5 / k=3 on the same input) are stacked
                 into one grouped conv with the k=3 kernel zero-padded on the left;
                 both second-stage convs are stacked into one block-diagonal conv.
                 Mathematically identical to the four separate convolutions.
  * "batch"    : the adapter delivers a *complete* sequence per request, so the
                 whole request can be evaluated in one pass instead of one pass
                 per 127-step chunk (per-chunk host syncs disappear).
  * "graph"    : CUDA-graph replay of the fixed-shape pass + pinned staging.
"""

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


def _pad_left_k5(w):
    """Zero-pad a (out, in, 3) causal kernel to a (out, in, 5) causal kernel.

    A causal k=3 conv on x[t-2..t] equals a causal k=5 conv whose two oldest
    kernel taps are zero, so the two can be stacked into one grouped conv.
    """
    return torch.cat([w.new_zeros(*w.shape[:-1], 2), w], dim=-1)


def _load_layers(repository, config, device):
    """Reuse the user's own layer builder so the weights are bit-identical."""
    from branch_features.model import build_layers
    return build_layers(repository, config, device)


def _fused_weights(layers, device):
    conv = {name: layers[name].conv for name in ('a0', 'a1', 'b0', 'b1')}
    c_out = conv['a1'].weight.shape[0]
    h = conv['a0'].weight.shape[0]
    w1 = torch.cat([conv['a0'].weight.detach(), _pad_left_k5(conv['b0'].weight.detach())], 0)
    b1 = torch.cat([conv['a0'].bias.detach(), conv['b0'].bias.detach()], 0)
    w2 = torch.zeros(2 * c_out, 2 * h, 5, device=device, dtype=w1.dtype)
    w2[:c_out, :h] = _pad_left_k5(conv['a1'].weight.detach())
    w2[c_out:, h:] = conv['b1'].weight.detach()
    b2 = torch.cat([conv['a1'].bias.detach(), conv['b1'].bias.detach()], 0)
    return w1.contiguous(), b1.contiguous(), w2.contiguous(), b2.contiguous()


class FusedComputer:
    """Both branches fused into two grouped convolutions."""

    def __init__(self, repository, config, device, use_graph=False):
        self.L = int(config['length'])
        self.C = int(config['channels'])
        self.H = int(config['hidden'])
        self.chunk = int(config['chunk'])
        self.device = torch.device(device)
        self.layers = _load_layers(repository, config, str(self.device))
        self.W1, self.B1, self.W2, self.B2 = _fused_weights(self.layers, self.device)
        self.h1 = torch.zeros(1, self.C, 4, device=self.device)
        self.h2 = torch.zeros(1, 2 * self.H, 4, device=self.device)
        self.fresh = True
        self._graphs = None
        if use_graph and self.device.type == 'cuda':
            self._x = torch.zeros(1, self.C, self.L, device=self.device)
            self._out = torch.zeros(1, self.C, self.L, device=self.device)
            self._host_in = torch.empty(self.C, self.L, dtype=torch.float32, pin_memory=True)
            self._host_out = torch.empty(self.C, self.L, dtype=torch.float32, pin_memory=True)
            self._graphs = {'fresh': self._capture(True), 'steady': self._capture(False)}
            self.h1.zero_()
            self.h2.zero_()
            self.fresh = True

    # ---- one causal pass over an arbitrary number of steps -------------------
    def _fwd(self, x, fresh):
        c, h = self.C, self.H
        h1 = x[:, :, :1].repeat(1, 1, 4) if fresh else self.h1
        xj = torch.cat([h1, x], dim=-1)
        hs = F.silu(F.conv1d(F.pad(xj, (4, 0)), self.W1, self.B1)[:, :, 4:])
        h2 = self.h2
        if fresh:
            h2 = torch.cat([hs[:, :h, :1].repeat(1, 1, 4), hs[:, h:, :1].repeat(1, 1, 4)], dim=1)
        y2 = F.conv1d(F.pad(torch.cat([h2, hs], dim=-1), (4, 0)), self.W2, self.B2)[:, :, 4:]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        out = gate * y2[:, :c] + (1 - gate) * y2[:, c:] + 0.1 * x
        self.h1.copy_(xj[:, :, -4:])
        self.h2.copy_(hs[:, :, -4:])
        return out

    def _capture(self, fresh):
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side), torch.inference_mode():
            for _ in range(3):
                self._fwd(self._x, fresh)
        torch.cuda.current_stream().wait_stream(side)
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph), torch.inference_mode():
            self._out.copy_(self._fwd(self._x, fresh))
        torch.cuda.synchronize()
        return graph

    def reset(self):
        self.fresh = True

    def process(self, features):
        """features: (C, n) float32 numpy -> (C, n) float32 numpy."""
        if self._graphs is not None:
            self._host_in.copy_(torch.from_numpy(features))
            self._x.copy_(self._host_in, non_blocking=True)
            fresh = self.fresh
            self.fresh = False
            self._graphs['fresh' if fresh else 'steady'].replay()
            self._host_out.copy_(self._out[0], non_blocking=True)
            torch.cuda.current_stream().synchronize()
            return self._host_out.numpy()
        x = torch.from_numpy(features).unsqueeze(0).to(self.device)
        fresh = self.fresh
        self.fresh = False
        with torch.inference_mode():
            out = self._fwd(x, fresh)
        return out[0].cpu().numpy()

    def chunks(self, features):
        """Whole request in one pass, then slice the output into contract chunks."""
        out = self.process(features)
        for index, pos in enumerate(range(0, self.L, self.chunk)):
            yield index, out[:, pos:pos + self.chunk]


class FusedChunkComputer(FusedComputer):
    """Same fused kernels, but evaluated one contract chunk at a time."""

    def __init__(self, repository, config, device):
        super().__init__(repository, config, device, use_graph=False)

    def chunks(self, features):
        for index, pos in enumerate(range(0, self.L, self.chunk)):
            part = np.ascontiguousarray(features[:, pos:pos + self.chunk])
            yield index, self.process(part)


class FourConvComputer:
    """Unfused four-convolution path built on the user's own reference pipeline.

    ``whole`` selects between the reference cadence (one pass per chunk) and a
    single pass over the complete request.
    """

    def __init__(self, repository, config, device, whole):
        from branch_features.model import ReferencePipeline
        cfg = dict(config)
        cfg['device'] = device
        self.pipe = ReferencePipeline(repository, cfg)
        self.whole = whole
        self.L = int(config['length'])
        self.chunk = int(config['chunk'])

    def reset(self):
        self.pipe.reset()

    def chunks(self, features):
        if self.whole:
            out = self.pipe.step(features)
            for index, pos in enumerate(range(0, self.L, self.chunk)):
                yield index, out[:, pos:pos + self.chunk]
        else:
            for index, pos in enumerate(range(0, self.L, self.chunk)):
                yield index, self.pipe.step(features[:, pos:pos + self.chunk])


VARIANTS = {
    # name -> (kind, kwargs)
    'chunkwise_4conv': ('4conv', {'whole': False}),
    'chunkwise_fused': ('fused_chunk', {}),
    'fullreq_4conv': ('4conv', {'whole': True}),
    'fullreq_fused': ('fused', {'use_graph': False}),
    'fullreq_fused_graph': ('fused', {'use_graph': True}),
    'fullreq_fused_cpu': ('fused', {'use_graph': False, 'device': 'cpu'}),
}


def build_computer(variant, repository, config, device):
    kind, kwargs = VARIANTS[variant]
    device = kwargs.get('device', device)
    if str(device).startswith('cuda') and not torch.cuda.is_available():
        device = 'cpu'
    if kind == '4conv':
        return FourConvComputer(repository, config, device, whole=kwargs['whole'])
    if kind == 'fused_chunk':
        return FusedChunkComputer(repository, config, device)
    return FusedComputer(repository, config, device, use_graph=kwargs.get('use_graph', False))


def main(variant):
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    repository = str(args.repository.resolve())
    sys.path.insert(0, repository)

    from branch_features.adapter import open_buffers, close_buffers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = config.get('device') or 'cuda'
    computer = build_computer(variant, repository, config, device)
    device = str(getattr(computer, 'device', device))

    buffers = open_buffers(config, create=True)
    in_buf, out_buf, meta_buf, control = (buffers['input'], buffers['output'],
                                          buffers['metadata'], buffers['control'])
    channels, chunk = int(config['channels']), int(config['chunk'])
    pad = np.zeros((channels, chunk), dtype=np.float32)
    consumed, last_command, active = 0, 0, False
    idle = 0
    try:
        print(json.dumps({'ready': True, 'device': device, 'task': 'branch_features',
                          'variant': variant}), flush=True)
        while True:
            opcode = control.recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    control.commit()
                    break
                if opcode == 3:
                    computer.reset()
                    active = False
                    control.commit()
                elif opcode == 1:
                    active = True
                    control.commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                idle += 1
                if idle >= 50000:
                    idle = 0
                    time.sleep(0.0)
                continue
            num = int(in_buf.num_arr[0])
            if num <= consumed:
                idle = 0
                continue
            if num - consumed > 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = num - 1
            features = np.ascontiguousarray(in_buf.tensor[request_id % in_buf.max_len])
            consumed = num
            for index, output in computer.chunks(features):
                valid = output.shape[-1]
                if valid == chunk:
                    payload = output
                else:
                    pad[:, :valid] = output
                    if valid < chunk:
                        pad[:, valid:] = 0.0
                    payload = pad
                out_buf.write(payload)
                meta_buf.write(np.array([request_id, index, valid], dtype=np.int64))
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)
