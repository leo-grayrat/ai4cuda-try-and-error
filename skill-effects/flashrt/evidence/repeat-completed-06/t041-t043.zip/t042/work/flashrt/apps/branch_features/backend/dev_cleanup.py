"""Remove the two entry points that were never launched end-to-end (the
upstream rule: a variant entry either has a matching benchmark record or does
not exist), and print the final backend inventory.
"""
from pathlib import Path

BACKEND = Path(__file__).resolve().parent
for rel in ('variants/chunkwise_4conv.py', 'entry.py'):
    path = BACKEND / rel
    if path.exists():
        path.unlink()
        print('removed', rel)

entries = sorted(p.relative_to(BACKEND).as_posix() for p in BACKEND.rglob('*.py'))
print('python entries:', entries)
measured = sorted(p.name for p in (BACKEND / 'benchmarks' / 'results').glob('*_RTX5060-8GB_*.json'))
print('measured variant records:', measured)
log = (BACKEND / 'notes' / 'experiment_log.md').read_text(encoding='utf-8')
for row in [line for line in log.splitlines() if line.startswith('| ')][:10]:
    print(row)
