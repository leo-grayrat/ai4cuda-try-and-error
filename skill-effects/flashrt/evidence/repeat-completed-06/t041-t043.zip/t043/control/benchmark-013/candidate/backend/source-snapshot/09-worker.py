"""Recommended branch_features backend (standalone entry).

Accepts --repository and --config and honours flashrt/apps/branch_features/adapter.py
exactly (same control opcodes, buffer names, chunk cadence and metadata).

Strategy (see backend/notes/experiment_log.md for the measurements):
  * both branches are fused into two conv launches per request (k=3 kernels are
    left-zero-padded to k=5 and the second stage runs as one grouped conv);
  * history is 4 samples of the raw input plus 4 samples of the branch-0 output;
    session start primes it with x[:, :, :1] (== the reference's replicate pad);
  * the whole 1043-sample request is one captured CUDA graph replay instead of
    nine python-driven chunk steps;
  * chunk 0 is copied out and published first, the remaining chunks follow in a
    single batched publish;
  * the input poll is a tight spin so the request is picked up immediately.

If CUDA-graph capture is unavailable the worker falls back to the same math
executed eagerly, so the adapter contract is always honoured.
"""
import sys

import numpy as np
import torch

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # launched directly from this directory
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
    import core
    import graphengine

def _busy_await(self, consumed, last_command):
    """Tight input poll (no sleep) to cut the input-pickup latency."""
    ctrl, inp = self.buffers['control'], self.buffers['input']
    while True:
        if ctrl.recv() != last_command:
            return None, None
        nxt, feats = inp.read(consumed, 1)
        if feats is not None:
            return nxt, feats


core.Protocol._await_input = _busy_await

class Session:
    def __init__(self, engine, proto):
        self.engine = engine
        self.ge = graphengine.GraphEngine(engine, proto.length, proto.chunk)

    def reset(self):
        self.engine.reset()
        self.ge.reset()

    def process(self, proto, features):
        ge = self.ge
        ge.load(features, pinned=True)
        ge.replay()
        proto.emit(ge.read_head())
        proto.emit_all(ge.read_all())

class FallbackSession:
    """Eager equivalent used when CUDA-graph capture is not available."""

    def __init__(self, engine, proto=None):
        self.engine = engine

    def reset(self):
        self.engine.reset()

    def process(self, proto, features):
        x = torch.from_numpy(np.ascontiguousarray(features)).to(self.engine.device)
        out = self.engine.forward(x)
        proto.emit_all(out[0].to('cpu').numpy())


def _build(engine, proto):
    try:
        return Session(engine, proto)
    except Exception as exc:  # capture unsupported -> eager, still exact
        print(f'warning: CUDA graph capture failed ({exc!r}); eager path', file=sys.stderr, flush=True)
        return FallbackSession(engine, proto)


def process(proto, engine, features):
    sess = getattr(proto, '_sess', None)
    if sess is None:
        sess = proto._sess = (
            _build(engine, proto))
        proto.engine = sess
    sess.process(proto, features)


if __name__ == '__main__':
    core.main(process, device='cuda')
