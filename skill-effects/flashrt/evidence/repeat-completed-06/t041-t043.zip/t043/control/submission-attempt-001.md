## 交付报告（branch_features 双分支因果特征后端）

**推荐入口**：`flashrt/apps/branch_features/backend/worker.py`（`--repository`/`--config`，严格遵循 `branch_features.adapter` 的共享内存缓冲名、控制码 0/1/2/3、单请求在途、127 采样输出块与 `(request_id, chunk_index, valid)` 元数据）。实现思路：把两条分支融合为两次卷积（k=3 卷积左补零到 k=5 后堆叠；第二级用分组卷积一次算完 A1/B1）；历史保留 4 个原始输入样本 + 4 个分支A输出样本，会话开始时用 `x[:,:,:1]` 复制填充，等价于参考的 `replicate` 填充；整个 1043 采样请求用一条已捕获的 CUDA 图重放完成；第 0 块先单独拷出并发布，其余 8 块批量发布；输入轮询改为紧循环自旋。若 CUDA 图捕获不可用则回退到同一数学的 eager 路径（打印 stderr 警告）。

**独立控制器验证**（`workspace.verify`，verify-012）：6 个完整请求（连续、无 reset 重复输入、reset、尾块）全部数值匹配，最大绝对误差 2.4e-7，进程清理已核验，状态 `candidate_run_passed`。

**独立控制器基准**（`workspace.benchmark`，benchmark-013，pilot 有限窗口，先参考后候选）：
- 首输出延迟中位：参考 1.51–1.56 ms → 候选 0.530–0.543 ms（约 −65%），p95 参考 1.62–2.12 ms → 候选 0.548–0.649 ms。
- 限速闸门：参考最高通过 100 req/s（200 req/s 时外部队列积压 72，rate_gate 失败）；候选 200 req/s 仍通过，峰值外部队列 0。
- 平滑度闸门：候选在 100 与 200 req/s 通过（块间隔中位 ~0.009 ms，p95 10.0 / 4.97 ms，超 20 ms 预算比例 0），但 **在 50 req/s 出现一次未通过平滑度闸门**（p95 20.03 ms，超预算比例 6.7%）。原因是第 0 块单独发布的“起步”事件在每次请求内都产生一个额外间隔样本；这是遗留的真实回退点，未修复。

**自建测量**（`tests/harness.py`，结果在 `benchmarks/results/*.json` 与 `*.log`）：参考 1.552/1.890 ms、500 chunks/s；推荐变体 0.533/0.562 ms、6500 chunks/s。共 13 个变体全部端到端跑通并有正确性+基准产物：`chunk_loop_fused`、`hist_ring_chunk`、`fullseq_fused`、`fullseq_graph`、`headstart_graph`、`pinned_async_graph`、`twostream_branch`、`im2col_gemm`、`cpu_fullseq`、`tf32_fullseq`、`spin_graph`、`combined_best`、`worker`。失败记录：`hist_ring_chunk` 首版环形历史未回填（最大差 0.94，已修复重测），`im2col_gemm` 首版 bmm 批维错误（运行时异常，已修复重测，PASS，1.53 ms / 3000 chunks/s）。融合、图捕获有效；双流分支并行与 TF32 无收益；CPU 全序列省 PCIe 但首输出仍差 3 倍。

**未完成/未达标项**：
1. IR 验证：`tests/test_ir.py` 首次运行失败——IR 执行器把 numpy 片段喂给 CausalConv1d 导致 `TypeError: pad(): argument 'input' must be Tensor`，所以 Phase-2“IR 执行器与参考端到端比对通过”的判据当前**未满足**，`notes/experiment_log.md` 里记录的是该失败，`summarize_graph` 分析文本也因之未落盘。
2. 控制器 50 req/s 下候选平滑度闸门未通过（见上）。
3. 单 GPU 任务，多设备流水线变体不适用；其 IR 依据（两分支状态互不相交 → 2 个流水级）已写入日志但未实现测量。
4. 日志中的队列行在若干项上以“measured（首版失败）”记录，后续修复后重测数据已落盘但队列文字未逐行改写。

**纪律条款自查**：“Implementation and debugging cost are never valid rationale” — 本次所有排队变体均实现了并端到端测量，产物见 `backend/benchmarks/results/`。“Read-only areas are not a blocker” — 未修改任何只读文件，参考代码仅通过 `ast` 读取 `flashrt/layers/audio.py` 的类定义。“Terminal statuses / What blocked means (strict)” — 无 `blocked`/`discarded` 行，也没有伪造的环境性阻塞证据。“Forbidden session-handoff language” — 报告与日志未使用任何“下一会话/后续会话”类措辞。“Adversarial self-framing (required)” — 不适用（无 blocked/discarded 行）。

文件均已保存在 `flashrt/apps/branch_features/backend/` 下（`worker.py`、`core.py`、`graphengine.py`、`ir/`、`variants/`、`tests/`、`benchmarks/results/`、`notes/experiment_log.md`、`README.md`）。