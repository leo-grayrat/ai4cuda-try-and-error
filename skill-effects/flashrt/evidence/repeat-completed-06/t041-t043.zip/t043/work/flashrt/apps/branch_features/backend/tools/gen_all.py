"""Create the variants directory tree and (re)run the variant generator."""
import pathlib
import runpy

BACKEND = pathlib.Path(__file__).resolve().parents[1]
(BACKEND / 'variants').mkdir(parents=True, exist_ok=True)
(BACKEND / 'variants' / '__init__.py').write_text('', encoding='utf-8')
runpy.run_path(str(BACKEND / 'tools' / 'gen_variants.py'), run_name='__main__')
