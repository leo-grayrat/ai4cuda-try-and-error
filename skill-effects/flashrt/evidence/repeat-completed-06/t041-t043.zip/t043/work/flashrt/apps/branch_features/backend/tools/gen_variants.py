"""Generate the deployment-variant worker entries under backend/variants/.

Each generated worker is a complete, standalone backend entry (accepts
--repository/--config, honours the branch_features adapter protocol) and
differs in its chunk-scheduling / model-execution strategy.  Shared model
math and IPC plumbing live in backend/core.py (documented there); the CUDA
graph executor lives in backend/graphengine.py.

Run:  python flashrt/apps/branch_features/backend/tools/gen_variants.py
"""
import pathlib

BACKEND = pathlib.Path(__file__).resolve().parents[1]

# ---------------------------------------------------------------- core patch
core_path = BACKEND / 'core.py'
text = core_path.read_text(encoding='utf-8')
if 'flashrt' in text and "sys.path.insert(0, repository)" in text:
    text = text.replace(
        "    sys.path.insert(0, repository)\n",
        "    for _p in (repository, str(Path(repository) / 'flashrt' / 'apps')):\n"
        "        if _p not in sys.path:\n"
        "            sys.path.insert(0, _p)\n",
    )
    text = text.replace(
        "        from branch_features.adapter import open_buffers, close_buffers\n",
        "        try:\n"
        "            from branch_features.adapter import open_buffers, close_buffers\n"
        "        except ImportError:\n"
        "            from flashrt.apps.branch_features.adapter import open_buffers, close_buffers\n",
    )
    core_path.write_text(text, encoding='utf-8')
    print('patched core.py')

for d in [BACKEND, BACKEND / 'variants']:
    (d / '__init__.py').write_text('', encoding='utf-8')

HEADER = '''"""Variant `{name}`: {desc}

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/core.py.
"""
import sys

import numpy as np
import torch
import torch.nn.functional as F

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
    import core
    import graphengine
'''

FOOTER = '''

if __name__ == '__main__':
    core.main(process, device={device!r}{extra})
'''

GRAPH_SESSION = '''
class Session:
    """Holds the CUDA-graph executor and keeps history reset in sync."""

    def __init__(self, engine, proto):
        self.engine = engine
        self.ge = graphengine.GraphEngine(engine, proto.length, proto.chunk)
        self.mode = {mode!r}

    def reset(self):
        self.engine.reset()
        self.ge.reset()

    def process(self, proto, features):
        ge = self.ge
        ge.load(features, pinned={pinned!r})
        ge.replay()
{emit}

def process(proto, engine, features):
    sess = getattr(proto, '_sess', None)
    if sess is None:
        sess = proto._sess = Session(engine, proto)
        proto.engine = sess  # core.Protocol calls engine.reset() on opcode 3
    sess.process(proto, features)
'''

VARIANT_BY_NAME = {}

# ------------------------------------------------------------------ variants
VARIANT_BY_NAME['chunk_loop_fused'] = dict(
    desc='reference cadence with both branches fused into two conv launches per chunk',
    device='cuda', extra='',
    body='''

def process(proto, engine, features):
    dev = engine.device
    x = torch.from_numpy(np.ascontiguousarray(features)).to(dev)
    total, chunk = x.shape[-1], proto.chunk
    for lo in range(0, total, chunk):
        out = engine.forward(x[:, :, lo:lo + chunk])
        proto.emit(out[0].to('cpu').numpy())
''')

VARIANT_BY_NAME['fullseq_fused'] = dict(
    desc='one whole-request fused pass instead of nine chunk passes',
    device='cuda', extra='',
    body='''

def process(proto, engine, features):
    dev = engine.device
    x = torch.from_numpy(np.ascontiguousarray(features)).to(dev)
    out = engine.forward(x)
    proto.emit_all(out[0].to('cpu').numpy())
''')

GRAPH_BODY_EMIT_ALL = '''
        proto.emit_all(ge.read_all())
'''
GRAPH_BODY_HEAD = '''
        proto.emit(ge.read_head())
        proto.emit_all(ge.read_all())
'''

VARIANT_BY_NAME['fullseq_graph'] = dict(
    desc='whole-request fused pass replayed from a captured CUDA graph',
    device='cuda', extra='',
    body=GRAPH_SESSION.format(mode='all', pinned=False, emit=GRAPH_BODY_EMIT_ALL))

VARIANT_BY_NAME['headstart_graph'] = dict(
    desc='CUDA graph replay, chunk 0 copied out and published before the rest',
    device='cuda', extra='',
    body=GRAPH_SESSION.format(mode='head', pinned=False, emit=GRAPH_BODY_HEAD))

VARIANT_BY_NAME['pinned_async_graph'] = dict(
    desc='CUDA graph + pinned-memory async H2D/D2H staging',
    device='cuda', extra='',
    body=GRAPH_SESSION.format(mode='pinned', pinned=True, emit=GRAPH_BODY_EMIT_ALL))

VARIANT_BY_NAME['cpu_fullseq'] = dict(
    desc='whole-request fused pass on the CPU (no PCIe round trip)',
    device='cpu', extra='',
    body='''

def process(proto, engine, features):
    x = torch.from_numpy(np.ascontiguousarray(features))
    out = engine.forward(x)
    proto.emit_all(out[0].numpy())
''')

VARIANT_BY_NAME['im2col_gemm'] = dict(
    desc='whole-request convs as explicit unfold+GEMM (im2col) on the GPU',
    device='cuda', extra='',
    body='''

def conv_gemm(padded, weight, bias, groups=1):
    """padded: (1,Cin,Lp) already causal-padded; weight: (Cout,Cin//g,5)."""
    x = padded[0]
    length = x.shape[-1] - 4
    win = x.unfold(-1, 5, 1)                      # (Cin, L, 5)
    if groups == 1:
        mat = win.permute(1, 0, 2).reshape(length, -1)
        return (mat @ weight.reshape(weight.shape[0], -1).t() + bias).t().unsqueeze(0)
    cin_g, cout_g = weight.shape[1], weight.shape[0] // groups
    mat = win.reshape(groups, cin_g, length, 5).permute(2, 0, 1, 3).reshape(length, groups, cin_g * 5)
    wg = weight.reshape(groups, cout_g, cin_g * 5).transpose(1, 2)
    out = torch.bmm(mat, wg)                      # (L, groups, Cout//groups)
    return out.permute(1, 2, 0).reshape(weight.shape[0], length).add(bias.unsqueeze(-1)).unsqueeze(0)


class GemmEngine:
    def __init__(self, engine):
        self.e = engine
        self.dev = engine.device
        self.reset()

    def reset(self):
        e = self.e
        self.hist_in = torch.zeros(1, e.channels, 4, device=self.dev)
        self.hist_mid = torch.zeros(1, 2 * e.hidden, 4, device=self.dev)
        self.primed = False

    def forward(self, x):
        e, prime = self.e, not self.primed
        hist = x[:, :, :1].expand(-1, -1, 4) if prime else self.hist_in
        joined = torch.cat([hist, x], -1)
        mid = F.silu(conv_gemm(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))[:, :, 4:]
        hist_mid = mid[:, :, :1].expand(-1, -1, 4) if prime else self.hist_mid
        jm = torch.cat([hist_mid, mid], -1)
        y = conv_gemm(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]
        self.hist_in = joined[:, :, -4:].clone()
        self.hist_mid = jm[:, :, -4:].clone()
        self.primed = True
        a, b = y[:, :e.channels], y[:, e.channels:]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return gate * a + (1 - gate) * b + 0.1 * x


def process(proto, engine, features):
    ge = getattr(proto, '_gemm', None)
    if ge is None:
        ge = proto._gemm = GemmEngine(engine)
        proto.engine = ge  # reset hook
    x = torch.from_numpy(np.ascontiguousarray(features)).to(engine.device)
    out = ge.forward(x)
    proto.emit_all(out[0].to('cpu').numpy())
''')

VARIANT_BY_NAME['twostream_branch'] = dict(
    desc='per-chunk loop, the two branches run concurrently on two CUDA streams',
    device='cuda', extra='',
    body='''

class StreamEngine:
    def __init__(self, engine):
        self.e = engine
        self.dev = engine.device
        self.s_a = torch.cuda.Stream()
        self.s_b = torch.cuda.Stream()
        self.reset()

    def reset(self):
        e = self.e
        self.hist_in = torch.zeros(1, e.channels, 4, device=self.dev)
        self.hist_mid = torch.zeros(1, 2 * e.hidden, 4, device=self.dev)
        self.primed = False

    def forward(self, x):
        e, prime, hidden = self.e, not self.primed, self.e.hidden
        hist = x[:, :, :1].expand(-1, -1, 4) if prime else self.hist_in
        joined = torch.cat([hist, x], -1)
        padded = F.pad(joined, (4, 0), mode='replicate')
        cur = torch.cuda.current_stream()
        start = torch.cuda.Event()
        start.record(cur)
        self.s_a.wait_event(start)
        self.s_b.wait_event(start)
        with torch.cuda.stream(self.s_a):
            mid_a = F.silu(F.conv1d(padded, e.sep_w['a0'], e.sep_b['a0']))[:, :, 4:]
            h_a = mid_a[:, :, :1].expand(-1, -1, 4) if prime else self.hist_mid[:, :hidden]
            jm_a = torch.cat([h_a, mid_a], -1)
            out_a = F.conv1d(F.pad(jm_a, (4, 0), mode='replicate'), e.sep_w['a1'], e.sep_b['a1'])[:, :, 4:]
        with torch.cuda.stream(self.s_b):
            mid_b = F.silu(F.conv1d(padded, e.sep_w['b0'], e.sep_b['b0']))[:, :, 4:]
            h_b = mid_b[:, :, :1].expand(-1, -1, 4) if prime else self.hist_mid[:, hidden:]
            jm_b = torch.cat([h_b, mid_b], -1)
            out_b = F.conv1d(F.pad(jm_b, (4, 0), mode='replicate'), e.sep_w['b1'], e.sep_b['b1'])[:, :, 4:]
        done_a, done_b = torch.cuda.Event(), torch.cuda.Event()
        done_a.record(self.s_a)
        done_b.record(self.s_b)
        cur.wait_event(done_a)
        cur.wait_event(done_b)
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        out = gate * out_a + (1 - gate) * out_b + 0.1 * x
        self.hist_in = joined[:, :, -4:].clone()
        self.hist_mid = torch.cat([jm_a[:, :, -4:], jm_b[:, :, -4:]], 1).clone()
        self.primed = True
        return out


def process(proto, engine, features):
    se = getattr(proto, '_se', None)
    if se is None:
        se = proto._se = StreamEngine(engine)
        proto.engine = se
    x = torch.from_numpy(np.ascontiguousarray(features)).to(engine.device)
    total, chunk = x.shape[-1], proto.chunk
    for lo in range(0, total, chunk):
        out = se.forward(x[:, :, lo:lo + chunk])
        proto.emit(out[0].to('cpu').numpy())
''')

VARIANT_BY_NAME['hist_ring_chunk'] = dict(
    desc='per-chunk loop with preallocated ring-buffer history (allocation-free steady state)',
    device='cuda', extra='',
    body='''

class RingEngine:
    def __init__(self, engine, chunk):
        self.e = engine
        self.dev = engine.device
        self.chunk = chunk
        self.buf_in = torch.zeros(1, engine.channels, 4 + chunk, device=self.dev)
        self.buf_mid = torch.zeros(1, 2 * engine.hidden, 4 + chunk, device=self.dev)
        self.primed = False

    def reset(self):
        self.buf_in.zero_()
        self.buf_mid.zero_()
        self.primed = False

    def forward(self, x):
        e = self.e
        total = x.shape[-1]
        buf = self.buf_in
        if not self.primed:
            buf[:, :, :4] = x[:, :, :1].expand(-1, -1, 4)
        buf[:, :, 4:4 + total] = x
        joined = buf[:, :, :4 + total]
        mid = F.silu(F.conv1d(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))
        mbuf = self.buf_mid
        if not self.primed:
            mbuf[:, :, :4] = mid[:, :, :1].expand(-1, -1, 4)
        mbuf[:, :, 4:4 + total] = mid
        jm = mbuf[:, :, :4 + total]
        y = F.conv1d(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)
        self.primed = True
        a, b = y[:, :e.channels], y[:, e.channels:]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return gate * a + (1 - gate) * b + 0.1 * x


def process(proto, engine, features):
    ring = getattr(proto, '_ring', None)
    if ring is None:
        ring = proto._ring = RingEngine(engine, proto.chunk)
        proto.engine = ring
    x = torch.from_numpy(np.ascontiguousarray(features)).to(engine.device)
    total, chunk = x.shape[-1], proto.chunk
    for lo in range(0, total, chunk):
        out = ring.forward(x[:, :, lo:lo + chunk])
        proto.emit(out[0].to('cpu').numpy())
''')

VARIANT_BY_NAME['tf32_fullseq'] = dict(
    desc='whole-request fused pass with TF32 conv/matmul enabled',
    device='cuda', extra=', tf32=True',
    body=VARIANT_BY_NAME['fullseq_fused']['body'])

VARIANT_BY_NAME['combined_best'] = dict(
    desc='CUDA graph + head-start publish + pinned async staging stacked',
    device='cuda', extra='',
    body=GRAPH_SESSION.format(mode='combined', pinned=True, emit=GRAPH_BODY_HEAD))


def write_variant(name, spec):
    directory = BACKEND / 'variants' / name
    directory.mkdir(parents=True, exist_ok=True)
    (directory / '__init__.py').write_text('', encoding='utf-8')
    src = HEADER.format(name=name, desc=spec['desc']) + spec['body'] + FOOTER.format(
        device=spec['device'], extra=spec['extra'])
    (directory / 'worker.py').write_text(src, encoding='utf-8')
    print('wrote', directory / 'worker.py')


for name, spec in VARIANT_BY_NAME.items():
    write_variant(name, spec)
