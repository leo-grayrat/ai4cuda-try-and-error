"""Round-1 fixes: slice conv outputs back to the new-sample positions, measure
intra-request chunk gaps only, shorter adapter timeouts.

The causal conv over [history | new samples] emits one output per *joined*
position (length hist+L); the reference keeps only the last L (`out[:,
:, history.shape[-1]:]`).  Mirroring that slice everywhere is required before
`gate * A + (1-gate) * B + 0.1 * x` lines up with x.
"""
import pathlib

BACKEND = pathlib.Path(__file__).resolve().parents[1]

CONV_FIXES = {
    'core.py': [
        ("        mid = F.silu(F.conv1d(F.pad(joined, (PINS, 0), mode='replicate'), self.W0, self.B0))\n",
         "        mid = F.silu(F.conv1d(F.pad(joined, (PINS, 0), mode='replicate'), self.W0, self.B0))[:, :, PINS:]\n"),
        ("        y = F.conv1d(F.pad(joined_mid, (PINS, 0), mode='replicate'), self.W1, self.B1, groups=2)\n",
         "        y = F.conv1d(F.pad(joined_mid, (PINS, 0), mode='replicate'), self.W1, self.B1, groups=2)[:, :, PINS:]\n"),
    ],
    'graphengine.py': [
        ("        mid = F.silu(F.conv1d(F.pad(joined, (PINS, 0), mode='replicate'), e.W0, e.B0))\n",
         "        mid = F.silu(F.conv1d(F.pad(joined, (PINS, 0), mode='replicate'), e.W0, e.B0))[:, :, PINS:]\n"),
        ("        y = F.conv1d(F.pad(jm, (PINS, 0), mode='replicate'), e.W1, e.B1, groups=2)\n",
         "        y = F.conv1d(F.pad(jm, (PINS, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, PINS:]\n"),
    ],
    'variants/im2col_gemm/worker.py': [
        ("        mid = F.silu(conv_gemm(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))\n",
         "        mid = F.silu(conv_gemm(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))[:, :, 4:]\n"),
        ("        y = conv_gemm(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)\n",
         "        y = conv_gemm(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]\n"),
    ],
    'variants/twostream_branch/worker.py': [
        ("            mid_a = F.silu(F.conv1d(padded, e.sep_w['a0'], e.sep_b['a0']))\n",
         "            mid_a = F.silu(F.conv1d(padded, e.sep_w['a0'], e.sep_b['a0']))[:, :, 4:]\n"),
        ("            out_a = F.conv1d(F.pad(jm_a, (4, 0), mode='replicate'), e.sep_w['a1'], e.sep_b['a1'])\n",
         "            out_a = F.conv1d(F.pad(jm_a, (4, 0), mode='replicate'), e.sep_w['a1'], e.sep_b['a1'])[:, :, 4:]\n"),
        ("            mid_b = F.silu(F.conv1d(padded, e.sep_w['b0'], e.sep_b['b0']))\n",
         "            mid_b = F.silu(F.conv1d(padded, e.sep_w['b0'], e.sep_b['b0']))[:, :, 4:]\n"),
        ("            out_b = F.conv1d(F.pad(jm_b, (4, 0), mode='replicate'), e.sep_w['b1'], e.sep_b['b1'])\n",
         "            out_b = F.conv1d(F.pad(jm_b, (4, 0), mode='replicate'), e.sep_w['b1'], e.sep_b['b1'])[:, :, 4:]\n"),
    ],
    'variants/hist_ring_chunk/worker.py': [
        ("        mid = F.silu(F.conv1d(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))\n",
         "        mid = F.silu(F.conv1d(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))[:, :, 4:]\n"),
        ("        y = F.conv1d(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)\n",
         "        y = F.conv1d(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]\n"),
    ],
    # keep the generator in sync so regeneration reproduces the fixed variants
    'tools/gen_variants.py': [
        ("            mid_a = F.silu(F.conv1d(padded, e.sep_w['a0'], e.sep_b['a0']))\\n",
         "            mid_a = F.silu(F.conv1d(padded, e.sep_w['a0'], e.sep_b['a0']))[:, :, 4:]\\n"),
        ("            out_a = F.conv1d(F.pad(jm_a, (4, 0), mode='replicate'), e.sep_w['a1'], e.sep_b['a1'])\\n",
         "            out_a = F.conv1d(F.pad(jm_a, (4, 0), mode='replicate'), e.sep_w['a1'], e.sep_b['a1'])[:, :, 4:]\\n"),
        ("            mid_b = F.silu(F.conv1d(padded, e.sep_w['b0'], e.sep_b['b0']))\\n",
         "            mid_b = F.silu(F.conv1d(padded, e.sep_w['b0'], e.sep_b['b0']))[:, :, 4:]\\n"),
        ("            out_b = F.conv1d(F.pad(jm_b, (4, 0), mode='replicate'), e.sep_w['b1'], e.sep_b['b1'])\\n",
         "            out_b = F.conv1d(F.pad(jm_b, (4, 0), mode='replicate'), e.sep_w['b1'], e.sep_b['b1'])[:, :, 4:]\\n"),
        ("        mid = F.silu(conv_gemm(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))\\n",
         "        mid = F.silu(conv_gemm(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))[:, :, 4:]\\n"),
        ("        y = conv_gemm(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)\\n",
         "        y = conv_gemm(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]\\n"),
        ("        mid = F.silu(F.conv1d(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))\\n",
         "        mid = F.silu(F.conv1d(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))[:, :, 4:]\\n"),
        ("        y = F.conv1d(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)\\n",
         "        y = F.conv1d(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]\\n"),
    ],
}

HARNESS_FIXES = [
    ("        gaps, stamps, stalls = [], [], 0\n", "        gaps, stamps, stalls = [], [], 0\n"),
    ("""            while True:
                _data, observed = adapter.receive(timeout_s=60)
                stamps.append(observed)
                if adapter.pending is None:
                    break
            last_drain = time.perf_counter()
""",
     """            chan = []
            while True:
                _data, observed = adapter.receive(timeout_s=20)
                stamps.append(observed)
                chan.append(observed)
                if adapter.pending is None:
                    break
            for a, b in zip(chan, chan[1:]):
                gaps.append((b - a) / 1e9)
            last_drain = time.perf_counter()
"""),
    ("""        for a, b in zip(stamps, stamps[1:]):
            gaps.append((b - a) / 1e9)
""",
     """        # Inter-chunk gaps are measured within a request only: the sweep's
        # offered-rate pacing intentionally spaces requests, so cross-request
        # gaps reflect the schedule rather than backend smoothness.
"""),
    ("timeout_s=60", "timeout_s=20"),
]


def patch(rel, fixes, required=True):
    path = BACKEND / rel
    text = path.read_text(encoding='utf-8')
    for old, new in fixes:
        if old not in text:
            if required:
                raise SystemExit(f'MISSING in {rel}: {old[:70]!r}')
            continue
        text = text.replace(old, new)
    path.write_text(text, encoding='utf-8')
    print('patched', rel)


for rel, fixes in CONV_FIXES.items():
    patch(rel, fixes)
patch('tests/harness.py', HARNESS_FIXES)
print('done')
