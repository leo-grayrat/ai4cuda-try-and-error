"""Variant `im2col_gemm`: whole-request convs as explicit unfold+GEMM (im2col) on the GPU

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/core.py.
"""
import sys

import numpy as np
import torch
import torch.nn.functional as F

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
    import core
    import graphengine


def conv_gemm(padded, weight, bias, groups=1):
    """padded: (1,Cin,Lp) already causal-padded; weight: (Cout,Cin//g,5)."""
    x = padded[0]
    length = x.shape[-1] - 4
    win = x.unfold(-1, 5, 1)                      # (Cin, L, 5)
    if groups == 1:
        mat = win.permute(1, 0, 2).reshape(length, -1)
        return (mat @ weight.reshape(weight.shape[0], -1).t() + bias).t().unsqueeze(0)
    cin_g, cout_g = weight.shape[1], weight.shape[0] // groups
    # (groups, L, cin_g*5) @ (groups, cin_g*5, Cout/groups)
    mat = win.reshape(groups, cin_g, length, 5).permute(0, 2, 1, 3).reshape(groups, length, cin_g * 5)
    wg = weight.reshape(groups, cout_g, cin_g * 5).transpose(1, 2)
    out = torch.bmm(mat, wg)                      # (groups, L, Cout//groups)
    out = out.permute(0, 2, 1).reshape(weight.shape[0], length)
    return out.add(bias.unsqueeze(-1)).unsqueeze(0)


class GemmEngine:
    def __init__(self, engine):
        self.e = engine
        self.dev = engine.device
        self.reset()

    def reset(self):
        e = self.e
        self.hist_in = torch.zeros(1, e.channels, 4, device=self.dev)
        self.hist_mid = torch.zeros(1, 2 * e.hidden, 4, device=self.dev)
        self.primed = False

    def forward(self, x):
        e, prime = self.e, not self.primed
        hist = x[:, :, :1].expand(-1, -1, 4) if prime else self.hist_in
        joined = torch.cat([hist, x], -1)
        mid = F.silu(conv_gemm(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))[:, :, 4:]
        hist_mid = mid[:, :, :1].expand(-1, -1, 4) if prime else self.hist_mid
        jm = torch.cat([hist_mid, mid], -1)
        y = conv_gemm(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]
        self.hist_in = joined[:, :, -4:].clone()
        self.hist_mid = jm[:, :, -4:].clone()
        self.primed = True
        a, b = y[:, :e.channels], y[:, e.channels:]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return gate * a + (1 - gate) * b + 0.1 * x


def process(proto, engine, features):
    ge = getattr(proto, '_gemm', None)
    if ge is None:
        ge = proto._gemm = GemmEngine(engine)
        proto.engine = ge  # reset hook
    x = torch.from_numpy(np.ascontiguousarray(features)).to(engine.device)
    out = ge.forward(x)
    proto.emit_all(out[0].to('cpu').numpy())


if __name__ == '__main__':
    core.main(process, device='cuda')
