"""Stage runner: patch + drive tests/harness.py over the whole variant set.

Usage:
  python flashrt/apps/branch_features/backend/tools/stage.py --stage correct [--only a,b]
  python flashrt/apps/branch_features/backend/tools/stage.py --stage bench   [--only a,b]
"""
import argparse
import pathlib
import runpy
import sys

BACKEND = pathlib.Path(__file__).resolve().parents[1]
APP = 'flashrt/apps/branch_features'
ENTRIES = {
    'ref': f'{APP}/reference.py',
    'chunk_loop_fused': f'{APP}/backend/variants/chunk_loop_fused/worker.py',
    'fullseq_fused': f'{APP}/backend/variants/fullseq_fused/worker.py',
    'fullseq_graph': f'{APP}/backend/variants/fullseq_graph/worker.py',
    'headstart_graph': f'{APP}/backend/variants/headstart_graph/worker.py',
    'pinned_async_graph': f'{APP}/backend/variants/pinned_async_graph/worker.py',
    'cpu_fullseq': f'{APP}/backend/variants/cpu_fullseq/worker.py',
    'im2col_gemm': f'{APP}/backend/variants/im2col_gemm/worker.py',
    'twostream_branch': f'{APP}/backend/variants/twostream_branch/worker.py',
    'hist_ring_chunk': f'{APP}/backend/variants/hist_ring_chunk/worker.py',
    'tf32_fullseq': f'{APP}/backend/variants/tf32_fullseq/worker.py',
    'combined_best': f'{APP}/backend/variants/combined_best/worker.py',
    'worker': f'{APP}/backend/worker.py',
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--stage', default='both', choices=['both', 'correct', 'bench'])
    ap.add_argument('--only', default='')
    ap.add_argument('--outdir', default=f'{APP}/backend/benchmarks/results')
    ap.add_argument('--rates', default='200,500,900,1400,2000,3000,4500,6500,9000')
    args = ap.parse_args()

    harness = BACKEND / 'tests' / 'harness.py'
    text = harness.read_text(encoding='utf-8')
    if 'parents[4]' in text:
        harness.write_text(text.replace('parents[4]', 'parents[5]'), encoding='utf-8')
        print('patched harness REPO resolution')

    names = [n for n in (args.only.split(',') if args.only else ENTRIES) if n]
    entries = ','.join(f'{n}={ENTRIES[n]}' for n in names)
    sys.argv = [str(harness), '--entries', entries, '--outdir', args.outdir,
                '--mode', args.stage, '--rates', args.rates]
    runpy.run_path(str(harness), run_name='__main__')


if __name__ == '__main__':
    main()
