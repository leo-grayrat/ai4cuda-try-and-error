"""Environment / dependency diagnostics (agent scratch, not a benchmark)."""
import ast, inspect, json, pathlib, re, sys

root = pathlib.Path('.').resolve()
print('cwd', root)
import torch, numpy
print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), 'numpy', numpy.__version__)
if torch.cuda.is_available():
    print('gpu', torch.cuda.get_device_name(0), torch.cuda.get_device_properties(0).total_memory)

src = (root / 'flashrt/layers/audio.py').read_text(encoding='utf-8')
node = next(n for n in ast.parse(src).body if isinstance(n, ast.ClassDef) and n.name == 'CausalConv1d')
print('=== CausalConv1d ===')
print(ast.get_source_segment(src, node))

for name in ['flashrt/channels/shm_channel/tensor_buffer.py',
             'flashrt/channels/shm_channel/control_buffer.py']:
    p = root / name
    print(f'=== {name} ===')
    text = p.read_text(encoding='utf-8')
    print(text)

print('=== files mentioning branch_features / causal_features configs ===')
for p in root.rglob('*'):
    if p.is_file() and p.suffix in {'.yaml', '.yml', '.json', '.py', '.md'} and 'backend/' not in str(p):
        try:
            t = p.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            continue
        if 'branch_features' in t or 'causal_features' in t:
            print(p.relative_to(root))
