"""Phase-1 IR graph builders for the branch_features pipeline.

Two graphs:
  * ``branch_features/model``  - the fine-grained per-chunk graph (four convs,
    two SiLUs, gate/merge) with the four history StateObjects.
  * ``branch_features/worker`` - the high-level stage graph (ingest -> model ->
    publish) whose model stage is the COMPOSITE sub-graph above and whose
    model->publish edge is a fixed-rate 1:1 streaming edge (one output chunk per
    input chunk, both 127 samples in the default development config).
"""
from flashrt.ir import (IRGraph, IREdge, OpType, StateObject, StreamMode,
                        StreamingInfo, StreamingPattern, TensorPort)

from flashrt.apps.branch_features.backend.ir.ops import (
    CausalConv, ModelStage, gate_merge, ingest, publish, silu_a, silu_b,
)

HISTORIES = ('hist_a0', 'hist_a1', 'hist_b0', 'hist_b1')


def build_model_graph(config):
    graph = IRGraph(name='branch_features/model')
    for hist in HISTORIES:
        graph.add_state(StateObject(name=hist, scope='chunk_persistent',
                                    description=f'{hist}: sliding causal input history'))
    a0 = CausalConv('a0', 'a0', 'hist_a0')
    a1 = CausalConv('a1', 'a1', 'hist_a1')
    b0 = CausalConv('b0', 'b0', 'hist_b0')
    b1 = CausalConv('b1', 'b1', 'hist_b1')
    for op in (a0, silu_a, a1, b0, silu_b, b1, gate_merge):
        graph.add_operator(op)
    graph.external_inputs = [TensorPort('x'), TensorPort('features')]
    graph.external_outputs = [TensorPort('y')]
    graph.add_edge(IREdge('a0', 'y', 'silu_a', 'x'))
    graph.add_edge(IREdge('silu_a', 'y', 'a1', 'x'))
    graph.add_edge(IREdge('b0', 'y', 'silu_b', 'x'))
    graph.add_edge(IREdge('silu_b', 'y', 'b1', 'x'))
    graph.add_edge(IREdge('a1', 'y', 'gate_merge', 'branch_a'))
    graph.add_edge(IREdge('b1', 'y', 'gate_merge', 'branch_b'))
    graph.chunk_ops = ['a0', 'silu_a', 'a1', 'b0', 'silu_b', 'b1', 'gate_merge']
    return graph


def build_worker_graph(config):
    graph = IRGraph(name='branch_features/worker')
    model = build_model_graph(config)
    graph.sub_graphs['model'] = model
    for hist in HISTORIES:
        graph.add_state(StateObject(name=hist, scope='chunk_persistent',
                                    description=f'{hist}: owned by the model sub-graph'))
    graph.add_operator(ingest)
    graph.add_operator(ModelStage(HISTORIES))
    graph.add_operator(publish)
    graph.external_inputs = [TensorPort('x'), TensorPort('features')]
    graph.external_outputs = [TensorPort('out')]
    graph.add_edge(IREdge('ingest', 'x', 'model', 'x'))
    graph.add_edge(IREdge('ingest', 'features', 'model', 'features'))
    chunk = int(config['chunk'])
    graph.add_edge(IREdge('model', 'y', 'publish', 'y',
                          streaming=StreamingInfo(pattern=StreamingPattern.FIXED_RATE,
                                                  src_chunk_size=chunk, dst_chunk_size=chunk,
                                                  description='one output chunk per input chunk')))
    graph.chunk_ops = ['ingest', 'model', 'publish']
    return graph
