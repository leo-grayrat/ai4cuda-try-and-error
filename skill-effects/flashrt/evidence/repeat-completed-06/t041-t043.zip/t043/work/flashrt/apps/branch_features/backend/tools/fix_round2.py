"""Round-2: fix im2col (non-contiguous view) + ring-history carry, add the
spin-poll graph variant, and write the recommended backend/worker.py entry.
"""
import pathlib

BACKEND = pathlib.Path(__file__).resolve().parents[1]


def patch(rel, fixes):
    path = BACKEND / rel
    text = path.read_text(encoding='utf-8')
    for old, new in fixes:
        if old not in text:
            print(f'  MISSING in {rel}: {old.splitlines()[0][:70]!r}')
            continue
        text = text.replace(old, new)
    path.write_text(text, encoding='utf-8')
    print('patched', rel)


patch('variants/im2col_gemm/worker.py', [
    ("    mat = win.view(groups, cin_g, length, 5).permute(2, 0, 1, 3).reshape(length, groups, cin_g * 5)\n",
     "    mat = win.reshape(groups, cin_g, length, 5).permute(2, 0, 1, 3).reshape(length, groups, cin_g * 5)\n"),
])
patch('tools/gen_variants.py', [
    ("    mat = win.view(groups, cin_g, length, 5).permute(2, 0, 1, 3).reshape(length, groups, cin_g * 5)\n",
     "    mat = win.reshape(groups, cin_g, length, 5).permute(2, 0, 1, 3).reshape(length, groups, cin_g * 5)\n"),
])
patch('variants/hist_ring_chunk/worker.py', [
    ("        y = F.conv1d(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]\n"
     "        self.primed = True\n",
     "        y = F.conv1d(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]\n"
     "        # carry the newest 4 samples to the front of the ring (allocation-free history)\n"
     "        buf[:, :, :4] = buf[:, :, total:total + 4].clone()\n"
     "        mbuf[:, :, :4] = mbuf[:, :, total:total + 4].clone()\n"
     "        self.primed = True\n"),
])

HEADER = '''"""Variant `{name}`: {desc}

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/{shared}.
"""
import sys

import numpy as np
import torch

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[{depth}]))
    import core
    if '{with_graph}' == 'yes':
        import graphengine
'''

BUSY = '''
def _busy_await(self, consumed, last_command):
    """Tight input poll (no sleep) to cut the input-pickup latency."""
    ctrl, inp = self.buffers['control'], self.buffers['input']
    while True:
        if ctrl.recv() != last_command:
            return None, None
        nxt, feats = inp.read(consumed, 1)
        if feats is not None:
            return nxt, feats


core.Protocol._await_input = _busy_await
'''

GRAPH_SESSION = '''
class Session:
    def __init__(self, engine, proto):
        self.engine = engine
        self.ge = graphengine.GraphEngine(engine, proto.length, proto.chunk)

    def reset(self):
        self.engine.reset()
        self.ge.reset()

    def process(self, proto, features):
        ge = self.ge
        ge.load(features, pinned=True)
        ge.replay()
        proto.emit(ge.read_head())
        proto.emit_all(ge.read_all())
'''

PLAIN_SESSION = '''
class Session:
    """Plain (no graph) whole-request path; also the capture fallback."""

    def __init__(self, engine, proto=None):
        self.engine = engine

    def reset(self):
        self.engine.reset()

    def process(self, proto, features):
        x = torch.from_numpy(np.ascontiguousarray(features)).to(self.engine.device)
        out = self.engine.forward(x)
        proto.emit_all(out[0].to('cpu').numpy())
'''

PROCESS = '''

def process(proto, engine, features):
    sess = getattr(proto, '_sess', None)
    if sess is None:
        sess = proto._sess = (
            Session(engine, proto))
        proto.engine = sess
    sess.process(proto, features)
'''

FOOTER = '''

if __name__ == '__main__':
    core.main(process, device='cuda')
'''

# ------------------------------------------------------- spin_graph variant
spin = (HEADER.format(name='spin_graph',
                      desc='CUDA graph + head-start publish + pinned staging + busy-poll input pickup',
                      shared='core.py + graphengine.py', depth=1, with_graph='yes')
        + BUSY + GRAPH_SESSION + PROCESS + FOOTER)
d = BACKEND / 'variants' / 'spin_graph'
d.mkdir(parents=True, exist_ok=True)
(d / '__init__.py').write_text('', encoding='utf-8')
(d / 'worker.py').write_text(spin, encoding='utf-8')
print('wrote', d / 'worker.py')

# ------------------------------------------------------- recommended entry
RECOMMENDED_HEADER = '''"""Recommended branch_features backend (standalone entry).

Accepts --repository and --config and honours flashrt/apps/branch_features/adapter.py
exactly (same control opcodes, buffer names, chunk cadence and metadata).

Strategy (see backend/notes/experiment_log.md for the measurements):
  * both branches are fused into two conv launches per request (k=3 kernels are
    left-zero-padded to k=5 and the second stage runs as one grouped conv);
  * history is 4 samples of the raw input plus 4 samples of the branch-0 output;
    session start primes it with x[:, :, :1] (== the reference's replicate pad);
  * the whole 1043-sample request is one captured CUDA graph replay instead of
    nine python-driven chunk steps;
  * chunk 0 is copied out and published first, the remaining chunks follow in a
    single batched publish;
  * the input poll is a tight spin so the request is picked up immediately.

If CUDA-graph capture is unavailable the worker falls back to the same math
executed eagerly, so the adapter contract is always honoured.
"""
import sys

import numpy as np
import torch

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # launched directly from this directory
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
    import core
    import graphengine
'''
RECOMMENDED_BODY = BUSY + GRAPH_SESSION + '''
class FallbackSession:
    """Eager equivalent used when CUDA-graph capture is not available."""

    def __init__(self, engine, proto=None):
        self.engine = engine

    def reset(self):
        self.engine.reset()

    def process(self, proto, features):
        x = torch.from_numpy(np.ascontiguousarray(features)).to(self.engine.device)
        out = self.engine.forward(x)
        proto.emit_all(out[0].to('cpu').numpy())


def _build(engine, proto):
    try:
        return Session(engine, proto)
    except Exception as exc:  # capture unsupported -> eager, still exact
        print(f'warning: CUDA graph capture failed ({exc!r}); eager path', file=sys.stderr, flush=True)
        return FallbackSession(engine, proto)
''' + PROCESS.replace("Session(engine, proto))", "_build(engine, proto))") + FOOTER
(BACKEND / 'worker.py').write_text(RECOMMENDED_HEADER + RECOMMENDED_BODY, encoding='utf-8')
print('wrote', BACKEND / 'worker.py')
