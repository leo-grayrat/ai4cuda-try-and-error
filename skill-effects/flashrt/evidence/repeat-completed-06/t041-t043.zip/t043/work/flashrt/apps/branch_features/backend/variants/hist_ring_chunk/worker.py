"""Variant `hist_ring_chunk`: per-chunk loop with preallocated ring-buffer history (allocation-free steady state)

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/core.py.
"""
import sys

import numpy as np
import torch
import torch.nn.functional as F

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
    import core
    import graphengine


class RingEngine:
    def __init__(self, engine, chunk):
        self.e = engine
        self.dev = engine.device
        self.chunk = chunk
        self.buf_in = torch.zeros(1, engine.channels, 4 + chunk, device=self.dev)
        self.buf_mid = torch.zeros(1, 2 * engine.hidden, 4 + chunk, device=self.dev)
        self.primed = False

    def reset(self):
        self.buf_in.zero_()
        self.buf_mid.zero_()
        self.primed = False

    def forward(self, x):
        e = self.e
        total = x.shape[-1]
        buf = self.buf_in
        if not self.primed:
            buf[:, :, :4] = x[:, :, :1].expand(-1, -1, 4)
        buf[:, :, 4:4 + total] = x
        joined = buf[:, :, :4 + total]
        mid = F.silu(F.conv1d(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))[:, :, 4:]
        mbuf = self.buf_mid
        if not self.primed:
            mbuf[:, :, :4] = mid[:, :, :1].expand(-1, -1, 4)
        mbuf[:, :, 4:4 + total] = mid
        jm = mbuf[:, :, :4 + total]
        y = F.conv1d(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]
        # carry the newest 4 samples to the front of the ring (allocation-free history)
        buf[:, :, :4] = buf[:, :, total:total + 4].clone()
        mbuf[:, :, :4] = mbuf[:, :, total:total + 4].clone()
        self.primed = True
        a, b = y[:, :e.channels], y[:, e.channels:]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return gate * a + (1 - gate) * b + 0.1 * x


def process(proto, engine, features):
    ring = getattr(proto, '_ring', None)
    if ring is None:
        ring = proto._ring = RingEngine(engine, proto.chunk)
        proto.engine = ring
    x = torch.from_numpy(np.ascontiguousarray(features)).to(engine.device)
    total, chunk = x.shape[-1], proto.chunk
    for lo in range(0, total, chunk):
        out = ring.forward(x[:, :, lo:lo + chunk])
        proto.emit(out[0].to('cpu').numpy())


if __name__ == '__main__':
    core.main(process, device='cuda')
