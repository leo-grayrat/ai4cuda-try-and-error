"""Variant `twostream_branch`: per-chunk loop, the two branches run concurrently on two CUDA streams

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/core.py.
"""
import sys

import numpy as np
import torch
import torch.nn.functional as F

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
    import core
    import graphengine


class StreamEngine:
    def __init__(self, engine):
        self.e = engine
        self.dev = engine.device
        self.s_a = torch.cuda.Stream()
        self.s_b = torch.cuda.Stream()
        self.reset()

    def reset(self):
        e = self.e
        self.hist_in = torch.zeros(1, e.channels, 4, device=self.dev)
        self.hist_mid = torch.zeros(1, 2 * e.hidden, 4, device=self.dev)
        self.primed = False

    def forward(self, x):
        e, prime, hidden = self.e, not self.primed, self.e.hidden
        hist = x[:, :, :1].expand(-1, -1, 4) if prime else self.hist_in
        joined = torch.cat([hist, x], -1)
        padded = F.pad(joined, (4, 0), mode='replicate')
        cur = torch.cuda.current_stream()
        start = torch.cuda.Event()
        start.record(cur)
        self.s_a.wait_event(start)
        self.s_b.wait_event(start)
        with torch.cuda.stream(self.s_a):
            mid_a = F.silu(F.conv1d(padded, e.sep_w['a0'], e.sep_b['a0']))[:, :, 4:]
            h_a = mid_a[:, :, :1].expand(-1, -1, 4) if prime else self.hist_mid[:, :hidden]
            jm_a = torch.cat([h_a, mid_a], -1)
            out_a = F.conv1d(F.pad(jm_a, (4, 0), mode='replicate'), e.sep_w['a1'], e.sep_b['a1'])[:, :, 4:]
        with torch.cuda.stream(self.s_b):
            mid_b = F.silu(F.conv1d(padded, e.sep_w['b0'], e.sep_b['b0']))[:, :, 4:]
            h_b = mid_b[:, :, :1].expand(-1, -1, 4) if prime else self.hist_mid[:, hidden:]
            jm_b = torch.cat([h_b, mid_b], -1)
            out_b = F.conv1d(F.pad(jm_b, (4, 0), mode='replicate'), e.sep_w['b1'], e.sep_b['b1'])[:, :, 4:]
        done_a, done_b = torch.cuda.Event(), torch.cuda.Event()
        done_a.record(self.s_a)
        done_b.record(self.s_b)
        cur.wait_event(done_a)
        cur.wait_event(done_b)
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        out = gate * out_a + (1 - gate) * out_b + 0.1 * x
        self.hist_in = joined[:, :, -4:].clone()
        self.hist_mid = torch.cat([jm_a[:, :, -4:], jm_b[:, :, -4:]], 1).clone()
        self.primed = True
        return out


def process(proto, engine, features):
    se = getattr(proto, '_se', None)
    if se is None:
        se = proto._se = StreamEngine(engine)
        proto.engine = se
    x = torch.from_numpy(np.ascontiguousarray(features)).to(engine.device)
    total, chunk = x.shape[-1], proto.chunk
    for lo in range(0, total, chunk):
        out = se.forward(x[:, :, lo:lo + chunk])
        proto.emit(out[0].to('cpu').numpy())


if __name__ == '__main__':
    core.main(process, device='cuda')
