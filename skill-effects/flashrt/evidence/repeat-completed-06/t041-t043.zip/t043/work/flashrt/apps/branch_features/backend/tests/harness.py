"""Correctness + timing harness for branch_features backends (agent-authored).

Drives a backend subprocess through the fixed shared adapter
(flashrt/apps/branch_features/adapter.py) exactly like the frontend does:
control opcodes 1 (start) / 3 (reset) / 2 (terminate), one request in flight,
output chunks read in order.

Usage (from the repo root):
  python flashrt/apps/branch_features/backend/tests/harness.py \
      --entries ref=flashrt/apps/branch_features/reference.py,\
best=flashrt/apps/branch_features/backend/worker.py \
      --outdir flashrt/apps/branch_features/backend/benchmarks/results

Prints a PASS/FAIL verdict for the 6-request correctness scenario and the
measured latency / sustainable-rate numbers for every entry.
"""
import argparse
import json
import math
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]  # repo root: .../flashrt/apps/<app>/backend/tests/harness.py
APP = REPO / 'flashrt' / 'apps' / 'branch_features'
TOL = 1e-4  # abs tolerance vs the CPU full-sequence oracle (exact-math rewrite; fp32 conv reassociation only)
GAP_BUDGET_S = 0.020


def make_config(prefix, variant='unknown'):
    return {
        'prefix': prefix,
        'device': 'cuda',
        'weight_seed': 1234,
        'channels': 16,
        'hidden': 32,
        'length': 1043,
        'chunk': 127,
        'variant_name': variant,
    }


def child_env():
    env = os.environ.copy()
    env['PYTHONPATH'] = os.pathsep.join([str(REPO), str(REPO / 'flashrt' / 'apps')])
    env.setdefault('CUDA_VISIBLE_DEVICES', '0')
    return env


class Backend:
    def __init__(self, entry, config, log_path):
        self.entry = str(entry)
        self.config = config
        self.cfg_path = Path(log_path).with_suffix('.config.json')
        self.cfg_path.write_text(json.dumps(config), encoding='utf-8')
        self.log = open(log_path, 'w', encoding='utf-8')
        kwargs = {}
        if os.name == 'nt':
            kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs['preexec_fn'] = os.setsid
        self.proc = subprocess.Popen(
            [sys.executable, '-u', self.entry, '--repository', str(REPO),
             '--config', str(self.cfg_path)],
            cwd=str(REPO), env=child_env(), stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, bufsize=1, **kwargs)
        self.adapter = None

    def wait_ready(self, timeout=180.0):
        deadline = time.monotonic() + timeout
        banner = None
        while time.monotonic() < deadline:
            line = self.proc.stdout.readline()
            if line:
                self.log.write(line)
                self.log.flush()
                if '"ready": true' in line or "'ready': True" in line or '"ready": True' in line:
                    banner = line.strip()
                    break
            elif self.proc.poll() is not None:
                raise RuntimeError(f'backend exited before ready: {self.entry}')
            else:
                time.sleep(0.005)
        if banner is None:
            raise TimeoutError('backend did not report ready')
        from branch_features.adapter import FeatureAdapter
        self.adapter = FeatureAdapter(self.config)  # attaches to the shm the backend created
        self._drain_stdout_async()
        return banner

    def _drain_stdout_async(self):
        # keep the pipe empty so the child never blocks on a full stdout buffer
        import threading
        def pump():
            for line in self.proc.stdout:
                self.log.write(line)
                self.log.flush()
        self._pump = threading.Thread(target=pump, daemon=True)
        self._pump.start()

    def close(self):
        try:
            if self.adapter is not None:
                try:
                    self.adapter.terminate()
                except Exception:
                    pass
                try:
                    self.adapter.close()
                except Exception:
                    pass
        finally:
            try:
                self.proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=20)
            self.log.close()


def oracle_group(config, group):
    from branch_features.model import full_sequence_oracle
    joined = np.concatenate(group, axis=1)
    return full_sequence_oracle(str(REPO), config, joined)


def request_inputs(seed=7):
    rng = np.random.default_rng(seed)
    ch, ln = 16, 1043
    base = [rng.standard_normal((ch, ln)).astype(np.float32) for _ in range(6)]
    base[1] *= 0.6
    base[2] = base[1].copy()          # repeated input without reset
    base[3] *= 1.7
    base[4] *= 0.35
    base[5] *= 2.2                    # tail chunk stress
    return base


def correctness(backend, config, inputs):
    adapter = backend.adapter
    groups = [[inputs[0], inputs[1], inputs[2]], [inputs[3], inputs[4], inputs[5]]]
    diffs = []
    oracle_calls = 0
    adapter.start()
    for g, group in enumerate(groups):
        if g:
            adapter.reset()
        ref = oracle_group(config, group)
        offset = 0
        for req, feats in zip(group, [(x, ) for x in group]):
            array = feats[0]
            adapter.submit(array)
            chunks = []
            while True:
                data, _ts = adapter.receive(timeout_s=20)
                chunks.append(data)
                if adapter.pending is None:
                    break
            got = np.concatenate(chunks, axis=1)
            want = ref[:, offset: offset + array.shape[1]]
            offset += array.shape[1]
            diffs.append(float(np.max(np.abs(got - want))))
            oracle_calls += 1
    worst = max(diffs)
    return {'pass': bool(worst <= TOL), 'max_abs_diff': worst, 'per_request': diffs,
            'tolerance': TOL, 'requests_compared': oracle_calls}


def latency_run(backend, config, inputs, n=8):
    adapter = backend.adapter
    lat = []
    for i in range(n):
        feats = inputs[i % len(inputs)]
        _rid, published = adapter.submit(feats)
        _data, observed = adapter.receive(timeout_s=20)
        lat.append(observed - published)
        while adapter.pending is not None:
            adapter.receive(timeout_s=20)
    ms = np.array(lat, dtype=np.float64) / 1e6
    return {'n': n, 'median_ms': float(np.median(ms)), 'p95_ms': float(np.percentile(ms, 95)),
            'min_ms': float(ms.min()), 'max_ms': float(ms.max()), 'all_ms': ms.tolist()}


def rate_sweep(backend, config, inputs, rates, nreq=12, budget=GAP_BUDGET_S):
    adapter = backend.adapter
    nchunks = len(range(0, config['length'], config['chunk']))
    out = []
    for rate in rates:
        period = nchunks / rate
        gaps, stamps, stalls = [], [], 0
        t0 = time.perf_counter()
        last_drain = t0
        published_first = None
        for j in range(nreq):
            target = t0 + j * period
            now = time.perf_counter()
            if now < target:
                time.sleep(target - now)
            elif now - target > period:
                pass
            if j and last_drain > target:
                stalls += 1
            feats = inputs[j % len(inputs)]
            _rid, published = adapter.submit(feats)
            if published_first is None:
                published_first = published
            chan = []
            while True:
                _data, observed = adapter.receive(timeout_s=20)
                stamps.append(observed)
                chan.append(observed)
                if adapter.pending is None:
                    break
            for a, b in zip(chan, chan[1:]):
                gaps.append((b - a) / 1e9)
            last_drain = time.perf_counter()
        span = (stamps[-1] - published_first) / 1e9
        # Inter-chunk gaps are measured within a request only: the sweep's
        # offered-rate pacing intentionally spaces requests, so cross-request
        # gaps reflect the schedule rather than backend smoothness.
        g = np.array(gaps)
        achieved = (len(stamps) - 1) / span if span > 0 else float('inf')
        over = float(np.mean(g > budget)) if len(g) else 0.0
        out.append({'offered_chunks_per_s': rate, 'achieved_chunks_per_s': achieved,
                    'requests': nreq, 'chunks': len(stamps), 'stalls': stalls,
                    'gap_median_ms': float(np.median(g) * 1e3), 'gap_p95_ms': float(np.percentile(g, 95) * 1e3),
                    'over_budget_fraction': over,
                    'sustainable': bool(stalls == 0 and over <= 0.02 and achieved >= 0.95 * rate)})
    ok = [r['offered_chunks_per_s'] for r in out if r['sustainable']]
    best = max(ok) if ok else 0
    return {'sweep': out, 'max_sustainable_chunks_per_s': best, 'gap_budget_ms': budget * 1e3}


def run_entry(name, entry, outdir, rates, do_correct, do_bench):
    config = make_config(f'bf{os.getpid()}{abs(hash(name)) % 10000}', name)
    log_path = Path(outdir) / f'{name}.log'
    log_path.parent.mkdir(parents=True, exist_ok=True)
    result = {'entry': str(entry), 'name': name, 'config': config,
              'python': sys.executable, 'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES')}
    backend = Backend(entry, config, log_path)
    try:
        result['banner'] = backend.wait_ready()
        if do_correct:
            try:
                result['correctness'] = correctness(backend, config, request_inputs())
                result['verdict'] = 'PASS' if result['correctness']['pass'] else 'FAIL'
            except Exception as exc:
                result['correctness'] = {'pass': False, 'error': repr(exc)}
                result['verdict'] = 'FAIL'
                result['traceback'] = traceback.format_exc()
        if do_bench:
            try:
                base = request_inputs(11)
                result['latency'] = latency_run(backend, config, base)
                result['rate'] = rate_sweep(backend, config, base, rates)
            except Exception as exc:
                result['bench_error'] = repr(exc)
                result['traceback_bench'] = traceback.format_exc()
    finally:
        backend.close()
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--entries', required=True, help='name=path,...')
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--mode', default='both', choices=['both', 'correct', 'bench'])
    ap.add_argument('--rates', default='200,500,900,1400,2000,3000,4500,6500,9000')
    args = ap.parse_args()
    rates = [int(x) for x in args.rates.split(',')]
    entries = []
    for item in args.entries.split(','):
        if not item.strip():
            continue
        name, path = item.split('=', 1)
        entries.append((name.strip(), path.strip()))
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    summary = {}
    for name, path in entries:
        print(f'=== {name}: {path}', flush=True)
        try:
            res = run_entry(name, path, outdir, rates,
                            args.mode in ('both', 'correct'), args.mode in ('both', 'bench'))
        except Exception:
            traceback.print_exc()
            summary[name] = {'error': 'launch failed'}
            continue
        (outdir / f'{name}.json').write_text(json.dumps(res, indent=2), encoding='utf-8')
        summary[name] = res
        if 'correctness' in res:
            c = res['correctness']
            print(f"  correctness: {'PASS' if c.get('pass') else 'FAIL'} max_abs_diff={c.get('max_abs_diff')} tol={c.get('tolerance')}")
        if 'latency' in res:
            print(f"  latency: median={res['latency']['median_ms']:.3f}ms p95={res['latency']['p95_ms']:.3f}ms")
        if 'rate' in res:
            r = res['rate']
            print(f"  max sustainable: {r['max_sustainable_chunks_per_s']} chunks/s")
            for row in r['sweep']:
                print(f"    offered={row['offered_chunks_per_s']:>5} achieved={row['achieved_chunks_per_s']:>8.1f} "
                      f"stalls={row['stalls']:>2} gap_med={row['gap_median_ms']:.3f}ms "
                      f"gap_p95={row['gap_p95_ms']:.3f}ms over={row['over_budget_fraction']:.2f} "
                      f"sustainable={row['sustainable']}")
    print('SUMMARY ' + json.dumps({k: {'verdict': v.get('verdict'), 'lat': v.get('latency', {}).get('median_ms'),
                                       'p95': v.get('latency', {}).get('p95_ms'),
                                       'rate': v.get('rate', {}).get('max_sustainable_chunks_per_s')}
                                   for k, v in summary.items()}), flush=True)


if __name__ == '__main__':
    main()
