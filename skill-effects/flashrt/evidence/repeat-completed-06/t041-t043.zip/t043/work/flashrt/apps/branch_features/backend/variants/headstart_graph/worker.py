"""Variant `headstart_graph`: CUDA graph replay, chunk 0 copied out and published before the rest

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/core.py.
"""
import sys

import numpy as np
import torch
import torch.nn.functional as F

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
    import core
    import graphengine

class Session:
    """Holds the CUDA-graph executor and keeps history reset in sync."""

    def __init__(self, engine, proto):
        self.engine = engine
        self.ge = graphengine.GraphEngine(engine, proto.length, proto.chunk)
        self.mode = 'head'

    def reset(self):
        self.engine.reset()
        self.ge.reset()

    def process(self, proto, features):
        ge = self.ge
        ge.load(features, pinned=False)
        ge.replay()

        proto.emit(ge.read_head())
        proto.emit_all(ge.read_all())


def process(proto, engine, features):
    sess = getattr(proto, '_sess', None)
    if sess is None:
        sess = proto._sess = Session(engine, proto)
        proto.engine = sess  # core.Protocol calls engine.reset() on opcode 3
    sess.process(proto, features)


if __name__ == '__main__':
    core.main(process, device='cuda')
