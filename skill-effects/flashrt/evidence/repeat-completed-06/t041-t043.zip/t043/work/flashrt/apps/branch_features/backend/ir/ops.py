"""Phase-1 IR operators for the two-branch causal feature pipeline.

Mirrors flashrt/apps/branch_features/model.py: four history-carrying CausalConv1d
layers (a0 -> a1 on branch A, b0 -> b1 on branch B), a SiLU after each first
stage, and the sigmoid gate + 0.1 residual merge.  Each conv owns a separate
history StateObject, exactly the four entries the reference keeps in
``pipeline.histories``; that is what makes the two branches state-independent.
"""
import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort, ir_operator


class CausalConv(IROperator):
    """One causal conv with its own sliding input history (kernel-1 samples)."""

    def __init__(self, name, layer_key, history):
        super().__init__(name=name, op_type=OpType.EXPOSED,
                         inputs=[TensorPort('x')], outputs=[TensorPort('y')],
                         state_reads=[history], state_writes=[history],
                         stream_mode=StreamMode.BATCH, config={'layer': layer_key})
        self.layer_key = layer_key
        self.history = history

    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.layer_key]
        history = state.get(self.history)
        x = inputs['x']
        joined = x if history is None else torch.cat([history, x], dim=-1)
        out = layer(joined)
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        state.set(self.history, joined[:, :, -layer._time_causal_padding[0]:].clone())
        return {'y': out}


@ir_operator(name='silu_a', op_type=OpType.EXPOSED,
             inputs=[TensorPort('x')], outputs=[TensorPort('y')])
def silu_a(inputs, ctx, state):
    del ctx, state
    return {'y': F.silu(inputs['x'])}


@ir_operator(name='silu_b', op_type=OpType.EXPOSED,
             inputs=[TensorPort('x')], outputs=[TensorPort('y')])
def silu_b(inputs, ctx, state):
    del ctx, state
    return {'y': F.silu(inputs['x'])}


@ir_operator(name='gate_merge', op_type=OpType.EXPOSED,
             inputs=[TensorPort('features'), TensorPort('branch_a'), TensorPort('branch_b')],
             outputs=[TensorPort('y')])
def gate_merge(inputs, ctx, state):
    del ctx, state
    features = inputs['features']
    gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
    merged = gate * inputs['branch_a'] + (1 - gate) * inputs['branch_b'] + 0.1 * features
    return {'y': merged}


class ModelStage(IROperator):
    """Worker-level view of the whole two-branch model (composite sub-graph)."""

    def __init__(self, histories):
        super().__init__(name='model', op_type=OpType.COMPOSITE,
                         inputs=[TensorPort('x'), TensorPort('features')],
                         outputs=[TensorPort('y')],
                         state_reads=list(histories), state_writes=list(histories),
                         stream_mode=StreamMode.STREAMING, sub_graph='model')

    def execute(self, inputs, ctx, state):
        del state
        return {'y': ctx.model_forward(inputs['x'], inputs['features'])}


@ir_operator(name='ingest', op_type=OpType.EXPOSED,
             inputs=[TensorPort('x'), TensorPort('features')],
             outputs=[TensorPort('x'), TensorPort('features')])
def ingest(inputs, ctx, state):
    del ctx, state
    return {'x': inputs['x'], 'features': inputs['features']}


@ir_operator(name='publish', op_type=OpType.EXPOSED,
             inputs=[TensorPort('y')], outputs=[TensorPort('out')])
def publish(inputs, ctx, state):
    del ctx, state
    return {'out': inputs['y']}
