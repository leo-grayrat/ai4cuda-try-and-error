"""Phase-2 IR validation: SequentialExecutor vs the reference backend.

Launches flashrt/apps/branch_features/reference.py as a subprocess, drives it
through the fixed adapter over the 6-request fixture (continuation, repeated
input without reset, reset, tail chunk), then runs the IR model graph through
SequentialExecutor over the same session structure and compares every chunk.

Tolerance 1e-5 absolute: both sides run the reference's own CausalConv1d layers
in fp32 on the same GPU through the same per-chunk arithmetic, so only cuDNN
algorithm selection on differently-shaped tensors can differ.
"""
import hashlib
import os
import sys
from pathlib import Path

import numpy as np
import torch

BACKEND = Path(__file__).resolve().parents[1]
REPO = BACKEND.parents[3]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(BACKEND / 'tests'))

import harness  # noqa: E402  (agent harness: fixture + adapter subprocess driver)
from flashrt.ir import SequentialExecutor  # noqa: E402
from flashrt.apps.branch_features.backend.core import build_layers  # noqa: E402
from flashrt.apps.branch_features.backend.ir.graph_builder import (  # noqa: E402
    HISTORIES, build_model_graph)

TOL = 1e-5


class Ctx:
    def __init__(self, repository, config):
        self.layers = build_layers(repository, config, config['device'])


def groups_for(inputs):
    return [[inputs[0], inputs[1], inputs[2]], [inputs[3], inputs[4], inputs[5]]]


def reference_outputs(config, groups):
    log = BACKEND / 'benchmarks' / 'results' / 'ir_validation_reference.log'
    log.parent.mkdir(parents=True, exist_ok=True)
    backend = harness.Backend(f'{harness.APP}/reference.py', config, log)
    outs = []
    try:
        backend.wait_ready()
        adapter = backend.adapter
        adapter.start()
        for gi, group in enumerate(groups):
            if gi:
                adapter.reset()
            for req in group:
                adapter.submit(req)
                chunks = []
                while True:
                    data, _ts = adapter.receive(timeout_s=30)
                    chunks.append(data)
                    if adapter.pending is None:
                        break
                outs.append(np.concatenate(chunks, axis=1))
    finally:
        backend.close()
    return outs


def executor_outputs(repository, config, groups):
    graph = build_model_graph(config)
    executor = SequentialExecutor(graph)
    ctx = Ctx(repository, config)
    outs = []
    chunk = config['chunk']
    for group in groups:
        executor.init_state({name: None for name in HISTORIES})
        for req in group:
            chunks = []
            for lo in range(0, config['length'], chunk):
                part = req[:, lo:lo + chunk]
                res = executor.run_chunk({'x': part, 'features': part}, ctx)
                chunks.append(res['y'])
            outs.append(torch.cat(chunks, dim=-1)[0].detach().cpu().numpy())
    return outs


def digest(arrays):
    h = hashlib.sha256()
    for a in arrays:
        h.update(np.ascontiguousarray(a, dtype=np.float32).tobytes())
    return h.hexdigest()[:16]


def main():
    config = harness.make_config(f'ir{os.getpid()}', 'ir_validation')
    inputs = harness.request_inputs()
    groups = groups_for(inputs)
    ref = reference_outputs(config, groups)
    ex = executor_outputs(str(REPO), config, groups)
    diffs = [float(np.max(np.abs(a - b))) for a, b in zip(ref, ex)]
    shapes_ok = all(a.shape == b.shape for a, b in zip(ref, ex))
    ok = shapes_ok and max(diffs) <= TOL
    print('IR validation fixture: 6 requests (continuation, repeat-without-reset, reset, tail chunk)')
    print('per-request max_abs_diff:', [f'{d:.3e}' for d in diffs])
    print('shapes match:', shapes_ok, '| tolerance:', TOL)
    print('executor_output_hash:', digest(ex))
    print('reference_output_hash:', digest(ref))
    print('IR VALIDATION:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
