"""Focused staged run (execute takes no CLI args, so targets live in-file)."""
import pathlib
import runpy
import sys

BACKEND = pathlib.Path(__file__).resolve().parents[1]
APP = 'flashrt/apps/branch_features'
TARGETS = {
    'im2col_gemm': f'{APP}/backend/variants/im2col_gemm/worker.py',
    'hist_ring_chunk': f'{APP}/backend/variants/hist_ring_chunk/worker.py',
    'spin_graph': f'{APP}/backend/variants/spin_graph/worker.py',
    'worker': f'{APP}/backend/worker.py',
}
MODE = 'both'

harness = BACKEND / 'tests' / 'harness.py'
entries = ','.join(f'{n}={p}' for n, p in TARGETS.items())
sys.argv = [str(harness), '--entries', entries,
            '--outdir', f'{APP}/backend/benchmarks/results',
            '--mode', MODE, '--rates', '200,500,900,1400,2000,3000,4500,6500,9000']
runpy.run_path(str(harness), run_name='__main__')
