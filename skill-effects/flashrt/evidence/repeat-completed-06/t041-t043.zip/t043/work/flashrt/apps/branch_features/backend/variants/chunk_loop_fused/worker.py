"""Variant `chunk_loop_fused`: reference cadence with both branches fused into two conv launches per chunk

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/core.py.
"""
import sys

import numpy as np
import torch
import torch.nn.functional as F

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
    import core
    import graphengine


def process(proto, engine, features):
    dev = engine.device
    x = torch.from_numpy(np.ascontiguousarray(features)).to(dev)
    total, chunk = x.shape[-1], proto.chunk
    for lo in range(0, total, chunk):
        out = engine.forward(x[:, :, lo:lo + chunk])
        proto.emit(out[0].to('cpu').numpy())


if __name__ == '__main__':
    core.main(process, device='cuda')
