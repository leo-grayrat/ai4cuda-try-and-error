# branch_features backend (`flashrt/apps/branch_features/backend/`)

Standalone optimized backend for the two-branch causal feature task. It speaks
exactly the shared adapter contract (`flashrt/apps/branch_features/adapter.py`:
control opcodes 0/1/2/3, the same shared-memory buffer names, one request in
flight, 127-sample output chunks with `(request_id, chunk_index, valid)`
metadata) and never touches the reference or the adapter.

## Launch (drop-in replacement for the reference backend)

```bash
python flashrt/apps/branch_features/backend/worker.py \
    --repository <repo root> --config <config.json>
```

The worker prints `{"ready": true, ...}` on stdout once the buffers exist, then
serves the control loop until opcode 2. Any frontend or harness that drives
`flashrt/apps/branch_features/reference.py` today can drive this file unchanged
(the independent controller supplies module paths; the worker also accepts
`--repository` pointing at the repo root and adds `<repo>/flashrt/apps` to
`sys.path` so `import branch_features.adapter` resolves).

## What it does

1. Both branches are fused: the k=3 kernels (`b0`, `a1`) are left-zero-padded to
   k=5 and stacked, so one conv launch covers `a0`+`b0` (output channels
   stacked) and one *grouped* conv covers `a1`+`b1`. Exact same taps, 2 launches
   instead of 4.
2. History = 4 raw-input samples + 4 branch-0 output samples. At session start
   it is primed with `x[:, :, :1]`, which reproduces the reference's
   `replicate` padding without host branching.
3. One request is a single captured CUDA-graph replay (fixed shapes from the
   config) instead of nine python-driven chunk steps. Chunk 0 is copied out and
   published first, the remaining 8 follow in one batched publish.
4. The input poll is a tight spin, so the request is picked up immediately.
5. If CUDA-graph capture is unavailable the worker falls back to the same math
   executed eagerly (a warning goes to stderr); the contract and the numerics
   are unchanged.

## Verification & measurement (agent harness)

```bash
python flashrt/apps/branch_features/backend/tests/harness.py \
  --entries ref=flashrt/apps/branch_features/reference.py,\
best=flashrt/apps/branch_features/backend/worker.py \
  --outdir flashrt/apps/branch_features/backend/benchmarks/results --mode both
python flashrt/apps/branch_features/backend/tests/test_ir.py   # Phase-2 IR check
```

Results land as JSON + per-entry backend logs under `benchmarks/results/`.
Measured on the RTX 5060 8 GB laptop GPU: candidate median first-output latency
**0.53 ms** vs reference **1.55 ms**; sustainable output rate **6500** vs **500**
chunks/s; inter-chunk gaps (within a request) median 0.004 ms. Details and the
full variant queue: `notes/experiment_log.md`.

## Layout

* `core.py` - shared model math (fused weights, history, priming) + adapter loop.
* `graphengine.py` - CUDA-graph executor with pinned staging.
* `worker.py` - the recommended entry (above).
* `variants/<idea>/worker.py` - one measured deployment variant per idea.
* `ir/` - Phase-1 IR conversion (ops + model/worker graphs).
* `tests/` - `harness.py` (correctness+sweep), `test_ir.py`, logs.
* `benchmarks/results/` - per-variant JSON + backend stdout logs.
* `notes/` - experiment log and the `summarize_graph` analysis dump.
