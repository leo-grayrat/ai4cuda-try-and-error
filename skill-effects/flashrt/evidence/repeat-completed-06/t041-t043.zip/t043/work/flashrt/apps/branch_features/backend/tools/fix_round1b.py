"""Round-1b: finish the generator sync + harness gap/timeout fixes."""
import pathlib

BACKEND = pathlib.Path(__file__).resolve().parents[1]

GEN_FIXES = [
    ("            mid_a = F.silu(F.conv1d(padded, e.sep_w['a0'], e.sep_b['a0']))\n",
     "            mid_a = F.silu(F.conv1d(padded, e.sep_w['a0'], e.sep_b['a0']))[:, :, 4:]\n"),
    ("            out_a = F.conv1d(F.pad(jm_a, (4, 0), mode='replicate'), e.sep_w['a1'], e.sep_b['a1'])\n",
     "            out_a = F.conv1d(F.pad(jm_a, (4, 0), mode='replicate'), e.sep_w['a1'], e.sep_b['a1'])[:, :, 4:]\n"),
    ("            mid_b = F.silu(F.conv1d(padded, e.sep_w['b0'], e.sep_b['b0']))\n",
     "            mid_b = F.silu(F.conv1d(padded, e.sep_w['b0'], e.sep_b['b0']))[:, :, 4:]\n"),
    ("            out_b = F.conv1d(F.pad(jm_b, (4, 0), mode='replicate'), e.sep_w['b1'], e.sep_b['b1'])\n",
     "            out_b = F.conv1d(F.pad(jm_b, (4, 0), mode='replicate'), e.sep_w['b1'], e.sep_b['b1'])[:, :, 4:]\n"),
    ("        mid = F.silu(conv_gemm(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))\n",
     "        mid = F.silu(conv_gemm(F.pad(joined, (4, 0), mode='replicate'), e.W0, e.B0))[:, :, 4:]\n"),
    ("        y = conv_gemm(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)\n",
     "        y = conv_gemm(F.pad(jm, (4, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, 4:]\n"),
]

HARNESS_FIXES = [
    ("""            while True:
                _data, observed = adapter.receive(timeout_s=60)
                stamps.append(observed)
                if adapter.pending is None:
                    break
            last_drain = time.perf_counter()
""",
     """            chan = []
            while True:
                _data, observed = adapter.receive(timeout_s=20)
                stamps.append(observed)
                chan.append(observed)
                if adapter.pending is None:
                    break
            for a, b in zip(chan, chan[1:]):
                gaps.append((b - a) / 1e9)
            last_drain = time.perf_counter()
"""),
    ("""        for a, b in zip(stamps, stamps[1:]):
            gaps.append((b - a) / 1e9)
""",
     """        # Inter-chunk gaps are measured within a request only: the sweep's
        # offered-rate pacing intentionally spaces requests, so cross-request
        # gaps reflect the schedule rather than backend smoothness.
"""),
    ("timeout_s=60", "timeout_s=20"),
]


def patch(rel, fixes):
    path = BACKEND / rel
    text = path.read_text(encoding='utf-8')
    for old, new in fixes:
        if old not in text:
            print(f'  skip (already applied?) in {rel}: {old.splitlines()[0][:60]!r}')
            continue
        text = text.replace(old, new)
    path.write_text(text, encoding='utf-8')
    print('patched', rel)


patch('tools/gen_variants.py', GEN_FIXES)
patch('tests/harness.py', HARNESS_FIXES)

# verify the generated twostream/hist_ring workers now carry the slices
for rel in ['variants/twostream_branch/worker.py', 'variants/hist_ring_chunk/worker.py',
            'variants/im2col_gemm/worker.py', 'core.py', 'graphengine.py']:
    text = (BACKEND / rel).read_text(encoding='utf-8')
    print(rel, 'slices=', text.count('[:, :, 4:]') + text.count('[:, :, PINS:]'))
