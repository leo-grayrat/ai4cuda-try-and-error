"""CUDA-graph executor for the fused dual-branch model (agent-authored).

Captures one whole-request forward at the fixed (length, chunk) shapes so a
request costs a single graph replay instead of ~14 kernel launches per chunk.
The captured graph reads a device-side `prime` flag via `torch.where`, which
reproduces the reference's session-start `replicate` padding without host
branching inside the graph.
"""
import numpy as np
import torch
import torch.nn.functional as F

PINS = 4


class GraphEngine:
    def __init__(self, engine, length, chunk, warmup=2):
        self.e = engine
        self.dev = engine.device
        c, h2 = engine.channels, 2 * engine.hidden
        self.x = torch.zeros(1, c, length, device=self.dev)
        self.hist_in = torch.zeros(1, c, PINS, device=self.dev)
        self.hist_mid = torch.zeros(1, h2, PINS, device=self.dev)
        self.out = torch.zeros(1, c, length, device=self.dev)
        self.prime = torch.zeros((), device=self.dev)
        self.pinned_in = torch.empty(1, c, length, pin_memory=True)
        self.pinned_out = torch.empty(1, c, length, pin_memory=True)
        self.pinned_head = torch.empty(1, c, chunk, pin_memory=True)
        self.primed = False
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(warmup):
                self._fwd()
        torch.cuda.current_stream().wait_stream(side)
        torch.cuda.synchronize()
        self.graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.graph):
            self._fwd()
        torch.cuda.synchronize()

    def _fwd(self):
        e = self.e
        hist = torch.where(self.prime > 0.5, self.x[:, :, :1].expand(-1, -1, PINS), self.hist_in)
        joined = torch.cat([hist, self.x], -1)
        mid = F.silu(F.conv1d(F.pad(joined, (PINS, 0), mode='replicate'), e.W0, e.B0))[:, :, PINS:]
        hist_mid = torch.where(self.prime > 0.5, mid[:, :, :1].expand(-1, -1, PINS), self.hist_mid)
        jm = torch.cat([hist_mid, mid], -1)
        y = F.conv1d(F.pad(jm, (PINS, 0), mode='replicate'), e.W1, e.B1, groups=2)[:, :, PINS:]
        self.hist_in.copy_(joined[:, :, -PINS:])
        self.hist_mid.copy_(jm[:, :, -PINS:])
        a, b = y[:, : e.channels], y[:, e.channels:]
        gate = torch.sigmoid(self.x.mean(dim=1, keepdim=True))
        self.out.copy_(gate * a + (1 - gate) * b + 0.1 * self.x)

    def reset(self):
        self.hist_in.zero_()
        self.hist_mid.zero_()
        self.primed = False

    def load(self, features, pinned=True):
        src = torch.from_numpy(np.ascontiguousarray(features))
        if pinned:
            self.pinned_in.copy_(src)
            self.x.copy_(self.pinned_in, non_blocking=True)
        else:
            self.x.copy_(src)

    def replay(self):
        self.prime.fill_(0.0 if self.primed else 1.0)
        self.graph.replay()
        self.primed = True

    def read_head(self):
        width = self.pinned_head.shape[-1]
        self.pinned_head.copy_(self.out[:, :, :width], non_blocking=True)
        torch.cuda.current_stream().synchronize()
        return self.pinned_head[0].numpy()

    def read_all(self):
        self.pinned_out.copy_(self.out, non_blocking=True)
        torch.cuda.current_stream().synchronize()
        return self.pinned_out[0].numpy()
