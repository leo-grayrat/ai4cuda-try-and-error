"""Variant `cpu_fullseq`: whole-request fused pass on the CPU (no PCIe round trip)

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/core.py.
"""
import sys

import numpy as np
import torch
import torch.nn.functional as F

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
    import core
    import graphengine


def process(proto, engine, features):
    x = torch.from_numpy(np.ascontiguousarray(features))
    out = engine.forward(x)
    proto.emit_all(out[0].numpy())


if __name__ == '__main__':
    core.main(process, device='cpu')
