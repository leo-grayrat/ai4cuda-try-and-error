# branch_features - experiment log (agent)

## IR Conversion (2026-02-14)

- Worker graph: `branch_features/worker`, 3 operators, 3 edges
  - `ingest` (EXPOSED, BATCH) -> `model` (COMPOSITE, STREAMING, sub-graph `model`)
    -> `publish` (EXPOSED, BATCH).
  - Streaming edge: `model -> publish`, FIXED_RATE 127 -> 127 (ratio 1.0): one
    output chunk per input chunk, so target 2 does not collapse to 1/latency.
  - Black-box stages: none (every stage of this app is exposed).
  - Persistent state: `hist_a0`, `hist_a1`, `hist_b0`, `hist_b1`
    (`chunk_persistent`), one per conv - the reference's four `histories`.
- Model graph: `branch_features/model`, 7 operators, 6 data edges
  - `a0 -> silu_a -> a1 -> gate_merge.branch_a`,
    `b0 -> silu_b -> b1 -> gate_merge.branch_b`, `gate_merge` also consumes the
    raw chunk (external input `features`).
  - State objects: the four histories above; chunk-periodic operators: all 7.
- IR validation: **FAIL**
  - fixture: `tests/harness.py::request_inputs` (6 requests: continuation,
    repeated input without reset, reset, tail chunk; 1043 samples, chunk 127)
  - reference_run: `tests/ir_validation_reference.log` (reference backend driven
    through `branch_features.adapter`)
  - executor/reference hashes: see `tests/ir_validation.log`
  - tolerance: 1e-5 absolute (both sides run the same CausalConv1d layers in
    fp32 on the same GPU; only cuDNN algorithm choice for different shapes can
    differ - measured diff is <= 1e-6).
- Analysis summary (`notes/ir_analysis.txt`, produced by `summarize_graph` with
  measured per-op latencies):
  - Pipeline stages: 2 - Stage 0 `[a0, a1]` (branch A), Stage 1 `[b0, b1]`
    (branch B): the four convs share no persistent state, so the two branches are
    the natural parallel split; `gate_merge` joins them inside one chunk.
  - Cross-chunk independent pairs: every A-op with every B-op, and across chunks
    each conv is independent of the *other* branch's convs (four disjoint ring
    buffers). Same-branch pairs (`a0`,`a1`,`hist_a1` vs `hist_a0`) are
    independent too because each conv owns its own history object.
  - Streaming overlaps: `model -> publish` 1:1 fixed rate.
  - Critical path: `a0 -> silu_a -> a1 -> gate_merge` (branch A chain is the
    longer one: k=5 then k=3), i.e. one conv chain per chunk.
  - Bottleneck stage: the per-chunk conv chain; measured ~1.05 ms/chunk in the
    reference, matching the 500 chunks/s sustainable ceiling.

## Variant Queue (last updated 2026-02-14)

| # | name | hypothesis | IR basis | predicted impact | status |
|---|------|-----------|----------|------------------|--------|
| 0 | `reference` | baseline: 4 sequential convs + 9 python chunk steps | - | anchor | measured (baseline) |
| 1 | `chunk_loop_fused` | fuse both branches into 2 conv launches, keep the per-chunk cadence | model graph: A and B share no state -> one stacked + one grouped conv | latency -25%, rate +80% | measured |
| 2 | `hist_ring_chunk` | the same, with preallocated ring histories (no `cat` per chunk) | four independent history objects can be views into fixed buffers | small win vs #1 | measured (after 1 fix) |
| 3 | `fullseq_fused` | one whole-request fused pass, publish all 9 chunks | causal convs make the whole request one dependency chain; no cross-chunk barrier exists | latency -3%, rate 3.3x | measured |
| 4 | `fullseq_graph` | capture that pass in a CUDA graph | same, launch overhead dominates at these shapes | latency -33% vs #3, rate 1.5x | measured |
| 5 | `headstart_graph` | publish chunk 0 before the rest of the request is copied out | streaming edge `model->publish` is 1:1, first chunk is consumable immediately | latency -1%, smoothness | measured |
| 6 | `pinned_async_graph` | pinned-memory async H2D/D2H staging | data movement, not compute, dominates the critical path | latency -0%, rate flat | measured |
| 7 | `twostream_branch` | run branches A and B concurrently on two CUDA streams per chunk | pipeline stages 0/1 are state-disjoint | latency ~0, rate 1.8x over #1 | measured |
| 8 | `im2col_gemm` | express both convs as unfold+GEMM (cuBLAS) | same graph, different kernels | unknown | measured (after 1 fix: PASS (max_abs_diff 1.07e-06), latency median 1.532 ms / p95 1.600 ms, sustainable 3000 chunks/s) |
| 9 | `cpu_fullseq` | avoid the PCIe round trip, compute on CPU | exposed model is tiny (11 MFLOP/request) | latency flat, rate 3.3x | measured |
| 10 | `tf32_fullseq` | allow TF32 for conv/matmul | same graph, lower precision | latency flat | measured (numerically fine, no speed win) |
| 11 | `spin_graph` | #4+#5+#6 plus a busy-poll input wait | input pickup was the dominant residual latency | latency -47%, rate 1.4x | measured |
| 12 | `worker` (recommended) | #11 with an eager fallback when graph capture is unavailable | same | best measured | measured |

Rationale for ordering: the IR ranks the per-chunk conv chain as the bottleneck
and shows the branches are state-disjoint (so both fusion and branch-parallel
scheduling are legal); the launch/IPC overhead of nine python-driven chunk steps
was predicted to dominate at these tensor sizes, which is why the graph-capture
variants are ranked highest after the pure fusion variants.

Changelog:
- 2026-02-14: initial queue committed from the IR analysis (fusion, per-chunk vs
  whole-request scheduling, branch-parallel streams, kernel substitution,
  co-location on CPU, precision, staging).
- 2026-02-14: measured #1; fusion alone only removed ~1/3 of the per-chunk cost,
  so the whole-request scheduling rows (#3-#6) were confirmed ahead of further
  per-chunk micro-optimisation.
- 2026-02-14: measured #3/#4; graph replay cut 0.52 ms of the 1.51 ms, i.e. the
  remaining cost was IPC/launch, so #11 (busy-poll) was added.
- 2026-02-14: measured #11 -> 0.526 ms / 6500 chunks/s; promoted to `worker.py`.
- 2026-02-14: #2 and #8 failed first (missing ring-history carry; wrong bmm batch
  layout) - agent bugs, fixed and re-measured in the same iteration.

## Deployment iterations (all measured through `tests/harness.py`)

All runs: RTX 5060 Laptop 8 GB, fp32, `cudnn.benchmark=False`, one backend
process at a time, 6-request correctness scenario + 8-request latency run +
9-point offered-rate sweep (200..9000 chunks/s, 12 requests per point, 20 ms
gap budget). Artifacts: `benchmarks/results/<name>.json` and `<name>.log`.

| variant | correctness | t_first_out median / p95 (ms) | max sustainable (chunks/s) | gap median / p95 (ms) |
|---|---|---|---|---|
| reference | PASS (1.1e-6) | 1.552 / 1.890 | 500 | 1.067 / 1.150 |
| chunk_loop_fused | PASS (1.1e-6) | 1.550 / 1.598 | 900 | 0.525 / 1.060 |
| hist_ring_chunk | PASS (1.1e-6, after fix) | 1.569 / 1.636 | 500 | 0.525 / 1.050 |
| fullseq_fused | PASS (1.1e-6) | 1.511 / 1.600 | 3000 | 0.004 / 0.010 |
| fullseq_graph | PASS (1.1e-6) | 0.988 / 1.020 | 4500 | 0.004 / 0.006 |
| headstart_graph | PASS (1.1e-6) | 0.981 / 1.049 | 3000 | 0.004 / 0.009 |
| pinned_async_graph | PASS (1.1e-6) | 0.999 / 1.084 | 4500 | 0.004 / 0.006 |
| twostream_branch | PASS (1.1e-6) | 1.542 / 1.570 | 900 | 0.600 / 1.100 |
| im2col_gemm | PASS (max_abs_diff 1.07e-06), latency median 1.532 ms / p95 1.600 ms, sustainable 3000 chunks/s | see JSON | see JSON | see JSON |
| cpu_fullseq | PASS (3.6e-7) | 1.496 / 1.547 | 3000 | 0.004 / 0.010 |
| tf32_fullseq | PASS (1.1e-6) | 1.572 / 2.010 | 3000 | 0.006 / 0.010 |
| spin_graph | PASS (1.1e-6) | 0.526 / 0.535 | 6500 | 0.006 / 0.009 |
| **worker (recommended)** | **PASS (1.1e-6)** | **0.533 / 0.562** | **6500** | **0.004 / 0.010** |

Delta of the recommended variant vs the reference: first-output latency
-66 % (median) / -70 % (p95), sustainable output rate 13x, and the inter-chunk
gap p95 shrinks from ~1.15 ms to ~0.01 ms (0 % of gaps over the 20 ms budget).

### Hypotheses, evidence, failures, trade-offs

* **Fusion (#1, #2)** is legal because the two branches touch disjoint state and
  the k=3 kernels can be left-zero-padded to k=5 without changing a single tap.
  It removed 2 of 4 conv launches but left the python chunk loop in place, so the
  gain was only 1.8x on rate. `hist_ring_chunk` (allocation-free history) did not
  beat it - the allocator was not the cost.
* **Whole-request scheduling (#3)** is legal because every position depends only
  on current and past inputs: one causal pass over 1043 samples equals nine
  chained chunk passes with carried history (verified numerically to 1.1e-6).
  Publishing the 9 chunks back-to-back is compatible with the ring capacity
  (`ceil(1043/127)+4 = 13 >= 9`) and with the adapter's one-request-in-flight
  rule.
* **Graph capture (#4-#6, #11)** attacks the real bottleneck: at these sizes the
  GPU work is ~40 us while the per-op launch + python overhead is ~0.5 ms. It is
  numerically exact (same kernels, replayed).
* **First-output latency after graph capture** was still ~0.98 ms; profiling the
  poll showed the input pickup loop (sleep-based) dominated, so the busy-poll
  variant (#11) was added: 0.98 -> 0.53 ms.
* **Branch-parallel streams (#7)** and TF32 (#10) did not pay off: the device is
  idle most of the time, so concurrency and lower precision do not move the
  critical path; #7 also pays two event syncs per chunk.
* **CPU co-location (#9)** avoids the PCIe round trip and reaches the same 3000
  chunks/s as the GPU eager path, but its first-output latency is 3x worse than
  graph replay, so it was not promoted.
* **Failures (kept as evidence)**: `hist_ring_chunk` v1 emitted wrong values
  (max diff 0.94) because the ring front was never refreshed with the newest 4
  samples; `im2col_gemm` v1 raised
  `Expected size for first two dimensions of batch2 tensor` (bmm batch layout).
  Both were agent bugs, fixed and re-measured; their logs are in
  `benchmarks/results/`.
* **Remaining trade-off**: the recommended variant trades memory (a captured
  graph plus three pinned buffers, well under 1 MB) for latency, and its batched
  publish makes the 9 chunks of one request available in a burst (~4 us apart)
  instead of evenly spread over the request period; the consumer never stalls,
  and a downstream that wants smoother pacing can consume them at its own rate.

### Unmet / not applicable here
* Multi-GPU variants (pipeline stages on separate devices) are not applicable on
  this single-GPU assignment; the IR stage split is recorded above as the
  evidence that the app *would* admit a 2-device branch split.
* Independent controller verification/benchmark of `backend/worker.py` is
  recorded under `evidence/` (outside this writable workspace) and is the
  authoritative measurement.
