"""Shared model math + IPC protocol plumbing for branch_features backend variants.

Divergence note: this file is agent-authored (not vendored). The reference
(flashrt/apps/branch_features/model.py) is still the numerical specification; the
layers are rebuilt with the *identical* seed/construction order so weights match
bit-for-bit, and every conv keeps the reference's causal `replicate` padding.

Fusion identities used by the variants (all mathematically exact):
  * both k=3 branch-0/1 convs are left-zero-padded to k=5, which keeps the same
    taps while allowing one stacked/grouped conv launch for both branches;
  * prepending k-1 history samples and then applying a k-1 `replicate` pad is
    identical to the reference's chunk-local `replicate` pad followed by a
    sliding-history cat (replicate of the oldest sample == the history tail at
    session start, which is reproduced by priming the history from x[:, :, :1]).
"""
import argparse
import ast
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

PINS = 4  # largest (kernel_size - 1) among the four convs


def build_layers(repository, config, device):
    source_path = Path(repository) / 'flashrt/layers/audio.py'
    node = next(node for node in ast.parse(source_path.read_text(encoding='utf-8')).body
                if isinstance(node, ast.ClassDef) and node.name == 'CausalConv1d')
    namespace = {'nn': torch.nn, 'F': F, 'torch': torch}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source_path), 'exec'), namespace)
    conv = namespace['CausalConv1d']
    torch.manual_seed(config['weight_seed'])
    channels, hidden = config['channels'], config['hidden']
    return torch.nn.ModuleDict({'a0': conv(channels, hidden, 5), 'a1': conv(hidden, channels, 3),
                                'b0': conv(channels, hidden, 3), 'b1': conv(hidden, channels, 5)}).to(device).eval()


def _pad5(w):
    """Left-zero-pad a (out, in, k<=5) kernel to k=5 (oldest taps)."""
    return F.pad(w, (5 - w.shape[-1], 0))


class Engine:
    """Fused dual-branch causal conv model with per-session history state."""

    def __init__(self, repository, config, device='cuda'):
        self.config = config
        self.device = torch.device(device)
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        layers = build_layers(repository, config, 'cpu')  # same seed/order as the reference
        w = {k: layers[k].conv.weight.detach().clone() for k in layers}
        b = {k: layers[k].conv.bias.detach().clone() for k in layers}
        dev = self.device
        # stacked/grouped fused kernels
        self.W0 = torch.cat([w['a0'], _pad5(w['b0'])], 0).to(dev).contiguous()
        self.B0 = torch.cat([b['a0'], b['b0']]).to(dev).contiguous()
        self.W1 = torch.cat([_pad5(w['a1']), w['b1']], 0).to(dev).contiguous()
        self.B1 = torch.cat([b['a1'], b['b1']]).to(dev).contiguous()
        # separate kernels (branch-parallel variants)
        self.sep_w = {k: _pad5(v).to(dev).contiguous() for k, v in w.items()}
        self.sep_b = {k: v.to(dev).contiguous() for k, v in b.items()}
        self.reset()

    # ---- session state -------------------------------------------------
    def reset(self):
        c, h = self.channels, self.hidden
        self.hist_in = torch.zeros(1, c, PINS, device=self.device)
        self.hist_mid = torch.zeros(1, 2 * h, PINS, device=self.device)
        self.primed = False

    def _join(self, x, hist, prime):
        if prime:
            hist = x[:, :, :1].expand(-1, -1, PINS)
        return torch.cat([hist, x], -1)

    def _finish(self, x, y):
        a, b = y[:, : self.channels], y[:, self.channels:]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return gate * a + (1 - gate) * b + 0.1 * x

    # ---- computation ---------------------------------------------------
    def forward(self, x):
        """x: (1, C, L) -> (1, C, L). Consumes/produces session history."""
        prime = not self.primed
        joined = self._join(x, self.hist_in, prime)
        mid = F.silu(F.conv1d(F.pad(joined, (PINS, 0), mode='replicate'), self.W0, self.B0))[:, :, PINS:]
        joined_mid = self._join(mid, self.hist_mid, prime)
        y = F.conv1d(F.pad(joined_mid, (PINS, 0), mode='replicate'), self.W1, self.B1, groups=2)[:, :, PINS:]
        self.hist_in = joined[:, :, -PINS:].clone()
        self.hist_mid = joined_mid[:, :, -PINS:].clone()
        self.primed = True
        return self._finish(x, y)


class Protocol:
    """Adapter-compatible control/input/output loop."""

    def __init__(self, config):
        try:
            from branch_features.adapter import open_buffers, close_buffers
        except ImportError:
            from flashrt.apps.branch_features.adapter import open_buffers, close_buffers
        self._close = close_buffers
        self.buffers = open_buffers(config, create=True)
        self.chunk = int(config['chunk'])
        self.length = int(config['length'])
        self.channels = int(config['channels'])
        self.nchunks = len(range(0, self.length, self.chunk))
        self.residual = np.zeros((self.channels, self.chunk), dtype=np.float32)
        self.batch = np.zeros((self.nchunks, self.channels, self.chunk), dtype=np.float32)
        self.meta = np.zeros((self.nchunks, 3), dtype=np.int64)
        self.consumed = 0
        self.request_id = 0
        self.index = 0
        self.engine = None

    # ---- publishing ----------------------------------------------------
    def emit(self, values):
        """Publish the next chunk of the current request; values: (C, valid)."""
        valid = int(values.shape[-1])
        if valid == self.chunk:
            self.buffers['output'].write(np.ascontiguousarray(values))
        else:
            self.residual[:, :valid] = values
            self.buffers['output'].write(self.residual)
            self.residual[:, :valid] = 0.0
        self.buffers['metadata'].write(np.array([self.request_id, self.index, valid], dtype=np.int64))
        self.index += 1

    def emit_all(self, out):
        """Publish all remaining chunks from a (C, length) host array in one batch."""
        idx = self.index
        batch, chunk, total = self.batch, self.chunk, self.length
        for k in range(idx, self.nchunks):
            lo = k * chunk
            hi = min(lo + chunk, total)
            batch[k, :, : hi - lo] = out[:, lo:hi]
            self.meta[k] = (self.request_id, k, hi - lo)
        self.buffers['output'].write(batch[idx:])
        self.buffers['metadata'].write(self.meta[idx:])
        self.index = self.nchunks

    # ---- control loop --------------------------------------------------
    def _on_reset(self):
        if self.engine is not None:
            self.engine.reset()

    def _await_input(self, consumed, last_command):
        ctrl, inp = self.buffers['control'], self.buffers['input']
        spin = 0
        while True:
            if ctrl.recv() != last_command:
                return None, None
            nxt, feats = inp.read(consumed, 1)
            if feats is not None:
                return nxt, feats
            spin += 1
            if spin < 32:
                time.sleep(0)
            else:
                time.sleep(0.00002)

    def run(self, process):
        last_command, active = None, False
        try:
            while True:
                opcode = self.buffers['control'].recv()
                if opcode != last_command:
                    last_command = opcode
                    if opcode == 2:
                        self.buffers['control'].commit()
                        break
                    if opcode == 3:
                        self._on_reset()
                        active = False
                        self.buffers['control'].commit()
                    elif opcode == 1:
                        active = True
                        self.buffers['control'].commit()
                    elif opcode != 0:
                        raise ValueError(f'Unknown control opcode: {opcode}')
                if not active:
                    time.sleep(0.00002)
                    continue
                nxt, features = self._await_input(self.consumed, last_command)
                if features is None:
                    continue
                if nxt != self.consumed + 1:
                    raise RuntimeError('Input overwritten before processing')
                self.request_id, self.consumed = self.consumed, nxt
                self.index = 0
                process(self, features)
                if self.index != self.nchunks:
                    raise RuntimeError(f'Emitted {self.index} of {self.nchunks} chunks')
        finally:
            self._close(self.buffers, unlink=True)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    return parser.parse_args()


def main(process, device='cuda', tf32=False):
    args = parse_args()
    repository = str(args.repository.resolve())
    for _p in (repository, str(Path(repository) / 'flashrt' / 'apps')):
        if _p not in sys.path:
            sys.path.insert(0, _p)
    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    if device == 'cuda':
        torch.backends.cudnn.allow_tf32 = bool(tf32)
        torch.backends.cuda.matmul.allow_tf32 = bool(tf32)
    engine = Engine(repository, config, device=device, )
    protocol = Protocol(config)
    protocol.engine = engine
    print(json.dumps({'ready': True, 'device': str(device), 'task': 'branch_features',
                      'variant': config.get('variant_name', 'unknown')}), flush=True)
    protocol.run(lambda proto, feats: process(proto, engine, feats))
    print(json.dumps({'closed': True}), flush=True)
