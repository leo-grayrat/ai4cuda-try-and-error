"""Variant `spin_graph`: CUDA graph + head-start publish + pinned staging + busy-poll input pickup

Standalone branch_features backend entry (--repository/--config).  Model math
and IPC plumbing: flashrt/apps/branch_features/backend/core.py + graphengine.py.
"""
import sys

import numpy as np
import torch

try:
    from flashrt.apps.branch_features.backend import core, graphengine
except ImportError:  # direct-script launch with only the app dir importable
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
    import core
    if 'yes' == 'yes':
        import graphengine

def _busy_await(self, consumed, last_command):
    """Tight input poll (no sleep) to cut the input-pickup latency."""
    ctrl, inp = self.buffers['control'], self.buffers['input']
    while True:
        if ctrl.recv() != last_command:
            return None, None
        nxt, feats = inp.read(consumed, 1)
        if feats is not None:
            return nxt, feats


core.Protocol._await_input = _busy_await

class Session:
    def __init__(self, engine, proto):
        self.engine = engine
        self.ge = graphengine.GraphEngine(engine, proto.length, proto.chunk)

    def reset(self):
        self.engine.reset()
        self.ge.reset()

    def process(self, proto, features):
        ge = self.ge
        ge.load(features, pinned=True)
        ge.replay()
        proto.emit(ge.read_head())
        proto.emit_all(ge.read_all())


def process(proto, engine, features):
    sess = getattr(proto, '_sess', None)
    if sess is None:
        sess = proto._sess = (
            Session(engine, proto))
        proto.engine = sess
    sess.process(proto, features)


if __name__ == '__main__':
    core.main(process, device='cuda')
