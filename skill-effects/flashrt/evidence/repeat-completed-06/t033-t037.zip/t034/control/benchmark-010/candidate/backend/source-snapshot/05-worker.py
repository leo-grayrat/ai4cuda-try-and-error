"""Optimized streaming backend for the causal_features task.

The fixed computation is defined by ``causal_features.model``: three
``CausalConv1d`` layers (C->H->H->C, kernels 5/5/3, SiLU after each) whose
weights are seeded with ``config['weight_seed']``.  This worker keeps that
exact computation and the exact adapter contract (shared control/tensor
buffers, opcodes 1/3/2, data-before-metadata publication, ``(channels,
chunk)`` payloads and int64 ``(request, chunk, valid)`` metadata).

Why it is faster than the sequential reference on one GPU:
  * all three layers stay on the GPU between chunks; the reference copies
    every layer's chunk input through ``torch.from_numpy`` and copies every
    chunk output back with a blocking ``.cpu()``;
  * inside one request the causally-convolved positions are grouped into
    two contiguous segments (chunk 0, then the remainder) instead of one
    segment per chunk.  A causal convolution is position-local, so grouping
    contiguous positions does not change any output value -- it only removes
    Python overhead, kernel-launch overhead and device synchronisations.
    The tail chunk is emitted with its true valid length;
  * the first output chunk is computed and published before the remainder
    of the request is transferred to the GPU, so first-output latency does
    not pay for the whole sequence;
  * one device-to-host copy per segment instead of one per chunk; the host
    array is then sliced into the shared-memory output ring;
  * the idle poll loop busy-spins briefly before falling back to a sleep, so
    an input published just after a poll is observed with microsecond rather
    than OS-timer latency (the reference polls with a 0.2 ms sleep).

Per-layer histories (last kernel_size-1 inputs of each layer) are kept as
tensors across requests; ``reset`` (opcode 3) clears them.  Consecutive
requests without reset are therefore equivalent to one concatenated
sequence, matching the reference and the CPU full-sequence oracle.
"""

import argparse
import json
import sys
import time
from pathlib import Path

SPIN_LIMIT = 20000  # empty polls before falling back to a short sleep


def _resolve_device(torch, raw):
    if isinstance(raw, int):
        return torch.device("cuda", raw)
    device = torch.device(raw)
    if device.type == "cuda" and not torch.cuda.is_available():
        return torch.device("cpu")
    return device


class FastPipeline:
    """Chunk-streaming causal stack with persistent per-layer histories."""

    def __init__(self, layers, device, chunk):
        self.layers = layers
        self.device = device
        self.chunk = int(chunk)
        self.pads = [int(layer._time_causal_padding[0]) for layer in layers]
        self.histories = [None] * len(layers)

    def reset(self):
        self.histories = [None] * len(self.layers)

    def run_segment(self, value):
        """Run three causal layers over one contiguous time segment."""
        import torch
        import torch.nn.functional as F

        for index, layer in enumerate(self.layers):
            history = self.histories[index]
            joined = value if history is None else torch.cat((history, value), dim=-1)
            result = layer(joined)
            if history is not None:
                result = result[..., history.shape[-1]:]
            pad = self.pads[index]
            if pad > 0:
                # Same cache update as the reference:
                # histories[i] = joined[..., -pad:].clone()
                self.histories[index] = joined[..., -pad:].clone()
            value = F.silu(result)
        return value

    def _to_device(self, features, start, end):
        import numpy as np
        import torch

        block = np.ascontiguousarray(features[:, start:end])
        return torch.from_numpy(block).unsqueeze(0).to(self.device)

    def process(self, features, publish, mode="chunk0"):
        """Process one complete request; ``publish(index, host_array)`` emits."""
        import torch

        with torch.inference_mode():
            total = features.shape[-1]
            if mode == "chunked":
                index = 0
                for position in range(0, total, self.chunk):
                    end = min(position + self.chunk, total)
                    out = self.run_segment(self._to_device(features, position, end))
                    publish(index, out[0].cpu().numpy())
                    index += 1
                return

            if mode == "full":
                host = self.run_segment(self._to_device(features, 0, total))[0].cpu().numpy()
                index = 0
                for position in range(0, total, self.chunk):
                    end = min(position + self.chunk, total)
                    publish(index, host[:, position:end])
                    index += 1
                return

            # Recommended: earliest first chunk, then the whole remainder.
            first = min(self.chunk, total)
            out = self.run_segment(self._to_device(features, 0, first))
            publish(0, out[0].cpu().numpy())
            if first >= total:
                return
            rest = self.run_segment(self._to_device(features, first, total))
            host = rest[0].cpu().numpy()
            index = 1
            position = first
            while position < total:
                end = min(position + self.chunk, total)
                publish(index, host[:, position - first:end - first])
                position = end
                index += 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--mode",
        default=None,
        choices=("chunk0", "full", "chunked"),
        help="segment grouping; default comes from the config or 'chunk0'",
    )
    args = parser.parse_args()

    repository = args.repository.resolve()
    sys.path.insert(0, str(repository))
    # Allow the worker to be launched standalone (outside the controller's
    # module-path setup) while still using the supplied packages.
    apps = repository / "flashrt" / "apps"
    if apps.is_dir() and str(apps) not in sys.path:
        sys.path.insert(0, str(apps))

    import numpy as np
    import torch

    from causal_features.adapter import close_buffers, open_buffers
    from causal_features.model import build_layers

    config = json.loads(args.config.read_text(encoding="utf-8"))
    mode = args.mode or config.get("mode") or "chunk0"

    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    # The CPU oracle accumulates in float32; TF32 convolution would exceed the
    # documented atol=3e-5 / rtol=3e-4 tolerance.
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = _resolve_device(torch, config.get("device", "cuda:0"))
    layers = build_layers(repository, config, device)
    chunk = int(config["chunk"])
    channels = int(config["channels"])
    pipeline = FastPipeline(layers, device, chunk)

    buffers = open_buffers(config, create=True)
    scratch = np.zeros((channels, chunk), dtype=np.float32)
    metadata = np.zeros((3,), dtype=np.int64)

    def publish(index, host):
        valid = int(host.shape[-1])
        if valid < chunk:
            scratch.fill(0.0)
        scratch[:, :valid] = host
        # Data first, metadata second: the adapter checks that ordering.
        buffers["output"].write(scratch)
        metadata[0] = request_id
        metadata[1] = index
        metadata[2] = valid
        buffers["metadata"].write(metadata)

    consumed, last_command, active = 0, 0, False
    request_id = 0
    sleep_s = 0.0002
    idle = 0
    try:
        print(json.dumps({"ready": True, "device": str(device), "mode": mode}), flush=True)
        while True:
            opcode = buffers["control"].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers["control"].commit()
                    break
                if opcode == 3:
                    pipeline.reset()
                    active = False
                    buffers["control"].commit()
                elif opcode == 1:
                    active = True
                    buffers["control"].commit()
                elif opcode != 0:
                    raise ValueError(f"Unknown control opcode: {opcode}")
            if not active:
                idle += 1
                if idle < SPIN_LIMIT:
                    continue
                time.sleep(sleep_s)
                continue
            next_cursor, features = buffers["input"].read(consumed, 1)
            if features is None:
                idle += 1
                if idle < SPIN_LIMIT:
                    continue
                time.sleep(sleep_s)
                continue
            idle = 0
            if next_cursor != consumed + 1:
                raise RuntimeError("Input overwritten before processing")
            request_id = consumed
            consumed = next_cursor
            pipeline.process(features[0], publish, mode=mode)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({"closed": True}), flush=True)


if __name__ == "__main__":
    main()
