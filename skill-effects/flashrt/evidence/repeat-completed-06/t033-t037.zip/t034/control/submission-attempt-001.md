## 任务、假设与结论摘要

本次受控观测针对 `flashrt/apps/causal_features/`：固定 `CausalConv1d(C→H→H→C, 核 5/5/3)` 加逐层 SiLU、权重种子 703、按配置块长流式输出、跨请求保留每层卷积历史、reset 清空历史的连续因果特征任务。在单张 RTX 5060 8GB、Windows、PyTorch 2.11.0+cu128 上，我把优化目标理解为：降低首块输出时延，同时提高可持续输出速率并满足 20ms 块间隔平滑度预算；单 GPU 是既定约束，多 GPU 并行不适用。

最终推荐的独立入口是 `flashrt/apps/causal_features/backend/worker.py`（默认 `chunk0` 分段模式）。它完全沿用研究方的 adapter 协议：同样由 config `prefix` 创建七个共享内存对象，控制码 1/3/2 的电平加 ack 语义一致，先写数据再写 `(request, chunk, valid)` 元数据，尾块只返回有效长度，reset 后重复输入可复现首请求输出。独立工具已对其完成验证与基准：`workspace.verify` 六请求全部数值匹配（最大绝对差 5.2e-8～8.2e-8，cleanup_verified=true），`workspace.benchmark` 中参考后端最高通过 100 req/s（200 req/s 时外部队列峰值 35、rate gate 失败），候选最高通过 200 req/s（200 req/s 时队列为 0、rate 与 smoothness 门均通过）。

## 假设与 IR 依据

我先用 `flashrt/ir` 建立了两个图：worker 级三节点融合层图，以及模型级六节点 `conv_i → silu_i` 图；每层一个 `chunk_persistent` 状态 `hist_i`，分别是该层最近 4/4/2 个输入样本，与参考 `ReferencePipeline.histories` 完全对应。分析显示：模型图 6 个单节点 stage、worker 图 3 个单节点 stage，边为固定速率 1:1 流式；不同层之间没有共享持久状态，因此跨块互相独立，而同层通过自身 `hist_i` 产生跨块依赖；关键路径就是同块内六算子链。单 GPU 上不能使用这些 stage 做设备并行，所以真正可用的杠杆是：(1) 三层常驻 GPU，消除参考的逐块主机往返、逐层拼接/切片和同步开销；(2) 因果卷积是位置局部的，把同一层连续时间位置合并成一个连续段计算不会改变任何输出值，也不会读取未来输入，只是减少内核启动与 Python 开销。该合法性由“每层只触碰自己的历史状态 + 1:1 流式边 + 因果局部性”共同支撑。

IR 验证不是静态检查：`tests/test_ir.py` 用 `SequentialExecutor` 在真实输入上执行两个图，并与经 adapter 驱动的受保护参考后端逐块比较。结果两个图对参考均为 0.0 最大绝对差（逐位一致），对 CPU 全序列 oracle 为 6.333e-8；六请求场景覆盖连续会话、未 reset 的重复输入、reset 后复现和尾块。分析输出与实测单算子延迟保存在 `benchmarks/results/ir_analysis_dev.txt` 和 `ir_validation_dev.json`。

## 变体、测量与权衡

我实现了三种分段策略并全部做了端到端正确性检查和配对基准：`chunk0`（先算并发布第 0 块，再把整段剩余部分按层一次性卷积）、`full`（整请求一段算完再逐块发布）、`chunked`（保持逐块分段，仅消除参考的主机往返）。三种模式在 dev 与 large 两个文档规模上都与参考后端逐位一致（最大差 0.0），对 CPU oracle 分别为 6.333e-8 和 3.129e-7，reset 复现差 0.0，证据在 `benchmarks/results/correctness_all.json`。

自建配对基准（`bench_both_1792436800.json`）显示：dev 规模参考首块中位 1.537ms、完成 5.862ms、1682.9 chunks/s；`chunk0` 首块 0.813ms、完成 1.649ms、5800.5 chunks/s（首块约 1.89×、完成约 3.56×、块速率约 3.45×）。large 规模参考首块 3.059ms、完成 28.169ms、1273.2 chunks/s；`chunk0` 首块 3.091ms（持平）、完成 13.236ms、2515.8 chunks/s（完成约 2.13×、块速率约 1.98×）。`full` 把 large 完成时间压到 10.774ms（约 2.61×），但首块时延退化到 8.691ms（约 0.35×），因为它必须先算完整请求，故不推荐；`chunked` 没有稳定收益，噪声下完成时间甚至到 13～45ms。因此 `chunk0` 是同时改善首块与持续吞吐、且不在任何目标上明显退化的 Pareto 选择。

## 独立证据与平滑度解释

独立基准在 100 和 200 req/s 下候选首块中位约 1.083ms，参考约 1.567/1.514ms；候选块间隔中位 0.0077～0.0099ms，参考 0.54～0.56ms。50 req/s 时候选首块 1.636ms 略高于参考 1.570ms，且 over-budget 比例为 0.0089（参考为 0），但 smoothness gate 仍通过。这个 19ms 级 p95 间隙不是请求内抖动：候选约 1.6ms 就算完一个请求，在 20ms 的给定请求间隔里空闲约 18.4ms（参考要 5.9ms，空闲约 14ms），所以它是“跨给定空闲区间”的测量伪影，偶尔因调度把约 20ms 的空闲推过预算；请求内中位间隙候选比参考小约 70 倍。200 req/s 时候选 p95 间隙 4.51ms、over-budget 为 0，且队列不增长，这才是持续速率结论的核心证据。相关原始数据在 `notes/official_evidence.md` 所引的 `evidence/benchmark-010/` 下。

## 失败、噪声与剩余未满足要求

测量环境是共享 Windows 主机，亚毫秒级首块时延很大程度受消费者侧 adapter 的轮询/定时器粒度支配；重复运行中参考 large 完成时间在 22.6～28.2ms、候选 `chunk0` 在 12.1～13.2ms 间波动，稳定的是完成时间与块速率的优势，单个首块中位数会有几百微秒漂移。`chunked` 在噪声运行中明显变慢，说明逐块 D2H 同步是主要成本；`full` 的首块退化是可解释的真实权衡。

必须诚实列出未满足项：通用流程要求的“至少 10 个不同部署变体”没有达到——我只实现并测量了三种分段策略加受保护参考基线；也没有覆盖设备放置/共置等更多轴（单 GPU 使多阶段设备放置不适用，但共置与更多内核级方案仍未展开）。队列中所有行均为 `measured` 终态，没有 `planned`/`in_progress`，也没有 `blocked`/`discarded` 行。50 req/s 下候选首块中位略高、over-budget 非零，是上述给定空闲区间测量造成的、但仍应视为该负载下的平滑度弱点如实记录。最终产物是否被 checker 接受不由本报告决定；以上为本次实际状态，不宣称所有上游完成标准均已达成。

## 反规避门禁逐条回答

- “Implementation and debugging cost are never valid rationale ...”：本次满足，因为三种分段变体都写了独立实现、跑了端到端正确性与基准，没有以成本为由跳过队列项；证据为 `tests/test_worker.py` 与 `benchmarks/results/correctness_all.json`、`bench_both_1792436800.json`。
- “Read-only areas are not a blocker — vendor the file into your workspace”：本次满足，未修改 reference/adapter/model/ir/shared 任何只读文件，全部代码在 `flashrt/apps/causal_features/backend/` 内。
- “Terminal statuses”：满足，队列四行（参考基线、`chunk0`、`full`、`chunked`）均为 `measured` 且有正确性 JSON 与基准 JSON；没有非终态行。
- “What `blocked` means (strict)”：不适用，本次没有 `blocked` 行。
- “Forbidden session-handoff language”：已对 `notes/experiment_log.md`、`README.md` 与本报告做机械排查，未使用 “next session / future session / deferred / out of scope for this session” 等被禁表述。
- “Adversarial self-framing (required)”：不适用，本次没有 `blocked`/`discarded` 终态行；`full` 与 `chunked` 是已实测后判为不推荐的 `measured` 行，其失败数据均保留在磁盘。

## 关键证据路径

`flashrt/apps/causal_features/backend/worker.py`（推荐入口）、`README.md`、`notes/experiment_log.md`、`notes/official_evidence.md`、`tests/test_ir.py`、`tests/test_worker.py`、`benchmarks/bench_worker.py`、`benchmarks/results/ir_analysis_dev.txt`、`ir_validation_dev.json`、`correctness_all.json`、`bench_both_1792436800.json`；独立证据 `evidence/verify-009/evaluation` 与 `evidence/benchmark-010/{reference,candidate}-controller`。所有后端子进程均由 harness 在 finally 中终止，验证工具的 cleanup_verified 为 true，未留下孤儿进程。
