"""Graph builders for the causal_features IR conversion.

``build_model_graph`` decomposes one chunk into the six fine-grained
operators of the fixed stack (conv/SiLU per layer).  ``build_worker_graph``
is the fused worker-level view (one conv+SiLU node per layer).  Both carry
one ``chunk_persistent`` history state per layer, exactly the state the
reference keeps in ``ReferencePipeline.histories``.

Layer shapes are fixed by ``causal_features.model.build_layers``:
``CausalConv1d(C,H,5) -> CausalConv1d(H,H,5) -> CausalConv1d(H,C,3)``,
each followed by SiLU, so the history lengths are 4, 4 and 2 samples.
"""

from flashrt.ir import (
    IREdge,
    IRGraph,
    StateObject,
    StreamingInfo,
    StreamingPattern,
    TensorPort,
)

from .ops import CausalConvStep, CausalLayerStep, SiluStep

KERNELS = (5, 5, 3)
HISTORY_LENGTHS = tuple(k - 1 for k in KERNELS)


def _add_histories(graph):
    for index, length in enumerate(HISTORY_LENGTHS):
        graph.add_state(
            StateObject(
                name=f"hist_{index}",
                description=(
                    f"last {length} input samples of layer {index} "
                    f"(kernel {KERNELS[index]}), persists across chunks and requests"
                ),
                scope="chunk_persistent",
            )
        )


def _streaming(chunk):
    return StreamingInfo(
        pattern=StreamingPattern.FIXED_RATE,
        src_chunk_size=int(chunk),
        dst_chunk_size=int(chunk),
        description="one output chunk per input chunk (1:1 causal streaming)",
    )


def build_model_graph(config):
    """Fine-grained per-chunk graph: conv_i -> silu_i -> conv_{i+1} ..."""
    chunk = int(config.get("chunk", 127))
    channels = int(config.get("channels", 16))
    graph = IRGraph(name="causal_features_model")
    graph.external_inputs = [TensorPort("features_chunk", (channels, chunk), "float32")]
    graph.external_outputs = [TensorPort("out_chunk", (channels, chunk), "float32")]
    _add_histories(graph)

    conv = []
    silu = []
    for index in range(3):
        conv.append(
            CausalConvStep(
                index,
                input_port="features_chunk" if index == 0 else f"act_{index - 1}",
                output_port=f"conv_{index}",
                state_name=f"hist_{index}",
            )
        )
        silu.append(
            SiluStep(
                index,
                input_port=f"conv_{index}",
                output_port="out_chunk" if index == 2 else f"act_{index}",
            )
        )
        graph.add_operator(conv[index])
        graph.add_operator(silu[index])

    for index in range(3):
        graph.add_edge(
            IREdge(
                src_op=conv[index].name,
                src_port=conv[index].output_port,
                dst_op=silu[index].name,
                dst_port=silu[index].input_port,
                streaming=_streaming(chunk),
            )
        )
        if index:
            graph.add_edge(
                IREdge(
                    src_op=silu[index - 1].name,
                    src_port=silu[index - 1].output_port,
                    dst_op=conv[index].name,
                    dst_port=conv[index].input_port,
                )
            )
    graph.chunk_ops = [op.name for pair in zip(conv, silu) for op in pair]
    return graph


def build_worker_graph(config):
    """Worker-level graph: three fused layer nodes chained within a chunk."""
    chunk = int(config.get("chunk", 127))
    channels = int(config.get("channels", 16))
    graph = IRGraph(name="causal_features_worker")
    graph.external_inputs = [TensorPort("features_chunk", (channels, chunk), "float32")]
    graph.external_outputs = [TensorPort("out_chunk", (channels, chunk), "float32")]
    _add_histories(graph)

    layers = []
    for index in range(3):
        layer = CausalLayerStep(
            index,
            input_port="features_chunk" if index == 0 else f"x_{index}",
            output_port="out_chunk" if index == 2 else f"x_{index + 1}",
            state_name=f"hist_{index}",
        )
        layers.append(layer)
        graph.add_operator(layer)

    for index in range(1, 3):
        graph.add_edge(
            IREdge(
                src_op=layers[index - 1].name,
                src_port=layers[index - 1].output_port,
                dst_op=layers[index].name,
                dst_port=layers[index].input_port,
                streaming=_streaming(chunk),
            )
        )
    graph.chunk_ops = [layer.name for layer in layers]
    return graph
