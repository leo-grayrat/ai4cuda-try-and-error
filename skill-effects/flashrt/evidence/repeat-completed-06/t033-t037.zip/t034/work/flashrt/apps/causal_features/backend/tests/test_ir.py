"""Phase-2 IR validation harness.

Builds the model-level and worker-level IR graphs, executes them with the
original ``SequentialExecutor`` on real input, and compares every output
chunk against the protected reference backend driven through the adapter.
Also compares the reference against the CPU full-sequence oracle, measures
per-operator latency, and records ``summarize_graph`` output.
"""

import argparse
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))

import common  # noqa: E402

sys.path.insert(0, str(common.BACKEND))
from ir import build_model_graph, build_worker_graph  # noqa: E402

from flashrt.ir import SequentialExecutor, summarize_graph  # noqa: E402
from causal_features.model import build_layers  # noqa: E402


def execute_graph(graph, config, arrays, scheme, device):
    """Run a graph chunk-by-chunk over the six-request scheme."""
    layers = build_layers(common.REPO, config, device)
    ctx = SimpleNamespace(layers=layers)
    executor = SequentialExecutor(graph)
    state = {f"hist_{i}": None for i in range(3)}
    executor.init_state(dict(state))
    runs = []
    for array_index, reset in scheme:
        if reset:
            executor.init_state({f"hist_{i}": None for i in range(3)})
        features = arrays[array_index]
        chunks = []
        for position in range(0, features.shape[-1], config["chunk"]):
            block = np.ascontiguousarray(features[:, position:position + config["chunk"]])
            tensor = torch.from_numpy(block).unsqueeze(0).to(device)
            out = executor.run_chunk({"features_chunk": tensor}, ctx)
            chunks.append(out["out_chunk"][0].cpu().numpy().copy())
        runs.append({"chunks": chunks})
    return runs


def _time_ms(torch_device, fn, iters=100):
    if torch_device.type == "cuda":
        torch.cuda.synchronize()
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(iters):
            fn()
        end.record()
        torch.cuda.synchronize()
        return start.elapsed_time(end) / iters / 1000.0
    import time

    t0 = time.perf_counter()
    for _ in range(iters):
        fn()
    return (time.perf_counter() - t0) / iters


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scale", default="dev", choices=sorted(common.SCALES))
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()

    cfg = common.make_config(common.make_prefix("ir"), args.scale, args.device)
    arrays = common.make_arrays(cfg)
    scheme = common.six_request_scheme()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    print("running reference backend for IR validation ...", flush=True)
    ref_runs = common.run_backend(common.REFERENCE, cfg, arrays, scheme, "ir_ref")
    oracle = common.oracle_requests(cfg, arrays)
    ref_ok, ref_worst = common.compare_to_oracle(ref_runs, oracle)

    graphs = {
        "model": build_model_graph(cfg),
        "worker": build_worker_graph(cfg),
    }
    results = {}
    overall = True
    for name, graph in graphs.items():
        runs = execute_graph(graph, cfg, arrays, scheme, device)
        ok, worst, per_request = common.compare_chunks(ref_runs, runs)
        oracle_ok, oracle_worst = common.compare_to_oracle(runs, oracle)
        results[name] = {
            "operators": len(graph.operators),
            "edges": len(graph.edges),
            "pass_ref": ok,
            "max_abs_vs_ref": worst,
            "per_request_max_abs": per_request,
            "pass_oracle": oracle_ok,
            "max_abs_vs_oracle": oracle_worst,
            "executor_hash": common.digest(runs),
        }
        overall = overall and ok and oracle_ok
        print(
            f"graph={name} ops={len(graph.operators)} edges={len(graph.edges)} "
            f"max_abs_vs_ref={worst:.3e} max_abs_vs_oracle={oracle_worst:.3e}",
            flush=True,
        )

    # Per-operator latency for critical-path analysis.
    layers = build_layers(common.REPO, cfg, device)
    chunk = cfg["chunk"]
    in_channels = [cfg["channels"], cfg["hidden"], cfg["hidden"]]
    latencies = {}
    for i, layer in enumerate(layers):
        pad = int(layer._time_causal_padding[0])
        sample = torch.randn(1, in_channels[i], chunk + pad, device=device)
        latencies[f"layer{i}_conv"] = _time_ms(device, lambda layer=layer, sample=sample: layer(sample))
        act = torch.randn(1, cfg["channels"], chunk, device=device)
        latencies[f"layer{i}_silu"] = _time_ms(device, lambda act=act: torch.nn.functional.silu(act))
    worker_latencies = {
        f"layer{i}": latencies[f"layer{i}_conv"] + latencies[f"layer{i}_silu"] for i in range(3)
    }

    model_summary = summarize_graph(graphs["model"], op_latencies=latencies)
    worker_summary = summarize_graph(graphs["worker"], op_latencies=worker_latencies)
    print(model_summary)
    print(worker_summary)

    common.RESULTS.mkdir(parents=True, exist_ok=True)
    analysis_path = common.RESULTS / f"ir_analysis_{args.scale}.txt"
    analysis_path.write_text(
        "=== measured per-operator latency (seconds, device=%s) ===\n%s\n\n%s\n\n%s"
        % (device, json.dumps(latencies, indent=2), model_summary, worker_summary),
        encoding="utf-8",
    )
    summary = {
        "scale": args.scale,
        "device": str(device),
        "reference_vs_oracle": {"pass": ref_ok, "max_abs": ref_worst},
        "graphs": results,
        "hashes": {"reference": common.digest(ref_runs)},
        "op_latencies_s": latencies,
        "analysis_file": str(analysis_path),
        "verdict": "PASS" if overall and ref_ok else "FAIL",
    }
    out = common.RESULTS / f"ir_validation_{args.scale}.json"
    out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"evidence: {out}")
    print("VERDICT:", summary["verdict"])
    return 0 if summary["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
