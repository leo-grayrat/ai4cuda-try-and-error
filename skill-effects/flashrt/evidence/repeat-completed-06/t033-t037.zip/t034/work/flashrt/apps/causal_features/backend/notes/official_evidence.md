# Official (independent) verification and benchmark evidence

## Correctness — `workspace.verify` on `backend/worker.py`

- status: `candidate_run_passed`
- requests completed: 6
- per-request max abs difference vs the CPU full-sequence oracle:
  5.215e-08, 7.451e-08, 5.215e-08, 6.706e-08, 5.960e-08, 8.196e-08
- cleanup_verified: true
- evidence directory: `evidence/verify-009/evaluation`

## Paired load sweep — `workspace.benchmark` on `backend/worker.py`

Pilot finite windows, reference measured first, candidate second.

| offered req/s | reference first-out med/p95 ms | reference gap med/p95 ms | ref rate gate | candidate first-out med/p95 ms | candidate gap med/p95 ms | cand rate gate |
|---|---|---|---|---|---|---|
| 50 | 1.570 / 2.186 | 0.541 / 15.80 | pass | 1.636 / 2.169 | 0.0077 / 19.32 | pass |
| 100 | 1.567 / 1.757 | 0.558 / 5.68 | pass | 1.083 / 1.572 | 0.0096 / 9.49 | pass |
| 200 | 1.514 / 2.014 | 0.559 / 1.58 | **fail** (peak external queue 35) | 1.083 / 1.212 | 0.0099 / 4.51 | **pass** |

- reference highest tested passing offered rate: 100 req/s
- candidate highest tested passing offered rate: 200 req/s
- candidate over-budget (>20 ms) fractions: 0.0089 at 50 req/s, 0.0 at
  100 and 200 req/s; smoothness gate passed at every load for both.
- evidence directories: `evidence/benchmark-010/reference-controller`,
  `evidence/benchmark-010/candidate-controller`

The candidate's 0.0089 over-budget fraction at 50 req/s is the idle gap
between the last chunk of one request and the first chunk of the next
offered request: the candidate finishes a request in ~1.6 ms, so it sits
idle for ~18.4 ms of the 20 ms offered interval (the reference finishes in
~5.9 ms and idles ~14 ms). It is an artefact of measuring across an offered
idle interval, not a within-request stutter; within a request the candidate
median gap is 0.0077-0.0099 ms versus 0.54-0.56 ms for the reference.
