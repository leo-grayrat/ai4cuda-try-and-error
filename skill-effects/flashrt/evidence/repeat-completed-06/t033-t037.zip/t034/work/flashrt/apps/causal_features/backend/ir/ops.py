"""IR operators for the causal_features graph.

Two levels are expressed:

* ``CausalConvStep`` + ``SiluStep`` -- the model-level decomposition of one
  chunk through the fixed stack: conv (with its own persistent history) then
  SiLU, three times.  This mirrors ``causal_features.model.ReferencePipeline``
  statement for statement and is what the Phase-2 executor validates.
* ``CausalLayerStep`` -- the fused per-layer view used by the worker-level
  graph (conv + SiLU in one node, one history per layer).

The history state object of layer ``i`` is the last ``kernel_size_i - 1``
inputs that layer consumed, i.e. exactly the tensor the reference stores in
``ReferencePipeline.histories[i]``.  It is ``chunk_persistent``: it creates
the cross-chunk dependency of each layer with itself.
"""

import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort


class CausalConvStep(IROperator):
    """One causal convolution layer, keeping its own input history."""

    def __init__(self, layer_index, input_port, output_port, state_name,
                 op_type=OpType.EXPOSED, label=None):
        super().__init__(
            name=label or f"layer{layer_index}_conv",
            op_type=op_type,
            inputs=[TensorPort(input_port)],
            outputs=[TensorPort(output_port)],
            state_reads=[state_name],
            state_writes=[state_name],
            stream_mode=StreamMode.STREAMING,
            config={"layer_index": layer_index, "input_port": input_port,
                    "output_port": output_port, "state": state_name},
        )
        self.layer_index = int(layer_index)
        self.input_port = input_port
        self.output_port = output_port
        self.state_name = state_name

    @torch.inference_mode()
    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.layer_index]
        pad = int(layer._time_causal_padding[0])
        value = inputs[self.input_port]
        history = state.get(self.state_name)
        joined = value if history is None else torch.cat((history, value), dim=-1)
        result = layer(joined)
        if history is not None:
            result = result[..., history.shape[-1]:]
        if pad > 0:
            state.set(self.state_name, joined[..., -pad:].clone())
        return {self.output_port: result}


class SiluStep(IROperator):
    """SiLU activation between two layers (leaf op)."""

    def __init__(self, layer_index, input_port="x", output_port="y"):
        super().__init__(
            name=f"layer{layer_index}_silu",
            op_type=OpType.EXPOSED,
            inputs=[TensorPort(input_port)],
            outputs=[TensorPort(output_port)],
            stream_mode=StreamMode.STREAMING,
        )
        self.input_port = input_port
        self.output_port = output_port

    @torch.inference_mode()
    def execute(self, inputs, ctx, state):
        del ctx, state
        return {self.output_port: F.silu(inputs[self.input_port])}


class CausalLayerStep(IROperator):
    """Fused conv+SiLU view of one layer for the worker-level graph."""

    def __init__(self, layer_index, input_port, output_port, state_name):
        super().__init__(
            name=f"layer{layer_index}",
            op_type=OpType.COMPOSITE,
            inputs=[TensorPort(input_port)],
            outputs=[TensorPort(output_port)],
            state_reads=[state_name],
            state_writes=[state_name],
            stream_mode=StreamMode.STREAMING,
            config={"layer_index": int(layer_index), "state": state_name},
        )
        self.layer_index = int(layer_index)
        self.input_port = input_port
        self.output_port = output_port
        self.state_name = state_name

    @torch.inference_mode()
    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.layer_index]
        pad = int(layer._time_causal_padding[0])
        value = inputs[self.input_port]
        history = state.get(self.state_name)
        joined = value if history is None else torch.cat((history, value), dim=-1)
        result = layer(joined)
        if history is not None:
            result = result[..., history.shape[-1]:]
        if pad > 0:
            state.set(self.state_name, joined[..., -pad:].clone())
        return {self.output_port: F.silu(result)}
