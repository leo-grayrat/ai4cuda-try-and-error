"""Paired reference/candidate benchmark for the causal_features backend.

Measures, per backend, scale and candidate segmentation mode, on the same
hardware and the same inputs:
  * latency to first output chunk (cold start reported separately),
  * time to complete a request,
  * back-to-back offered load: request period, request rate, chunk rate,
  * inter-chunk gap distribution (median, p95, max) and the fraction above
    the app's 20 ms per-chunk budget.
Raw timestamps are persisted under benchmarks/results/.
"""

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tests"))

import common  # noqa: E402

BUDGET_NS = 20_000_000


def _stats(values):
    if not values:
        return {"n": 0}
    array = np.asarray(values, dtype=np.float64)
    return {
        "n": int(array.size),
        "median": float(np.median(array)),
        "mean": float(array.mean()),
        "p95": float(np.percentile(array, 95)),
        "max": float(array.max()),
    }


def _ms(stats):
    return {k: (v / 1e6 if k in ("median", "mean", "p95", "max") else v) for k, v in stats.items()}


def measure(script, config, arrays, trials, burst, tag):
    chunks = common.num_chunks(config)
    log_path = common.RESULTS / f"bench_{tag}.log"
    with common.BackendSession(script, config, log_path) as adapter:
        # Warm-up (not measured): two complete requests.
        adapter.reset()
        for index in range(2):
            adapter.submit(arrays[index])
            for _ in range(chunks):
                adapter.receive(timeout_s=120)
        adapter.reset()

        latency = []
        for trial in range(trials):
            request_id, submitted = adapter.submit(arrays[2 + trial])
            observed = []
            for _ in range(chunks):
                _, stamp = adapter.receive(timeout_s=120)
                observed.append(int(stamp))
            latency.append(
                {
                    "request_id": int(request_id),
                    "submit_ns": int(submitted),
                    "observed_ns": observed,
                }
            )

        adapter.reset()
        burst_runs = []
        for index in range(burst):
            request_id, submitted = adapter.submit(arrays[2 + trials + index])
            observed = []
            for _ in range(chunks):
                _, stamp = adapter.receive(timeout_s=120)
                observed.append(int(stamp))
            burst_runs.append(
                {
                    "request_id": int(request_id),
                    "submit_ns": int(submitted),
                    "observed_ns": observed,
                }
            )

    first_out = [(run["observed_ns"][0] - run["submit_ns"]) for run in latency]
    complete = [(run["observed_ns"][-1] - run["submit_ns"]) for run in latency]
    gaps = [
        run["observed_ns"][i + 1] - run["observed_ns"][i]
        for run in latency
        for i in range(len(run["observed_ns"]) - 1)
    ]
    burst_timeline = [stamp for run in burst_runs for stamp in run["observed_ns"]]
    burst_gaps = [b - a for a, b in zip(burst_timeline, burst_timeline[1:])]
    periods = [
        burst_runs[i + 1]["submit_ns"] - burst_runs[i]["submit_ns"]
        for i in range(len(burst_runs) - 1)
    ]
    window = burst_runs[-1]["observed_ns"][-1] - burst_runs[0]["submit_ns"]
    total_chunks = burst * chunks
    return {
        "tag": tag,
        "chunks_per_request": chunks,
        "trials": trials,
        "burst_requests": burst,
        "cold_first_out_ms": first_out[0] / 1e6,
        "first_out_ms": _ms(_stats(first_out[1:])),
        "complete_ms": _ms(_stats(complete[1:])),
        "inter_chunk_gap_ms": _ms(_stats(gaps)),
        "burst_inter_chunk_gap_ms": _ms(_stats(burst_gaps)),
        "burst_over_budget_fraction": float(np.mean(np.asarray(burst_gaps) > BUDGET_NS))
        if burst_gaps else 0.0,
        "burst_request_period_ms": _ms(_stats(periods)),
        "burst_request_rate_per_s": (len(burst_runs) - 1) / (sum(periods) / 1e9) if periods else 0.0,
        "burst_chunk_rate_per_s": total_chunks / (window / 1e9) if window > 0 else 0.0,
        "raw": {"latency": latency, "burst": burst_runs},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scales", default="both")
    parser.add_argument("--modes", default="chunk0,full,chunked")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--trials", type=int, default=7)
    parser.add_argument("--burst", type=int, default=6)
    parser.add_argument("--candidate", default=str(common.CANDIDATE))
    args = parser.parse_args()

    common.RESULTS.mkdir(parents=True, exist_ok=True)
    scales = list(common.SCALES) if args.scales == "both" else [args.scales]
    modes = [m for m in args.modes.split(",") if m]
    report = {"device": args.device, "modes": modes, "budget_ms": BUDGET_NS / 1e6,
              "candidate": args.candidate, "runs": {}}
    for scale in scales:
        arrays = common.make_arrays(common.make_config(common.make_prefix("bench"), scale),
                                    count=32, seed=7)
        cfg = common.make_config(common.make_prefix(f"bench_ref_{scale}"), scale, args.device)
        measured = measure(common.REFERENCE, cfg, arrays, args.trials, args.burst,
                           f"bench_ref_{scale}")
        measured["scale"] = scale
        measured["backend"] = "reference"
        report["runs"][f"reference_{scale}"] = measured
        print(
            f"{'reference':9s} {scale:5s} cold_first={measured['cold_first_out_ms']:.3f}ms "
            f"first_out_med={measured['first_out_ms'].get('median', 0):.3f}ms "
            f"p95={measured['first_out_ms'].get('p95', 0):.3f}ms "
            f"complete_med={measured['complete_ms'].get('median', 0):.3f}ms "
            f"req/s={measured['burst_request_rate_per_s']:.2f} "
            f"chunks/s={measured['burst_chunk_rate_per_s']:.1f} "
            f"gap_p95={measured['burst_inter_chunk_gap_ms'].get('p95', 0):.3f}ms "
            f"over_budget={measured['burst_over_budget_fraction']:.3f}",
            flush=True,
        )
        for mode in modes:
            tag = f"bench_cand_{scale}_{mode}"
            cand_cfg = common.make_config(common.make_prefix(tag), scale, args.device)
            cand_cfg["mode"] = mode
            cand = measure(common.CANDIDATE, cand_cfg, arrays, args.trials, args.burst, tag)
            cand["scale"] = scale
            cand["backend"] = f"candidate:{mode}"
            report["runs"][f"candidate_{scale}_{mode}"] = cand
            print(
                f"{'cand:' + mode:9s} {scale:5s} cold_first={cand['cold_first_out_ms']:.3f}ms "
                f"first_out_med={cand['first_out_ms'].get('median', 0):.3f}ms "
                f"p95={cand['first_out_ms'].get('p95', 0):.3f}ms "
                f"complete_med={cand['complete_ms'].get('median', 0):.3f}ms "
                f"req/s={cand['burst_request_rate_per_s']:.2f} "
                f"chunks/s={cand['burst_chunk_rate_per_s']:.1f} "
                f"gap_p95={cand['burst_inter_chunk_gap_ms'].get('p95', 0):.3f}ms "
                f"over_budget={cand['burst_over_budget_fraction']:.3f}",
                flush=True,
            )

    deltas = {}
    for scale in scales:
        ref = report["runs"].get(f"reference_{scale}")
        if not ref:
            continue
        for mode in modes:
            cand = report["runs"].get(f"candidate_{scale}_{mode}")
            if not cand:
                continue
            deltas[f"{scale}:{mode}"] = {
                "first_out_ms_speedup": ref["first_out_ms"].get("median", 0)
                / max(cand["first_out_ms"].get("median", 1e-9), 1e-9),
                "complete_ms_speedup": ref["complete_ms"].get("median", 0)
                / max(cand["complete_ms"].get("median", 1e-9), 1e-9),
                "chunk_rate_speedup": cand["burst_chunk_rate_per_s"]
                / max(ref["burst_chunk_rate_per_s"], 1e-9),
            }
    report["deltas"] = deltas
    out = common.RESULTS / f"bench_{args.scales}_{int(time.time())}.json"
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    for key, delta in deltas.items():
        print(key, json.dumps(delta))
    print(f"evidence: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
