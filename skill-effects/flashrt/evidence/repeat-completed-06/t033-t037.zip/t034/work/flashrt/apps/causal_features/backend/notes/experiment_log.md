# causal_features — experiment log

Workspace: `flashrt/apps/causal_features/backend/`.
Hardware: one RTX 5060 8 GB, Windows, PyTorch 2.11.0+cu128.
Task: continuous causal feature processing; fixed weights (seed 703); the
protected CPU full-sequence oracle is the numerical reference.

## IR Conversion (Phase 1–2)

- Worker graph `causal_features_worker`: 3 operators, 2 data edges.
  - Exposed/composite stages: three fused `CausalLayerStep` nodes
    (conv + SiLU per layer), each owning one `chunk_persistent` history.
  - Streaming edges: layer0→layer1, layer1→layer2, fixed rate 1:1.
- Model graph `causal_features_model`: 6 operators, 5 data edges.
  - Operators: `layer{0,1,2}_conv` (`EXPOSED`, streaming) and
    `layer{0,1,2}_silu` (`EXPOSED`, streaming).
  - State objects: `hist_0` (last 4 input samples, kernel 5), `hist_1`
    (last 4, kernel 5), `hist_2` (last 2, kernel 3), all
    `chunk_persistent`; they are exactly the tensors the reference stores in
    `ReferencePipeline.histories`.
  - Chunk-periodic operators: all six, one invocation per input chunk.
- IR validation: **PASS** (executed, not inspected).
  - harness: `tests/test_ir.py`
  - fixture: deterministic `RandomState(1234)` inputs, dev scale
    (`C=16,H=32,T=1043,chunk=127`), six requests: A, B (continuation),
    A again without reset, reset→C, reset→A, D (continuation).
  - reference run: reference backend subprocess driven through
    `causal_features.adapter.FeatureAdapter`; log
    `benchmarks/results/backend_ir_ref.log`.
  - executor output hash:
    `benchmarks/results/ir_validation_dev.json` (`graphs.model.executor_hash`,
    `graphs.worker.executor_hash`).
  - reference output hash: same JSON, `hashes.reference`
    (`507f4831…506c0` at dev scale).
  - tolerance: `atol=3e-5, rtol=3e-4` (documented task tolerance for
    CPU/GPU float32 accumulation-order differences).
  - result: both IR graphs match the reference backend bit-exactly
    (`max_abs_vs_ref = 0.0`) and the CPU oracle at `6.333e-08`.
- Analysis (`benchmarks/results/ir_analysis_dev.txt`):
  - Pipeline stages: model graph 6 singleton stages, worker graph 3
    singleton stages; each `layerI_conv` is grouped only with itself via
    `hist_I`, and the within-chunk data chain orders the stages.
  - Streaming overlaps: 3 (model graph) / 2 (worker graph) fixed-rate 1:1
    conv→activation / layer→layer edges.
  - Critical path: all six operators in sequence (per-op latencies are
    sub-millisecond and recorded in `ir_validation_dev.json`).
  - Key independent pairs: every pair of distinct layers is independent
    across chunks (different history state), e.g. `layer0 || layer1`,
    `layer0 || layer2`, `layer1 || layer2`.
  - Interpretation used for deployment: the stage partition suggests
    layer-level pipeline parallelism, but the assigned machine has one GPU,
    so multi-GPU stages are not applicable. The useful single-GPU levers are
    (a) removing per-chunk host/launch/sync overhead while keeping the three
    state-carrying layers resident, and (b) regrouping contiguous causal
    positions inside a layer, which the IR's 1:1 streaming and per-layer
    independent histories show is legal (no operator reads a future input;
    each layer touches only its own history).

## Variant Queue (final; all rows terminal)

| # | name | hypothesis | IR basis | predicted impact | status |
|---|------|-----------|----------|------------------|--------|
| 0 | `reference_baseline` | protected sequential per-chunk reference is the anchor | per-chunk graph, no regrouping | baseline for every target | measured |
| 1 | `chunk0` | compute+emit chunk 0 alone, then convolve the whole remainder in one segment per layer | per-layer independent 1:1 streaming; causal locality | first-output ↓, completion ↓↓, smoothness unchanged | measured |
| 2 | `full` | convolve the whole request in one segment per layer, then emit all chunks | same causality/locality result, maximal regrouping | completion ↓↓, first-output ↑ (waits for full sequence) | measured |
| 3 | `chunked` | keep per-chunk segments but keep layers GPU-resident and remove reference host round-trips | baseline schedule, implementation-only lever | small completion gain, no regrouping | measured |

Ordering rationale: variants were ranked by expected effect on the two
active targets. `chunk0` was expected to dominate because it attacks both
first-output latency and completion; `full` isolates the maximal-regrouping
effect on completion while exposing its first-output cost; `chunked`
isolates the implementation-only lever from regrouping.

No `blocked` or `discarded` rows exist; every queued variant was launched
end-to-end.

## Deployment iteration records

### reference_baseline (measured)
- Hypothesis: the protected sequential backend defines the anchor.
- Correctness: reference vs CPU oracle PASS, max_abs `6.333e-08` (dev) /
  `3.129e-07` (large), tolerance `atol=3e-5, rtol=3e-4`.
  - correctness evidence: `benchmarks/results/correctness_all.json`.
- dev: first-output median 1.537 ms (p95 1.950), completion 5.862 ms,
  back-to-back 186.0 req/s / 1682.9 chunks/s, burst gap p95 1.237 ms,
  over 20 ms fraction 0.
- large: first-output median 3.059 ms (p95 3.375), completion 28.169 ms,
  39.5 req/s / 1273.2 chunks/s, burst gap p95 1.224 ms, over-budget 0.
- benchmark_json: `benchmarks/results/bench_both_1792436800.json`.

### chunk0 (measured; recommended)
- Hypothesis: emitting chunk 0 before transferring/computing the remainder
  removes the full-sequence wait from first-output latency, while one
  contiguous remainder segment per layer removes per-chunk overhead from
  completion.
- IR analysis basis: each layer owns only its own `chunk_persistent`
  history (`hist_I`), the layer chain is fixed-rate 1:1, and a causal conv
  is position-local, so regrouping contiguous positions cannot change an
  output value.
- Correctness: PASS on dev and large, candidate vs reference `0.0` max abs
  (bit-exact), candidate vs CPU oracle `6.333e-08` / `3.129e-07`, reset
  reproduction `0.0`. Evidence: `benchmarks/results/correctness_all.json`.
- dev: first-output median **0.813 ms** (p95 2.047), completion **1.649 ms**,
  **652.8 req/s / 5800.5 chunks/s**, burst gap p95 0.578 ms, over-budget 0.
- large: first-output median **3.091 ms** (p95 4.098), completion
  **13.236 ms**, **77.2 req/s / 2515.8 chunks/s**, burst gap p95 3.569 ms,
  over-budget 0.
- Δ vs baseline: dev first-output 1.89×, completion 3.56×, chunk rate 3.45×;
  large first-output 0.99× (parity within run noise), completion 2.13×,
  chunk rate 1.98×. No target regressed; smoothness stayed inside the 20 ms
  chunk budget on both scales.
- benchmark_json: `benchmarks/results/bench_both_1792436800.json`.
- Verdict: promote.
- Follow-ups: none queued; the two remaining segmentation orders were
  measured as rows 2–3.

### full (measured)
- Hypothesis: a single segment per layer (3 conv launches per request) is
  the minimum-overhead schedule for total completion time.
- IR analysis basis: same per-layer history independence and causal
  position-locality as `chunk0`.
- Correctness: PASS, candidate vs reference `0.0`, oracle `6.333e-08` /
  `3.129e-07`; `benchmarks/results/correctness_all.json`.
- dev: first-output 1.610 ms, completion 1.667 ms, 457.5 req/s /
  4274.4 chunks/s.
- large: first-output **8.691 ms**, completion **10.774 ms**, 98.0 req/s /
  3162.0 chunks/s.
- Δ vs baseline: large completion 2.61× and chunk rate 2.48×, but
  first-output 0.35× (regression) because the whole sequence is computed
  before the first chunk is published. Because it regresses an active
  target, it is not promoted despite the best large completion time.
- benchmark_json: `benchmarks/results/bench_both_1792436800.json`.
- Verdict: discard (measured trade-off: wins completion, loses first-output).
- Follow-ups: none; `chunk0` is the measured Pareto point that combines the
  regrouping win with chunk-0-first emission.

### chunked (measured)
- Hypothesis: keeping the per-chunk schedule but keeping all three layers
  GPU-resident and avoiding the reference's per-layer host copies is enough
  to improve the baseline without regrouping.
- IR analysis basis: baseline chunk-periodic graph, no state-independence
  transformation; implementation-only lever.
- Correctness: PASS, candidate vs reference `0.0`, oracle `6.333e-08` /
  `3.129e-07`; `benchmarks/results/correctness_all.json`.
- dev: first-output 1.737 ms, completion 13.375 ms, 110.9 req/s /
  1069.3 chunks/s.
- large: first-output 3.530 ms, completion 44.993 ms, 35.5 req/s /
  1168.3 chunks/s.
- Δ vs baseline: no consistent gain; per-chunk D2H synchronisation and
  device round-trips dominate, so this implementation-only lever is weaker
  than regrouping. No target is meaningfully improved.
- benchmark_json: `benchmarks/results/bench_both_1792436800.json`.
- Verdict: discard.
- Follow-ups: none.

## Notes on measurement variance

The machine is shared and Windows timer/consumer polling dominates
sub-millisecond first-output measurements; repeated runs showed reference
large completion between 22.6 and 28.2 ms and candidate `chunk0` between
12.1 and 13.2 ms, i.e. the completion/chunk-rate advantage is stable while
individual first-output medians move by a few hundred microseconds. All
reported numbers come from the persisted JSON above; no estimated values are
recorded.

## Scope statement

This workspace contains the IR conversion/validation, the standalone
optimized worker, three measured segmentation variants, paired benchmarks on
both documented scales, and all evidence files listed above. The general
workflow's floor of ten distinct deployment variants was not reached within
this observation's request/token budget; that remains an unmet applicable
requirement, reported honestly in the final report.
