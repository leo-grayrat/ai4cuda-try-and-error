"""Shared subprocess / adapter harness utilities for causal_features tests.

Every harness launches a backend as a subprocess, drives it through the
supplied ``flashrt.apps.causal_features.adapter.FeatureAdapter`` and always
terminates the process and removes the seven shared-memory objects in a
``finally`` path.
"""

import hashlib
import json
import math
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]
try:  # the shared helper is the documented way to locate the repo root
    from flashrt.paths import repo_root as _repo_root

    REPO = Path(_repo_root())
except Exception:  # pragma: no cover - fallback for standalone execution
    pass

APP = REPO / "flashrt" / "apps" / "causal_features"
BACKEND = APP / "backend"
RESULTS = BACKEND / "benchmarks" / "results"
REFERENCE = APP / "reference.py"
CANDIDATE = BACKEND / "worker.py"

if str(REPO / "flashrt" / "apps") not in sys.path:
    sys.path.insert(0, str(REPO / "flashrt" / "apps"))

from flashrt.apps.causal_features.adapter import FeatureAdapter  # noqa: E402
from flashrt.apps.causal_features.model import full_sequence_oracle  # noqa: E402

SCALES = {
    "dev": dict(channels=16, hidden=32, length=1043, chunk=127),
    "large": dict(channels=128, hidden=256, length=16384, chunk=512),
}


def make_config(prefix, scale="dev", device="cuda:0", **overrides):
    cfg = dict(SCALES[scale])
    cfg.update(weight_seed=703, device=device, prefix=prefix)
    cfg.update(overrides)
    return cfg


def make_prefix(tag):
    return f"cf_{tag}_{os.getpid()}_{int(time.time() * 1000) % 100000}"


def make_arrays(config, count=4, seed=1234):
    rng = np.random.RandomState(seed)
    return [
        rng.randn(config["channels"], config["length"]).astype(np.float32)
        for _ in range(count)
    ]


def num_chunks(config):
    return int(math.ceil(config["length"] / config["chunk"]))


def six_request_scheme():
    """Six complete requests: continuation, repeated input, reset, tail chunk.

    request 0: A (cold start, after adapter start)
    request 1: B (continuation)
    request 2: A again without reset (repeated input, continuation)
    request 3: reset -> C
    request 4: reset -> A (must reproduce request 0)
    request 5: D (continuation after A)
    """
    return [(0, False), (1, False), (0, False), (2, True), (0, True), (3, False)]


def write_config(config):
    directory = tempfile.mkdtemp(prefix="causal_cfg_")
    path = Path(directory) / "config.json"
    path.write_text(json.dumps(config), encoding="utf-8")
    return path


def _shm_names(prefix):
    return [
        prefix + "__ctrl",
        prefix + "_input__meta",
        prefix + "_input__tensor",
        prefix + "_output__meta",
        prefix + "_output__tensor",
        prefix + "_metadata__meta",
        prefix + "_metadata__tensor",
    ]


def cleanup_shm(prefix):
    from multiprocessing import shared_memory

    for name in _shm_names(prefix):
        try:
            shm = shared_memory.SharedMemory(name=name, create=False)
        except Exception:
            continue
        try:
            shm.close()
            shm.unlink()
        except Exception:
            pass


def _child_env():
    env = os.environ.copy()
    here = str(REPO)
    apps = str(REPO / "flashrt" / "apps")
    parts = [p for p in env.get("PYTHONPATH", "").split(os.pathsep) if p]
    for extra in (apps, here):
        if extra not in parts:
            parts.insert(0, extra)
    env["PYTHONPATH"] = os.pathsep.join(parts)
    env["PYTHONUNBUFFERED"] = "1"
    env.setdefault("CUDA_VISIBLE_DEVICES", "0")
    return env


def launch(script, config_path, log_path):
    cleanup_shm(json.loads(Path(config_path).read_text())["prefix"])
    log = open(log_path, "w", encoding="utf-8")
    cmd = [
        sys.executable,
        str(script),
        "--repository",
        str(REPO),
        "--config",
        str(config_path),
    ]
    kwargs = {}
    if os.name == "nt":
        flag = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if flag:
            kwargs["creationflags"] = flag
    else:
        kwargs["preexec_fn"] = os.setsid
    proc = subprocess.Popen(
        cmd,
        cwd=str(REPO),
        env=_child_env(),
        stdout=log,
        stderr=subprocess.STDOUT,
        **kwargs,
    )
    return proc, log


def wait_ready(proc, config, log_path, timeout_s=120):
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            text = Path(log_path).read_text(encoding="utf-8", errors="replace")
            raise RuntimeError(f"backend exited with {proc.returncode}:\n{text}")
        try:
            adapter = FeatureAdapter(config)
        except Exception:
            time.sleep(0.05)
            continue
        adapter.start()
        return adapter
    raise TimeoutError("backend did not become ready")


class BackendSession:
    """Launch one backend, expose the adapter, always clean everything up."""

    def __init__(self, script, config, log_path):
        self.script = Path(script)
        self.config = config
        self.log_path = Path(log_path)
        self.proc = None
        self.log = None
        self.adapter = None

    def __enter__(self):
        RESULTS.mkdir(parents=True, exist_ok=True)
        self.config_path = write_config(self.config)
        self.proc, self.log = launch(self.script, self.config_path, self.log_path)
        try:
            self.adapter = wait_ready(self.proc, self.config, self.log_path)
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return self.adapter

    def __exit__(self, exc_type, exc, tb):
        adapter, proc, log = self.adapter, self.proc, self.log
        if adapter is not None:
            try:
                adapter.terminate()
            except Exception:
                pass
            try:
                adapter.close()
            except Exception:
                pass
        if proc is not None:
            if proc.poll() is None:
                proc.terminate()
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                if os.name != "nt":
                    try:
                        os.killpg(os.getpgid(proc.pid), 9)
                    except Exception:
                        pass
                proc.kill()
                proc.wait()
        if log is not None:
            log.close()
        cleanup_shm(self.config["prefix"])
        return False


def drive(adapter, arrays, scheme, chunks):
    """Run a request scheme; returns per-request chunk arrays and timestamps."""
    runs = []
    for array_index, reset in scheme:
        if reset:
            adapter.reset()
        request_id, submitted_ns = adapter.submit(arrays[array_index])
        chunks_out, observed = [], []
        for _ in range(chunks):
            data, stamp = adapter.receive(timeout_s=120)
            chunks_out.append(np.array(data, dtype=np.float32, copy=True))
            observed.append(int(stamp))
        runs.append(
            {
                "request_id": int(request_id),
                "array": int(array_index),
                "submit_ns": int(submitted_ns),
                "observed_ns": observed,
                "chunks": chunks_out,
            }
        )
    return runs


def run_backend(script, config, arrays, scheme, tag):
    RESULTS.mkdir(parents=True, exist_ok=True)
    log_path = RESULTS / f"backend_{tag}.log"
    with BackendSession(script, config, log_path) as adapter:
        return drive(adapter, arrays, scheme, num_chunks(config))


def split_chunks(sequence, config):
    out = []
    for position in range(0, sequence.shape[-1], config["chunk"]):
        out.append(sequence[:, position:position + config["chunk"]].copy())
    return out


def oracle_requests(config, arrays):
    """CPU full-sequence oracle per session, split back into requests/chunks."""
    sessions = [([0, 1, 0]), ([2]), ([0, 3])]
    mapping = []
    for indices in sessions:
        joined = np.concatenate([arrays[i] for i in indices], axis=-1)
        oracle = full_sequence_oracle(REPO, config, joined)
        offset = 0
        for index in indices:
            length = arrays[index].shape[-1]
            piece = oracle[:, offset:offset + length]
            mapping.append(split_chunks(piece, config))
            offset += length
    return mapping


def compare_chunks(reference_runs, candidate_runs, atol=3e-5, rtol=3e-4):
    diffs = []
    worst = 0.0
    ok = True
    for run_ref, run_cand in zip(reference_runs, candidate_runs):
        per_request = 0.0
        for chunk_ref, chunk_cand in zip(run_ref["chunks"], run_cand["chunks"]):
            diff = float(np.max(np.abs(chunk_ref - chunk_cand)))
            per_request = max(per_request, diff)
            worst = max(worst, diff)
            if not np.allclose(chunk_ref, chunk_cand, atol=atol, rtol=rtol):
                ok = False
        diffs.append(per_request)
    return ok, worst, diffs


def compare_to_oracle(runs, oracle, atol=3e-5, rtol=3e-4):
    worst = 0.0
    ok = True
    for run, expected in zip(runs, oracle):
        for chunk, target in zip(run["chunks"], expected):
            diff = float(np.max(np.abs(chunk - target)))
            worst = max(worst, diff)
            if not np.allclose(chunk, target, atol=atol, rtol=rtol):
                ok = False
    return ok, worst


def digest(runs):
    sha = hashlib.sha256()
    for run in runs:
        for chunk in run["chunks"]:
            sha.update(np.ascontiguousarray(chunk, dtype=np.float32).tobytes())
    return sha.hexdigest()
