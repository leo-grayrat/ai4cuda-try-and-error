"""causal_features optimized backend workspace."""

from . import ir

__all__ = ["ir"]
