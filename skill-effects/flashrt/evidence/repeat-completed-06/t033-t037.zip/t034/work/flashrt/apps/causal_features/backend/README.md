# causal_features — optimized backend (CUDA)

Single-GPU streaming backend for the fixed causal feature stack
(`CausalConv1d(C,H,5) -> SiLU -> CausalConv1d(H,H,5) -> SiLU ->
CausalConv1d(H,C,3) -> SiLU`, weights seeded with `weight_seed=703`).

The recommended entry is `worker.py` (segmentation mode `chunk0`).  It
honors the supplied `flashrt/apps/causal_features/adapter.py` contract
unchanged: it creates the same seven shared-memory objects from the config
`prefix`, speaks control opcodes `1` start / `3` reset / `2` terminate with
the same level + ack semantics, publishes `(channels, chunk)` float32
payloads before int64 `(request, chunk, valid)` metadata, and emits the last
chunk with its true valid length.

## Launch

```bash
python flashrt/apps/causal_features/backend/worker.py \
    --repository <repo-root> \
    --config <config.json>
```

`--repository` is the repository root (it contains `flashrt/layers/audio.py`,
which `causal_features.model.build_layers` parses for the pinned
`CausalConv1d`).  The worker also adds `<repository>/flashrt/apps` to
`sys.path` so `causal_features.adapter` / `causal_features.model` resolve
when it is launched directly.

Example config (the same object the reference takes):

```json
{
  "prefix": "cf_demo",
  "device": "cuda:0",
  "channels": 16,
  "hidden": 32,
  "length": 1043,
  "chunk": 127,
  "weight_seed": 703
}
```

Large documented case: `channels=128, hidden=256, length=16384, chunk=512`.
No downloads or training are involved; weights are re-derived from the fixed
seed exactly as in `causal_features.model.build_layers`.

The unchanged frontend under `flashrt/apps/causal_features/frontend/` can
drive this backend: launch `worker.py` instead of
`python -m causal_features.reference`, then use the adapter as usual.

## What is optimized

* The three layers stay resident on the GPU; there is no per-layer Python
  module construction and no host round-trip per chunk.
* Within a request the causally-convolved time positions are grouped into
  two contiguous segments — chunk 0, then the whole remainder.  A causal
  convolution is position-local, so grouping does not change any output
  value (verified bit-exact against the reference); it removes per-chunk
  launch, `torch.cat`, slice, synchronisation and Python overhead.
* Chunk 0 is computed, copied back and published before the remainder is
  transferred to the GPU, which keeps first-output latency low.
* One D2H copy per segment instead of one per chunk; the host array is then
  sliced into the shared-memory output ring.
* The idle poll loop busy-spins briefly before sleeping, so inputs published
  between polls are seen in microseconds instead of OS-timer quanta.
* TF32 is disabled (`cudnn.allow_tf32=False`) so GPU results stay inside the
  documented `atol=3e-5, rtol=3e-4` tolerance of the CPU oracle.

Optional segmentation modes (config key `mode` or `--mode`) are kept for the
experiment record: `chunk0` (default, recommended), `full` (one segment per
request: best completion time, worst first-output latency), and `chunked`
(one segment per chunk: closest to the reference schedule).

## Evidence and harnesses

* Correctness (both scales, all three modes, six requests including
  continuation, repeated input, reset reproduction and tail chunks):
  `benchmarks/results/correctness_all.json`, produced by
  `python flashrt/apps/causal_features/backend/tests/test_worker.py`.
* IR conversion and Phase-2 execution validation:
  `python flashrt/apps/causal_features/backend/tests/test_ir.py` →
  `benchmarks/results/ir_validation_dev.json`,
  `benchmarks/results/ir_analysis_dev.txt`.
* Paired reference/candidate latency, completion, offered-load and 20 ms
  chunk-gap measurements:
  `python flashrt/apps/causal_features/backend/benchmarks/bench_worker.py`
  → `benchmarks/results/bench_both_*.json`.
* Experiment history and variant queue: `notes/experiment_log.md`.

All harnesses launch backends as subprocesses through the supplied adapter,
terminate them in a `finally` block, and remove the shared-memory objects
afterwards.
