"""Phase-4 deployment correctness harness for the causal_features backend.

Launches the protected reference backend and each candidate segmentation mode
as separate subprocesses, drives them through the supplied adapter over the
same six-request scenario, and compares every output chunk numerically.
Also compares all of them against the CPU full-sequence oracle and checks
that a reset reproduces the first request.  Prints PASS/FAIL per mode.
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import common  # noqa: E402


def evaluate_scale(scale, modes, device):
    ref_cfg = common.make_config(common.make_prefix("ref"), scale, device)
    arrays = common.make_arrays(ref_cfg)
    scheme = common.six_request_scheme()
    print(f"[{scale}] running reference backend ...", flush=True)
    ref_runs = common.run_backend(common.REFERENCE, ref_cfg, arrays, scheme, f"ref_{scale}")
    oracle = common.oracle_requests(ref_cfg, arrays)
    ref_vs_oracle_ok, ref_vs_oracle_worst = common.compare_to_oracle(ref_runs, oracle)

    summaries = {}
    all_ok = ref_vs_oracle_ok
    for mode in modes:
        cand_cfg = common.make_config(common.make_prefix(f"cand_{mode}"), scale, device)
        cand_cfg["mode"] = mode
        print(f"[{scale}] running candidate mode={mode} ...", flush=True)
        cand_runs = common.run_backend(
            common.CANDIDATE, cand_cfg, arrays, scheme, f"cand_{scale}_{mode}"
        )
        cand_vs_ref_ok, cand_vs_ref_worst, per_request = common.compare_chunks(ref_runs, cand_runs)
        cand_vs_oracle_ok, cand_vs_oracle_worst = common.compare_to_oracle(cand_runs, oracle)
        reset_repro = max(
            float(abs(a - b).max())
            for a, b in zip(cand_runs[0]["chunks"], cand_runs[4]["chunks"])
        )
        reset_ok = reset_repro <= 3e-5
        ok = cand_vs_ref_ok and cand_vs_oracle_ok and reset_ok
        all_ok = all_ok and ok
        summary = {
            "scale": scale,
            "mode": mode,
            "device": device,
            "requests": len(cand_runs),
            "chunks_per_request": common.num_chunks(ref_cfg),
            "candidate_vs_reference": {
                "pass": cand_vs_ref_ok,
                "max_abs": cand_vs_ref_worst,
                "per_request_max_abs": per_request,
            },
            "reference_vs_cpu_oracle": {"pass": ref_vs_oracle_ok, "max_abs": ref_vs_oracle_worst},
            "candidate_vs_cpu_oracle": {
                "pass": cand_vs_oracle_ok,
                "max_abs": cand_vs_oracle_worst,
            },
            "reset_reproduction_max_abs": reset_repro,
            "tolerance": {"atol": 3e-5, "rtol": 3e-4},
            "hashes": {
                "reference": common.digest(ref_runs),
                "candidate": common.digest(cand_runs),
            },
            "verdict": "PASS" if ok else "FAIL",
        }
        out = common.RESULTS / f"correctness_{scale}_{mode}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
        summaries[mode] = summary
        print(
            f"[{scale}:{mode}] candidate_vs_reference={cand_vs_ref_worst:.3e} "
            f"candidate_vs_oracle={cand_vs_oracle_worst:.3e} "
            f"reference_vs_oracle={ref_vs_oracle_worst:.3e} "
            f"reset_repro={reset_repro:.3e} -> {summary['verdict']}",
            flush=True,
        )
    return all_ok, summaries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--modes", default="chunk0,full,chunked")
    parser.add_argument("--scales", default="dev,large")
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()

    modes = [m for m in args.modes.split(",") if m]
    scales = [s for s in args.scales.split(",") if s]
    results = {}
    overall = True
    for scale in scales:
        ok, summaries = evaluate_scale(scale, modes, args.device)
        overall = overall and ok
        results[scale] = summaries
    out = common.RESULTS / "correctness_all.json"
    out.write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(f"evidence: {out}")
    print("VERDICT:", "PASS" if overall else "FAIL")
    return 0 if overall else 1


if __name__ == "__main__":
    sys.exit(main())
