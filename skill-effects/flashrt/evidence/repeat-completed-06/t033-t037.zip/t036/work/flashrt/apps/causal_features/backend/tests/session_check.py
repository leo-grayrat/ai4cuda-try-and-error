"""Six-request correctness check: candidate variants vs reference vs CPU oracle.

  python flashrt/apps/causal_features/backend/tests/session_check.py \
      --cases dev,large --variants stream,hybrid,whole,eager

Tolerance atol=3e-5 / rtol=3e-4 as fixed by CONTRACT.zh.md: it admits
CPU-vs-GPU float32 accumulation-order differences only.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

LOG = common.LOGS


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cases', default='dev')
    ap.add_argument('--variants', default='stream,hybrid,whole,eager')
    ap.add_argument('--reference', action='store_true', default=True)
    args = ap.parse_args()
    LOG.mkdir(parents=True, exist_ok=True)
    summary, ok_all = [], True
    for case in args.cases.split(','):
        script = common.build_session(case)
        oracle = common.oracle_session(case, script)
        ref = None
        if args.reference:
            r = common.run_session('reference', case, None, script, f'{case}_ref')
            ref_ok = all(common.compare(c, o)[0] for c, o in zip(r['outs'], oracle))
            print(f'[{case}] reference backend vs CPU oracle: '
                  f'{"PASS" if ref_ok else "FAIL"} '
                  f'({common.compare(r["outs"][0], oracle[0])[1]})')
            summary.append(dict(kind='reference', case=case, ok=ref_ok))
            ref = r['outs']
        for variant in args.variants.split(','):
            r = common.run_session('worker', case, variant, script,
                                   f'{case}_{variant}_cand')
            msgs = [common.compare(c, o) for c, o in zip(r['outs'], oracle)]
            ok = all(m[0] for m in msgs)
            extra = ''
            if ref is not None:
                rm = [common.compare(c, x) for c, x in zip(r['outs'], ref)]
                extra = f' | vs reference {"PASS" if all(m[0] for m in rm) else "FAIL"}'
                ok = ok and all(m[0] for m in rm)
            ok_all &= ok
            print(f'[{case}] {variant:7s} vs CPU oracle: '
                  f'{"PASS" if ok else "FAIL"} {msgs[0][1]}{extra}')
            summary.append(dict(kind=variant, case=case, ok=ok,
                                detail=msgs[0][1]))
    (LOG / 'verdict.json').write_text(json.dumps(summary, indent=1), encoding='utf-8')
    print(f'VERDICT: {"PASS" if ok_all else "FAIL"}')


if __name__ == '__main__':
    main()
