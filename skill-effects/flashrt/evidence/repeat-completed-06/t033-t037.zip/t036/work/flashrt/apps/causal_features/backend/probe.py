import inspect
from flashrt.paths import app_dir
print(inspect.signature(app_dir))
print(app_dir('causal_features'))
