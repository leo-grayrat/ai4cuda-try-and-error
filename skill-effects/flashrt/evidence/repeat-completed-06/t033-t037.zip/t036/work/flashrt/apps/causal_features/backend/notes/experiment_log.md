# causal_features backend — experiment log

Scope: single RTX 5060 8GB laptop GPU, Windows, torch 2.11.0+cu128.
Writable area: `flashrt/apps/causal_features/backend/`. Entry: `backend/worker.py`
(`--repository`, `--config`, optional `--variant`).

## Phase 1/2 — state dependency model (by hand, not executed through flashrt.ir)

Reference (`causal_features/reference.py` + `model.py`) is a 3-layer causal
network: `C->H (k=5) -> H->H (k=5) -> H->C (k=3)`, each layer `SiLU(conv1d)` with
`replicate` left padding. Per chunk and per layer it prepends the last `k-1`
inputs (`self.histories[layer]`) and slices the context off again, so:

* state objects: `hist0 (C,4)`, `hist1 (H,4)`, `hist2 (H,2)`, scope
  `chunk_persistent` — written and read by the same layer, no sharing between
  layers, so the three layers of one chunk form a strict chain and there is no
  cross-chunk independence *within* a layer (each chunk's output depends on the
  previous chunk's tail);
* the only genuine independent axis is *between requests*: a request's output
  depends on the previous request only through the 3 history tails, so the
  chunk sequence of a request can be re-grouped (segments) without touching
  semantics — this is the lever all variants below use;
* `ephemeral` values: the per-chunk buffers; `session_init`: none.

This mapping was derived by reading `reference.py` and `flashrt/layers/audio.py`
(`CausalConv1d.forward`), and it is encoded directly in
`worker.py:CausalEngine._body` (history copy in, conv+SiLU, history copy out).
`SequentialExecutor`/`summarize_graph` were **not** executed on it — see
"Unmet requirements".

## Variant queue (all rows measured or explicitly unmet)

| # | name | hypothesis | status |
|---|------|-----------|--------|
| 1 | `eager` | preallocated device buffers + pinned staging, no CUDA graphs (isolates the graph lever) | measured |
| 2 | `stream` | one CUDA-graph replay per configured chunk (max streaming) | measured |
| 3 | `hybrid` | chunk 0 first, remainder in one replay (default) | measured |
| 4 | `whole` | whole request in one replay | measured |
| 5 | device-resident history instead of host `torch.cat` per chunk | part of 1-4 | measured (inside 1) |
| 6 | pre-capture graphs at startup (removes capture from first request) | part of 2-4 | measured (inside 2-4) |
| 7 | segment-only H2D staging (first output never waits for full input) | part of 2-4 | measured (inside 2-4) |
| 8 | chunk publication pacing to flatten inter-chunk gaps at low offered load | not implemented — unmet |
| 9 | sub-chunk pipelining of the 3 layers (layer L on chunk i+1 while L+1 runs chunk i) | not implemented — unmet |
| 10 | wider batch/aggregate session handling (multiple requests in flight) | not implemented — not legal under the one-in-flight adapter contract |

Rows 8-10 are *not* claimed as results; they are listed so the gap is visible.

## Measured evidence

Correctness (six-request session: continuation, repeat-without-reset, reset
replay, tail chunk), tolerance atol=3e-5 / rtol=3e-4 (CPU-vs-GPU fp32 ordering):

* `tests/logs/verdict.json` + `tests/session_check_all.py` output:
  dev `max_abs=5.96e-08`, large `max_abs=2.31e-07`, `bad=0`, PASS for
  reference and all four variants, vs CPU full-sequence oracle *and* vs the
  reference backend.
* Independent controller: `verify-014` — `candidate_run_passed`, 6/6 requests
  numerical match (5.2e-08 … 8.2e-08), `cleanup_verified: true`.

Benchmarks (my harness `benchmarks/bench.py`, JSON in
`benchmarks/results/all_20261020_031232.json`; dev = C16/H32/T1043/c127,
large = C128/H256/T16384/c512):

| backend | dev first ms (med/p95) | dev chunks/s | large first ms | large chunks/s |
|---|---|---|---|---|
| reference | 1.118 / 134* | 1665 | 2.567 | 1303 |
| `eager` | 2.525 | 1801 | 2.882 | 1637 |
| `stream` | 0.995 / 1.57 | 5078 | 1.982 | 2812 |
| `whole` | 0.997 | 8543 | 7.366 | 3479 |
| `hybrid` (pre-reorder) | 0.992 | 8528 | 3.502 | 3286 |

\* p95 of the first-output sample set is dominated by one ~120-170 ms outlier
that appears for *every* backend including the reference (environmental).

Independent controller paired sweep (`benchmark-015`, dev scale):
reference `highest_tested_passing_rate=100 req/s` (fails the rate gate at 200),
candidate `200 req/s` (rate gate passes at 50/100/200, external queue 0).
First output median 1.03 ms (p95 1.15-1.23) vs reference 1.51-1.58 ms
(p95 1.98-2.29). Output gap median 6 µs vs 0.56 ms.

Known trade-off: at the *lowest* offered load (50 req/s, period 20 ms = the
20 ms budget) the candidate's compressed publication (~1 ms per request) makes
the cross-request gap sit at the budget edge: `over_budget_fraction=0.04`,
p95 gap 19.9 ms, so that one sweep's smoothness gate fails, while the
reference passes it with a 0.56 ms median gap and a 5 ms per-request spread.
At 100 and 200 req/s every gate passes for the candidate.

## Unmet requirements (honest list)

1. `flashrt/ir` was used only as a conceptual notation here: no
   `backend/ir/graph_builder.py` and no executed `SequentialExecutor`
   comparison exists, so Phase-2 IR validation is **not** done. Correctness is
   instead established against the CPU oracle and the reference backend.
2. Only 4 measured deployment variants (rows 1-4); the 10-variant floor, the
   layer-pipelining variant (row 9) and the pacing variant (row 8) are not met.
3. Variants are selected by `--variant` inside one worker rather than separate
   subpackages with their own configs/launch scripts.
4. The smoothness side condition is not fully satisfied at 50 req/s (above).
