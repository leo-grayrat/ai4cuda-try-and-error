"""Shared development harness utilities (subprocess + adapter driven)."""
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

try:
    from flashrt.paths import repo_root as _repo_root, app_dir as _app_dir
    REPO = Path(_repo_root()).resolve()
    APP = Path(_app_dir('causal_features')).resolve()
except Exception:  # pragma: no cover
    REPO = Path(__file__).resolve().parents[5]
    APP = REPO / 'flashrt' / 'apps' / 'causal_features'

WORKER = APP / 'backend' / 'worker.py'
LOGS = APP / 'backend' / 'tests' / 'logs'
RESULTS = APP / 'backend' / 'benchmarks' / 'results'

CASES = {
    'dev': dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703,
                device='cuda:0'),
    'large': dict(channels=128, hidden=256, length=16384, chunk=512,
                  weight_seed=703, device='cuda:0'),
}


def make_config(case, prefix, device='cuda:0'):
    cfg = dict(CASES[case])
    cfg['device'] = device
    cfg['prefix'] = prefix
    cfg['case'] = case
    return cfg


def write_config(cfg, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(cfg), encoding='utf-8')
    return Path(path)


def build_session(case, seed=0):
    """Six requests: continuation, repeat-without-reset, reset replay, new tail."""
    c = CASES[case]
    rng = np.random.default_rng(seed)
    a, b, d = (rng.standard_normal((c['channels'], c['length'])).astype(np.float32)
               for _ in range(3))
    return [('submit', a), ('submit', b), ('submit', a), ('submit', a),
            ('reset', None), ('submit', a), ('submit', d)]


def oracle_session(case, script):
    """CPU full-sequence oracle following the documented session semantics."""
    from causal_features.model import full_sequence_oracle
    c = CASES[case]
    outs, session = [], []
    for kind, feats in script:
        if kind == 'reset':
            session = []
            continue
        session.append(feats)
        joined = np.concatenate(session, axis=-1)
        full = full_sequence_oracle(REPO, c, joined)
        outs.append(full[:, -c['length']:].copy())
    return outs


def _spawn(cmd, cwd):
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = env.get('CUDA_VISIBLE_DEVICES', '0')
    env['PYTHONPATH'] = os.pathsep.join([str(REPO), str(APP.parent)])
    env['PYTHONUNBUFFERED'] = '1'
    return subprocess.Popen(cmd, cwd=str(cwd), env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, bufsize=1)


def stop(proc, log=None):
    out = ''
    try:
        if proc.poll() is None:
            proc.terminate()
        try:
            out, _ = proc.communicate(timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            out, _ = proc.communicate(timeout=20)
    except Exception:
        try:
            out = proc.stdout.read() if proc.stdout else ''
        except Exception:
            out = ''
    if log is not None and out:
        Path(log).write_text(out, encoding='utf-8')
    return out or ''


def n_chunks(cfg):
    return math.ceil(cfg['length'] / cfg['chunk'])


def attach(cfg, timeout_s=180.0):
    from causal_features.adapter import FeatureAdapter
    t0 = time.time()
    last = None
    while time.time() - t0 < timeout_s:
        try:
            return FeatureAdapter(cfg)
        except Exception as exc:
            last = exc
            time.sleep(0.02)
    raise TimeoutError(f'adapter attach failed: {last}')


def drive(adapter, cfg, requests):
    out = []
    for req in requests:
        if req[0] == 'reset':
            adapter.reset()
            out.append(None)
            continue
        _, feats = req
        _, t_pub = adapter.submit(feats)
        chunks, times = [], []
        for _ in range(n_chunks(cfg)):
            data, t_obs = adapter.receive(timeout_s=120)
            chunks.append(data.copy())
            times.append(t_obs)
        out.append((chunks, times, t_pub))
    return out


def run_session(kind, case, variant, script, tag):
    """Launch one backend, drive the script through the adapter, clean up."""
    cfg = make_config(case, f'cf_{tag}')
    cfg_path = write_config(cfg, LOGS / f'cfg_{tag}.json')
    LOGS.mkdir(parents=True, exist_ok=True)
    log = LOGS / f'{tag}.log'
    if kind == 'reference':
        cmd = [sys.executable, '-m', 'causal_features.reference',
               '--repository', str(REPO), '--config', str(cfg_path)]
    else:
        cmd = [sys.executable, str(WORKER), '--repository', str(REPO),
               '--config', str(cfg_path), '--variant', variant]
    proc = _spawn(cmd, REPO)
    adapter = None
    try:
        adapter = attach(cfg)
        adapter.start()
        res = drive(adapter, cfg, script)
        try:
            adapter.terminate()
        except Exception:
            pass
    finally:
        text = stop(proc, log)
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
    outs = [np.concatenate(r[0], axis=-1) for r in res if r is not None]
    return dict(outs=outs, res=res, cfg=cfg, log=str(log), stdout=text)


def compare(a, b, atol=3e-5, rtol=3e-4):
    if a.shape != b.shape:
        return False, f'shape {a.shape} != {b.shape}'
    diff = np.abs(a.astype(np.float64) - b.astype(np.float64))
    tol = atol + rtol * np.abs(b.astype(np.float64))
    bad = int((diff > tol).sum())
    return bad == 0, (f'max_abs={diff.max():.3e} bad={bad}/{a.size}')
