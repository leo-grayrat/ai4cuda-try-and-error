"""Paired benchmark: reference vs candidate segment plans, both config cases.

Measures, per backend:
  * latency to first output (t_first_chunk_observed - t_submit) over N requests,
    median / p95 (first request of each session flagged as cold);
  * finite offered-load sweep: request periods 0/0.5/1/2/5/10 ms, 24 requests
    each with 4 rotating inputs, reporting achieved chunk rate, per-chunk gap
    median/p95/max and the fraction of gaps above the 20 ms chunk-gap budget.
"""
import json
import statistics
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
import common  # noqa: E402

PERIODS = [0.0, 0.0005, 0.001, 0.002, 0.005, 0.010]
BUDGET_S = 0.020
N_LATENCY = 8
N_PER_RATE = 24


def pct(vals, q):
    if not vals:
        return float('nan')
    s = sorted(vals)
    k = min(len(s) - 1, max(0, int(round(q * (len(s) - 1)))))
    return s[k]


def bench_one(kind, case, variant, tag):
    cfg = common.make_config(case, f'cf_bench_{tag}')
    cfg_path = common.write_config(cfg, common.LOGS / f'cfg_bench_{tag}.json')
    common.LOGS.mkdir(parents=True, exist_ok=True)
    log = common.LOGS / f'bench_{tag}.log'
    if kind == 'reference':
        cmd = [sys.executable, '-m', 'causal_features.reference',
               '--repository', str(common.REPO), '--config', str(cfg_path)]
    else:
        cmd = [sys.executable, str(common.WORKER), '--repository',
               str(common.REPO), '--config', str(cfg_path), '--variant', variant]
    rng = np.random.default_rng(1234)
    inputs = [rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32)
              for _ in range(4)]
    nch = common.n_chunks(cfg)
    proc = common._spawn(cmd, common.REPO)
    adapter = None
    result = dict(kind=kind, case=case, variant=variant, cfg=cfg,
                  n_chunks=nch, chunk=cfg['chunk'])
    try:
        adapter = common.attach(cfg)
        adapter.start()
        firsts, drain = [], []
        for i in range(N_LATENCY):
            _, t_pub = adapter.submit(inputs[i % 4])
            data, t_obs = adapter.receive(timeout_s=120)
            firsts.append((t_obs - t_pub) / 1e6)
            for _ in range(nch - 1):
                adapter.receive(timeout_s=120)
            drain.append((time.perf_counter_ns() - t_pub) / 1e6)
        adapter.reset()
        result['first_out_ms'] = dict(
            median=statistics.median(firsts), p95=pct(firsts, 0.95),
            cold=firsts[0], samples=[round(v, 3) for v in firsts])
        result['request_cycle_ms'] = dict(
            median=statistics.median(drain), p95=pct(drain, 0.95))
        sweep = []
        for period in PERIODS:
            gaps, chunks, t_start = [], 0, None
            for i in range(N_PER_RATE):
                target = None if t_start is None else t_start + i * period * 1e9
                if target is not None:
                    while time.perf_counter_ns() < target:
                        pass
                _, t_pub = adapter.submit(inputs[i % 4])
                if t_start is None:
                    t_start = t_pub
                prev = None
                for _ in range(nch):
                    data, t_obs = adapter.receive(timeout_s=120)
                    if prev is not None:
                        gaps.append((t_obs - prev) / 1e6)
                    prev = t_obs
                    chunks += 1
            wall = (time.perf_counter_ns() - t_start) / 1e9
            sweep.append(dict(
                offered_rps=(1.0 / period if period else None),
                achieved_chunk_rate=chunks / wall,
                achieved_rps=N_PER_RATE / wall,
                gap_median_ms=statistics.median(gaps),
                gap_p95_ms=pct(gaps, 0.95), gap_max_ms=max(gaps),
                over_budget=sum(1 for g in gaps if g / 1000.0 > BUDGET_S) / len(gaps)))
            print(f'  {case}/{tag} period={period*1e3:.1f}ms '
                  f'-> {sweep[-1]["achieved_chunk_rate"]:.0f} chunks/s '
                  f'gap_med={sweep[-1]["gap_median_ms"]:.3f}ms '
                  f'gap_p95={sweep[-1]["gap_p95_ms"]:.3f}ms', flush=True)
            adapter.reset()
        result['sweep'] = sweep
    finally:
        if adapter is not None:
            try:
                adapter.terminate()
            except Exception:
                pass
        text = common.stop(proc, log)
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
        result['exit_log_tail'] = text[-400:]
    return result


def main():
    common.RESULTS.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d_%H%M%S')
    all_results = []
    for case in ('dev', 'large'):
        for kind, variant in [('reference', None), ('worker', 'stream'),
                              ('worker', 'hybrid'), ('worker', 'whole'),
                              ('worker', 'eager')]:
            tag = f'{case}_{kind if variant is None else variant}'
            t0 = time.time()
            r = bench_one(kind, case, variant, tag)
            r['wall_s'] = round(time.time() - t0, 2)
            all_results.append(r)
            fo = r['first_out_ms']
            print(f'{case}/{tag}: first={fo["median"]:.3f}ms '
                  f'p95={fo["p95"]:.3f}ms cycle={r["request_cycle_ms"]["median"]:.3f}ms '
                  f'best_rate={max(s["achieved_chunk_rate"] for s in r["sweep"]):.0f} '
                  f'chunks/s gapmax={max(s["gap_max_ms"] for s in r["sweep"]):.3f}ms',
                  flush=True)
            (common.RESULTS / f'{tag}_{stamp}.json').write_text(
                json.dumps(r, indent=1), encoding='utf-8')
    (common.RESULTS / f'all_{stamp}.json').write_text(
        json.dumps(all_results, indent=1), encoding='utf-8')
    print(f'wrote {common.RESULTS}/all_{stamp}.json')


if __name__ == '__main__':
    main()
