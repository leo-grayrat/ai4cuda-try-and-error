"""In-process numeric diagnosis of CausalEngine vs the reference pipeline."""
import sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

REPO = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / 'flashrt' / 'apps'))
from causal_features.model import build_layers, ReferencePipeline
from causal_features.backend.worker import CausalEngine

cfg = dict(channels=16, hidden=32, length=103, chunk=32, weight_seed=703, device='cuda:0')
rng = np.random.default_rng(0)
a = rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32)
b = rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32)


class Stub:
    """Mimics the two adapter buffers; records (kind, payload) chronologically."""

    def __init__(self):
        self.log = []

    def __getitem__(self, k):
        return self

    def write(self, x):
        x = np.array(x, copy=True)
        self.log.append(('meta' if x.shape[-1] == 3 else 'data', x))
        return len(self.log)

    def outputs(self):
        out, pend = [], None
        for kind, x in self.log:
            if kind == 'data':
                pend = x
            else:
                out.append(pend[:, :int(x[2])].copy())
        return out


def run_variant(variant):
    layers = build_layers(REPO, cfg, cfg['device'])
    eng = CausalEngine(torch, F, layers, cfg, variant)
    st = Stub()
    outs = []
    for i, feats in enumerate([a, b]):
        st.log.clear()
        eng.process(feats[None], i, st)
        outs.append(np.concatenate(st.outputs(), axis=-1))
    return outs


ref = ReferencePipeline(REPO, cfg)
ref_outs = []
for feats in [a, b]:
    o = [ref.step(feats[:, p:p + cfg['chunk']]) for p in range(0, cfg['length'], cfg['chunk'])]
    ref_outs.append(np.concatenate(o, axis=-1))

for variant in ['eager', 'stream', 'hybrid', 'whole']:
    outs = run_variant(variant)
    for i, o in enumerate(outs):
        d = np.abs(o - ref_outs[i])
        print(f'{variant:7s} req{i}: shape={o.shape} max_abs={d.max():.3e} mean={d.mean():.3e}')
