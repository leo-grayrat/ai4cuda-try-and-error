"""Run the six-request correctness check on both config cases."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.argv[1:] = ['--cases', 'dev,large']
import session_check  # noqa: E402

session_check.main()
