# causal_features backend (cuda, single GPU)

Entry point: `worker.py` — accepts `--repository <repo root>` and
`--config <json>` (same contract as `causal_features.reference`), optional
`--variant hybrid|stream|whole|eager` (default `hybrid`, also readable from
`config["variant"]`). It creates the seven shared-memory objects the fixed
adapter expects, honors control opcodes 1/3/2, publishes payload before
metadata, and unlinks the objects on exit.

Launch against the unchanged frontend, from the repo root:

    python flashrt/apps/causal_features/backend/worker.py \
        --repository <repo root> --config <app config json>

The frontend then drives it through `causal_features.adapter.FeatureAdapter`
exactly as it drives the reference backend.

Checks (run from the repo root, no args needed):

    python flashrt/apps/causal_features/backend/tests/session_check_all.py   # six-request, both cases
    python flashrt/apps/causal_features/backend/benchmarks/bench.py         # offered-load sweep

Correctness tolerance: atol=3e-5, rtol=3e-4 (CONTRACT.zh.md). Evidence and the
variant table live in `notes/experiment_log.md`, benchmark JSON in
`benchmarks/results/`, harness output in `tests/logs/`.
