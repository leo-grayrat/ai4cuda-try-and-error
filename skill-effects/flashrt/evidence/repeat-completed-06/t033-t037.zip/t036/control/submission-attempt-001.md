## 最终报告（causal_features，单卡 RTX 5060 8GB / Windows / torch 2.11.0+cu128）

### 结论摘要
提交的后端入口为 `flashrt/apps/causal_features/backend/worker.py`（接受 `--repository`、`--config`，可选 `--variant`，默认 `hybrid`），严格遵守 `causal_features/adapter.py` 的七个共享内存对象、控制码 1/3/2、先数据后元数据的发布顺序，以及退出时 unlink 的约定，控制循环语义与 `reference.py` 逐行对齐（含 `last_command` 电平判定与 `commit()` 应答）。独立控制器验证通过，成对负载扫描在首块延迟与通过的提供速率上优于参考，但在最低提供负载点的平滑度侧条件出现过预算缺口。

### 假设与 IR 依据（用原始 IR 工具表达状态依赖）
参考实现是三层因果网络（C→H k=5 → H→H k=5 → H→C k=3，每层 `SiLU(conv1d)` + `replicate` 左填充）。逐块处理时每层把最近 k−1 个输入存进 `self.histories[layer]` 并在输出上切掉同样长度。据此我判定：三个状态对象 `hist0(C,4)/hist1(H,4)/hist2(H,2)` 的作用域是 `chunk_persistent`，但每层只读写自己的历史，层间无共享状态；同一层跨块严格串行（第 i 块依赖第 i−1 块的尾样本），所以不存在“块内三层并行”或“同层跨块独立”的合法切分；真正可重组的自由度只在**同一请求内部的段划分**——输出只通过三条历史尾巴依赖上一请求，因此把 9 个块合成 1~2 个固定形状的段不改变任何数据依赖，也不访问未来输入（因果卷积只需左侧上下文）。这份依赖映射直接编码在 `CausalEngine._body` 中：拷入历史 → 复制填充 + conv1d → SiLU → 写入下一层窗口 → 更新历史；并且把状态留在显存，替掉参考里每块 `torch.cat` + `[: , :, -pad:].clone()` 的分配与拷贝。

**但必须如实说明：`flashrt/ir` 只被当作概念记号使用，`backend/ir/` 下没有 `graph_builder.py`，`SequentialExecutor` 从未被实例化执行并与参考比对，因此 Phase‑2 的“IR 执行级验证”这一条未完成。** 正确性改由 CPU 整段 oracle 与参考后端两条独立对照建立（见下）。

### 优化实现要点
1. 权重完全来自原 `causal_features.model.build_layers`（上游 `CausalConv1d`，种子 703），数值一致性是继承来的，不重写卷积语义。
2. 每层历史（k−1）常驻显存；每段一次 CUDA Graph 重放，图体固定形状，启动时 `prewarm()` 预捕获（`cold`/`steady` × 段长），因此首请求不含捕获开销。
3. 只把“即将运行的那一段”从共享内存经 pinned 暂存做 H2D，首块输出不再等待整条输入；D2H 用两个 pinned 缓冲 + CUDA event 双缓冲。
4. 段完成即发布，再准备下一段（这条顺序修正把大案例首块延迟从 3.5 ms 拉回到与纯流式同档）。
5. 段划分只改变调度：`stream`（每块一段）、`hybrid`（第 0 块一段 + 其余一段，默认）、`whole`（整条一段）、`eager`（同 stream 但不用图，用于隔离图这一杠杆）。

### 证据（全部为真实端到端运行）
- 独立验证（控制器工具，提交前最后一次代码改动后执行）：`verify-014` → `candidate_run_passed`，6/6 请求 `numerical_match`，最大绝对差 5.2e‑08…8.2e‑08，`cleanup_verified: true`（六请求含连续会话、未重置重复输入、重置复现与末尾短块）。
- 本地六请求对照（`tests/session_check_all.py`，`tests/logs/verdict.json`）：dev 案例 `max_abs=5.96e-08`、large 案例 `max_abs=2.31e-07`，`bad=0`，参考后端与四个变体对 CPU 整段 oracle 及对参考后端全部 PASS，容差 atol=3e‑5/rtol=3e‑4（只允许 CPU/GPU fp32 累加顺序差异）。
- 独立成对负载扫描（`benchmark-015`，dev 规模，50/100/200 req/s）：候选 `highest_tested_passing_rate=200`，三个负载点 rate gate 全过、外部排队 0；参考 `100`（200 req/s 时排队 32 个请求、rate gate 失败）。首块延迟中位 1.03 ms（p95 1.15–1.23）对参考 1.51–1.58 ms（p95 1.98–2.29）；输出间隔中位 6 µs 对 0.56 ms。
- 自建扫描（`benchmarks/results/all_20261020_031232.json`）：dev 参考 1665 chunks/s、首块 1.118 ms；`hybrid` 8528 chunks/s、0.992 ms；large 参考 1303 chunks/s、2.567 ms；`stream` 2812 chunks/s、1.982 ms；`whole` 3479 chunks/s 但首块 7.366 ms。每次运行后进程均被 terminate/wait，共享内存随机前缀清理，无孤儿进程。

### 失败与权衡（不掩饰）
1. **平滑度侧条件在最低提供负载点未达标**：50 req/s 时提供周期正好等于 20 ms 预算，候选把一个请求的 9 块压缩在约 1 ms 内发布，使“跨请求”间隙贴到预算边缘，`over_budget_fraction=0.04`、p95 间隙 19.9 ms，该点 smoothness gate 失败；参考因每请求摊开约 5 ms 而在该点通过。100/200 req/s 下候选全部 gate 通过。这是“更低首块延迟/更高吞吐”与“低负载下间隙分布”之间的真实权衡，我没有把它写成已解决。
2. `whole` 在大案例首块 7.366 ms 明显差于参考 2.567 ms（整条算完才出首块），因此未作为推荐；`eager` 首块与速率都差（图这一杠杆的对照）。
3. 首块 p95 在自建扫描中出现约 120–170 ms 的离群点，**参考后端与所有候选同时出现**，判断为环境噪声，但我无法在本观测预算内进一步定位。
4. 未完成项：IR 图构建与执行级验证缺失（见上）；只有 4 个实测变体，未达 10 变体下限，且未实现“层间跨块流水（层 L 处理块 i+1、层 L+1 处理块 i）”与“块发布节流”这两个已列出的想法；变体以 `--variant` 选择而非各自独立子包 + 配置 + 启动脚本；`backend/ir/` 目录不存在。这些都写在 `notes/experiment_log.md` 的 “Unmet requirements” 中，未以任何“后续会话”式措辞掩盖。

### 对 Phase‑4 强制性条款的逐条自检
- **“Implementation and debugging cost are never valid rationale …”**：本次会话满足该条——四项变体（`eager`/`stream`/`hybrid`/`whole`）都各自端到端跑过并有正确性判定 + 基准 JSON（`benchmarks/results/all_20261020_031232.json`、`tests/logs/verdict.json`、`verify-014`、`benchmark-015`）；未测量的想法在 `notes/experiment_log.md` 的队列行 8–10 明确标为 unmet，而不是以成本为由降级。
- **“Read-only areas are not a blocker — vendor the file …”**：本次会话满足该条——未修改 `reference/`、`adapter.py`、`model.py`、`flashrt/ir/`、`flashrt/*`；全部新增代码仅在 `flashrt/apps/causal_features/backend/`（`worker.py`、`tests/`、`benchmarks/`、`notes/`、`README.md`），无需 vendor。
- **“Terminal statuses”**：本次会话**违反**该条——队列行 8–10 仍是未测量/未完成状态（`notes/experiment_log.md` 的 “Unmet requirements”），因此在严格意义上本会话未达到 done 检查表；我按要求如实上报，而不是伪造完成。
- **“What `blocked` means (strict)”**：本次会话满足该条——没有把任何变体标为 `blocked`，未发生硬件/权重/第三方库类不可解环境故障。
- **“Forbidden session-handoff language”**：本次会话满足该条——`notes/experiment_log.md`、`README.md` 与本报告均未出现“下次会话/后续会话/留给后续”等表述（用词为“未完成/unmet”并指向具体产物）。
- **“Adversarial self-framing (required)”**：本次会话满足该条——没有 `blocked`/`discarded` 队列行，故无需该段；唯一未完成项以 `notes/experiment_log.md` 的行号与 `backend/` 内实际缺失项（无 `ir/`、行 8–10）作为具体指针，而非泛泛理由。

**一句话总结**：在固定权重、同一硬件、同一适配器契约下，提交的后端在六请求正确性上通过独立验证（最大差 ~8e‑08），在成对负载扫描中把最高通过提供速率从 100 提到 200 req/s 并把首块延迟中位从 ~1.55 ms 降到 ~1.03 ms；但 50 req/s 点的间隙平滑度侧条件失败（4% 间隙超 20 ms 预算），且 IR 执行级验证与 10 变体下限未完成。