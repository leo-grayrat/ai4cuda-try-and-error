"""Optimized causal-feature backend worker (single CUDA GPU).

Honors the adapter contract in ``causal_features/adapter.py`` and the reference
control/session semantics in ``causal_features/reference.py`` exactly.

Design (see notes/experiment_log.md):

* Weights come from the *original* ``causal_features.model.build_layers``
  (upstream ``CausalConv1d``, seed 703), so numerical parity is inherited.
* Per-layer causal context (kernel-1 samples) lives in device buffers, i.e.
  the same state semantics as the reference's ``self.histories``, kept on GPU.
* A request is processed as a list of *segments* of fixed length; each segment
  is one captured CUDA-graph replay whose body is: prepend per-layer history
  -> replicate pad + conv1d -> SiLU -> write into the next layer window ->
  update history.  Segment lengths are a pure scheduling choice and all
  arithmetic stays causal:
    - ``hybrid`` (default): chunk 0 first (fast first output), remainder in
      one pass,
    - ``stream``: one segment per configured chunk (maximum streaming),
    - ``whole`` : the whole request in a single segment.
* Only the segment about to run is staged host->device, and each finished
  segment is published before the next one is staged, so the first output
  never waits for the rest of the request; device->host uses pinned staging
  plus CUDA events (double buffered).
"""
import argparse
import json
import sys
import time
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--variant', default=None,
                        help='segment plan: hybrid | stream | whole | eager')
    return parser.parse_args()


class CausalEngine:
    """Segmented causal conv engine with per-layer history state on device."""

    def __init__(self, torch, F, layers, config, variant):
        self.torch = torch
        self.F = F
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        self.length = int(config['length'])
        self.chunk = int(config['chunk'])
        self.device = torch.device(config['device'])
        self.variant = variant
        self.use_graph = variant != 'eager'
        self.weights = [l.conv.weight.detach() for l in layers]
        self.biases = [l.conv.bias.detach() for l in layers]
        self.hist_len = [int(l._time_causal_padding[0]) for l in layers]
        if self.chunk <= max(self.hist_len):
            raise RuntimeError('chunk must exceed the causal context length')
        self.layer_channels = [self.channels, self.hidden, self.hidden]
        self.hist = [torch.zeros(1, self.layer_channels[i], self.hist_len[i],
                                 device=self.device) for i in range(3)]
        self.segs = self._plan(variant)
        self.max_seg = max(self.segs)
        self._ctx = {}
        self._graphs = {}
        self.cold = True
        self.pin_in = torch.empty(self.channels, self.max_seg,
                                  dtype=torch.float32, pin_memory=True)
        self._pin_in_np = self.pin_in.numpy()
        self.seg_pin = [torch.empty(self.channels, self.max_seg,
                                    dtype=torch.float32, pin_memory=True)
                        for _ in range(2)]
        self._pin_np = [p.numpy() for p in self.seg_pin]
        self.events = [torch.cuda.Event() for _ in range(2)]
        self.scratch = torch.zeros(self.channels, self.chunk,
                                   dtype=torch.float32,
                                   pin_memory=True).numpy()
        self._meta = torch.zeros(3, dtype=torch.int64).numpy()

    def _plan(self, variant):
        n_full, tail = divmod(self.length, self.chunk)
        base = [self.chunk] * n_full + ([tail] if tail else [])
        if variant in ('stream', 'eager'):
            return base
        if variant == 'hybrid':
            return base if len(base) == 1 else [self.chunk, self.length - self.chunk]
        if variant == 'whole':
            return [self.length]
        raise ValueError(f'unknown variant: {variant}')

    def _ctx_for(self, v):
        ctx = self._ctx.get(v)
        if ctx is None:
            torch = self.torch
            ctx = {
                'v': v,
                'xin': torch.empty(1, self.channels, v, device=self.device),
                'w': [torch.empty(1, self.layer_channels[i],
                                  self.hist_len[i] + v, device=self.device)
                      for i in range(3)],
                'out': torch.empty(1, self.channels, v, device=self.device),
            }
            self._ctx[v] = ctx
        return ctx

    def _conv(self, x, layer):
        h = self.hist_len[layer]
        if h:
            x = self.F.pad(x, (h, 0), mode='replicate')
        return self.F.conv1d(x, self.weights[layer], self.biases[layer])

    def _body(self, ctx, cold):
        F = self.F
        x = ctx['xin']
        v = ctx['v']
        for layer in range(3):
            h = self.hist_len[layer]
            if cold:
                y = F.silu(self._conv(x, layer))
            else:
                w = ctx['w'][layer]
                if h:
                    w[:, :, :h].copy_(self.hist[layer])
                w[:, :, h:].copy_(x)
                y = F.silu(self._conv(w, layer)[:, :, h:])
            if h:
                self.hist[layer].copy_(x[:, :, v - h:])
            if layer < 2:
                x = y
            else:
                ctx['out'].copy_(y)

    def prewarm(self):
        """Capture every (segment length, cold/steady) graph before serving."""
        for v in self.segs:
            for cold in (True, False):
                self._get(v, cold)

    def _get(self, v, cold):
        ctx = self._ctx_for(v)
        if not self.use_graph:
            return ctx, None
        key = (v, cold)
        graph = self._graphs.get(key)
        if graph is None:
            graph = self._capture(ctx, cold)
            self._graphs[key] = graph
        return ctx, graph

    def _capture(self, ctx, cold):
        torch = self.torch
        backup = [h.clone() for h in self.hist]
        graph = None
        try:
            side = torch.cuda.Stream()
            side.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(side):
                with torch.inference_mode():
                    for _ in range(2):
                        self._body(ctx, cold)
            torch.cuda.current_stream().wait_stream(side)
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                with torch.inference_mode():
                    self._body(ctx, cold)
            torch.cuda.current_stream().synchronize()
        except Exception as exc:  # pragma: no cover - defensive fallback
            print(json.dumps({'graph_capture_failed': str(exc)}), flush=True)
            graph = None
        finally:
            torch.cuda.current_stream().synchronize()
            for h, b in zip(self.hist, backup):
                h.copy_(b)
            torch.cuda.current_stream().synchronize()
        return graph

    def reset(self):
        self.cold = True

    def _stage(self, features, ctx, pos, v):
        self._pin_in_np[:, :v] = features[0][:, pos:pos + v]
        ctx['xin'][:, :, :v].copy_(self.pin_in[:, :v], non_blocking=True)

    def process(self, features, request_id, buffers):
        torch = self.torch
        pos = 0
        pending = None
        for si, v in enumerate(self.segs):
            if pending is not None:
                # publish the finished segment before staging the next one
                self._publish(pending, buffers, request_id)
            cold = self.cold and si == 0
            ctx, graph = self._get(v, cold)
            self._stage(features, ctx, pos, v)
            if graph is not None:
                graph.replay()
            else:
                with torch.inference_mode():
                    self._body(ctx, cold)
            slot = si & 1
            self.seg_pin[slot][:, :v].copy_(ctx['out'][0], non_blocking=True)
            self.events[slot].record()
            pending = (slot, v, pos)
            pos += v
        self._publish(pending, buffers, request_id)
        self.cold = False

    def _publish(self, pending, buffers, request_id):
        slot, v, pos = pending
        self.events[slot].synchronize()
        arr = self._pin_np[slot]
        meta = self._meta
        write = buffers['output'].write
        write_meta = buffers['metadata'].write
        chunk = self.chunk
        index = pos // chunk
        off = 0
        while off < v:
            valid = min(chunk, v - off)
            if valid == chunk:
                write(arr[:, off:off + valid])
            else:
                self.scratch[:, :valid] = arr[:, off:off + valid]
                write(self.scratch)
            meta[0] = request_id
            meta[1] = index
            meta[2] = valid
            write_meta(meta)
            index += 1
            off += valid


def main():
    args = parse_args()
    sys.path.insert(0, str(args.repository.resolve()))
    from flashrt.paths import app_dir
    sys.path.insert(0, str(Path(app_dir('causal_features')).parent))
    import torch
    import torch.nn.functional as F
    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    variant = args.variant or config.get('variant', 'hybrid')
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    layers = build_layers(args.repository, config, config['device'])
    engine = CausalEngine(torch, F, layers, config, variant)
    engine.prewarm()
    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({'ready': True, 'device': config['device'],
                          'variant': variant}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.00002)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0.00002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            engine.process(features, request_id, buffers)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
