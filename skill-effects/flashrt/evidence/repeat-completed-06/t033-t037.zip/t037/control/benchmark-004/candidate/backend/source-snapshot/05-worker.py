"""Optimized standalone backend for the causal_features application.

Reference behaviour (see causal_features.reference): for every output chunk the
reference re-launches pad -> cat -> conv -> slice -> SiLU for each of the three
CausalConv1d layers.  With the default C=16/H=32/T=1043/chunk=127 case that is
~9 chunks * 3 layers * ~5 kernels of tiny work, i.e. the request is dominated by
kernel-launch and Python loop overhead, not arithmetic.

A causal Conv1d is shift-equivariant.  If the last (K-1) frames of each layer's
*input* are carried across requests as the only chunk-persistent state, then
evaluating a whole request as one contiguous causal convolution produces exactly
the same numbers as evaluating it chunk by chunk (the reference's extra
replicate-padded positions are sliced away before the SiLU).  So we keep the
same per-layer history semantics but collapse the per-chunk launch storm into
three convolutions per request, then publish the precomputed result chunk by
chunk through the unchanged shared-memory protocol.

Nothing here reads future input and no history is dropped at a chunk boundary:
the three independent per-layer histories are the only cross-chunk state, as
expressed and validated with flashrt.ir in ir_state_graph.py.
"""

import argparse
import json
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))

    import numpy as np
    import torch
    import torch.nn.functional as F
    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    layers = build_layers(args.repository, config, config['device'])
    device = layers[0].conv.weight.device
    weights = [layer.conv.weight for layer in layers]
    biases = [layer.conv.bias for layer in layers]
    pads = [int(layer._time_causal_padding[0]) for layer in layers]

    channels = int(config['channels'])
    length = int(config['length'])
    chunk = int(config['chunk'])

    # Per-layer input history (K-1 frames).  This is the only session state and
    # it is exactly what the reference keeps in ReferencePipeline.histories.
    histories = [None] * len(layers)

    def reset_state():
        for index in range(len(histories)):
            histories[index] = None

    @torch.inference_mode()
    def process(features):
        # features: (channels, length) float32, one complete request.
        value = torch.from_numpy(features).to(device).unsqueeze(0)
        for index, weight in enumerate(weights):
            pad = pads[index]
            history = histories[index]
            if history is None:
                # Session start: reproduce the reference's replicate boundary by
                # padding the first frame and convolving once.
                joined = F.pad(value, (pad, 0), mode='replicate')
                result = F.conv1d(joined, weight, biases[index])
            else:
                # Continue the causal stream: the real history replaces the
                # replicate padding, so a plain valid convolution is exact.
                joined = torch.cat([history, value], dim=-1)
                result = F.conv1d(joined, weight, biases[index])
            # History is the last (K-1) frames of this layer's unpadded input;
            # padding only prepends, so the tail of `joined` is the tail of
            # `value`.
            histories[index] = joined[..., -pad:].clone()
            value = F.silu(result)
        return value[0].to('cpu').numpy()

    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({'ready': True, 'device': str(device)}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    reset_state()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor

            output = process(features[0])  # (channels, length)

            frame = np.zeros((channels, chunk), dtype=np.float32)
            for index, position in enumerate(range(0, length, chunk)):
                valid = min(chunk, length - position)
                frame[:, :valid] = output[:, position:position + valid]
                if valid < chunk:
                    frame[:, valid:] = 0.0
                # Publish payload first, then metadata, exactly as the adapter
                # protocol requires.
                buffers['output'].write(frame)
                buffers['metadata'].write(
                    np.array([request_id, index, valid], dtype=np.int64))
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
