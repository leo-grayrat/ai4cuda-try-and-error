"""Supplemental numeric check for both contract cases (dev and large).

Compares, on the deployment GPU, the worker's whole-request-with-history
computation ("batch") against a chunk-by-chunk emulation of the reference backend
("chunked") for a continuation of three requests, then after an explicit reset
re-checks reproducibility against the CPU full-sequence oracle.  This covers the
larger C=128/H=256/T=16384/chunk=512 case that the IPC verifier (which the
controller pins to the dev config) does not exercise, plus the tail chunk.

Run via workspace.execute (no argv): defaults point at the two local configs and
the repository root.
"""

import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

REPO = str(Path.cwd())
CONFIGS = [
    'flashrt/apps/causal_features/backend/config_dev.json',
    'flashrt/apps/causal_features/backend/config_large.json',
]


class ChunkedRef:
    """Emulates causal_features.reference's per-chunk loop exactly."""

    def __init__(self, layers, device, length, chunk):
        self.layers = layers
        self.device = device
        self.length = length
        self.chunk = chunk
        self.histories = [None] * len(layers)

    def reset(self):
        self.histories = [None] * len(self.layers)

    @torch.inference_mode()
    def __call__(self, features):
        value = torch.from_numpy(features).to(self.device).unsqueeze(0)
        pieces = []
        for position in range(0, self.length, self.chunk):
            block = value[:, :, position:position + self.chunk]
            current = block
            for index, layer in enumerate(self.layers):
                history = self.histories[index]
                joined = current if history is None else torch.cat([history, current], dim=-1)
                result = layer(joined)
                if history is not None:
                    result = result[:, :, history.shape[-1]:]
                self.histories[index] = joined[:, :, -layer._time_causal_padding[0]:].clone()
                current = F.silu(result)
            pieces.append(current)
        return torch.cat(pieces, dim=-1)[0].cpu().numpy()


class Batch:
    """Mirrors worker.process's whole-request causal convolution."""

    def __init__(self, layers, device):
        self.device = device
        self.weights = [layer.conv.weight for layer in layers]
        self.biases = [layer.conv.bias for layer in layers]
        self.pads = [int(layer._time_causal_padding[0]) for layer in layers]
        self.histories = [None] * len(layers)

    def reset(self):
        self.histories = [None] * len(self.weights)

    @torch.inference_mode()
    def __call__(self, features):
        value = torch.from_numpy(features).to(self.device).unsqueeze(0)
        for index, weight in enumerate(self.weights):
            pad = self.pads[index]
            history = self.histories[index]
            if history is None:
                joined = F.pad(value, (pad, 0), mode='replicate')
                result = F.conv1d(joined, weight, self.biases[index])
            else:
                joined = torch.cat([history, value], dim=-1)
                result = F.conv1d(joined, weight, self.biases[index])
            self.histories[index] = joined[..., -pad:].clone()
            value = F.silu(result)
        return value[0].to('cpu').numpy()


def main():
    sys.path.insert(0, REPO)
    from causal_features.model import build_layers, full_sequence_oracle

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    report = []
    for config_path in CONFIGS:
        config = json.loads(Path(config_path).read_text(encoding='utf-8'))
        channels, length, chunk = config['channels'], config['length'], config['chunk']
        cfg_gpu = dict(config, device=device)
        cfg_cpu = dict(config, device='cpu')
        layers = build_layers(REPO, cfg_gpu, device)
        torch.manual_seed(20240517)
        x1 = np.random.standard_normal((channels, length)).astype(np.float32)
        x2 = np.random.standard_normal((channels, length)).astype(np.float32)
        x3 = np.random.standard_normal((channels, length)).astype(np.float32)

        batch = Batch(layers, device)
        chunked = ChunkedRef(layers, device, length, chunk)

        cont_err = []
        for x in (x1, x2, x3):
            cont_err.append(float(np.abs(batch(x) - chunked(x)).max()))

        # Explicit reset must reproduce the first output of a fresh session.
        batch.reset()
        chunked.reset()
        first_batch = batch(x1)
        first_chunked = chunked(x1)
        oracle_x1 = np.asarray(full_sequence_oracle(REPO, cfg_cpu, x1))

        # Full-sequence oracle of the concatenated continuation.
        concat = np.concatenate([x1, x2, x3], axis=-1)
        oracle_concat = np.asarray(full_sequence_oracle(REPO, cfg_cpu, concat))

        batch.reset()
        chunked.reset()
        got = np.concatenate([batch(x1), batch(x2), batch(x3)], axis=-1)
        cont_oracle_err = float(np.abs(got - oracle_concat).max())

        report.append({
            'config': config_path,
            'device': device,
            'shape': [channels, length],
            'chunk': chunk,
            'n_chunks': (length + chunk - 1) // chunk,
            'batch_vs_chunked_continuation_max_abs': cont_err,
            'reset_reproduces_first_output_max_abs': float(np.abs(first_batch - first_chunked).max()),
            'after_reset_vs_cpu_oracle_max_abs': float(np.abs(first_batch - oracle_x1).max()),
            'continuation_vs_cpu_concat_oracle_max_abs': cont_oracle_err,
            'tolerance_ok': (max(cont_err) < 3e-5 and cont_oracle_err < 3e-4),
        })

    print(json.dumps(report, indent=2))
    assert all(row['tolerance_ok'] for row in report), report
    print('numeric equivalence check: PASS')


if __name__ == '__main__':
    main()
