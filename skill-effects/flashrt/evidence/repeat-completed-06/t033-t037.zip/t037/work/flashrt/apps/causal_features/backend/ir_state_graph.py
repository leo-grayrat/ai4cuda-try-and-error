"""Express the causal_features streaming state graph with flashrt.ir and check it.

This is the diagnostic that justifies the worker's optimisation.  It models the
three CausalConv1d layers as three IR operators, each of which owns exactly one
chunk-persistent state object (the (K-1)-frame input history of that layer).
The graph is validated structurally (graph.validate + cross-chunk dependency
analysis) and then executed with the original SequentialExecutor chunk by chunk.
The concatenated streaming output is compared against the CPU full-sequence
oracle from causal_features.model, proving that the state model is faithful and
that the single-history-per-layer picture is complete.

Run: python backend/ir_state_graph.py --repository <repo> --config <json>
"""

import argparse
import json
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

from flashrt.ir import (
    IRGraph,
    IREdge,
    IROperator,
    OpType,
    SequentialExecutor,
    StateObject,
    TensorPort,
    analyze_cross_chunk_dependencies,
    summarize_graph,
)


class ConvStateOp(IROperator):
    """One causal conv layer with a single (K-1)-frame input history state."""

    def __init__(self, index):
        super().__init__(
            name=f'conv{index}',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort(f'in{index}')],
            outputs=[TensorPort(f'out{index}')],
            state_reads=[f'hist{index}'],
            state_writes=[f'hist{index}'],
        )
        self.index = index

    def execute(self, inputs, context, state):
        layer = context['layers'][self.index]
        pad = int(layer._time_causal_padding[0])
        x = inputs[f'in{self.index}']
        history = state.get(f'hist{self.index}')
        if history.shape[-1] == 0:
            joined = F.pad(x, (pad, 0), mode='replicate')
            result = F.conv1d(joined, layer.conv.weight, layer.conv.bias)
            history_input = x
        else:
            joined = torch.cat([history, x], dim=-1)
            result = F.conv1d(joined, layer.conv.weight, layer.conv.bias)
            history_input = joined
        state.set(f'hist{self.index}', history_input[..., -pad:].clone())
        return {f'out{self.index}': F.silu(result)}


def build_graph(config):
    graph = IRGraph(name='causal_features_3layer')
    for index in range(3):
        graph.add_state(StateObject(
            f'hist{index}',
            description=f'layer {index} (K-1)-frame input history',
            scope='chunk_persistent',
        ))
    for index in range(3):
        graph.add_operator(ConvStateOp(index))
    for index in range(2):
        graph.add_edge(IREdge(
            src_op=f'conv{index}', src_port=f'out{index}',
            dst_op=f'conv{index + 1}', dst_port=f'in{index + 1}',
        ))
    graph.external_inputs = [TensorPort('in0')]
    graph.external_outputs = [TensorPort('out2')]
    graph.chunk_ops = ['conv0', 'conv1', 'conv2']
    return graph


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))

    from causal_features.model import build_layers, full_sequence_oracle

    config = json.loads(args.config.read_text(encoding='utf-8'))
    cpu_config = dict(config)
    cpu_config['device'] = 'cpu'
    layers = build_layers(args.repository, cpu_config, 'cpu')

    graph = build_graph(config)
    print(summarize_graph(graph))

    dep_info = analyze_cross_chunk_dependencies(graph)
    print('state_groups:', {k: sorted(v) for k, v in dep_info.state_groups.items()})
    print('independent_pairs:', dep_info.independent_pairs)

    channels = int(config['channels'])
    hidden = int(config['hidden'])
    length = int(config['length'])
    chunk = int(config['chunk'])

    torch.manual_seed(1234)
    features = torch.randn(channels, length, dtype=torch.float32)

    executor = SequentialExecutor(graph)
    executor.init_state({
        'hist0': torch.zeros(1, channels, 0),
        'hist1': torch.zeros(1, hidden, 0),
        'hist2': torch.zeros(1, hidden, 0),
    })

    pieces = []
    context = {'layers': layers}
    with torch.inference_mode():
        for position in range(0, length, chunk):
            block = features[:, position:position + chunk].unsqueeze(0)
            outputs = executor.run_chunk({'in0': block}, context)
            pieces.append(outputs['out2'])
    streaming = torch.cat(pieces, dim=-1)

    oracle = torch.from_numpy(full_sequence_oracle(
        args.repository, cpu_config, features.numpy())).unsqueeze(0)

    max_abs = (streaming - oracle).abs().max().item()
    print(json.dumps({
        'chunk_order': executor.chunk_execution_order,
        'stream_shape': list(streaming.shape),
        'oracle_shape': list(oracle.shape),
        'max_abs_error': max_abs,
        'validation_errors': graph.validate(),
    }))
    assert streaming.shape == oracle.shape, (streaming.shape, oracle.shape)
    assert max_abs < 3e-5, max_abs
    print('IR state-graph validation: PASS')


if __name__ == '__main__':
    main()
