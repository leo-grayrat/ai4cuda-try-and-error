# causal_features backend notes

## Task restated
Fixed 3-layer causal network: CausalConv1d(C->H,k=5) -> SiLU -> CausalConv1d(H->H,k=5)
-> SiLU -> CausalConv1d(H->C,k=3) -> SiLU, weight seed 703. Per-layer `(K-1)`-frame
input histories are the only session state. One request in flight; chunked output
via the fixed `FeatureAdapter` shared-memory protocol.

## Hypotheses
1. The reference backend is launch/Python-bound, not FLOP-bound: per output chunk it
   runs `F.pad -> cat -> conv -> slice -> SiLU` for each of 3 layers, so the dev case
   (9 chunks) issues ~100+ tiny kernels per request.
2. A causal Conv1d is shift-equivariant. If the reference's per-layer `(K-1)`-frame
   **input** history is carried across requests, the whole request can be evaluated as
   one contiguous valid convolution per layer and is numerically identical to the
   per-chunk loop (the reference's replicate-padded positions are sliced off before the
   SiLU). This removes the per-chunk launch storm without changing the causal function.
3. Because the output is precomputed, dumping all chunks at once makes the
   inter-request gap equal to the offered period. At a 50/s offered load (20 ms period)
   that sits exactly on the 20 ms chunk-gap budget, so ~5% of gaps exceeded it. Pacing
   the tail chunks toward ~70% of the measured offered period keeps every gap under
   budget while still finishing before the next due admission.

## Evidence
- `ir_state_graph.py`: flashrt.ir graph with one chunk-persistent `hist{i}` per layer.
  `graph.validate()` PASS; `SequentialExecutor` chunked run vs CPU full-sequence oracle
  max abs error 8.9e-08. Cross-chunk deps are purely per-layer (homogeneous), confirming
  the single-history-per-layer model is complete.
- `check_numerics.py`: GPU `Batch` vs `ChunkedRef` continuation diff = 0.0 for both dev
  and large configs; after reset reproduces; vs CPU concat oracle <= 7.9e-05 (within
  atol/rtol). Covers the larger C=128/H=256/T=16384/chunk=512 case and the dev tail chunk.
- Independent `verify` (verify-005, worker.py): 6/6 requests match oracle, max abs
  <= 8.2e-08, cleanup verified (all 7 shm objects unlinked).
- `timing.py` per-request GPU wall (includes launches + D2H):
  - dev   (16/1043/chunk127, 9 chunks):  chunked 4.46 ms -> batch 0.44 ms (~10.1x)
  - large (128/16384/chunk512, 32 chunks): chunked 19.10 ms -> batch 3.88 ms (~4.9x)

## Benchmark (paired, independent controller; dev config)
- reference: highest_tested_passing_rate = 100 req/s. At 200 req/s the admission/queue
  gate failed (peak offered queue 33) because per-request work exceeded the 5 ms period.
- candidate (worker.py, with pacing): highest_tested_passing_rate = 200 req/s. Passed
  both gates at 50, 100 and 200 req/s:
  - 50/s: over-budget gap fraction 0.22% (only the first, deliberately unpaced, request
    boundary), p95 gap 6.6 ms
  - 100/s: 0%, p95 gap 3.7 ms
  - 200/s: 0%, p95 gap 5.0 ms
This is a pilot finite-window comparison (fixed reference-then-candidate order), not a
sustained-throughput proof, but candidate dominates on the tested rates.

## Variants / trade-offs
- v1: batch compute but dump all chunks. Fastest raw (exceeded 200 req/s headroom) but
  failed the 50/s smoothness gate (5.3% > 1%).
- v2 (submitted worker.py): batch compute + period-adaptive tail pacing, active only when
  the measured period >= 8 ms. Keeps high-rate raw throughput (no pacing when period is
  far below 20 ms) and fixes low-rate gaps. Cost: a short busy-spin (<= ~14 ms/request at
  50/s) while publishing; harmless because one request is in flight and the GPU is idle.
- Pacing uses `time.monotonic_ns` busy-spin, not `time.sleep`, because the Windows sleep
  timer can overshoot past the offered period at 100-200 req/s.
- Larger-case D2H of a (128,16384) result dominates its 3.9 ms; further gains would need
  avoiding the host copy, but the shared-memory protocol requires host-side numpy.

## Failures / unfinished
- The larger case was validated numerically and timed, but the controller's IPC load
  sweep is pinned to the dev config, so no paired offered-load result exists for the
  large case.
- Pacing is heuristic (period >= 8 ms, target 70% of period). It assumes the 20 ms budget
  and a roughly periodic offered load; a bursty aperiodic client could still produce a
  boundary gap above budget.
- The one unpaced request per offered-load window (period estimate not yet available)
  contributes the residual 0.22% over-budget fraction at 50/s; still under the 1% gate.
- No CUDA graph / custom kernel fusion attempted; the 3 layers remain 3 separate convs
  because SiLU sits between them.
