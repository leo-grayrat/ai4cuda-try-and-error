"""Per-request GPU wall-time comparison: chunked reference loop vs batch worker.

The IPC load sweep is pinned to the development config.  This harness times the
same computation for the larger contract case too, including kernel launches and
the device->host copy (cuda.synchronize around each call).  Steady state has a
non-empty history on every layer, which is what the load sweep measures after
the first request.

Run via workspace.execute (no argv).
"""

import json
import statistics
import sys
import time
from pathlib import Path

import numpy as np
import torch

from check_numerics import Batch, ChunkedRef, CONFIGS, REPO

sys.path.insert(0, REPO)


def main():
    from causal_features.model import build_layers

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    torch.cuda.synchronize() if device == 'cuda' else None
    report = []
    for config_path in CONFIGS:
        config = json.loads(Path(config_path).read_text(encoding='utf-8'))
        channels, length, chunk = config['channels'], config['length'], config['chunk']
        layers = build_layers(REPO, dict(config, device=device), device)
        rng = np.random.default_rng(7)
        x = rng.standard_normal((channels, length)).astype(np.float32)
        reps = 200 if length <= 2048 else 20

        rows = {}
        for name, factory in (
            ('chunked_reference', lambda: ChunkedRef(layers, device, length, chunk)),
            ('batch_worker', lambda: Batch(layers, device)),
        ):
            obj = factory()
            obj(x)  # warm up; also populates histories
            if device == 'cuda':
                torch.cuda.synchronize()
            samples = []
            for _ in range(reps):
                start = time.perf_counter()
                obj(x)
                if device == 'cuda':
                    torch.cuda.synchronize()
                samples.append((time.perf_counter() - start) * 1e3)
            rows[name] = {
                'median_ms': statistics.median(samples),
                'p95_ms': float(np.percentile(samples, 95)),
            }
        speedup = rows['chunked_reference']['median_ms'] / rows['batch_worker']['median_ms']
        report.append({
            'config': config_path,
            'shape': [channels, length],
            'chunk': chunk,
            'n_chunks': (length + chunk - 1) // chunk,
            'reps': reps,
            **rows,
            'median_speedup': speedup,
        })
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
