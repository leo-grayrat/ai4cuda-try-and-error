"""Diagnostic runner: workspace.execute cannot pass argv, so supply it here.

Edit CONFIG below to switch between the development and large cases.
"""
import runpy
import sys
from pathlib import Path

CONFIG = 'flashrt/apps/causal_features/backend/config_dev.json'
SCRIPT = 'flashrt/apps/causal_features/backend/ir_state_graph.py'
sys.argv = ['ir_state_graph.py', '--repository', str(Path.cwd()), '--config', CONFIG]
runpy.run_path(SCRIPT, run_name='__main__')
