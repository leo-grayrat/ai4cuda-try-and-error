本次观察的实际状态如下，全部基于磁盘上的测量证据，未完成的项按实列明。

**已交付并可运行的产物（仅在 backend/ 内）**
- `backend/worker.py`：独立后端，接受 `--repository`/`--config`，复用 `causal_features.model.build_layers`（即原库 `CausalConv1d`、种子 703），严格照 `adapter.open_buffers` 的七个共享内存对象、控制码 1/3/2、先数据后元数据的发布顺序与单调游标实现；reset 只清零各层卷积历史，不回退游标。内部含 6 个实现变体（`graph_split` 为默认、`graph_bulk`、`graph_hybrid`、`graph_chunk`、`graph_pipelined`、`eager`），通过 `--variant`/`CAUSAL_VARIANT` 选择；性能收益来自把每块「3 次 conv1d + 3 次 SiLU + cat + 历史 copy」捕获为 CUDA graph 回放，以及用固定暂存缓冲+事件替代每块的同步回拷。
- `backend/tests/harness.py`、`test_variant.py`、`suite.py`、`benchmarks/bench.py`：全部以子进程启动后端、只经适配器驱动、finally 中终止进程的脚本；本地因环境局限用 spec.json 传递参数（`workspace` 执行工具不接受命令行参数）。
- `backend/benchmarks/results/`：每个变体的 correctness JSON 与 benchmark JSON（dev 与 large 两种规模），共 13 个基准文件、8 个正确性文件。

**已验证的结论**
- 正确性（六完整请求：连续会话、未重置重复输入、两次重置、尾部短块；对照 CPU 全序列 oracle，容差 atol=3e-5/rtol=3e-4）：参考后端 large、`graph_chunk`、`graph_bulk`、`graph_hybrid`、`graph_pipelined`、`graph_split`（dev 与 large）、`eager`（修 bug 后）均 PASS，最大绝对误差 7.45e-08（dev）/2.53e-07（large）。`eager` 首轮 FAIL（max_abs 0.146，首块外的块也忽略历史），已修复并重测。
- dev 规模（C=16,H=32,T=1043,chunk=127）：参考 baseline 首块中位 1.444 ms/p95 1.917 ms，单请求总时中位 8.224 ms，块间隔 p95 1.549 ms，可持续载荷 49.3 req/s、饱和 158.5 req/s；推荐变体 `graph_split` 首块中位 0.523 ms/p95 0.604 ms，总时中位 1.071 ms，块间隔 p95 0.521 ms，可持续 196.8 req/s、饱和 779.2 req/s（对基线：首块 -64%，总时 -87%，可持续 +299%）。
- large 规模（C=128,H=256,T=16384,chunk=512）：参考总时中位 23.168 ms、块间隔 p95 1.446 ms、饱和 20.8 req/s；`graph_split` 总时中位 11.794 ms、块间隔 p95 0.617 ms、饱和 30.6 req/s，但首块中位略回退（3.642 vs 3.202 ms，p95 3.808 vs 3.838，差异在噪声内），原因是整请求 8 MB 先上卡再做首块，对应队列第 7/8 项修复。

**未完成或不合格的要求（如实列出）**
1. IR 阶段未完成验收：`backend/ir/graph_builder.py`（worker 图 + 模型图，各层各自 `hist_i` 为 chunk_persistent 状态、request→chunk 速率换算边）已写并部分执行过，但脚本取 repo 根路径时用了 `parents[4]`，导致首轮 FileNotFoundError；随后我把根路径改为 `flashrt.paths.repo_root()`，但 IR 校验脚本里 `EmitChunk` 已写入 `ctx.chunks` 而外层又追加一次，产生形状不匹配（16,2086 vs 16,1043）；最后的修补在写日志前失败。因此**没有一条来自 SequentialExecutor 的 PASS 记录**，`summarize_graph` 输出也未留档。IR 只在我据代码结构的分析层面支撑了变体排序（三层各自状态、严格因果链、唯一速率换算边在 request→chunk），不能声称已验证。
2. 变体数量不足：实测并落盘的是 6 个（eager、graph_chunk、graph_pipelined、graph_bulk、graph_hybrid、graph_split）+ 参考基线两个规模，未达到 AGENTS.md 要求的 ≥10 个不同策略/组合变体。队列中第 7–10 项（chunk-0 分片先行上卡、双流重叠、bulk 的 large 规模、torch.compile 对照）保持 planned 状态，未测量。
3. 文档缺失：`notes/experiment_log.md` 与 `backend/README.md` **没有写成功**（finalize.py 在写文件前因上述断言失败退出），`notes/` 下只有 harness 日志。变体队列、逐变体记录与中文说明目前只存在于本次报告与代码注释中。
4. 测量局限：可持续/饱和速率是下界（扫描中合成输入在计时区间内生成，约为 large 每请求 20 ms，双方同等计费）；每个变体只有 8 个实测请求，p95 统计力弱；仅单会话、单请求在途；本次受 48 次 API/96000 token 上限约束，编码在额度耗尽时被截断。
5. 首块延迟在 large 规模对基线有小幅中位数回退，未达「不退化任何活跃目标」的严格标准（dev 规模两个目标均显著改善）。
6. `backend/worker.py` 本身已做端到端验证（subprocess + 适配器 + oracle 比较 + 干净终止），但最后一次代码修改（加入 `graph_split` 与 eager 修 Bug）之后只经本地 suite 验证，**未再调用 workspace.verify / workspace.benchmark 对推荐入口独立复核**。

结论：单卡上把逐块启动与同步开销转成 CUDA graph 回放是主收益来源（dev 首块 -64%、可持续 +299%；large 单请求总时 -49%、饱和 +47%），推荐入口 `backend/worker.py`（默认 `graph_split`）在 dev 配置下正确且两项目标同时改善；但 IR 执行级验证、≥10 变体、实验日志与 README、large 规模首块回退、以及最终的独立验证/测量调用均未闭合，不能视为任务完成。