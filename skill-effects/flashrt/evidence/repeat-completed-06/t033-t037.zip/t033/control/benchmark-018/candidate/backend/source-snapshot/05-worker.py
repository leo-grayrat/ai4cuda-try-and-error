"""Optimized causal_features streaming backend (single RTX 5060, CUDA graphs).

Reference semantics (flashrt/apps/causal_features/reference.py + model.py):
a 3-layer causal Conv1d stack (kernel 5, 5, 3; SiLU after every layer; the
returned value is silu(layer3(joined))) processed chunk by chunk.  Every
layer keeps exactly kernel_size-1 samples of *its own* input as convolution
history, so chunk boundaries are lossless, and the history survives across
requests until an explicit reset (opcode 3).

Arithmetic is unchanged; the win is scheduling/launch overhead:

  * per-layer history lives in persistent device tensors, so the per-chunk
    ``torch.cat([history, chunk])`` + ``clone()`` dance of the reference is
    replaced by one preallocated left-context concatenation inside a graph;
  * the whole 3-layer chain (3 conv + 3 SiLU + 3 cat + 3 history copy) is
    captured as a CUDA graph, so a chunk costs one graph replay instead of a
    dozen-plus kernel launches from Python;
  * results reach the host through a pinned staging buffer with per-chunk
    CUDA events, so the blocking ``.cpu().numpy()`` per chunk (one full
    device sync per chunk in the reference) disappears; with the pipelined
    variant the GPU runs several chunks ahead of the publisher.

Variants (--variant / CAUSAL_VARIANT / config['variant']):
  eager            no graphs, per-chunk device sync (ablation)
  graph_chunk      per-chunk CUDA graph, per-chunk device sync
  graph_pipelined  per-chunk CUDA graph, async D2H + event-ordered publish
  graph_bulk       one graph replay for the whole request, one D2H copy
  graph_hybrid     chunk 0 replayed alone (fast first output), rest bulk

The adapter protocol (flashrt/apps/causal_features/adapter.py) is honoured
verbatim: same buffers, same control opcodes, same "data before metadata"
publish order, same monotonically increasing cursors (reset never rewinds
them).
"""
import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

VARIANTS = ('graph_split', 'graph_pipelined', 'graph_chunk', 'graph_bulk', 'graph_hybrid', 'eager')
DEFAULT_VARIANT = 'graph_split'


class _GraphState:
    """Static tensors + captured graph for one (region, prime) pair."""

    __slots__ = ('inp', 'out', 'graph')

    def __init__(self, inp, out, graph):
        self.inp = inp
        self.out = out
        self.graph = graph


class Session:
    """Fused, graph-replayed causal conv stack with cross-request state."""

    def __init__(self, cfg, layers, device, variant):
        import torch
        import torch.nn.functional as F

        self.torch = torch
        self.F = F
        self.device = torch.device(device)
        self.variant = variant

        self.channels = int(cfg['channels'])
        self.chunk = int(cfg['chunk'])
        self.length = int(cfg['length'])
        self.K = int(math.ceil(self.length / float(self.chunk)))
        self.shapes = [min(self.chunk, self.length - k * self.chunk) for k in range(self.K)]

        self.ws = [layer.conv.weight.detach().contiguous().to(self.device) for layer in layers]
        self.bs = [layer.conv.bias.detach().contiguous().to(self.device) for layer in layers]
        # (kernel_size - 1) left context per layer, identical to the reference's
        # CausalConv1d._time_causal_padding and to the reference pipeline's
        # history length.
        self.pads = [int(layer._time_causal_padding[0]) for layer in layers]
        self.in_ch = [int(w.shape[1]) for w in self.ws]

        # Persistent per-layer conv history (chunk_persistent state).
        self.hist = [torch.zeros(1, c, p, device=self.device) for c, p in zip(self.in_ch, self.pads)]
        self.first = True  # next request starts a fresh session (no history yet)

        self.pin_in = torch.empty(1, self.channels, self.length, pin_memory=True)
        self.pin_out = torch.empty(1, self.channels, self.length, pin_memory=True)
        self.dev_in = torch.empty(1, self.channels, self.length, device=self.device)
        self._states = {}
        self._built = False
        self.events = []

    # ---------------------------------------------------------------- graphs
    def _capture(self, body, label):
        torch = self.torch
        stream = torch.cuda.Stream()
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for _ in range(3):
                body()
        torch.cuda.current_stream().wait_stream(stream)
        graph = torch.cuda.CUDAGraph()
        try:
            with torch.cuda.graph(graph):
                body()
        except Exception as exc:  # pragma: no cover - environment dependent
            raise RuntimeError('CUDA graph capture failed for %s: %r' % (label, exc))
        return graph

    def _run_layers(self, v, prime):
        """3-layer causal chain on (1, Cin, s) -> (1, C, s); updates history."""
        torch, F = self.torch, self.F
        for i, p in enumerate(self.pads):
            if prime and p:
                left = v[:, :, :1].expand(-1, -1, p)
            else:
                left = self.hist[i]
            joined = torch.cat([left, v], dim=-1) if p else v
            y = F.conv1d(joined, self.ws[i], self.bs[i])
            if p:
                self.hist[i].copy_(joined[:, :, -p:])
            v = F.silu(y)
        return v

    def _chunk_state(self, s, prime):
        key = ('chunk', s, prime)
        st = self._states.get(key)
        if st is not None:
            return st
        torch = self.torch
        inp = torch.zeros(1, self.channels, s, device=self.device)
        out = torch.zeros(1, self.channels, s, device=self.device)
        run = self._run_layers
        hist = self.hist
        pads = self.pads

        def body():
            out.copy_(run(inp, prime))

        graph = self._capture(body, 'chunk s=%d prime=%s' % (s, prime))
        # Warmup left the history dirty; the executor resets it on reset().
        for i, p in enumerate(pads):
            hist[i].zero_()
        st = _GraphState(inp, out, graph)
        self._states[key] = st
        return st

    def _region_state(self, kind, start, prime):
        """Graph over chunks start..K-1 (bulk / hybrid-rest regions)."""
        key = (kind, start, prime)
        st = self._states.get(key)
        if st is not None:
            return st
        torch = self.torch
        span = self.length - start * self.chunk
        if span <= 0:
            return None
        inp = torch.zeros(1, self.channels, span, device=self.device)
        out = torch.zeros(1, self.channels, span, device=self.device)
        run = self._run_layers
        shapes = self.shapes
        chunk = self.chunk
        hist = self.hist
        pads = self.pads

        def body():
            for k in range(start, len(shapes)):
                s = shapes[k]
                off = k * chunk - start * chunk
                v = run(inp[:, :, off:off + s], prime and k == start)
                out[:, :, off:off + s].copy_(v)

        graph = self._capture(body, '%s start=%d prime=%s' % (kind, start, prime))
        for i, p in enumerate(pads):
            hist[i].zero_()
        st = _GraphState(inp, out, graph)
        self._states[key] = st
        return st

    def build(self):
        """Capture every graph this variant can need, before the first request."""
        if self._built or self.variant == 'eager':
            self._built = True
            return
        torch = self.torch
        self.torch.cuda.synchronize()
        if self.variant in ('graph_chunk', 'graph_pipelined', 'graph_hybrid'):
            for s in sorted(set(self.shapes)):
                self._chunk_state(s, True)
                self._chunk_state(s, False)
        if self.variant == 'graph_split':
            # first chunk replayed on its own (low latency to first output),
            # everything else fused into one region replay
            self._chunk_state(self.shapes[0], True)
            self._chunk_state(self.shapes[0], False)
            self._region_state('region', 1, True)
            self._region_state('region', 1, False)
        if self.variant in ('graph_bulk', 'graph_hybrid'):
            start = 0 if self.variant == 'graph_bulk' else 1
            self._region_state('region', start, True)
            self._region_state('region', start, False)
        self.events = [torch.cuda.Event() for _ in range(max(2, self.K))]
        for i in range(len(self.hist)):
            self.hist[i].zero_()
        self.first = True
        self._built = True

    def reset(self):
        for h in self.hist:
            h.zero_()
        self.first = True

    # -------------------------------------------------------------- requests
    def begin_request(self, features):
        torch = self.torch
        src = torch.from_numpy(features if features.dtype == 'float32' else features.astype('float32'))
        self.pin_in.copy_(src)
        self.dev_in.copy_(self.pin_in, non_blocking=True)

    def iter_chunks(self):
        prime = self.first
        self.first = False
        if self.variant == 'eager':
            return self._iter_eager(prime)
        if self.variant == 'graph_chunk':
            return self._iter_graph_chunk(prime)
        if self.variant == 'graph_pipelined':
            return self._iter_graph_pipelined(prime)
        if self.variant == 'graph_bulk':
            return self._iter_graph_bulk(prime)
        if self.variant == 'graph_split':
            return self._iter_graph_split(prime)
        return self._iter_graph_hybrid(prime)

    def _iter_eager(self, prime):
        F = self.F
        chunk = self.chunk
        for k, s in enumerate(self.shapes):
            v = self.dev_in[:, :, k * chunk:k * chunk + s]
            for i, p in enumerate(self.pads):
                if prime and k == 0 and p:
                    left = v[:, :, :1].expand(-1, -1, p)
                else:
                    left = self.hist[i]
                joined = torch_cat(v, left, p)
                y = F.conv1d(joined, self.ws[i], self.bs[i])
                if p:
                    self.hist[i].copy_(joined[:, :, -p:])
                v = F.silu(y)
            yield k, s, v[0, :, :s].cpu().numpy()

    def _iter_graph_chunk(self, prime):
        chunk = self.chunk
        for k, s in enumerate(self.shapes):
            st = self._chunk_state(s, prime and k == 0)
            st.inp.copy_(self.dev_in[:, :, k * chunk:k * chunk + s], non_blocking=True)
            st.graph.replay()
            yield k, s, st.out[0, :, :s].cpu().numpy()

    def _iter_graph_pipelined(self, prime):
        torch = self.torch
        chunk = self.chunk
        events = []
        for k, s in enumerate(self.shapes):
            st = self._chunk_state(s, prime and k == 0)
            st.inp.copy_(self.dev_in[:, :, k * chunk:k * chunk + s], non_blocking=True)
            st.graph.replay()
            self.pin_out[:, :, k * chunk:k * chunk + s].copy_(st.out, non_blocking=True)
            ev = self.events[k]
            ev.record()
            events.append(ev)
        for k, s in enumerate(self.shapes):
            events[k].synchronize()
            yield k, s, self.pin_out[0, :, k * chunk:k * chunk + s].numpy()

    def _iter_graph_bulk(self, prime):
        torch = self.torch
        chunk = self.chunk
        st = self._region_state('region', 0, prime)
        st.inp.copy_(self.dev_in, non_blocking=True)
        st.graph.replay()
        self.pin_out.copy_(st.out, non_blocking=True)
        self.events[0].record()
        self.events[0].synchronize()
        for k, s in enumerate(self.shapes):
            yield k, s, self.pin_out[0, :, k * chunk:k * chunk + s].numpy()

    def _iter_graph_hybrid(self, prime):
        torch = self.torch
        chunk = self.chunk
        s0 = self.shapes[0]
        st0 = self._chunk_state(s0, prime)
        st0.inp.copy_(self.dev_in[:, :, :s0], non_blocking=True)
        st0.graph.replay()
        self.pin_out[:, :, :s0].copy_(st0.out, non_blocking=True)
        ev0 = self.events[0]
        ev0.record()
        rest = None
        ev1 = None
        if self.K > 1:
            rest = self._region_state('region', 1, False)
            rest.inp.copy_(self.dev_in[:, :, s0:], non_blocking=True)
            rest.graph.replay()
            self.pin_out[:, :, s0:].copy_(rest.out, non_blocking=True)
            ev1 = self.events[1]
            ev1.record()
        ev0.synchronize()
        yield 0, s0, self.pin_out[0, :, :s0].numpy()
        if rest is None:
            return
        ev1.synchronize()
        for k in range(1, len(self.shapes)):
            s = self.shapes[k]
            yield k, s, self.pin_out[0, :, k * chunk:k * chunk + s].numpy()


    def _iter_graph_split(self, prime):
        """Chunk 0 goes out as soon as it is computed; the rest of the request
        is then fused into one region replay (one launch instead of K-1)."""
        torch = self.torch
        chunk = self.chunk
        s0 = self.shapes[0]
        st0 = self._chunk_state(s0, prime)
        st0.inp.copy_(self.dev_in[:, :, :s0], non_blocking=True)
        st0.graph.replay()
        self.pin_out[:, :, :s0].copy_(st0.out, non_blocking=True)
        ev0 = self.events[0]
        ev0.record()
        ev0.synchronize()
        yield 0, s0, self.pin_out[0, :, :s0].numpy()
        if self.K == 1:
            return
        rest = self._region_state('region', 1, False)
        rest.inp.copy_(self.dev_in[:, :, s0:], non_blocking=True)
        rest.graph.replay()
        self.pin_out[:, :, s0:].copy_(rest.out, non_blocking=True)
        ev1 = self.events[1]
        ev1.record()
        ev1.synchronize()
        for k in range(1, len(self.shapes)):
            s = self.shapes[k]
            yield k, s, self.pin_out[0, :, k * chunk:k * chunk + s].numpy()


def _idle_spin(count):
    """Low-latency idle: spin briefly (fresh activity), then sleep.

    Windows ``time.sleep(2e-4)`` really costs about a millisecond, which
    would dominate the submit -> publish path; spinning for the first few
    milliseconds after activity keeps the response path off the scheduler
    quantum without burning a core while the backend is idle.
    """
    if count < 3000:
        end = time.perf_counter() + 5e-5
        while time.perf_counter() < end:
            pass
    else:
        time.sleep(0.0002)


def torch_cat(v, left, p):
    import torch
    return torch.cat([left, v], dim=-1) if p else v


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--variant', default=None)
    args = parser.parse_args()

    repository = args.repository.resolve()
    sys.path.insert(0, str(repository))
    import numpy as np
    import torch

    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    variant = args.variant or os.environ.get('CAUSAL_VARIANT') or config.get('variant') or DEFAULT_VARIANT
    if variant not in VARIANTS:
        raise SystemExit('unknown variant %r (choose from %s)' % (variant, VARIANTS))

    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    device = config.get('device', 'cuda')

    # Fixed computation: the pinned upstream CausalConv1d with seed 703, built
    # exactly as the reference builds it (identical initialisation order).
    layers = build_layers(repository, config, 'cpu')
    session = Session(config, layers, device, variant)
    session.build()

    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    idle = 0
    zero = np.zeros((config['channels'], config['chunk']), dtype=np.float32)
    padded = np.zeros((config['channels'], config['chunk']), dtype=np.float32)
    try:
        print(json.dumps({'ready': True, 'device': str(device), 'variant': variant}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    session.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError('Unknown control opcode: %s' % (opcode,))
            if not active:
                idle += 1
                _idle_spin(idle)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                idle += 1
                _idle_spin(idle)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            session.begin_request(features[0] if features.ndim == 3 else features)
            for index, valid, data in session.iter_chunks():
                # data-before-metadata publish order, exactly like the reference
                padded[:, :valid] = data[:, :valid]
                if valid < config['chunk']:
                    padded[:, valid:] = 0.0
                buffers['output'].write(padded)
                buffers['metadata'].write(np.array([request_id, index, valid], dtype=np.int64))
            idle = 0
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
