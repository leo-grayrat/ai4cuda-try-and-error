"""One-off patch: add `graph_split` (publish chunk 0 before enqueuing the
remainder) and fix the eager ablation's priming condition."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
W = HERE.parent / 'worker.py'
src = W.read_text(encoding='utf-8')


def sub(old, new):
    global src
    assert old in src, old[:70]
    src = src.replace(old, new, 1)


sub("VARIANTS = ('graph_pipelined', 'graph_chunk', 'graph_bulk', 'graph_hybrid', 'eager')\nDEFAULT_VARIANT = 'graph_pipelined'",
    "VARIANTS = ('graph_split', 'graph_pipelined', 'graph_chunk', 'graph_bulk', 'graph_hybrid', 'eager')\nDEFAULT_VARIANT = 'graph_split'")

sub("""        if self.variant in ('graph_bulk', 'graph_hybrid'):
            start = 0 if self.variant == 'graph_bulk' else 1""",
    """        if self.variant == 'graph_split':
            # first chunk replayed on its own (low latency to first output),
            # everything else fused into one region replay
            self._chunk_state(self.shapes[0], True)
            self._chunk_state(self.shapes[0], False)
            self._region_state('region', 1, True)
            self._region_state('region', 1, False)
        if self.variant in ('graph_bulk', 'graph_hybrid'):
            start = 0 if self.variant == 'graph_bulk' else 1""")

sub("""        if self.variant == 'graph_bulk':
            return self._iter_graph_bulk(prime)
        return self._iter_graph_hybrid(prime)""",
    """        if self.variant == 'graph_bulk':
            return self._iter_graph_bulk(prime)
        if self.variant == 'graph_split':
            return self._iter_graph_split(prime)
        return self._iter_graph_hybrid(prime)""")

sub("""                if prime and p:
                    left = v[:, :, :1].expand(-1, -1, p)""",
    """                if prime and k == 0 and p:
                    left = v[:, :, :1].expand(-1, -1, p)""")

sub("def _idle_spin(count):",
    '''    def _iter_graph_split(self, prime):
        """Chunk 0 goes out as soon as it is computed; the rest of the request
        is then fused into one region replay (one launch instead of K-1)."""
        torch = self.torch
        chunk = self.chunk
        s0 = self.shapes[0]
        st0 = self._chunk_state(s0, prime)
        st0.inp.copy_(self.dev_in[:, :, :s0], non_blocking=True)
        st0.graph.replay()
        self.pin_out[:, :, :s0].copy_(st0.out, non_blocking=True)
        ev0 = self.events[0]
        ev0.record()
        ev0.synchronize()
        yield 0, s0, self.pin_out[0, :, :s0].numpy()
        if self.K == 1:
            return
        rest = self._region_state('region', 1, False)
        rest.inp.copy_(self.dev_in[:, :, s0:], non_blocking=True)
        rest.graph.replay()
        self.pin_out[:, :, s0:].copy_(rest.out, non_blocking=True)
        ev1 = self.events[1]
        ev1.record()
        ev1.synchronize()
        for k in range(1, len(self.shapes)):
            s = self.shapes[k]
            yield k, s, self.pin_out[0, :, k * chunk:k * chunk + s].numpy()


def _idle_spin(count):''')

W.write_text(src, encoding='utf-8')
print('patched worker')
