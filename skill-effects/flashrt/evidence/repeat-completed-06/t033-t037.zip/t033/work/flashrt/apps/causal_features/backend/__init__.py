"""Optimized single-GPU backend for the causal_features app."""
