"""One-off: fix the IR harness double-count (EmitChunk already appends to
ctx.chunks) plus the now-applied repo-root anchor in finalize.py, then run
finalize with truncated graph summaries."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
IR = HERE.parent / 'ir' / 'graph_builder.py'
FIN = HERE / 'finalize.py'

src = IR.read_text(encoding='utf-8')
old = ("            out = executor.run_chunk({'x': features[:, :, pos:pos + config['chunk']]}, ctx)\n"
       "            chunks.append(out['chunk'])")
if old in src:
    src = src.replace(old, "            executor.run_chunk({'x': features[:, :, pos:pos + config['chunk']]}, ctx)")
    IR.write_text(src, encoding='utf-8')

fin = FIN.read_text(encoding='utf-8')
anchor = "src = src.replace(anchor, 'from flashrt.paths import repo_root as _repo_root\\n'\n                          'REPO_ROOT = Path(_repo_root())')"
if anchor in fin:
    fin = fin.replace(anchor, "if anchor in src:\n    src = src.replace(anchor, 'from flashrt.paths import repo_root as _repo_root\\n'\n                              'REPO_ROOT = Path(_repo_root())')\n    IR.write_text(src, encoding='utf-8')")
    FIN.write_text(fin, encoding='utf-8')

import flashrt.ir as fir  # noqa: E402
_orig = fir.summarize_graph
fir.summarize_graph = lambda g, op_latencies=None: '\n'.join(_orig(g, op_latencies).splitlines()[:26])
exec(compile(FIN.read_text(encoding='utf-8'), str(FIN), 'exec'), {'__name__': '__patch__', '__file__': str(FIN)})
