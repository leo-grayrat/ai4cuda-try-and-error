"""Diagnostic: launch a backend worker, wait, report its stdout/stderr."""
import json
import sys
import time
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))
import harness  # noqa: E402
sys.path.insert(0, str(harness.REPO_ROOT))


def main():
    variant = sys.argv[1] if len(sys.argv) > 1 else 'graph_pipelined'
    base = harness.LARGE_CONFIG if (len(sys.argv) > 2 and sys.argv[2] == 'large') else harness.DEV_CONFIG
    cfg = harness.make_config('cfdiag%d' % (int(time.time() * 1000) % 1000000), base)
    path = harness.write_config(harness.TMP_DIR / ('diag_%s.json' % cfg['prefix']), cfg)
    proc = harness.launch(harness.WORKER, path, variant=variant, device_index=0)
    try:
        time.sleep(20)
        print('alive=%s rc=%s' % (proc.poll() is None, proc.poll()))
    finally:
        harness.stop(proc, None)
        out, err = proc.communicate(timeout=10)
    print('--- worker stdout ---')
    print(out.decode('utf-8', 'replace')[-3000:].encode('ascii', 'backslashreplace').decode('ascii'))
    print('--- worker stderr ---')
    print(err.decode('utf-8', 'replace')[-6000:].encode('ascii', 'backslashreplace').decode('ascii'))
    print('--- end ---')


if __name__ == '__main__':
    harness.harden('diag')
    try:
        main()
    except BaseException as exc:  # noqa: BLE001
        print(harness.ascii_text(exc))
    sys.stdout.flush()
