"""Subprocess-driven harness for the causal_features adapter contract.

Used by both the correctness checks in ``tests/`` and the measurements in
``benchmarks/``: launch a backend (the researcher reference or one of our
variants) as a subprocess, drive it purely through
``causal_features.adapter.FeatureAdapter``, collect every chunk with
timestamps, then terminate the process tree.

Nothing here touches the frontend; the adapter is the contract.
"""
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

import numpy as np

BACKEND_DIR = Path(__file__).resolve().parents[1]
APP_DIR = BACKEND_DIR.parent
from flashrt.paths import repo_root as _repo_root
REPO_ROOT = Path(_repo_root())
WORKER = BACKEND_DIR / 'worker.py'
REFERENCE = APP_DIR / 'reference.py'

DEV_CONFIG = dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703, device='cuda')
LARGE_CONFIG = dict(channels=128, hidden=256, length=16384, chunk=512, weight_seed=703, device='cuda')

TMP_DIR = BACKEND_DIR / 'benchmarks' / 'tmp'
LOG_DIR = BACKEND_DIR / 'notes' / 'logs'


def harden(log_name='harness'):
    """Keep our stdout pure ASCII and route native/library noise to a log file.

    The Windows CUDA stack prints localised (non-UTF-8) bytes straight to the
    C-level stderr; those would corrupt the captured stream, so fd 1/2 are
    re-pointed and Python-level streams are rebuilt on the saved descriptors
    with ``errors='backslashreplace'``.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        sys.stdout.flush()
        sys.stderr.flush()
        saved_out = os.dup(1)
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, 1)
        os.close(devnull)
        log_path = LOG_DIR / ('%s_%d.log' % (log_name, os.getpid()))
        saved_err = os.open(str(log_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC)
        os.dup2(saved_err, 2)
        sys.stdout = open(saved_out, 'w', encoding='utf-8', errors='backslashreplace',
                          buffering=1, closefd=False)
        sys.stderr = open(2, 'w', encoding='utf-8', errors='backslashreplace',
                          buffering=1, closefd=False)
    except Exception:
        pass
    return log_path if 'log_path' in dir() else None


def ascii_text(exc):
    return ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__)).encode(
        'ascii', 'backslashreplace').decode('ascii')


def make_config(prefix, base=DEV_CONFIG, **overrides):
    cfg = dict(base)
    cfg.update(overrides)
    cfg['prefix'] = prefix
    return cfg


def write_config(path, cfg):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(cfg), encoding='utf-8')
    return path


def _popen_kwargs():
    kwargs = dict(stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=str(REPO_ROOT))
    if os.name == 'nt':
        kwargs['creationflags'] = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    else:
        kwargs['preexec_fn'] = os.setsid
    return kwargs


def launch(worker, config_path, variant=None, device_index=None):
    cmd = [sys.executable, str(worker), '--repository', str(REPO_ROOT), '--config', str(config_path)]
    if variant:
        cmd += ['--variant', variant]
    env = os.environ.copy()
    if device_index is not None:
        env['CUDA_VISIBLE_DEVICES'] = str(device_index)
    return subprocess.Popen(cmd, env=env, **_popen_kwargs())


def stop(proc, adapter=None, timeout=25.0):
    if adapter is not None:
        try:
            adapter.terminate()
        except Exception:
            pass
    for _ in range(80):
        if proc.poll() is not None:
            break
        time.sleep(0.01)
    if proc.poll() is None:
        proc.terminate()
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            pass


def scenario_inputs(scenario, cfg, seed=1234):
    rng = np.random.default_rng(seed)
    cache = {}
    inputs = []
    for op in scenario:
        if op[0] == 'submit':
            key = op[1]
            if key not in cache:
                cache[key] = rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32)
            inputs.append(cache[key])
        else:
            inputs.append(None)
    return inputs


def run_scenario(worker, cfg, scenario, variant=None, device_index=0, timeout=120.0,
                 config_path=None):
    """Drive ``worker`` through ``scenario``; return outputs and timings."""
    from causal_features.adapter import FeatureAdapter

    if config_path is None:
        TMP_DIR.mkdir(parents=True, exist_ok=True)
        config_path = TMP_DIR / ('cfg_%s_%d.json' % (cfg['prefix'], os.getpid()))
    write_config(config_path, cfg)

    inputs = scenario_inputs(scenario, cfg)
    proc = launch(worker, config_path, variant=variant, device_index=device_index)
    adapter = None
    requests = []
    stdout = stderr = ''
    try:
        adapter = FeatureAdapter(dict(cfg))
        adapter.start()
        for op, data in zip(scenario, inputs):
            if op[0] == 'reset':
                adapter.reset()
                continue
            rid, t_in = adapter.submit(data)
            chunks, stamps = [], []
            while adapter.pending is not None:
                out, observed = adapter.receive(timeout_s=timeout)
                chunks.append(out.copy())
                stamps.append(observed)
            requests.append(dict(id=rid, t_in=t_in, stamps=stamps,
                                 out=np.concatenate(chunks, axis=1)))
    finally:
        stop(proc, adapter)
        try:
            stdout, stderr = proc.communicate(timeout=10)
        except Exception:
            stdout, stderr = b'', b''
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
    return dict(requests=requests,
                stdout=(stdout or b'').decode('utf-8', 'replace'),
                stderr=(stderr or b'').decode('utf-8', 'replace'),
                returncode=proc.returncode)


def oracle_requests(cfg, scenario, seed=1234):
    """CPU full-sequence oracle, split per request across the scenario.

    Continuation (no reset) means the inputs of a session are concatenated in
    time and the whole causal network is run over the concatenation, so
    request i of a segment is the tail slice of the full-sequence result.
    """
    from causal_features.model import full_sequence_oracle

    inputs = scenario_inputs(scenario, cfg, seed=seed)
    out = []
    segment = []
    for op, data in zip(scenario, inputs):
        if op[0] == 'reset':
            segment = []
            continue
        segment.append(data)
        joined = np.concatenate(segment, axis=1)
        full = full_sequence_oracle(str(REPO_ROOT), dict(cfg), joined)
        out.append(full[:, joined.shape[1] - cfg['length']:])
    return out


def compare(got, expected, atol=3e-5, rtol=3e-4):
    """Boolean per-request tolerance check plus worst-case deviations."""
    max_abs = 0.0
    max_rel = 0.0
    for g, e in zip(got, expected):
        if g.shape != e.shape:
            return dict(ok=False, reason='shape %s vs %s' % (g.shape, e.shape))
        d = np.abs(g - e)
        max_abs = max(max_abs, float(d.max()))
        max_rel = max(max_rel, float((d / np.maximum(np.abs(e), 1e-8)).max()))
        if not bool(np.all(d <= atol + rtol * np.abs(e))):
            return dict(ok=False, max_abs=max_abs, max_rel=max_rel,
                        reason='tolerance exceeded on a chunk')
    return dict(ok=True, max_abs=max_abs, max_rel=max_rel)


def gap_stats(stamps_ns, budget_ms=20.0):
    if len(stamps_ns) < 2:
        return dict(median_ms=0.0, p95_ms=0.0, over_budget_fraction=0.0, count=0)
    gaps = np.diff(np.array(stamps_ns, dtype=np.int64)) / 1e6
    return dict(median_ms=float(np.median(gaps)),
                p95_ms=float(np.percentile(gaps, 95)),
                max_ms=float(gaps.max()),
                over_budget_fraction=float(np.mean(gaps > budget_ms)),
                count=int(gaps.size))


def latency_stats(values_ms):
    arr = np.array(values_ms, dtype=np.float64)
    if arr.size == 0:
        return dict(median_ms=0.0, p95_ms=0.0, count=0)
    return dict(median_ms=float(np.median(arr)),
                p95_ms=float(np.percentile(arr, 95)),
                min_ms=float(arr.min()), max_ms=float(arr.max()),
                count=int(arr.size))


# Six complete requests: continuation, repeated input without reset, reset and
# a tail chunk (each request ends with the configured short tail chunk).
VERIFY_SCENARIO = [('submit', 'a'), ('submit', 'b'), ('reset',), ('submit', 'a'),
                   ('reset',), ('submit', 'a'), ('submit', 'c'), ('submit', 'a')]
