"""Correctness: launch a backend, drive the 6-request verification scenario,
compare every chunk against the CPU full-sequence oracle.

Usage (from repo root):
  python flashrt/apps/causal_features/backend/tests/test_variant.py --variant graph_pipelined
  python flashrt/apps/causal_features/backend/tests/test_variant.py --worker reference
"""
import argparse
import json
import sys
import time
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

import harness  # noqa: E402
sys.path.insert(0, str(harness.REPO_ROOT))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--variant', default='graph_pipelined')
    p.add_argument('--worker', default='candidate', choices=['candidate', 'reference'])
    p.add_argument('--base', default='dev', choices=['dev', 'large', 'tiny'])
    args = p.parse_args()

    base = {'dev': harness.DEV_CONFIG, 'large': harness.LARGE_CONFIG,
            'tiny': dict(harness.DEV_CONFIG, length=140, chunk=127)}[args.base]
    cfg = harness.make_config('cfchk%s%d' % (args.variant.replace('_', '')[:3],
                                            int(time.time() * 1000) % 1000000), base)
    worker = harness.WORKER if args.worker == 'candidate' else harness.REFERENCE
    variant = None if args.worker == 'reference' else args.variant

    t0 = time.time()
    result = harness.run_scenario(worker, cfg, harness.VERIFY_SCENARIO, variant=variant)
    expected = harness.oracle_requests(cfg, harness.VERIFY_SCENARIO)
    got = [r['out'] for r in result['requests']]
    if len(got) != len(expected):
        print('FAIL: collected %d requests, expected %d' % (len(got), len(expected)))
        print(result['stderr'][-4000:].encode('ascii', 'backslashreplace').decode('ascii'))
        print('FAIL')
        return 1
    diff = harness.compare(got, expected)
    lat = harness.latency_stats([(r['stamps'][0] - r['t_in']) / 1e6
                                for r in result['requests'] if r['stamps']])
    print(json.dumps(dict(worker=Path(worker).name, variant=variant, base=args.base,
                          requests=len(got), tolerance='atol=3e-5 rtol=3e-4',
                          diff=diff, first_out_ms=lat,
                          wall_s=round(time.time() - t0, 2),
                          returncode=result['returncode'],
                          stdout=result['stdout'].strip().splitlines()[:3],
                          stderr_tail=result['stderr'][-1200:])))
    print('PASS' if diff.get('ok') else 'FAIL')
    return 0 if diff.get('ok') else 1


if __name__ == '__main__':
    harness.harden('test_variant')
    try:
        rc = main()
    except BaseException as exc:  # noqa: BLE001
        print(harness.ascii_text(exc))
        print('FAIL')
        rc = 2
    sys.stdout.flush()
    sys.exit(rc)
