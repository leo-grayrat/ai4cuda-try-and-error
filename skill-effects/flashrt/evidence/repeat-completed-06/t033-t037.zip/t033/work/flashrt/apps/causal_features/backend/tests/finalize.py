"""Finalize: fix the IR script's repo-root resolution, validate the IR, and
write the experiment log + README with the measured evidence.

Run from the repo root:
    python flashrt/apps/causal_features/backend/tests/finalize.py
"""
import importlib.util
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BACKEND = HERE.parent
IR = BACKEND / 'ir' / 'graph_builder.py'

# ---- 1. repo-root resolution via the shared helper (no counting '..') --------
src = IR.read_text(encoding='utf-8')
anchor = 'REPO_ROOT = Path(__file__).resolve().parents[4]'
assert anchor in src
if anchor in src:
    src = src.replace(anchor, 'from flashrt.paths import repo_root as _repo_root\n'
                              'REPO_ROOT = Path(_repo_root())')
    IR.write_text(src, encoding='utf-8')
IR.write_text(src, encoding='utf-8')

sys.path.insert(0, str(BACKEND))
sys.path.insert(0, str(HERE))
import harness  # noqa: E402
sys.path.insert(0, str(harness.REPO_ROOT))

spec = importlib.util.spec_from_file_location('cf_ir', str(IR))
ir = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ir)

# ---- 2. execute the IR and compare with the CPU full-sequence oracle --------
config = dict(ir.DEV)
graph, got, want = ir.run_ir_session(config)
atol, rtol = 3e-5, 3e-4
import numpy as np
max_abs = max(float(np.abs(g - w).max()) for g, w in zip(got, want))
verdict = all(bool(np.all(np.abs(g - w) <= atol + rtol * np.abs(w))) for g, w in zip(got, want))
print('IR VALIDATION %s requests=%d max_abs=%.3e' % ('PASS' if verdict else 'FAIL', len(got), max_abs))

from causal_features.model import build_layers  # noqa: E402
layers = build_layers(str(harness.REPO_ROOT), config, 'cpu')
worker_graph = ir.build_worker_graph(layers, config)
model_graph = ir.build_model_graph(layers)
from flashrt.ir import summarize_graph  # noqa: E402
worker_summary = summarize_graph(worker_graph)
model_summary = summarize_graph(model_graph)
print('--- worker graph ---')
print(worker_summary)
print('--- model graph ---')
print(model_summary)

DEV_ROWS = [
    ('reference (baseline)', 1.444, 1.917, 8.224, 9.772, 1.549, 49.3, 158.5),
    ('eager (ablation)', 0.790, 1.128, 5.550, 7.020, 1.097, 98.1, 213.9),
    ('graph_chunk', 0.557, 0.762, 1.238, 1.456, 0.550, 196.5, 539.4),
    ('graph_pipelined', 1.104, 1.302, 1.165, 1.357, 0.011, 196.1, 496.2),
    ('graph_bulk', 0.938, 1.092, 1.131, 1.433, 0.017, 393.8, 1095.0),
    ('graph_hybrid', 1.041, 1.122, 1.072, 1.186, 0.011, 197.8, 740.8),
    ('graph_split (recommended)', 0.523, 0.604, 1.071, 1.172, 0.521, 196.8, 779.2),
]
LARGE_ROWS = [
    ('reference (baseline)', 3.202, 3.838, 23.168, 36.441, 1.446, 0.0, 20.8),
    ('graph_split (recommended)', 3.642, 3.808, 11.794, 12.764, 0.617, 0.0, 30.6),
]


def table(rows):
    out = ['| variant | first-out med | first-out p95 | request total med | total p95 | gap p95 | sustained req/s | saturated req/s |',
           '| --- | --- | --- | --- | --- | --- | --- | --- |']
    for name, f, fp, t, tp, gp, sus, sat in rows:
        out.append('| `%s` | %.3f ms | %.3f ms | %.3f ms | %.3f ms | %.3f ms | %.1f | %.1f |'
                   % (name, f, fp, t, tp, gp, sus, sat))
    return '\n'.join(out)


log = f"""# Experiment log - causal_features backend

Append-only record. Every number below is backed by a JSON file under
`benchmarks/results/` and, for the IR, by the executed validation in
`ir/graph_builder.py`. Hardware: one RTX 5060 8 GB, Windows, PyTorch
2.11.0+cu128; `CUDA_VISIBLE_DEVICES=0`; cudnn.benchmark=False,
allow_tf32=False (same knobs as the reference worker).

## IR Conversion  (session date: see file mtime)

- Worker graph `causal_features_worker`: 3 operators, 2 data edges
  - Black-box stages: `ingest_request` (IPC ingest, 1 whole request),
    `publish_chunks` (adapter publish, data before metadata)
  - Exposed/composite stages: `chunk_pipeline` (COMPOSITE, sub_graph
    `causal_features_model`, STREAMING)
  - Streaming edges: ingest -> pipeline (rate conversion `length` -> `chunk`),
    pipeline -> publish (`chunk` -> `chunk`)
- Model graph `causal_features_model`: 4 operators, 3 data edges
  - State objects: `hist_0` (4 samples), `hist_1` (4), `hist_2` (2), all
    scope `chunk_persistent` - the convolution history of each layer
  - Chunk-periodic operators: `conv_0`, `conv_1`, `conv_2`, `emit_chunk`
- IR validation: **{'PASS' if verdict else 'FAIL'}**
  - fixture: in-process deterministic `standard_normal` draws, 7-request
    scenario (continuation, repeat without reset, two resets)
  - executor vs CPU `full_sequence_oracle` over the concatenated session
    (the same oracle the researcher harness uses)
  - requests compared: {len(got)}; max_abs = {max_abs:.3e}
  - tolerance: atol=3e-5, rtol=3e-4 - CPU/GPU float32 accumulation order only;
    the arithmetic (kernel taps, SiLU placement, causal taps) is unchanged
- Analysis summary (from `summarize_graph`):

```
{worker_summary.strip()}
```

```
{model_summary.strip()}
```

### What the analysis says

- All three convolution layers chain through *different* state objects, and
  each layer's history is a pure function of that layer's own input, so no
  layer can begin chunk N before layer i-1 produced chunk N (true data
  dependency). Cross-chunk independence exists only along the *request*
  boundary and behind the publish step, which the adapter's
  one-request-in-flight rule closes.
- The only rate-conversion edge is request -> chunk (`length` -> `chunk`, 9
  chunks for the dev config, 32 for the large one). The pipeline is therefore
  a linear chain whose critical path is one chunk of 3 convolutions; the
  observable cost of a chunk in the reference is dominated by launch and
  synchronisation overhead, not arithmetic.
- Consequence: the productive levers are (a) collapse the per-chunk launch
  chain into a graph replay, (b) remove the per-chunk device sync, (c) fusion
  granularity (per chunk vs whole request), and (d) move the publish of the
  first chunk ahead of the rest of the work. Device placement / multi-GPU
  sharding has nothing to win here (one GPU assigned; each chunk is
  microseconds of arithmetic and the layers are strictly sequential).

## Variant Queue  (final state)

| # | name | hypothesis | IR basis | predicted impact | status |
| --- | --- | --- | --- | --- | --- |
| 1 | `eager` | keep the reference's per-chunk structure but drop `cat` copies / module overhead | model graph, 4 ops/chunk | baseline sanity, small gain | measured |
| 2 | `graph_chunk` | one CUDA graph replay per chunk | linear chain of 3 conv ops per chunk | cut launch overhead | measured |
| 3 | `graph_pipelined` | also drop the per-chunk device sync (pinned staging + events) | publish op is the only downstream consumer | cut total per-request time | measured |
| 4 | `graph_bulk` | one graph replay for the whole request | request -> chunk rate-conversion edge | maximise sustainable rate | measured |
| 5 | `graph_hybrid` | per-chunk graph for chunk 0, bulk for the rest | independent operator pairs at the publish boundary | both targets at once | measured |
| 6 | `graph_split` | publish chunk 0 *before* enqueuing the remainder | same as 5, ordering fixed | best of both | measured (**recommended**) |
| 7 | `graph_split_faststage` | stage only the chunk-0 slice to the device first, then the rest | ingest -> pipeline edge | large-config first-out -1.5 ms | planned (unmeasured) |
| 8 | `graph_two_stream` | overlap the rest-of-request H2D with chunk-0 compute on a second stream | same | large-config first-out | planned (unmeasured) |
| 9 | `graph_bulk_large` | measure the bulk variant on the large config | rate-conversion edge | sustainable rate | planned (unmeasured) |
| 10 | `torch_compile_chain` | replace graph capture with inductor compilation of the fused chain | model graph | compare against capture | planned (unmeasured) |

Rationale for ordering: ordered by IR-ranked expected impact on the two active
targets (chunk-launch collapse first, then sync removal, then fusion
granularity, then the publish ordering that the critical path exposes). The
observation budget for this session (indexed API-request cap) was exhausted
after variant 6; entries 7-10 remain unmeasured and are listed here as
unmet work rather than being claimed as results.

Changelog:
- initial queue committed from the IR analysis (6 graph/eager variants).
- `eager` first run FAILED correctness (max_abs 0.146): its session-priming
  branch ignored the history on every chunk, not just chunk 0. Fixed and
  re-measured; the failure is recorded below.
- after comparing 2-6, `graph_split` was added because `graph_hybrid`
  regressed first-output latency (1.041 ms) by enqueuing the bulk region
  before publishing chunk 0; the same numbers showed `graph_bulk` winning the
  sustainable-rate axis, which is exactly the non-dominated pair the split
  variant combines.
- entries 7-10 enqueued from the large-config first-output observation.

## Deployment iterations

Measurement protocol for every row (same harness for baseline and variants):
`benchmarks/bench.py` launches one backend subprocess per run, drives the
fixed adapter, 3 warmup requests, 8 measured back-to-back requests
(session continues, no reset), then a paced finite offered-load sweep
(25/50/100/200/400/800/1600 requests/s, 24 requests each). first-out =
`adapter.submit` timestamp -> first chunk timestamp. Gap statistics are the
differences between consecutive chunk timestamps. Chunk-gap budget: 20 ms.

## reference (baseline)  -  dev config (C=16, H=32, T=1043, chunk=127)
- Correctness: PASS against the CPU full-sequence oracle over the 6-request
  scenario (`benchmarks/results/correctness_reference_large_*.json` is the
  large-config twin; the dev twin is produced by the same harness).
- benchmark_json: `benchmarks/results/reference_dev_rtx5060_*.json`
- Verdict: baseline anchor. Never promoted, always the delta anchor.

## eager  -  dev config
- Hypothesis: the reference's per-chunk `torch.cat` + history clone + module
  dispatch is measurable; keep the arithmetic, use plain tensors.
- Change: persistent history tensors, `F.conv1d` on `[history | chunk]`,
  per-chunk blocking copy.
- Correctness: FAIL on the first run (max_abs 0.1456, `eager_dev_*_52214.json`),
  PASS after the priming fix (max_abs 7.45e-08).
- Numbers: {DEV_ROWS[1][1]:.3f}/{DEV_ROWS[1][2]:.3f} ms first-out,
  {DEV_ROWS[1][3]:.3f} ms total, gap p95 {DEV_ROWS[1][5]:.3f} ms,
  sustained {DEV_ROWS[1][6]:.1f}/s, saturated {DEV_ROWS[1][7]:.1f}/s.
- Δ vs reference: first-out -45 %, total -33 %, sustainable +99 %.
- Verdict: discard (kept as the ablation that isolates graph capture).

## graph_chunk  -  dev config
- Hypothesis: collapse 3 conv + 3 SiLU + 3 cat + 3 clone launches per chunk
  into one CUDA graph replay.
- Correctness: PASS (max_abs 7.45e-08). Numbers: {DEV_ROWS[2][1]:.3f} ms
  first-out, {DEV_ROWS[2][3]:.3f} ms total, gap p95 {DEV_ROWS[2][5]:.3f} ms,
  saturated {DEV_ROWS[2][7]:.1f}/s.
- Δ vs reference: first-out -61 %, total -85 %, sustainable +240 %.
- Verdict: promote as a lever (graph capture is the single biggest win).

## graph_pipelined  -  dev config
- Hypothesis: the per-chunk blocking `.cpu()` (one device sync per chunk) is
  the remaining cost; pinned staging + per-chunk events remove it.
- Correctness: PASS. Numbers: {DEV_ROWS[3][1]:.3f} ms first-out,
  {DEV_ROWS[3][3]:.3f} ms total, gap p95 {DEV_ROWS[3][5]:.3f} ms,
  saturated {DEV_ROWS[3][7]:.1f}/s.
- Δ vs `graph_chunk`: total -6 %, first-out +98 % (regression).
- Verdict: needs-followup - the enqueue-all-then-publish order pushes the
  first output behind 8 extra replays.

## graph_bulk  -  dev config
- Hypothesis: one replay for the whole request removes the remaining
  per-chunk launch cost entirely.
- Correctness: PASS. Numbers: {DEV_ROWS[4][1]:.3f} ms first-out,
  {DEV_ROWS[4][3]:.3f} ms total, gap p95 {DEV_ROWS[4][5]:.3f} ms,
  sustained {DEV_ROWS[4][6]:.1f}/s, saturated {DEV_ROWS[4][7]:.1f}/s.
- Δ vs reference: first-out -35 %, total -86 %, sustainable +700 %.
- Verdict: promote (best sustainable rate of the isolated levers, first-out
  worse than `graph_chunk`).

## graph_hybrid  -  dev config
- Hypothesis: chunk 0 alone (fast first output) + bulk region for the rest.
- Correctness: PASS. Numbers: {DEV_ROWS[5][1]:.3f} ms first-out,
  {DEV_ROWS[5][3]:.3f} ms total, gap p95 {DEV_ROWS[5][5]:.3f} ms,
  saturated {DEV_ROWS[5][7]:.1f}/s.
- Δ vs reference: first-out -28 %, total -87 %. But worse first-out than
  `graph_chunk` because the bulk region is enqueued before the publish.
- Verdict: needs-followup -> `graph_split`.

## graph_split (recommended)  -  dev config
- Hypothesis: publish chunk 0 as soon as it is computed, *then* enqueue the
  rest (fixes the ordering flaw of `graph_hybrid`).
- Correctness: PASS (max_abs 7.45e-08 over 6 requests, tolerance
  atol=3e-5/rtol=3e-4), `benchmarks/results/correctness_graph_split_dev_*.json`.
- Numbers:
  - first-out: median {DEV_ROWS[6][1]:.3f} ms, p95 {DEV_ROWS[6][2]:.3f} ms
  - request total (submit -> last chunk): median {DEV_ROWS[6][3]:.3f} ms,
    p95 {DEV_ROWS[6][4]:.3f} ms
  - inter-chunk gap: p95 {DEV_ROWS[6][5]:.3f} ms, over-budget fraction 0.0
  - sustained offered load: {DEV_ROWS[6][6]:.1f} req/s (duty >= 0.98),
    saturated {DEV_ROWS[6][7]:.1f} req/s
- Δ vs reference: first-out -64 %, request total -87 %, sustainable +299 %.
- Verdict: promote. Best first-output latency *and* within 7 % of the best
  saturated rate.

### dev-config table (all measured variants)

{table(DEV_ROWS)}

### large config (C=128, H=256, T=16384, chunk=512, 32 chunks/request)

{table(LARGE_ROWS)}

- `graph_split` on the large config: correctness PASS (max_abs 2.53e-07),
  request total -49 %, gap p95 0.617 ms (vs 1.446 ms), saturated rate +47 %.
- First-output latency on the large config is a **small median regression**
  (3.642 vs 3.202 ms) that is inside the run-to-run spread (p95 3.808 vs
  3.838 ms). Cause is identified: `begin_request` stages the whole 8 MB
  request to the device before chunk 0 runs. Queue entries 7/8 are the fix
  and are unmeasured.

### Measurement caveats (honest limits of these numbers)

- Sustainable-rate and saturated-rate columns are lower bounds: the paced
  sweep generates the synthetic input (`standard_normal`, 8 MB for the large
  config) between requests inside the timed span, which costs ~20 ms per
  request on the large config and is charged to both backends equally.
- 8 measured requests per variant for the latency distribution; the p95 is
  therefore a 2-sample-ish tail estimate.
- All runs are single-process, one request in flight, as the adapter demands;
  no measurement covers concurrent sessions.
"""

readme = """# causal_features backend (optimized, single GPU)

Standalone backend for `flashrt/apps/causal_features`, driven through the
unchanged adapter `flashrt/apps/causal_features/adapter.py`.

## What it computes (unchanged)

Three causal `CausalConv1d` layers (kernel 5/5/3, SiLU after each, weights from
`causal_features.model.build_layers`, seed 703), streamed chunk by chunk, each
layer carrying exactly `kernel_size - 1` samples of its own input as
convolution history. History survives across requests and is cleared by control
opcode 3 (reset). The published value is `silu(layer3(...))`, exactly as the
reference returns it.

## How to launch

```
python flashrt/apps/causal_features/backend/worker.py \\
    --repository <repo root> --config <config.json>
```

`--config` is the JSON config the research harness writes
(`prefix, channels, hidden, length, chunk, weight_seed, device`); the same file
the reference worker takes. Optional `--variant` (default `graph_split`) or the
`CAUSAL_VARIANT` environment variable selects the implementation strategy:

| variant | what it does |
| --- | --- |
| `graph_split` | chunk 0 in its own CUDA graph, published immediately; the remaining chunks fused into one region replay (**recommended**) |
| `graph_bulk` | one graph replay for the whole request, then publish |
| `graph_hybrid` | chunk 0 graph, then bulk region (publish after the region is enqueued) |
| `graph_chunk` | one graph replay + one device sync per chunk |
| `graph_pipelined` | one graph replay per chunk, async D2H, event-ordered publish |
| `eager` | no graphs, plain tensors (ablation) |

The worker creates the seven shared-memory objects the adapter expects, prints
`{"ready": true, ...}`, and removes the segments on exit (including the
terminate path and any exception path).

## Contract details that are easy to get wrong

- Publish order is data first, metadata second; `valid` is
  `min(chunk, length - index*chunk)`; tail padding is zero filled.
- Reset (opcode 3) clears convolution history only. Input/output cursors are
  **not** rewound - both sides keep counting monotonically across resets.
- Only one request may be in flight; a second submit before draining is an
  adapter-side error, and the worker mirrors the reference's
  "Input overwritten before processing" guard.

## Evidence

- Correctness + benchmarks: `benchmarks/results/*.json`
  (correctness files compare six complete requests against the CPU
  full-sequence oracle, tolerance atol=3e-5 / rtol=3e-4).
- Experiment log with the variant queue and every measured number:
  `notes/experiment_log.md`.
- IR conversion + executed validation + analysis:
  `ir/graph_builder.py` (`python flashrt/apps/causal_features/backend/ir/graph_builder.py`).
- Harness: `tests/harness.py` (adapter-driven subprocess driver),
  `tests/test_variant.py` (single correctness run), `tests/suite.py`
  (correctness + benchmark batch), `benchmarks/bench.py` (latency + paced
  offered-load sweep).
"""

(BACKEND / 'notes').mkdir(parents=True, exist_ok=True)
(BACKEND / 'notes' / 'experiment_log.md').write_text(log, encoding='utf-8')
(BACKEND / 'README.md').write_text(readme, encoding='utf-8')
print('wrote notes/experiment_log.md and README.md; IR verdict=%s' % verdict)
