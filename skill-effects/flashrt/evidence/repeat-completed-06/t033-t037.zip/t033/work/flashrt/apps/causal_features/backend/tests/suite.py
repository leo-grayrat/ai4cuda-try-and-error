"""Run a list of (correctness + benchmark) specs in one process, one backend
subprocess each; print one compact JSON line per spec and persist the raw
results under benchmarks/results/.

spec.json = {"entry": "suite", "runs": [{"variant": ..., "worker": "candidate"|"reference",
                                          "base": "dev"|"large", "label": ..., "requests": 24}]}
"""
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'benchmarks'))

import harness  # noqa: E402
import bench  # noqa: E402
sys.path.insert(0, str(harness.REPO_ROOT))

RESULTS = harness.BACKEND_DIR / 'benchmarks' / 'results'


def run_one(spec, stamp):
    base = harness.LARGE_CONFIG if spec.get('base', 'dev') == 'large' else harness.DEV_CONFIG
    is_ref = spec.get('worker', 'candidate') == 'reference'
    worker = harness.REFERENCE if is_ref else harness.WORKER
    variant = None if is_ref else spec.get('variant', 'graph_pipelined')
    label = spec.get('label') or ('%s_%s' % ('reference' if is_ref else variant, spec.get('base', 'dev')))
    n = int(spec.get('requests', 24))
    rates = [int(r) for r in spec.get('rates', bench.RATES)]

    # ---- correctness (six complete requests vs the CPU full-sequence oracle)
    ccfg = harness.make_config('cfq%s%06d' % (label.replace('_', '')[:6], stamp), base)
    t0 = time.time()
    res = harness.run_scenario(worker, ccfg, harness.VERIFY_SCENARIO, variant=variant)
    expected = harness.oracle_requests(ccfg, harness.VERIFY_SCENARIO)
    got = [r['out'] for r in res['requests']]
    if len(got) != len(expected):
        diff = dict(ok=False, reason='collected %d of %d' % (len(got), len(expected)))
    else:
        diff = harness.compare(got, expected)
    corr = dict(ok=bool(diff.get('ok')), max_abs=diff.get('max_abs'),
                max_rel=diff.get('max_rel'), reason=diff.get('reason'),
                requests=len(got), worker_rc=res['returncode'],
                stderr_tail=res['stderr'][-600:] if not diff.get('ok') else '')
    corr_path = RESULTS / ('correctness_%s_%d.json' % (label, stamp))
    corr_path.parent.mkdir(parents=True, exist_ok=True)
    corr_path.write_text(json.dumps(corr, indent=2), encoding='utf-8')

    # ---- benchmark (latency + finite offered-load sweep)
    bcfg = harness.make_config('cfb%s%06d' % (label.replace('_', '')[:6], stamp), base)
    m = bench.measure(worker, bcfg, variant, rates, sweep_n=n)
    sustainable = 0.0
    saturated = 0.0
    for r in m['sweep']:
        if r['duty'] >= 0.98:
            sustainable = max(sustainable, r['achieved_rate'])
        saturated = max(saturated, r['achieved_rate'])
    out = dict(label=label, worker=Path(worker).name, variant=variant, base=spec.get('base', 'dev'),
               config=dict(base), chunks_per_request=-(bcfg['length'] // -bcfg['chunk']),
               chunk_budget_ms=bench.BUDGET_MS, correctness=corr, **m,
               max_sustainable_rate=sustainable, saturated_rate=saturated,
               wall_s=round(time.time() - t0, 2))
    path = RESULTS / ('%s_rtx5060_%d.json' % (label, stamp))
    path.write_text(json.dumps(out, indent=2, default=float), encoding='utf-8')
    lat = m['latency']
    return dict(label=label, base=spec.get('base', 'dev'), correct=corr['ok'], rc=m['returncode'],
                max_abs=corr.get('max_abs'),
                first_med=round(lat['first_stats']['median_ms'], 3),
                first_p95=round(lat['first_stats']['p95_ms'], 3),
                total_med=round(lat['total_stats']['median_ms'], 3),
                total_p95=round(lat['total_stats']['p95_ms'], 3),
                gap_p95=round(lat['gap_stats'].get('p95_ms', 0.0), 3),
                gap_over=lat['gap_stats'].get('over_budget_fraction', 0.0),
                sustain=round(sustainable, 1), saturated=round(saturated, 1),
                sweep=[[r['offered_rate'], round(r['achieved_rate'], 1),
                        round(r['gaps'].get('p95_ms', 0.0), 2)] for r in m['sweep']],
                bench_json=str(path), corr_json=str(corr_path),
                stderr_tail=m['stderr'][-300:])


def main():
    spec = json.loads((HERE / 'spec.json').read_text(encoding='utf-8'))
    runs = spec.get('runs') or [spec]
    stamp = int(time.time() * 1000) % 1000000
    for s in runs:
        line = run_one(s, stamp)
        print(json.dumps(line))
        sys.stdout.flush()
    return 0


if __name__ == '__main__':
    harness.harden('suite')
    try:
        rc = main()
    except BaseException as exc:  # noqa: BLE001
        print(harness.ascii_text(exc))
        rc = 2
    sys.stdout.flush()
    sys.exit(rc)
