"""Finite offered-load sweep + first-output latency for one backend variant.

One backend process is launched per measurement run; every phase (warmup,
latency, paced sweep) is driven through the shared adapter, and the process is
cleanly terminated at the end.

Usage (from repo root):
  python flashrt/apps/causal_features/backend/benchmarks/bench.py --variant graph_pipelined
  python flashrt/apps/causal_features/backend/benchmarks/bench.py --worker reference --label reference

Active targets: latency-to-first-output and maximum sustainable output rate with
the smoothness side condition (inter-chunk gap distribution against the 20 ms
chunk-gap budget).
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

BENCH_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BENCH_DIR / '..' / 'tests'))

import harness  # noqa: E402
sys.path.insert(0, str(harness.REPO_ROOT))

BUDGET_MS = 20.0
RATES = [25, 50, 100, 200, 400, 800, 1600]


def _gaps(gaps, budget=BUDGET_MS):
    if not gaps:
        return dict(count=0)
    arr = np.array(gaps, dtype=np.float64)
    return dict(count=int(arr.size), median_ms=float(np.median(arr)),
                p95_ms=float(np.percentile(arr, 95)), max_ms=float(arr.max()),
                over_budget_fraction=float(np.mean(arr > budget)))


def _drive(adapter, cfg, rng):
    data = rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32)
    rid, t_in = adapter.submit(data)
    stamps = []
    while adapter.pending is not None:
        _out, observed = adapter.receive(timeout_s=120)
        stamps.append(observed)
    return t_in, stamps


def measure(worker, cfg, variant, rates, latency_n=8, sweep_n=24, warm=3):
    from causal_features.adapter import FeatureAdapter

    path = harness.write_config(
        harness.TMP_DIR / ('bench_%s.json' % cfg['prefix']), cfg)
    proc = harness.launch(worker, path, variant=variant, device_index=0)
    adapter = None
    rng = np.random.default_rng(20240607)
    out = dict(latency=dict(first=[], total=[], gaps=[]), sweep=[], stderr='',
               returncode=None, stdout='')
    try:
        adapter = FeatureAdapter(dict(cfg))
        adapter.start()
        for _ in range(warm):
            _drive(adapter, cfg, rng)
        # ---- latency phase: back-to-back requests, session continues ----
        for _ in range(latency_n):
            t_in, stamps = _drive(adapter, cfg, rng)
            out['latency']['first'].append((stamps[0] - t_in) / 1e6)
            out['latency']['total'].append((stamps[-1] - t_in) / 1e6)
            if len(stamps) > 1:
                out['latency']['gaps'].extend(list(np.diff(np.array(stamps, dtype=np.int64)) / 1e6))
        # ---- paced offered-load sweep ----
        for rate in rates:
            period = 1.0 / rate
            starts, dones, first, gaps = [], [], [], []
            t0 = time.perf_counter()
            for i in range(sweep_n):
                target = t0 + i * period
                now = time.perf_counter()
                if target > now:
                    time.sleep(target - now)
                start = time.perf_counter()
                t_in, stamps = _drive(adapter, cfg, rng)
                starts.append(start)
                dones.append(time.perf_counter())
                first.append((stamps[0] - t_in) / 1e6)
                if len(stamps) > 1:
                    gaps.extend(list(np.diff(np.array(stamps, dtype=np.int64)) / 1e6))
            span = dones[-1] - starts[0]
            achieved = (len(starts) - 1) / span if span > 0 else 0.0
            out['sweep'].append(dict(offered_rate=rate, achieved_rate=achieved,
                                     duty=(achieved / rate if rate else 0.0),
                                     first_out_ms=harness.latency_stats(first),
                                     gaps=_gaps(gaps)))
    finally:
        harness.stop(proc, adapter)
        try:
            stdout, stderr = proc.communicate(timeout=10)
            out['stdout'] = (stdout or b'').decode('utf-8', 'replace')[-500:]
            out['stderr'] = (stderr or b'').decode('utf-8', 'replace')[-2000:]
        except Exception:
            pass
        out['returncode'] = proc.returncode
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
    out['latency']['first_stats'] = harness.latency_stats(out['latency']['first'])
    out['latency']['total_stats'] = harness.latency_stats(out['latency']['total'])
    out['latency']['gap_stats'] = _gaps(out['latency']['gaps'])
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--variant', default='graph_pipelined')
    p.add_argument('--worker', default='candidate', choices=['candidate', 'reference'])
    p.add_argument('--base', default='dev', choices=['dev', 'large'])
    p.add_argument('--label', default=None)
    p.add_argument('--rates', default=None)
    p.add_argument('--requests', type=int, default=24)
    p.add_argument('--out', default=None)
    args = p.parse_args()

    base = harness.LARGE_CONFIG if args.base == 'large' else harness.DEV_CONFIG
    label = args.label or args.variant
    worker = harness.WORKER if args.worker == 'candidate' else harness.REFERENCE
    variant = None if args.worker == 'reference' else args.variant
    stamp = int(time.time() * 1000) % 10000000
    rates = [int(r) for r in args.rates.split(',')] if args.rates else RATES
    cfg = harness.make_config('cfb%s%s%d' % (label.replace('_', '')[:6], args.base[:2], stamp), base)

    t0 = time.time()
    m = measure(worker, cfg, variant, rates, sweep_n=args.requests)
    sustainable = 0.0
    for r in m['sweep']:
        if r['duty'] >= 0.98:
            sustainable = max(sustainable, r['achieved_rate'])
    result = dict(label=label, worker=Path(worker).name, variant=variant, base=args.base,
                  config=dict(base), chunks_per_request=-(cfg['length'] // -cfg['chunk']),
                  chunk_budget_ms=BUDGET_MS, **m,
                  max_sustainable_rate=sustainable, wall_s=round(time.time() - t0, 2))
    out = Path(args.out) if args.out else (
        harness.BACKEND_DIR / 'benchmarks' / 'results' /
        ('%s_%s_rtx5060_%d.json' % (label, args.base, stamp)))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, default=float), encoding='utf-8')
    lat = m['latency']
    print(json.dumps(dict(
        label=label, base=args.base, rc=m['returncode'],
        first_out_median_ms=round(lat['first_stats']['median_ms'], 3),
        first_out_p95_ms=round(lat['first_stats']['p95_ms'], 3),
        request_total_median_ms=round(lat['total_stats']['median_ms'], 3),
        request_total_p95_ms=round(lat['total_stats']['p95_ms'], 3),
        gap_p95_ms=round(lat['gap_stats'].get('p95_ms', 0.0), 3),
        gap_over_budget=lat['gap_stats'].get('over_budget_fraction', 0.0),
        max_sustainable_rate=round(sustainable, 1),
        sweep=[[r['offered_rate'], round(r['achieved_rate'], 1),
                round(r['gaps'].get('p95_ms', 0.0), 2),
                round(r['gaps'].get('over_budget_fraction', 0.0), 4)]
               for r in m['sweep']],
        stderr_tail=m['stderr'][-300:],
        result=str(out))))
    return 0


if __name__ == '__main__':
    harness.harden('bench')
    try:
        rc = main()
    except BaseException as exc:  # noqa: BLE001
        print(harness.ascii_text(exc))
        rc = 2
    sys.stdout.flush()
    sys.exit(rc)
