"""Spec-driven runner: workspace.execute takes no CLI arguments, so the run
specification lives in spec.json next to this file.

spec.json = {"entry": "bench" | "test" | "diag", "args": ["--worker", "reference", ...]}
"""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / 'benchmarks'))

import harness  # noqa: E402


def main():
    spec = json.loads((HERE / 'spec.json').read_text(encoding='utf-8'))
    entry = spec.get('entry', 'bench')
    sys.argv = [entry] + list(spec.get('args', []))
    print('RUN %s %s' % (entry, ' '.join(sys.argv[1:])))
    if entry == 'bench':
        import bench
        return bench.main()
    if entry == 'test':
        import test_variant
        return test_variant.main()
    raise SystemExit('unknown entry %r' % (entry,))


if __name__ == '__main__':
    harness.harden('run_spec')
    try:
        rc = main()
    except BaseException as exc:  # noqa: BLE001
        print(harness.ascii_text(exc))
        rc = 2
    sys.stdout.flush()
    sys.exit(rc)
