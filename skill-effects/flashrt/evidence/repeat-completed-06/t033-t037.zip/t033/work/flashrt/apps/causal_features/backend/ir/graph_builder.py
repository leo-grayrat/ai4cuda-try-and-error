"""IR conversion + validation for the causal_features app (Phases 1-2).

Model-level graph: one operator per causal Conv1d layer, each owning exactly
one `chunk_persistent` state object (the layer's `kernel_size - 1` samples of
convolution history) plus a streaming emit operator.  Worker-level graph: IPC
ingest -> composite chunk pipeline -> publish, with rate-conversion metadata on
the streaming edge (one whole request in, `chunk`-sized outputs out).

Run from the repo root:
    python flashrt/apps/causal_features/backend/ir/graph_builder.py

It executes the graph with `SequentialExecutor` over three complete requests
(continuation, reset, repeated input) and compares every chunk against the CPU
full-sequence oracle from `causal_features.model`, then prints the analysis
summary used to rank the deployment variants.
"""
import sys
import types
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from flashrt.ir import (IRGraph, IREdge, IROperator, OpType, SequentialExecutor,
                        StateObject, StreamMode, StreamingInfo, StreamingPattern,
                        TensorPort, summarize_graph)

from flashrt.paths import repo_root as _repo_root
REPO_ROOT = Path(_repo_root())

DEV = dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703, device='cpu')


class CausalConvLayer(IROperator):
    """`CausalConv1d` layer: conv over [history | chunk], history is state."""

    def __init__(self, index, layer):
        self.index = index
        self.weight = layer.conv.weight.detach().clone()
        self.bias = layer.conv.bias.detach().clone()
        self.pad = int(layer._time_causal_padding[0])
        name = 'hist_%d' % index
        super().__init__(
            name='conv_%d' % index,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')],
            outputs=[TensorPort('y')],
            state_reads=[name],
            state_writes=[name],
            stream_mode=StreamMode.BATCH,
            config=dict(pad=self.pad),
        )

    def execute(self, inputs, ctx, state):
        name = 'hist_%d' % self.index
        v = inputs['x']
        hist = state.get(name)
        if getattr(ctx, 'prime', False):
            # session start: the reference feeds a freshly reset history, whose
            # CausalConv1d replicate-pads the first sample of *this layer's*
            # input; equivalently prepend pad copies of it.
            left = v[:, :, :1].expand(-1, -1, self.pad)
        else:
            left = hist
        joined = torch.cat([left, v], dim=-1)
        y = F.conv1d(joined, self.weight, self.bias)
        state.set(name, joined[:, :, -self.pad:].clone())
        return {'y': F.silu(y)}


class EmitChunk(IROperator):
    """Publishes one chunk (data first, metadata after - adapter order)."""

    def __init__(self):
        super().__init__(name='emit_chunk', op_type=OpType.EXPOSED,
                         inputs=[TensorPort('y')], outputs=[TensorPort('chunk')],
                         stream_mode=StreamMode.STREAMING)

    def execute(self, inputs, ctx, state):
        ctx.chunks.append(inputs['y'])
        return {'chunk': inputs['y']}


class IngestRequest(IROperator):
    def __init__(self):
        super().__init__(name='ingest_request', op_type=OpType.BLACK_BOX,
                         inputs=[], outputs=[TensorPort('features')],
                         stream_mode=StreamMode.BATCH)

    def execute(self, inputs, ctx, state):
        return {'features': ctx.features}


class PublishChunks(IROperator):
    def __init__(self, name='publish_chunks'):
        super().__init__(name=name, op_type=OpType.BLACK_BOX,
                         inputs=[TensorPort('chunk')], outputs=[],
                         stream_mode=StreamMode.STREAMING)

    def execute(self, inputs, ctx, state):
        ctx.published.append(inputs['chunk'])
        return {}


def build_model_graph(layers, name='causal_features_model'):
    g = IRGraph(name=name)
    for i, layer in enumerate(layers):
        pad = int(layer._time_causal_padding[0])
        g.add_state(StateObject('hist_%d' % i,
                                'last %d samples of layer %d input' % (pad, i),
                                scope='chunk_persistent'))
        g.add_operator(CausalConvLayer(i, layer))
    g.add_operator(EmitChunk())
    g.external_inputs = [TensorPort('x')]
    g.external_outputs = [TensorPort('chunk')]
    chain = ['conv_%d' % i for i in range(len(layers))] + ['emit_chunk']
    for src, dst in zip(chain, chain[1:]):
        src_port = 'y'
        dst_port = 'x' if dst.startswith('conv') else 'y'
        streaming = None
        if dst == 'emit_chunk':
            streaming = StreamingInfo(StreamingPattern.FIXED_RATE, src_chunk_size=1,
                                      dst_chunk_size=1,
                                      description='one request in, chunk-sized outputs out')
        g.add_edge(IREdge(src, src_port, dst, dst_port, streaming=streaming))
    g.chunk_ops = list(chain)
    return g


def build_worker_graph(layers, config):
    """Application-level graph: ingest -> composite chunk pipeline -> publish."""
    g = IRGraph(name='causal_features_worker')
    model = build_model_graph(layers)
    g.sub_graphs[model.name] = model
    for state in model.state_objects.values():
        g.add_state(StateObject(state.name, state.description, scope=state.scope))
    hist_names = sorted(model.state_objects)
    g.add_operator(IngestRequest())
    g.add_operator(IROperator(
        name='chunk_pipeline', op_type=OpType.COMPOSITE,
        inputs=[TensorPort('features')], outputs=[TensorPort('chunk')],
        state_reads=list(hist_names), state_writes=list(hist_names),
        stream_mode=StreamMode.STREAMING, sub_graph=model.name))
    g.add_operator(PublishChunks())
    g.external_inputs = [TensorPort('features')]
    g.external_outputs = [TensorPort('chunk')]
    g.add_edge(IREdge('ingest_request', 'features', 'chunk_pipeline', 'features',
                      streaming=StreamingInfo(StreamingPattern.FIXED_RATE,
                                              src_chunk_size=config['length'],
                                              dst_chunk_size=config['chunk'],
                                              description='whole request in, chunk cadence out')))
    g.add_edge(IREdge('chunk_pipeline', 'chunk', 'publish_chunks', 'chunk',
                      streaming=StreamingInfo(StreamingPattern.FIXED_RATE,
                                              src_chunk_size=config['chunk'],
                                              dst_chunk_size=config['chunk'],
                                              description='data published before metadata')))
    g.chunk_ops = ['ingest_request', 'chunk_pipeline', 'publish_chunks']
    return g


def run_ir_session(config, seed=1234):
    sys.path.insert(0, str(REPO_ROOT))
    from causal_features.model import build_layers, full_sequence_oracle

    layers = build_layers(str(REPO_ROOT), config, 'cpu')
    graph = build_model_graph(layers)
    executor = SequentialExecutor(graph)
    rng = np.random.default_rng(seed)
    zeros = {name: torch.zeros(1, int(layers[i].conv.weight.shape[1]),
                              int(layers[i]._time_causal_padding[0]))
             for i, name in enumerate(sorted(graph.state_objects))}
    executor.init_state(zeros)

    scenario = ['a', 'b', 'reset', 'a', 'reset', 'a', 'c']
    pool = {}
    got, want = [], []
    segment = []
    for op in scenario:
        if op == 'reset':
            # explicit reset clears convolution history (both backends)
            executor.init_state({k: torch.zeros_like(v) for k, v in zeros.items()})
            segment = []
            continue
        if op not in pool:
            pool[op] = rng.standard_normal((config['channels'], config['length'])).astype(np.float32)
        data = pool[op]
        segment.append(data)
        joined = np.concatenate(segment, axis=1)
        features = torch.from_numpy(data).unsqueeze(0)
        chunks = []
        ctx = types.SimpleNamespace(chunks=chunks, prime=True)
        for k, pos in enumerate(range(0, config['length'], config['chunk'])):
            ctx.prime = (k == 0)
            executor.run_chunk({'x': features[:, :, pos:pos + config['chunk']]}, ctx)
        got.append(torch.cat(chunks, dim=-1)[0].numpy())
        full = full_sequence_oracle(str(REPO_ROOT), config, joined)
        want.append(full[:, joined.shape[1] - config['length']:])
    return graph, got, want


def main():
    import json
    config = dict(DEV)
    graph, got, want = run_ir_session(config)
    atol, rtol = 3e-5, 3e-4
    max_abs = 0.0
    ok = True
    for g, w in zip(got, want):
        d = np.abs(g - w)
        max_abs = max(max_abs, float(d.max()))
        ok = ok and bool(np.all(d <= atol + rtol * np.abs(w)))
    print('IR VALIDATION %s  requests=%d max_abs=%.3e tolerance atol=%g rtol=%g'
          % ('PASS' if ok else 'FAIL', len(got), max_abs, atol, rtol))
    sys.path.insert(0, str(REPO_ROOT))
    from causal_features.model import build_layers
    layers = build_layers(str(REPO_ROOT), config, 'cpu')
    print('=== worker graph ===')
    print(summarize_graph(build_worker_graph(layers, config)))
    print('=== model graph ===')
    print(summarize_graph(graph))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
