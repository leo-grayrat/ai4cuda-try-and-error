"""Standalone optimized backend for the causal_features task.

Usage (same two arguments as the researcher reference):

    python flashrt/apps/causal_features/backend/worker.py \
        --repository <repo root> --config <config.json>

IPC contract: identical to ``causal_features/reference.py`` (see adapter.py) --
same seven shared-memory objects, same level-valued control opcodes
(1 start / 2 terminate / 3 reset), same output ring, data published before
metadata.  Optimization is internal: the per-chunk stateful recursion is
re-associated into a few long causal-conv segments (see cf_engine.py), the
first chunk is published on its own so first-output latency stays minimal, the
rest of the request is streamed out block by block, and the whole segment body
is captured as a CUDA graph when the platform allows it.

Optional extra flags (the adapter contract does not require them):
  --variant {auto,eager,graph,single_pass}   (env CF_VARIANT)
  --block-chunks N                           (env CF_BLOCK_CHUNKS)
"""

import argparse
import json
import os
from pathlib import Path
import sys
import time


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--variant', default=None)
    parser.add_argument('--block-chunks', type=int, default=None)
    args = parser.parse_args(argv)

    repository = str(args.repository.resolve())
    if repository not in sys.path:
        sys.path.insert(0, repository)
    here = str(Path(__file__).resolve().parent)
    if here not in sys.path:
        sys.path.insert(0, here)

    import numpy as np
    import torch
    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers
    import cf_engine

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    variant = args.variant or os.environ.get('CF_VARIANT') or 'auto'
    block_chunks = args.block_chunks or int(os.environ.get('CF_BLOCK_CHUNKS') or 8)
    log = lambda text: print(json.dumps({'log': text}), flush=True)

    layers = build_layers(args.repository, config, config['device'])
    backend = cf_engine.Backend(layers, config, variant=variant,
                               block_chunks=block_chunks, log=log)
    backend.warmup()          # warm cuDNN + graphs before the client attaches
    buffers = open_buffers(config, create=True)
    backend.attach(buffers)

    control = buffers['control']
    input_buffer = buffers['input']
    input_num = input_buffer.num_arr
    input_tensor = input_buffer.tensor
    input_capacity = input_buffer.max_len
    consumed, last_command, active = 0, 0, False
    poll = 0.00002
    try:
        print(json.dumps({'ready': True, 'device': config['device'],
                          'variant': backend.describe()}), flush=True)
        while True:
            opcode = control.recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    control.commit()
                    break
                if opcode == 3:
                    backend.reset()
                    active = False
                    control.commit()
                elif opcode == 1:
                    active = True
                    control.commit()
                elif opcode != 0:
                    raise ValueError('Unknown control opcode: %r' % (opcode,))
            if not active:
                time.sleep(poll)
                continue
            available = int(input_num[0])
            if available <= consumed:
                time.sleep(poll)
                continue
            if available > consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            features = input_tensor[consumed % input_capacity]
            request_id = consumed
            consumed += 1
            backend.run(features, request_id)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
