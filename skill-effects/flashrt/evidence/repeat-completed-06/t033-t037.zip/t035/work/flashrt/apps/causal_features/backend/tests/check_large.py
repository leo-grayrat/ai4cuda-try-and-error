"""Same six-request contract check, but for the larger task case
(C=128, H=256, T=16384, chunk=512) -- the same task, a bigger shape.
Also reports per-request first-chunk latency for both backends at this size.
"""

import sys
import tempfile
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))

from common import ATOL, RTOL, make_config, repo_root  # noqa: E402
from check_backend import run_backend  # noqa: E402
from causal_features.model import full_sequence_oracle  # noqa: E402


def main():
    root = repo_root()
    cfg = make_config(channels=128, hidden=256, length=16384, chunk=512)
    log_dir = Path(tempfile.mkdtemp(prefix='cf_large_'))
    rng = np.random.default_rng(21)
    T = cfg['length']
    a = rng.standard_normal((cfg['channels'], T)).astype(np.float32)
    b = (rng.standard_normal((cfg['channels'], T)) * 0.5).astype(np.float32)
    features = [a, b, a, a, b, a]
    t0 = time.time()
    oracle = full_sequence_oracle(Path(root), cfg, np.concatenate([a, b, a], axis=1))
    print('oracle %.1fs' % (time.time() - t0))
    ref, ref_rc, ref_left, _ = run_backend('reference', cfg, root, log_dir, features)
    print('reference rc=%s leftover=%s first_ms=%s (%.1fs)'
          % (ref_rc, ref_left,
             ['%.2f' % ((r['first'] - r['t_in']) / 1e6) for r in ref],
             time.time() - t0))
    cand, rc, left, _ = run_backend('candidate', cfg, root, log_dir, features,
                                    ('--variant', 'auto'))
    print('candidate rc=%s leftover=%s first_ms=%s' % (
        rc, left, ['%.2f' % ((r['first'] - r['t_in']) / 1e6) for r in cand]))
    ok = rc == 0 and not left
    worst = 0.0
    gaps = []
    for step in range(6):
        mine = np.concatenate(cand[step]['chunks'], axis=1)
        expect = oracle[:, (step % 3) * T:(step % 3 + 1) * T]
        worst = max(worst, float(np.abs(mine - expect).max()))
        bad = int((np.abs(mine - expect) > ATOL + RTOL * np.abs(expect)).sum())
        ok = ok and bad == 0
        stamps = cand[step]['stamps']
        gaps.extend((stamps[k + 1] - stamps[k]) / 1e6 for k in range(len(stamps) - 1))
    same = np.array_equal(np.concatenate(cand[0]['chunks'], axis=1),
                          np.concatenate(cand[3]['chunks'], axis=1))
    print('worst|cand-oracle|=%.3e repeat_after_reset=%s gap_median=%.3fms '
          'gap_p95=%.3fms max=%.3fms' % (worst, same, float(np.median(gaps)),
                                         float(np.percentile(gaps, 95)), float(np.max(gaps))))
    print('VERDICT', 'PASS' if (ok and same) else 'FAIL', 'total %.1fs' % (time.time() - t0))


if __name__ == '__main__':
    main()
