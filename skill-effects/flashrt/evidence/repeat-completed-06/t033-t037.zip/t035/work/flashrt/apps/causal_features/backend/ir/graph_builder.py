"""IR graph builders for the causal_features task (Phase 1)."""

from __future__ import annotations

from flashrt.ir import (IREdge, IRGraph, OpType, StateObject, StreamMode,
                        StreamingInfo, StreamingPattern, TensorPort)

from . import ops


def build_worker_graph(config, layers, publish=None):
    """Worker-level graph: the reference's per-chunk stage schedule."""
    channels, chunk = int(config['channels']), int(config['chunk'])
    graph = IRGraph(name='causal_features_worker')
    graph.external_inputs = [TensorPort('features', (channels, chunk))]
    graph.external_outputs = [TensorPort('chunk_out', (channels, chunk))]

    graph.add_operator(ops.ingest)
    previous = 'ingest'
    for index, layer in enumerate(layers):
        op = ops.CausalLayer(index, layer, channels if index < 2 else channels)
        graph.add_operator(op)
        graph.add_state(StateObject(
            name=op.history,
            description='last kernel-1 input samples of layer %d' % index,
            scope='chunk_persistent'))
        graph.add_edge(IREdge(src_op=previous, src_port='value',
                              dst_op=op.name, dst_port='value',
                              streaming=StreamingInfo(
                                  pattern=StreamingPattern.FIXED_RATE,
                                  src_chunk_size=chunk, dst_chunk_size=chunk,
                                  description='one chunk in, one chunk out')))
        previous = op.name
    graph.add_operator(ops.emit)
    graph.add_edge(IREdge(src_op=previous, src_port='value',
                          dst_op='emit', dst_port='value'))
    graph.chunk_ops = ['ingest'] + [op.name for op in
                                    (graph.operators['layer_%d' % i]
                                     for i in range(len(layers)))] + ['emit']
    errors = graph.validate()
    if errors:
        raise ValueError(errors)
    graph.publish = publish
    return graph


def build_model_graph(config, layer, h, name='layer_model'):
    """Model-level graph: the fine-grained ops of one causal layer."""
    channels = int(config['channels'])
    graph = IRGraph(name=name)
    graph.external_inputs = [TensorPort('value', (1, channels, int(config['chunk'])))]
    graph.external_outputs = [TensorPort('out', (1, channels, int(config['chunk'])))]
    for op in (ops.history_join, ops.causal_conv, ops.causal_slice, ops.silu):
        graph.add_operator(op)
    graph.add_state(StateObject(name='layer_history',
                                description='last h samples entering the layer',
                                scope='chunk_persistent'))
    graph.add_edge(IREdge('history_join', 'joined', 'causal_conv', 'joined',
                          StreamingInfo(pattern=StreamingPattern.FIXED_RATE,
                                        src_chunk_size=int(config['chunk']),
                                        dst_chunk_size=int(config['chunk']))))
    graph.add_edge(IREdge('history_join', 'offset', 'causal_slice', 'offset'))
    graph.add_edge(IREdge('causal_conv', 'full', 'causal_slice', 'full'))
    graph.add_edge(IREdge('causal_slice', 'kept', 'silu', 'kept'))
    graph.chunk_ops = ['history_join', 'causal_conv', 'causal_slice', 'silu']
    errors = graph.validate()
    if errors:
        raise ValueError(errors)
    return graph
