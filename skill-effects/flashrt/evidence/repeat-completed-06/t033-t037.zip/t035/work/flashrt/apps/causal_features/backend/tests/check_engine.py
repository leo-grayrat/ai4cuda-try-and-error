"""In-process check of the segment engine against the research reference. See notes."""

import sys
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))

import cf_engine  # noqa: E402
from common import ATOL, RTOL, make_config, repo_root  # noqa: E402
from causal_features.model import build_layers, full_sequence_oracle, ReferencePipeline  # noqa: E402


class FakeRing:
    """Minimal stand-in for the two shm output rings, adapter-read compatible."""

    def __init__(self, cfg):
        cap = -(-cfg['length'] // cfg['chunk']) + 4
        self.out = np.zeros((cap, cfg['channels'], cfg['chunk']), np.float32)
        self.meta = np.zeros((cap, 3), np.int64)
        self.out_num = np.zeros(1, np.int64)
        self.meta_num = np.zeros(1, np.int64)
        self.consumed = 0
        self.buffers = {
            'output': SimpleNamespace(tensor=self.out, num_arr=self.out_num, max_len=cap),
            'metadata': SimpleNamespace(tensor=self.meta, num_arr=self.meta_num, max_len=cap),
        }

    def take(self, count):
        got = []
        for _ in range(count):
            pos = self.consumed % self.out.shape[0]
            assert self.meta_num[0] > self.consumed, 'metadata not published'
            assert self.out_num[0] > self.consumed, 'data not published before metadata'
            _req, index, valid = (int(v) for v in self.meta[pos])
            assert index == len(got), (index, len(got))
            got.append(self.out[pos][:, :valid].copy())
            self.consumed += 1
        return got


def run_sequence(cfg, features_list, variant, block_chunks=8):
    root = repo_root()
    layers = build_layers(Path(root), cfg, cfg['device'])
    backend = cf_engine.Backend(layers, cfg, variant=variant, block_chunks=block_chunks)
    backend.warmup()
    ring = FakeRing(cfg)
    backend.attach(ring.buffers)
    count = -(-cfg['length'] // cfg['chunk'])
    out = []
    backend.reset()
    for step, features in enumerate(features_list):
        if step == 3:                     # explicit reset between requests
            backend.reset()
        backend.run(features, step)
        out.append(ring.take(count))
    return out, backend


def main():
    t0 = time.time()
    cfg = make_config()
    root = repo_root()
    rng = np.random.default_rng(0)
    T = cfg['length']
    a = rng.standard_normal((cfg['channels'], T)).astype(np.float32)
    b = (rng.standard_normal((cfg['channels'], T)) * 0.5).astype(np.float32)
    features = [a, b, a, a, b, a]         # continuation, repeat, reset, repeat
    print('setup %.1fs root=%s' % (time.time() - t0, root))

    oracle = full_sequence_oracle(Path(root), cfg, np.concatenate([a, b, a], axis=1))
    reference = ReferencePipeline(root, cfg)
    ref_out = []
    for step, f in enumerate(features):
        if step == 3:
            reference.reset()
        ref_out.append([reference.step(f[:, o:o + cfg['chunk']])
                        for o in range(0, T, cfg['chunk'])])
    print('oracle+reference %.1fs' % (time.time() - t0))

    verdicts = {}
    for variant in ('eager', 'graph', 'single_pass'):
        try:
            got, backend = run_sequence(cfg, features, variant)
        except Exception as exc:  # noqa: BLE001
            print('VARIANT %-12s raised %r' % (variant, exc))
            verdicts[variant] = False
            continue
        ok = True
        worst = 0.0
        for step in range(6):
            expected = oracle[:, (step % 3) * T:(step % 3 + 1) * T]
            mine = np.concatenate(got[step], axis=1)
            ref = np.concatenate(ref_out[step], axis=1)
            if mine.shape != expected.shape:
                print('  %s step %d shape %s vs %s' % (variant, step, mine.shape, expected.shape))
                ok = False
                continue
            err_o = float(np.abs(mine - expected).max())
            bad = int((np.abs(mine - expected) > ATOL + RTOL * np.abs(expected)).sum())
            worst = max(worst, err_o, float(np.abs(mine - ref).max()))
            if bad:
                print('  %s step %d FAIL vs oracle: %d elems, max %.3e'
                      % (variant, step, bad, err_o))
                ok = False
        if not np.array_equal(np.concatenate(got[0], axis=1), np.concatenate(got[3], axis=1)):
            diff = float(np.abs(np.concatenate(got[0], axis=1)
                                - np.concatenate(got[3], axis=1)).max())
            print('  %s reset/repeat mismatch max %.3e' % (variant, diff))
            ok = False
        print('VARIANT %-12s %s worst_abs_err=%.3e active=%s'
              % (variant, 'PASS' if ok else 'FAIL', worst, backend.describe()))
        verdicts[variant] = ok

    print('VERDICT', 'PASS' if all(verdicts.values()) else 'FAIL', verdicts,
          'total %.1fs' % (time.time() - t0))


if __name__ == '__main__':
    main()
