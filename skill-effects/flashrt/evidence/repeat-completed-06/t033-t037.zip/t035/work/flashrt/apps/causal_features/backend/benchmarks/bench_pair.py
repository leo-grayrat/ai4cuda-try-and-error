"""Paired offered-load benchmark: reference backend vs. candidate backend.

Both backends are driven through the fixed adapter with the same varied inputs,
in separate processes, over a finite sweep of offered request periods.  For each
period we report (a) latency to first output chunk (median / p95), (b) achieved
output chunk rate, (c) the inter-chunk gap distribution and the fraction of gaps
above the task's 20 ms chunk-gap budget, and (d) whether the backend kept up
(turnaround <= offered period -> the consumer never has to wait).

Usage: python bench_pair.py [variant] [--reps N]
"""

import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[0] / 'tests'))
sys.path.insert(0, str(HERE.parent))

from common import make_config, repo_root  # noqa: E402
from causal_features.adapter import FeatureAdapter  # noqa: E402

PERIODS_MS = (2.0, 4.0, 8.0, 16.0, 32.0, 64.0)
GAP_BUDGET_MS = 20.0
SHM_SUFFIXES = ('__ctrl', '_input__meta', '_input__tensor', '_output__meta',
                '_output__tensor', '_metadata__meta', '_metadata__tensor')


def stats(values):
    if not values:
        return dict(median=float('nan'), p95=float('nan'), max=float('nan'), n=0)
    arr = np.asarray(values, dtype=np.float64)
    return dict(median=float(np.median(arr)), p95=float(np.percentile(arr, 95)),
                max=float(arr.max()), n=int(arr.size))


def run_backend(kind, cfg, root, log_dir, inputs, variant=None, reps=10):
    prefix = '%s_%s' % (kind, uuid.uuid4().hex[:10])
    cfg_path = Path(log_dir) / ('%s.json' % prefix)
    cfg_path.write_text(json.dumps(dict(cfg, prefix=prefix)), encoding='utf-8')
    if kind == 'reference':
        cmd = [sys.executable, '-m', 'causal_features.reference']
    else:
        cmd = [sys.executable, str(HERE.parent / 'worker.py')]
        if variant:
            cmd += ['--variant', variant]
    cmd += ['--repository', root, '--config', str(cfg_path)]
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='0', PYTHONUNBUFFERED='1')
    log = open(Path(log_dir) / ('%s_%s.log' % (kind, prefix)), 'w', encoding='utf-8')
    proc = subprocess.Popen(cmd, cwd=root, stdout=log, stderr=subprocess.STDOUT, env=env)
    adapter = None
    chunks_per_request = -(-cfg['length'] // cfg['chunk'])
    table = []
    cold = None
    try:
        adapter = FeatureAdapter(dict(cfg, prefix=prefix))
        adapter.start()
        for period_ms in PERIODS_MS:
            period = period_ms / 1000.0
            adapter.reset()
            adapter.receive  # noqa: B018  (documentation of the polled path)
            firsts, turns, gaps = [], [], []
            last_stamp = None
            block_start = time.perf_counter()
            kept_up = 0
            for index in range(reps):
                target = block_start + index * period
                delay = target - time.perf_counter()
                if delay > 0:
                    time.sleep(delay)
                request = inputs[index % len(inputs)]
                _rid, t_in = adapter.submit(request)
                stamps = []
                for _ in range(chunks_per_request):
                    _data, stamp = adapter.receive(timeout_s=60)
                    stamps.append(stamp)
                    if last_stamp is not None:
                        gaps.append((stamp - last_stamp) / 1e6)
                    last_stamp = stamp
                firsts.append((stamps[0] - t_in) / 1e6)
                turn = (stamps[-1] - t_in) / 1e6
                turns.append(turn)
                kept_up += int(turn <= period_ms)
            if cold is None:
                cold = firsts[0]
            elapsed = time.perf_counter() - block_start
            produced = len(turns) * chunks_per_request
            table.append(dict(
                offered_period_ms=period_ms,
                kept_up_frac=kept_up / len(turns),
                achieved_requests_per_s=len(turns) / elapsed,
                achieved_chunks_per_s=produced / elapsed,
                first_chunk_ms=stats(firsts),
                turnaround_ms=stats(turns),
                gap_ms=stats(gaps),
                gap_over_budget_frac=float(np.mean(np.asarray(gaps) > GAP_BUDGET_MS)),
            ))
        adapter.terminate()
    finally:
        if adapter is not None:
            adapter.close()
        try:
            proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        log.close()
    leftovers = [n for n in SHM_SUFFIXES if _exists(prefix + n)]
    return dict(table=table, rc=proc.returncode, cold_ms=cold, leftovers=leftovers)


def _exists(name):
    from multiprocessing import shared_memory
    try:
        shm = shared_memory.SharedMemory(name=name, create=False)
    except FileNotFoundError:
        return False
    shm.close()
    return True


def main():
    argv = [a for a in sys.argv[1:]]
    reps = 10
    if '--reps' in argv:
        index = argv.index('--reps')
        reps = int(argv[index + 1])
        del argv[index:index + 2]
    variants = argv or ['auto']
    root = repo_root()
    cfg = make_config()
    log_dir = Path(tempfile.mkdtemp(prefix='cf_bench_'))
    rng = np.random.default_rng(5)
    T = cfg['length']
    inputs = [(rng.standard_normal((cfg['channels'], T)) * scale).astype(np.float32)
              for scale in (1.0, 0.5, 2.0, 0.25)]
    print('logs:', log_dir)

    runs = {'reference': run_backend('reference', cfg, root, log_dir, inputs, reps=reps)}
    for variant in variants:
        runs[variant] = run_backend('candidate', cfg, root, log_dir, inputs,
                                    variant=variant, reps=reps)

    payload = dict(config=cfg, periods_ms=list(PERIODS_MS), gap_budget_ms=GAP_BUDGET_MS,
                   reps=reps, torch=subprocess.run(
                       [sys.executable, '-c', 'import torch; print(torch.__version__)'],
                       capture_output=True, text=True).stdout.strip(),
                   runs=runs)
    out = HERE / 'results'
    out.mkdir(parents=True, exist_ok=True)
    tag = 'pair_%s_%s.json' % (variants[0], time.strftime('%Y%m%d_%H%M%S'))
    (out / tag).write_text(json.dumps(payload, indent=1), encoding='utf-8')

    header = '%-10s %6s %8s %9s %9s %8s %8s %8s %8s %7s' % (
        'backend', 'period', 'keptup', 'req/s', 'chunk/s', 'first50', 'first95',
        'gap50', 'gap95', 'gap>20')
    print(header)
    for name, run in runs.items():
        for row in run['table']:
            print('%-10s %6.1f %8.2f %9.1f %9.1f %8.3f %8.3f %8.3f %8.3f %7.3f' % (
                name, row['offered_period_ms'], row['kept_up_frac'],
                row['achieved_requests_per_s'], row['achieved_chunks_per_s'],
                row['first_chunk_ms']['median'], row['first_chunk_ms']['p95'],
                row['gap_ms']['median'], row['gap_ms']['p95'],
                row['gap_over_budget_frac']))
        print('%-10s cold_first_ms=%.3f rc=%s leftover=%s' % (
            name, run['cold_ms'], run['rc'], run['leftovers']))
    print('wrote', out / tag)


if __name__ == '__main__':
    main()
