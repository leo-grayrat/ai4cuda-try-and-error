"""Phase-4 harness: candidate worker vs. the research reference backend,
both launched as subprocesses and driven through the fixed adapter.

Six complete requests: fresh session, continuation, repeat-without-reset,
explicit reset, repeat-after-reset (must reproduce), continuation after reset.
Every chunk is compared with the CPU full-sequence oracle and with the
reference backend's chunk, using the contract tolerances (atol=3e-5,
rtol=3e-4 -- float32 accumulation-order slack only).

Usage: python check_backend.py [variant ...]
"""

import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))

from common import ATOL, RTOL, make_config, repo_root  # noqa: E402
from causal_features.adapter import FeatureAdapter  # noqa: E402
from causal_features.model import full_sequence_oracle  # noqa: E402

SHM_SUFFIXES = ('__ctrl', '_input__meta', '_input__tensor', '_output__meta',
                '_output__tensor', '_metadata__meta', '_metadata__tensor')


def launch(kind, cfg_path, root, prefix, log_dir, extra=()):
    cfg = json.loads(Path(cfg_path).read_text(encoding='utf-8'))
    cfg['prefix'] = prefix
    Path(cfg_path).write_text(json.dumps(cfg), encoding='utf-8')
    if kind == 'reference':
        cmd = [sys.executable, '-m', 'causal_features.reference']
    else:
        cmd = [sys.executable, str(HERE.parent / 'worker.py')]
    cmd += ['--repository', root, '--config', str(cfg_path)] + list(extra)
    env = dict(os.environ)
    env['CUDA_VISIBLE_DEVICES'] = '0'
    env['PYTHONUNBUFFERED'] = '1'
    log = open(Path(log_dir) / ('%s_%s.log' % (kind, prefix)), 'w', encoding='utf-8')
    proc = subprocess.Popen(cmd, cwd=root, stdout=log, stderr=subprocess.STDOUT, env=env)
    return proc, log


def run_backend(kind, cfg, root, log_dir, features, extra=()):
    """Drive one backend through the whole six-request sequence."""
    prefix = '%s_%s' % (kind, uuid.uuid4().hex[:10])
    cfg_path = Path(log_dir) / ('%s.json' % prefix)
    cfg_path.write_text(json.dumps(cfg), encoding='utf-8')
    cfg = dict(cfg, prefix=prefix)
    proc, log = launch(kind, cfg_path, root, prefix, log_dir, extra)
    adapter = None
    records = []
    try:
        adapter = FeatureAdapter(cfg)
        adapter.start()
        for step, request in enumerate(features):
            if step == 3:
                adapter.reset()
            _rid, t_in = adapter.submit(request)
            chunks, stamps = [], []
            for _ in range(-(-cfg['length'] // cfg['chunk'])):
                data, stamp = adapter.receive(timeout_s=60)
                chunks.append(data.copy())
                stamps.append(stamp)
            records.append(dict(chunks=chunks, t_in=t_in, first=stamps[0],
                                stamps=stamps))
        adapter.terminate()
    finally:
        if adapter is not None:
            adapter.close()
        try:
            proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        log.close()
    leftovers = [s for s in SHM_SUFFIXES
                 if _exists(prefix + s)]
    return records, proc.returncode, leftovers, prefix


def _exists(name):
    from multiprocessing import shared_memory
    try:
        shm = shared_memory.SharedMemory(name=name, create=False)
    except FileNotFoundError:
        return False
    shm.close()
    return True


def main():
    variants = sys.argv[1:] or ['auto']
    root = repo_root()
    base = make_config()
    log_dir = Path(tempfile.mkdtemp(prefix='cf_verify_'))
    rng = np.random.default_rng(11)
    T = base['length']
    a = rng.standard_normal((base['channels'], T)).astype(np.float32)
    b = (rng.standard_normal((base['channels'], T)) * 0.5).astype(np.float32)
    features = [a, b, a, a, b, a]
    oracle = full_sequence_oracle(Path(root), base, np.concatenate([a, b, a], axis=1))

    print('logs:', log_dir)
    t0 = time.time()
    ref_records, ref_rc, ref_left, _ = run_backend('reference', base, root, log_dir, features)
    print('reference rc=%s leftover=%s (%.1fs)'
          % (ref_rc, ref_left, time.time() - t0))

    verdict = True
    for variant in variants:
        recs, rc, left, prefix = run_backend('candidate', base, root, log_dir, features,
                                            ('--variant', variant))
        ok = rc == 0 and not left
        worst_ref = worst_oracle = 0.0
        for step in range(6):
            mine = np.concatenate(recs[step]['chunks'], axis=1)
            theirs = np.concatenate(ref_records[step]['chunks'], axis=1)
            expect = oracle[:, (step % 3) * T:(step % 3 + 1) * T]
            e_ref = float(np.abs(mine - theirs).max())
            e_or = float(np.abs(mine - expect).max())
            bad = int((np.abs(mine - expect) > ATOL + RTOL * np.abs(expect)).sum())
            worst_ref, worst_oracle = max(worst_ref, e_ref), max(worst_oracle, e_or)
            if bad:
                print('  %s step %d: %d elements outside contract tolerance (max %.3e)'
                      % (variant, step, bad, e_or))
                ok = False
        same = np.array_equal(np.concatenate(recs[0]['chunks'], axis=1),
                              np.concatenate(recs[3]['chunks'], axis=1))
        shapes = {(c.shape[1]) for r in recs for c in r['chunks']}
        print('VARIANT %-12s %s rc=%s leftover=%s repeat_after_reset=%s '
              'chunk_widths=%s max|cand-ref|=%.3e max|cand-oracle|=%.3e'
              % (variant, 'PASS' if ok else 'FAIL', rc, left, same, sorted(shapes),
                 worst_ref, worst_oracle))
        verdict = verdict and ok and same
    print('VERDICT', 'PASS' if verdict else 'FAIL', 'elapsed %.1fs' % (time.time() - t0))


if __name__ == '__main__':
    main()
