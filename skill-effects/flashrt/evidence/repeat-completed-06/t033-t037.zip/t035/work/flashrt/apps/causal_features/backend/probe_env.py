"""Environment / spec probe: prints CausalConv1d source and basic timing facts."""
import ast
import inspect
from pathlib import Path

import torch

import flashrt

root = Path(flashrt.__file__).resolve().parent.parent
src = (root / 'flashrt/layers/audio.py').read_text(encoding='utf-8')
node = next(n for n in ast.parse(src).body
            if isinstance(n, ast.ClassDef) and n.name == 'CausalConv1d')
print('--- CausalConv1d source ---')
print(ast.get_source_segment(src, node))
print('--- torch ---')
print(torch.__version__, torch.version.cuda)
print('cuda avail', torch.cuda.is_available(), torch.cuda.device_count())
if torch.cuda.is_available():
    print(torch.cuda.get_device_name(0))
print('repo root', root)
