"""Unpaced latency + intra-request smoothness measurement (paired).

Requests are submitted back to back (the adapter contract allows only one in
flight, so this is the minimum possible offered period).  For each backend we
report latency-to-first-chunk and the inter-chunk gap distribution *within* a
request, plus the fraction of gaps over the 20 ms chunk-gap budget.

Usage: python bench_gaps.py [--reps N] [variant]
"""

import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[0] / 'tests'))
sys.path.insert(0, str(HERE.parent))

from common import make_config, repo_root  # noqa: E402
from causal_features.adapter import FeatureAdapter  # noqa: E402

BUDGET_MS = 20.0


def stats(values):
    arr = np.asarray(values, dtype=np.float64)
    return dict(median=float(np.median(arr)), p95=float(np.percentile(arr, 95)),
                max=float(arr.max()), n=int(arr.size))


def run(kind, cfg, root, log_dir, inputs, variant=None, reps=15):
    prefix = '%s_%s' % (kind, uuid.uuid4().hex[:10])
    cfg_path = Path(log_dir) / ('%s.json' % prefix)
    cfg_path.write_text(json.dumps(dict(cfg, prefix=prefix)), encoding='utf-8')
    if kind == 'reference':
        cmd = [sys.executable, '-m', 'causal_features.reference']
    else:
        cmd = [sys.executable, str(HERE.parent / 'worker.py')]
        if variant:
            cmd += ['--variant', variant]
    cmd += ['--repository', root, '--config', str(cfg_path)]
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='0', PYTHONUNBUFFERED='1')
    log = open(Path(log_dir) / ('%s_%s.log' % (kind, prefix)), 'w', encoding='utf-8')
    proc = subprocess.Popen(cmd, cwd=root, stdout=log, stderr=subprocess.STDOUT, env=env)
    adapter = None
    first, turn, gaps = [], [], []
    chunks = -(-cfg['length'] // cfg['chunk'])
    try:
        adapter = FeatureAdapter(dict(cfg, prefix=prefix))
        adapter.start()
        adapter.reset()
        for index in range(reps):
            _rid, t_in = adapter.submit(inputs[index % len(inputs)])
            stamps = []
            for _ in range(chunks):
                _data, stamp = adapter.receive(timeout_s=60)
                stamps.append(stamp)
            first.append((stamps[0] - t_in) / 1e6)
            turn.append((stamps[-1] - t_in) / 1e6)
            gaps.extend((stamps[k + 1] - stamps[k]) / 1e6 for k in range(len(stamps) - 1))
        adapter.terminate()
    finally:
        if adapter is not None:
            adapter.close()
        try:
            proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        log.close()
    return dict(first_ms=stats(first), turnaround_ms=stats(turn), gap_ms=stats(gaps),
                gap_over_budget_frac=float(np.mean(np.asarray(gaps) > BUDGET_MS)),
                rc=proc.returncode, chunks_per_request=chunks)


def main():
    argv = sys.argv[1:]
    reps = 15
    if '--reps' in argv:
        i = argv.index('--reps')
        reps = int(argv[i + 1])
        del argv[i:i + 2]
    variants = argv or ['auto']
    root, cfg = repo_root(), make_config()
    log_dir = Path(tempfile.mkdtemp(prefix='cf_gaps_'))
    rng = np.random.default_rng(7)
    T = cfg['length']
    inputs = [(rng.standard_normal((cfg['channels'], T)) * s).astype(np.float32)
              for s in (1.0, 0.5, 2.0, 0.25, 0.75)]
    runs = {'reference': run('reference', cfg, root, log_dir, inputs, reps=reps)}
    for variant in variants:
        runs[variant] = run('candidate', cfg, root, log_dir, inputs, variant=variant, reps=reps)
    out = HERE / 'results'
    out.mkdir(parents=True, exist_ok=True)
    tag = 'gaps_%s_%s.json' % (variants[0], time.strftime('%Y%m%d_%H%M%S'))
    (out / tag).write_text(json.dumps(dict(config=cfg, reps=reps, budget_ms=BUDGET_MS,
                                           runs=runs), indent=1), encoding='utf-8')
    print('%-10s %8s %8s %8s %8s %8s %8s %8s %8s' % (
        'backend', 'first50', 'first95', 'turn50', 'turn95', 'gap50', 'gap95',
        'gapmax', 'gap>20'))
    for name, r in runs.items():
        print('%-10s %8.3f %8.3f %8.3f %8.3f %8.4f %8.4f %8.4f %8.3f' % (
            name, r['first_ms']['median'], r['first_ms']['p95'],
            r['turnaround_ms']['median'], r['turnaround_ms']['p95'],
            r['gap_ms']['median'], r['gap_ms']['p95'], r['gap_ms']['max'],
            r['gap_over_budget_frac']))
    print('wrote', out / tag)


if __name__ == '__main__':
    main()
