"""Shared helpers for the causal_features backend harnesses."""

import sys
from pathlib import Path

ATOL, RTOL = 3e-5, 3e-4


def repo_root():
    """Directory that contains ``flashrt/layers/audio.py`` (the --repository arg)."""
    import flashrt
    return str(Path(flashrt.__file__).resolve().parent.parent)


def add_backend_path():
    here = Path(__file__).resolve().parent
    backend = str(here.parent)
    if backend not in sys.path:
        sys.path.insert(0, backend)
    return backend


def make_config(prefix='cf_test', **over):
    cfg = dict(prefix=prefix, channels=16, hidden=32, length=1043, chunk=127,
               weight_seed=703, device='cuda:0')
    cfg.update(over)
    return cfg


def n_chunks(cfg):
    return -(-cfg['length'] // cfg['chunk'])


def assemble(chunks):
    import numpy as np
    return np.concatenate(chunks, axis=1)
