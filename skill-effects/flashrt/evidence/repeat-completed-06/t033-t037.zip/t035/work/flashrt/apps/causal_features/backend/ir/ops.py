"""IR operators for the causal_features pipeline (Phase 1).

Two levels, both carrying their own ``execute``:

* worker level  -- ``ingest`` -> ``CausalLayer`` x3 -> ``emit``, i.e. the
  reference worker's per-chunk stage schedule.  Each layer owns one
  ``chunk_persistent`` history state, which is what makes the state
  dependencies (and therefore the cross-chunk constraints) explicit.
* model level   -- inside one layer: ``history_join`` -> ``causal_conv`` ->
  ``causal_slice`` -> ``silu``.  ``history_join`` is the only op that touches
  the persistent history, so the analysis tools see that every other op in a
  layer is state independent.

The op bodies reproduce the reference arithmetic exactly (cat + replicate pad +
slice), so a validated IR is a statement about the reference, not about the
optimized engine.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F

from flashrt.ir import (IROperator, OpType, StreamMode, TensorPort, ir_operator)


@ir_operator(
    name='ingest',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('features', ('C', 'chunk'))],
    outputs=[TensorPort('value', (1, 'C', 'chunk'))],
    config={'note': 'one chunk of the request arrives fully materialised in the '
                    'input ring; no cross-chunk state'},
)
def ingest(inputs, ctx, state):
    value = torch.from_numpy(inputs['features'].copy()).unsqueeze(0).to(ctx.device)
    return {'value': value}


class CausalLayer(IROperator):
    """One reference layer step: history join, causal conv, slice, SiLU."""

    def __init__(self, index: int, layer, channels: int):
        history = 'history_%d' % index
        super().__init__(
            name='layer_%d' % index,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('value', (1, channels, 'chunk'))],
            outputs=[TensorPort('value', (1, channels, 'chunk'))],
            state_reads=[history],
            state_writes=[history],
            stream_mode=StreamMode.STREAMING,
            config={'kernel': int(layer._time_causal_padding[0])},
        )
        self.history = history
        self.layer = layer

    def execute(self, inputs, ctx, state):
        history = state.get(self.history)
        value = inputs['value']
        joined = value if history is None else torch.cat([history, value], dim=-1)
        result = self.layer(joined)
        if history is not None:
            result = result[:, :, history.shape[-1]:]
        state.set(self.history, joined[:, :, -self.layer._time_causal_padding[0]:].clone())
        return {'value': F.silu(result)}


@ir_operator(
    name='emit',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('value', (1, 'C', 'chunk'))],
    outputs=[TensorPort('chunk_out', ('C', 'chunk'))],
    config={'note': 'publish data into the output ring, then metadata'},
)
def emit(inputs, ctx, state):
    value = inputs['value'].squeeze(0)
    if ctx.publish is not None:
        ctx.publish(value)
    return {'chunk_out': value}


# ------------------------------------------------------------------ model level

@ir_operator(
    name='history_join',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('value', (1, 'C', 'chunk'))],
    outputs=[TensorPort('joined', (1, 'C', 'chunk+h')),
             TensorPort('offset', ())],
    state_reads=['layer_history'],
    state_writes=['layer_history'],
    config={'note': 'only stateful op inside a layer; h = kernel-1'},
)
def history_join(inputs, ctx, state):
    history = state.get('layer_history')
    value = inputs['value']
    h = ctx.h
    if history is None:
        joined, offset = value, 0
    else:
        joined, offset = torch.cat([history, value], dim=-1), h
    state.set('layer_history', joined[:, :, -h:].clone())
    return {'joined': joined, 'offset': offset}


@ir_operator(
    name='causal_conv',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('joined', (1, 'C', 'chunk+h'))],
    outputs=[TensorPort('full', (1, 'C2', 'chunk+h'))],
    config={'note': 'CausalConv1d: replicate_left_pad(h) then conv1d'},
)
def causal_conv(inputs, ctx, state):
    return {'full': ctx.layer(inputs['joined'])}


@ir_operator(
    name='causal_slice',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('full', (1, 'C2', 'chunk+h')), TensorPort('offset', ())],
    outputs=[TensorPort('kept', (1, 'C2', 'chunk'))],
    config={'note': 'drop the h warm-up positions (0 on the first chunk)'},
)
def causal_slice(inputs, ctx, state):
    offset = inputs['offset']
    return {'kept': inputs['full'][:, :, offset:]}


@ir_operator(
    name='silu',
    op_type=OpType.EXPOSED,
    inputs=[TensorPort('kept', (1, 'C2', 'chunk'))],
    outputs=[TensorPort('out', (1, 'C2', 'chunk'))],
)
def silu(inputs, ctx, state):
    return {'out': F.silu(inputs['kept'])}
