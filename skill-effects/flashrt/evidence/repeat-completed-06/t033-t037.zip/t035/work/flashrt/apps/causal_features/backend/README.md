# causal_features backend (optimized, single RTX 5060)

Drop-in replacement for `flashrt/apps/causal_features/reference.py`: same two
arguments, same adapter contract (7 shared-memory objects, control opcodes
1 start / 2 terminate / 3 reset, output ring published data-then-metadata).

```
python flashrt/apps/causal_features/backend/worker.py \
    --repository <repo root containing flashrt/layers/audio.py> \
    --config <config.json with prefix/channels/hidden/length/chunk/weight_seed/device>
```
Optional: `--variant {auto,eager,graph,single_pass}` (env `CF_VARIANT`),
`--block-chunks N` (env `CF_BLOCK_CHUNKS`, default 8).

Layout: `worker.py` (IPC loop) · `cf_engine.py` (segment engine + CUDA-graph
segments + publisher) · `ir/` (worker- and model-level IR) · `tests/`
(`check_engine.py`, `check_ir.py`, `check_backend.py`, `check_large.py`) ·
`benchmarks/` (`bench_pair.py`, `bench_gaps.py`, `results/`) ·
`notes/experiment_log.md`.

Re-run evidence (each prints a PASS/FAIL verdict):

```
python flashrt/apps/causal_features/backend/tests/check_ir.py
python flashrt/apps/causal_features/backend/tests/check_engine.py
python flashrt/apps/causal_features/backend/tests/check_backend.py auto
python flashrt/apps/causal_features/backend/tests/check_large.py
python flashrt/apps/causal_features/backend/benchmarks/bench_pair.py auto
python flashrt/apps/causal_features/backend/benchmarks/bench_gaps.py
```

Result summary: bit-identical to the reference on the dev case, 6.7e-8 vs the
CPU full-sequence oracle (contract tolerance atol 3e-5 / rtol 3e-4); first-chunk
latency p95 1.3 ms vs 41 ms; intra-request chunk gaps 4 µs vs 530 µs median;
sustains the full contract offer down to a 2 ms request period (4554 chunks/s)
where the reference tops out near 1141 chunks/s. See `notes/experiment_log.md`.
