"""Segment-wise re-association engine for the causal_features task.

Reference semantics (``causal_features/reference.py`` + ``CausalConv1d``), per
chunk and per layer ``l`` with ``h_l = kernel_l - 1`` (``_time_causal_padding``):

    joined = cat([hist_l, value])          # first chunk of a session: joined = value
    y      = conv1d(replicate_left_pad(joined, h_l), w_l, b_l)
    keep   = y[..., h_l:]                  # first chunk: keep = y
    hist_l = joined[..., -h_l:]
    value  = silu(keep)

Every kept position ``i >= h_l`` of the padded conv has its whole window inside
``joined``, so ``keep`` equals ``conv1d(cat([hist_l, value]), w_l, b_l)`` with
*valid* padding.  Feeding a longer segment through the same recursion therefore
consumes exactly the same input values per output position: it is a legal
re-association (only the accumulation order over a longer sequence changes, the
same freedom the CPU full-sequence oracle in ``model.py`` already uses).

That lets one request be processed as a handful of long segments instead of
``ceil(T/chunk)`` tiny chunk steps, while session state (per-layer history, or
the "session not started yet" replicate padding) is preserved exactly.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F


def _layer(hist, value, weight, bias, h, new_hist):
    """One causal layer. ``hist=None`` means "start of session" (replicate pad)."""
    if hist is None:
        out = F.conv1d(F.pad(value, (h, 0), mode='replicate'), weight, bias)
        tail = value[:, :, -h:]
    else:
        joined = torch.cat([hist, value], dim=-1)
        out = F.conv1d(joined, weight, bias)
        tail = joined[:, :, -h:]
    if new_hist is None:
        return out, tail.clone()
    new_hist.copy_(tail)
    return out, new_hist


class CausalEngine:
    """Fixed-weight causal stack with persistent per-layer history."""

    def __init__(self, layers, config):
        self.channels = int(config['channels'])
        self.chunk = int(config['chunk'])
        self.total = int(config['length'])
        self.n_chunks = -(-self.total // self.chunk)
        self.weights = [layer.conv.weight for layer in layers]
        self.biases = [layer.conv.bias for layer in layers]
        self.kernels = [int(layer._time_causal_padding[0]) for layer in layers]
        self.device = self.weights[0].device
        self.hist_buffers = [
            torch.zeros((1, w.shape[1], h), device=self.device, dtype=torch.float32)
            for w, h in zip(self.weights, self.kernels)
        ]
        self.fresh = True  # no history yet -> replicate-pad branch

    def reset(self):
        self.fresh = True

    def segment(self, value, fresh):
        """Run the whole stack over ``value`` (1, C, L) and update history."""
        hists = [None] * len(self.weights) if fresh else list(self.hist_buffers)
        for i in range(len(self.weights)):
            out, _ = _layer(hists[i], value, self.weights[i], self.biases[i],
                            self.kernels[i], self.hist_buffers[i])
            value = F.silu(out)
        return value

    def plan(self, block_chunks, single_pass=False):
        """Publish plan: the first chunk alone, then blocks of `block_chunks`."""
        if single_pass:
            return [dict(c0=0, count=self.n_chunks, off=0, L=self.total)]
        blocks = [dict(c0=0, count=1, off=0, L=min(self.chunk, self.total))]
        index = 1
        while index < self.n_chunks:
            count = min(int(block_chunks), self.n_chunks - index)
            off = index * self.chunk
            length = min(count * self.chunk, self.total - off)
            blocks.append(dict(c0=index, count=count, off=off, L=length))
            index += count
        return blocks


class _GraphSeg:
    """One captured segment: pinned in -> H2D -> stack -> D2H -> pinned out."""

    def __init__(self, engine, length, fresh, pool):
        self.engine = engine
        self.length = int(length)
        self.fresh = bool(fresh)
        channels = engine.channels
        self.d_in = torch.empty((1, channels, self.length), device=engine.device,
                                dtype=torch.float32)
        self.p_in = torch.empty((1, channels, self.length), dtype=torch.float32,
                                pin_memory=True)
        self.p_out = torch.empty((1, channels, self.length), dtype=torch.float32,
                                 pin_memory=True)
        self.p_in_np = self.p_in[0].numpy()
        self.p_out_np = self.p_out[0].numpy()
        side = torch.cuda.Stream(device=engine.device)
        side.wait_stream(torch.cuda.current_stream(engine.device))
        with torch.cuda.stream(side):
            for _ in range(3):
                self._body()
        torch.cuda.current_stream(engine.device).wait_stream(side)
        self.graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self.graph, pool=pool):
            self._body()
        self.event = torch.cuda.Event()

    def _body(self):
        self.d_in.copy_(self.p_in, non_blocking=True)
        out = self.engine.segment(self.d_in, self.fresh)
        self.p_out.copy_(out[0], non_blocking=True)
        return out

    def submit(self, host_frame):
        np.copyto(self.p_in_np, host_frame)
        self.graph.replay()
        self.event.record()


class Backend:
    """Request driver: segment plan, device buffers, CUDA-graph fast path."""

    def __init__(self, layers, config, variant='auto', block_chunks=8, log=None):
        self.log = log or (lambda *a: None)
        self.engine = CausalEngine(layers, config)
        self.variant = variant
        self.chunk = self.engine.chunk
        self.total = self.engine.total
        self.channels = self.engine.channels
        block_chunks = block_chunks or 8
        self.plan = self.engine.plan(block_chunks, single_pass=(variant == 'single_pass'))
        self.buffers = None
        self.blocks = []
        self.graph_ok = False
        self._prepare(block_chunks)

    # ---------------------------------------------------------------- setup
    def _prepare(self, block_chunks):
        device = self.engine.device
        for block in self.plan:
            entry = dict(block)
            entry['pin'] = torch.empty((self.channels, block['L']), dtype=torch.float32,
                                       pin_memory=True)
            entry['pin_np'] = entry['pin'].numpy()
            entry['dev'] = torch.empty((1, self.channels, block['L']), device=device,
                                       dtype=torch.float32)
            entry['out'] = torch.empty((self.channels, block['L']), dtype=torch.float32,
                                       pin_memory=True)
            entry['out_np'] = entry['out'].numpy()
            entry['event'] = torch.cuda.Event()
            entry['graph'] = None
            entry['graph_fresh'] = None
            self.blocks.append(entry)

        if self.variant in ('graph', 'auto'):
            try:
                pool = torch.cuda.graphs.graph_pool_handle()
                for index, entry in enumerate(self.blocks):
                    entry['graph'] = _GraphSeg(self.engine, entry['L'], False, pool)
                    if index == 0:
                        entry['graph_fresh'] = _GraphSeg(self.engine, entry['L'], True, pool)
                self.graph_ok = True
                self.log('cuda-graph capture ok (%d segments)' % len(self.blocks))
            except Exception as exc:  # pragma: no cover - hardware dependent
                self.graph_ok = False
                for entry in self.blocks:
                    entry['graph'] = None
                    entry['graph_fresh'] = None
                torch.cuda.synchronize()
                self.log('cuda-graph capture failed, falling back to eager: %r' % (exc,))
        self.names = []

    def attach(self, buffers):
        self.buffers = buffers
        out = buffers['output']
        meta = buffers['metadata']
        self.out_tensor = out.tensor
        self.meta_tensor = meta.tensor
        self.out_num = out.num_arr
        self.meta_num = meta.num_arr
        self.cap = out.max_len
        self.meta_cap = meta.max_len

    def reset(self):
        self.engine.reset()

    def describe(self):
        if self.graph_ok:
            return 'graph' if self.variant in ('graph', 'auto') else self.variant
        return 'eager' if self.variant in ('graph', 'auto') else self.variant

    def warmup(self):
        """Touch every code path so the first real request is not special."""
        host = np.zeros((self.channels, self.total), dtype=np.float32)
        self.engine.reset()
        self._compute(host, publish=False)
        self.engine.reset()

    # ------------------------------------------------------------- request
    def run(self, features, request_id):
        self._compute(features, publish=True, request_id=request_id)

    def _compute(self, features, publish, request_id=0):
        engine = self.engine
        fresh = engine.fresh
        pending = None
        for entry in self.blocks:
            length = entry['L']
            off = entry['off']
            graph = entry['graph_fresh'] if (fresh and entry['graph_fresh'] is not None) \
                else entry['graph']
            if graph is not None:
                if fresh:
                    frame = np.ascontiguousarray(features[:, off:off + length])
                else:
                    frame = features[:, off:off + length]
                graph.submit(frame)
                event, host = graph.event, graph.p_out_np
            else:
                np.copyto(entry['pin_np'], features[:, off:off + length])
                entry['dev'].copy_(entry['pin'], non_blocking=True)
                out = engine.segment(entry['dev'], fresh)
                entry['out'].copy_(out[0], non_blocking=True)
                event, host = entry['event'], entry['out_np']
                event.record()
            fresh = False
            if pending is not None:
                pending[0].synchronize()
                if publish:
                    self._publish(pending[1], pending[2], request_id)
            pending = (event, entry, host)
        engine.fresh = False
        if pending is not None:
            pending[0].synchronize()
            if publish:
                self._publish(pending[1], pending[2], request_id)

    # ------------------------------------------------------------ publish
    def _publish(self, entry, host, request_id):
        """Write data into the shm ring first, then publish the metadata."""
        tensor = self.out_tensor
        meta = self.meta_tensor
        cap = self.cap
        chunk = self.chunk
        first = int(self.out_num[0])
        count = entry['count']
        c0 = entry['c0']
        for j in range(count):
            absolute = c0 + j
            valid = min(chunk, self.total - absolute * chunk)
            slot = tensor[(first + j) % cap]
            np.copyto(slot[:, :valid], host[:, j * chunk:j * chunk + valid])
            if valid != chunk:
                slot[:, valid:] = 0.0
            row = meta[(first + j) % self.meta_cap]
            row[0] = request_id
            row[1] = absolute
            row[2] = valid
        total = first + count
        self.out_num[0] = total
        self.meta_num[0] = total
