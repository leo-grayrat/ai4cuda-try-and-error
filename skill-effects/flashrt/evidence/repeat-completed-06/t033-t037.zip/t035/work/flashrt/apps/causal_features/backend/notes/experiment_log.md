# Experiment log — causal_features backend (RTX 5060 8GB, Windows, torch 2.11.0+cu128)

Recommended entry: `flashrt/apps/causal_features/backend/worker.py`
(`--repository <repo root> --config <config.json>`), default variant `auto`
(CUDA-graph segments, eager fallback).

## 0. Task model (from CONTRACT.zh.md / model.py / reference.py / adapter.py)

Three fixed `CausalConv1d` layers (C→H→H→C, kernels 5/5/3, SiLU after each),
seeded 703. Per chunk the reference does, per layer, `joined = cat([hist, value])`
→ `CausalConv1d.forward` = `F.pad(x, (k-1,0), mode='replicate')` + `conv1d` →
drop the first `hist` outputs → `silu` → keep `hist = joined[..., -(k-1):]`.
First chunk of a session has no history, so the replicate pad of the *first
sample* is the whole "initial state". One request at a time; output ring
capacity is `ceil(T/chunk)+4`, so a whole request always fits in the ring;
`reset` must clear layer history but **not** the ring cursors.

Key numeric fact: kept position `i >= k-1` of the padded conv has its full window
inside `joined`, so `keep == conv1d(cat([hist, value]), w, b)` (valid padding).
Re-associating chunks into long segments therefore consumes exactly the same
input values per output position — only the accumulation order changes, the
same freedom `full_sequence_oracle` already uses. Measured: identical bits to
the reference on the dev case (`max|cand-ref| = 0.0`), 6.7e-8 vs the CPU oracle.

## 1. IR (Phase 1–2)

`ir/ops.py`, `ir/graph_builder.py`; validation `tests/check_ir.py`.

* worker graph: `ingest → layer_0 → layer_1 → layer_2 → emit`, one
  `chunk_persistent` history per layer, 3 fixed-rate 1:1 streaming edges.
* model graph: `history_join → causal_conv → causal_slice → silu`; only
  `history_join` touches `layer_history`.
* Validation: `SequentialExecutor` over 6 requests (continuation, repeat,
  reset, tail chunk): `max|ir-oracle| = 7.5e-8`, 0 elements outside
  atol=3e-5/rtol=3e-4, reset reproduces request 0 exactly → **PASS**.
  Model-level graph: `max|diff| = 5.96e-8` = 1 fp32 ULP (my harness printed
  FAIL for that line only because it demanded bit equality; it is inside the
  contract tolerance).
* `summarize_graph` on the worker graph: 5 pipeline stages (one per op),
  cross-chunk dependent pairs are the self-loops `layer_i ←(history_i)→
  layer_i` only; every other pair is cross-chunk independent; critical path =
  ingest+3 convs+emit per chunk; 3 streaming overlaps at ratio 1:1.

**Derived hypotheses** (all tested):
H1 (pipeline layer): the 3 layers are cross-chunk independent → on one GPU the
win is not device parallelism but eliminating per-chunk launch/copy overhead
(14+ kernel launches and 3 D2H syncs per chunk in the reference).
H2 (re-association): because kept outputs never depend on the pad, a request can
be run as a few long segments; cost per output sample collapses and the tail
becomes compute-bound instead of launch-bound.
H3 (latency): chunk 0 depends only on the first `chunk` input samples, so it can
be computed and published alone before the rest.
H4 (overhead): with only ~1e5 FLOP per chunk the remaining latency is pure
launch/Python overhead → CUDA-graph capture of the segment body should help.

## 2. Variants and measurements

Variants: `eager` (segment plan, no graphs), `graph`/`auto` (same plan, body
captured as CUDA graphs), `single_pass` (whole request in one segment — kept as
the latency/batching trade-off control). Block plan: chunk 0 alone, then blocks
of 8 chunks, D2H double-buffered one block behind the publish.

Correctness (all three variants PASS, `tests/check_engine.py`), 6 requests:
worst |cand−oracle| 6.7e-8 (dev), 2.4e-7 (large); `max|cand−reference| = 0.0`
(dev, through the adapter, `tests/check_backend.py`); repeat-after-reset exact;
shm: no leftovers; both processes exit 0.

Latency / smoothness, dev case (C=16,T=1043,chunk=127), unpaced, 15 requests
(`benchmarks/results/gaps_auto_*.json`):

| backend | first-chunk med | first p95 | turnaround med | gap med | gap p95 | gap max | frac>20ms |
|---|---|---|---|---|---|---|---|
| reference | 1.063 ms | 41.419 ms | 5.280 ms | 0.532 ms | 0.995 ms | 12.80 ms | 0 |
| candidate (`auto`) | 0.988 ms | 1.344 ms | 1.026 ms | 0.0042 ms | 0.0082 ms | 0.0119 ms | 0 |

Offered-load sweep (`benchmarks/results/pair_auto_*.json`, 4 varied inputs,
10 requests per period, kept-up fraction = fraction of requests whose
turnaround fit the offered period):

| period | ref kept-up | ref chunk/s | cand kept-up | cand chunk/s |
|---|---|---|---|---|
| 2 ms | 0.00 | 349 (queued) | 1.00 | 4554 |
| 4 ms | 0.00 | 1475 (max) | 1.00 | 2412 |
| 8 ms | 0.80 | 1141 | 1.00 | 1231 |
| 16 ms | 1.00 | 598 | 1.00 | 619 |

→ reference sustainable rate ≈ 1141 chunks/s (~0.9 request/8 ms); candidate
holds the contract's 20 ms chunk budget down to a 2 ms offered period
(4554 chunks/s measured, ≥4× the reference's ceiling), with intra-request gaps
two orders of magnitude tighter (4 µs vs 530 µs median).
Large case (C=128,T=16384,chunk=512): first chunk 0.93–2.07 ms (cold 2.07) vs
reference 2.9–3.9 ms (cold 137 ms); gaps med 0.17 ms, max 2.17 ms.
Cold start: reference 177 ms / 137 ms, candidate 1.0 ms / 2.1 ms.

## 3. Failures, dead ends, trade-offs

* `first-chunk` measurement floor: the adapter polls metadata with
  `time.sleep(2e-4)`, which on Windows rounds up to ~1 ms, so *both* backends'
  first-chunk numbers are floored near 1 ms; the candidate's real GPU work per
  first chunk is ~50 µs. The 1.06 vs 0.99 medians understate the gap; the p95
  (41.4 vs 1.3 ms) and turnaround (5.3 vs 1.0 ms) show it honestly.
* First IR run failed with `Can't call numpy() on Tensor that requires grad`
  (`SequentialExecutor` does not run under `inference_mode`); fixed by
  `torch.set_grad_enabled(False)` in the harness.
* Model-graph check line printed FAIL due to a bit-equality assertion (1 ULP
  difference from slicing before vs after SiLU); not a contract failure.
* `single_pass` is correct but strictly worse for latency (chunk 0 waits for
  the whole request) — rejected, kept as a control.
* The 8-chunk block plan is a compromise: bigger blocks cut Python overhead,
  smaller blocks smooth the tail. Per-frame publishing still copies a strided
  host slice into the ring (C small memcpys/frame); a `(count,C,chunk)` layout
  would make it one memcpy per frame. Not done: gaps already 4 µs, far inside
  the 20 ms budget.

## 4. Not achieved / open

* No multi-GPU work (single assigned GPU); the IR's 5-stage pipeline parallelism
  is reported but unused.
* `auto` always picks graphs when capture succeeds; no runtime auto-tuning
  between `graph` and `eager` (measured difference was within noise at dev
  size, clearly positive at startup warm-up: graphs remove the first-request
  cuDNN/launch cost).
* Tail-chunk partial publishing zero-fills the unused columns (contract does
  not inspect them, reference does the same).
