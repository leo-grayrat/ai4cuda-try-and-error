"""Phase-2 IR validation + Phase-2 analysis output.

Runs the real ``SequentialExecutor`` over the converted graphs and compares the
results with the research reference (``ReferencePipeline`` stepped chunk by
chunk, and the CPU ``full_sequence_oracle``).  Structural validation (graph
checks) and numeric comparison are reported separately.  Also prints
``summarize_graph`` for the worker graph and for a model-level layer graph.
"""

import inspect
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))

from common import ATOL, RTOL, make_config, repo_root  # noqa: E402
from flashrt.ir import SequentialExecutor, summarize_graph  # noqa: E402
from causal_features.model import build_layers, full_sequence_oracle, ReferencePipeline  # noqa: E402
from ir import build_model_graph, build_worker_graph  # noqa: E402

STATES = ('history_0', 'history_1', 'history_2')


def summarize(graph, latencies=None):
    kwargs = {}
    try:
        params = inspect.signature(summarize_graph).parameters
    except (TypeError, ValueError):
        params = {}
    if latencies:
        for name in ('op_latencies', 'latencies'):
            if name in params:
                kwargs[name] = latencies
    return summarize_graph(graph, **kwargs)


def main():
    torch.set_grad_enabled(False)
    cfg = make_config()
    root = repo_root()
    rng = np.random.default_rng(3)
    T, chunk = cfg['length'], cfg['chunk']
    a = rng.standard_normal((cfg['channels'], T)).astype(np.float32)
    b = (rng.standard_normal((cfg['channels'], T)) * 0.5).astype(np.float32)
    features = [a, b, a, a, b, a]

    layers = build_layers(Path(root), cfg, 'cpu')
    graph = build_worker_graph(cfg, layers)
    print('worker graph structural errors:', graph.validate())
    print('chunk order:', SequentialExecutor(graph).chunk_execution_order)

    executor = SequentialExecutor(graph)
    executor.init_state({name: None for name in STATES})
    ctx = SimpleNamespace(device='cpu', publish=None)
    ir_out = []
    for step, request in enumerate(features):
        if step == 3:
            executor.init_state({name: None for name in STATES})
        chunks = []
        for off in range(0, T, chunk):
            out = executor.run_chunk({'features': request[:, off:off + chunk]}, ctx)
            chunks.append(out['chunk_out'].numpy())
        ir_out.append(np.concatenate(chunks, axis=1))

    oracle = full_sequence_oracle(Path(root), cfg, np.concatenate([a, b, a], axis=1))
    reference = ReferencePipeline(root, cfg)
    ref_out = []
    for step, request in enumerate(features):
        if step == 3:
            reference.reset()
        ref_out.append(np.concatenate(
            [reference.step(request[:, off:off + chunk]) for off in range(0, T, chunk)],
            axis=1))

    ok, worst = True, 0.0
    for step in range(6):
        expect = oracle[:, (step % 3) * T:(step % 3 + 1) * T]
        got = ir_out[step]
        err_ir = float(np.abs(got - expect).max())
        err_ref = float(np.abs(got - ref_out[step]).max())
        bad = int((np.abs(got - expect) > ATOL + RTOL * np.abs(expect)).sum())
        worst = max(worst, err_ir, err_ref)
        print('step %d: max|ir-oracle|=%.3e max|ir-reference|=%.3e out_of_tol=%d'
              % (step, err_ir, err_ref, bad))
        ok = ok and bad == 0
    repeat = np.array_equal(ir_out[0], ir_out[3])
    print('reset reproduces first request:', repeat)
    print('IR VERDICT', 'PASS' if (ok and repeat) else 'FAIL',
          'worst_abs_err=%.3e' % worst)

    # ---- model-level graph: one layer, executed over three chunks
    h = int(layers[0]._time_causal_padding[0])
    model_graph = build_model_graph(cfg, layers[0], h, name='layer_0_model')
    print('model graph structural errors:', model_graph.validate())
    model_exec = SequentialExecutor(model_graph)
    model_exec.init_state({'layer_history': None})
    mctx = SimpleNamespace(layer=layers[0], h=h)
    history, worst_layer = None, 0.0
    for off in range(0, 3 * chunk, chunk):
        value = torch.from_numpy(a[:, off:off + chunk].copy()).unsqueeze(0)
        got = model_exec.run_chunk({'value': value}, mctx)['out'].squeeze(0).numpy()
        joined = value if history is None else torch.cat([history, value], dim=-1)
        ref = torch.nn.functional.silu(layers[0](joined))
        if history is not None:
            ref = ref[:, :, history.shape[-1]:]
        history = joined[:, :, -h:].clone()
        worst_layer = max(worst_layer, float(np.abs(got - ref.squeeze(0).numpy()).max()))
    print('MODEL GRAPH VERDICT', 'PASS' if worst_layer == 0.0 else 'FAIL',
          'max|=%.3e' % worst_layer)

    print('=== analysis: worker graph ===')
    print(summarize(graph, {op: 1.0 for op in graph.operators}))
    print('=== analysis: layer model graph ===')
    print(summarize(model_graph, {op: 1.0 for op in model_graph.operators}))


if __name__ == '__main__':
    main()
