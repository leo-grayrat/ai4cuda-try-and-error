"""Profile the candidate backend phases (CF_PROFILE=1) and per-chunk gaps."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    import flashrt
    import causal_features
    repository = Path(flashrt.__file__).resolve().parent.parent
    workloads = Path(causal_features.__file__).resolve().parent.parent
    sys.path.insert(0, str(workloads)); sys.path.insert(0, str(repository))
    from causal_features.adapter import FeatureAdapter

    rng = np.random.default_rng(3)
    stamp = int(time.time() * 1000) % 100000
    for tag, cfg in [
        ('dev', dict(channels=16, hidden=32, length=1043, chunk=127)),
        ('large', dict(channels=128, hidden=256, length=16384, chunk=512)),
    ]:
        config = dict(cfg, weight_seed=703, device='cuda:0',
                      prefix=f'cf_prof_{tag}_{stamp}')
        cpath = HERE / f'prof_{tag}.json'
        cpath.write_text(json.dumps(config))
        env = dict(os.environ)
        env['CF_PROFILE'] = '1'
        env['PYTHONPATH'] = ';'.join([str(workloads), str(repository),
                                      env.get('PYTHONPATH', '')])
        proc = subprocess.Popen([sys.executable, str(HERE / 'worker.py'),
                                 '--repository', str(repository), '--config', str(cpath)],
                                cwd=str(repository.parent), stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, env=env)
        print(tag, 'ready:', proc.stdout.readline().strip())
        adapter = FeatureAdapter(config)
        rows = []
        try:
            adapter.start()
            for r in range(5):
                x = rng.standard_normal((config['channels'], config['length']),
                                        dtype=np.float32)
                t0 = time.perf_counter()
                adapter.submit(x)
                stamps = []
                while adapter.pending is not None:
                    _, ns = adapter.receive(timeout_s=60)
                    stamps.append(ns / 1e9)
                rows.append((t0, stamps))
            adapter.terminate()
            proc.wait(timeout=60)
        finally:
            adapter.close()
        out, err = proc.communicate()
        for i, (t0, stamps) in enumerate(rows):
            first = (stamps[0] - t0) * 1e3
            gaps = [(stamps[j] - stamps[j - 1]) * 1e3 for j in range(1, len(stamps))]
            print(f'{tag} req{i}: first={first:.2f}ms total={(stamps[-1]-t0)*1e3:.2f}ms '
                  f'chunks={len(stamps)} max_gap={max(gaps):.3f}ms '
                  f'gaps_mean={np.mean(gaps):.3f}ms')
        for line in err.strip().splitlines():
            print('  trace', line)


if __name__ == '__main__':
    main()
