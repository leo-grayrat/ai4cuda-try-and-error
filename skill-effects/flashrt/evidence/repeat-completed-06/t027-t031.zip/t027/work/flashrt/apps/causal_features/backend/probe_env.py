"""Environment probe: verify GPU, torch build, and causal_features imports."""
import json
import sys

import torch

print(json.dumps({
    'python': sys.version.split()[0],
    'torch': torch.__version__,
    'cuda_available': torch.cuda.is_available(),
    'device_count': torch.cuda.device_count(),
    'device_name': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    'capability': torch.cuda.get_device_capability(0) if torch.cuda.is_available() else None,
    'cudnn': torch.backends.cudnn.version() if torch.cuda.is_available() else None,
    'matmul_tf32': torch.backends.cuda.matmul.allow_tf32,
}, indent=2))

import causal_features.adapter as adapter
import causal_features.model as model
import flashrt.ir as ir
print('imports ok', adapter.__file__, model.__file__, ir.__file__)
