import os, sys
from pathlib import Path
import flashrt, causal_features, causal_features.adapter, causal_features.model
print('cwd', os.getcwd())
print('flashrt', flashrt.__file__)
print('causal_features', causal_features.__file__)
print('sys.path[:6]', sys.path[:6])
cf = Path(causal_features.__file__).resolve().parent
fr = Path(flashrt.__file__).resolve().parent
for root in [cf.parent, fr.parent, Path(os.getcwd())]:
    print('root', root, 'has flashrt/audio', (root/'flashrt/layers/audio.py').exists(),
          'has causal_features', (root/'causal_features/model.py').exists())
for p in sys.path:
    q = Path(p) if p else Path('.')
    if (q/'flashrt/layers/audio.py').exists() and (q/'causal_features/model.py').exists():
        print('MERGED ROOT:', q.resolve())
