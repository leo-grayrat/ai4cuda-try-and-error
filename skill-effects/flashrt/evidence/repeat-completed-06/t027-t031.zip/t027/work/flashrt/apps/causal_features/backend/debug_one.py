import json, os, subprocess, sys, time
from pathlib import Path
import numpy as np

import flashrt, causal_features
HERE = Path(__file__).resolve().parent
repository = Path(flashrt.__file__).resolve().parent.parent
workloads = Path(causal_features.__file__).resolve().parent.parent
sys.path.insert(0, str(workloads)); sys.path.insert(0, str(repository))
from causal_features.adapter import FeatureAdapter

config = dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703,
              device='cuda:0', prefix=f'cf_dbg_{int(time.time()*1000)%100000}')
cpath = HERE / 'dbg.json'; cpath.write_text(json.dumps(config))
env = dict(os.environ)
env['PYTHONPATH'] = ';'.join([str(workloads), str(repository), env.get('PYTHONPATH','')])
proc = subprocess.Popen([sys.executable, str(HERE/'worker.py'), '--repository', str(repository),
                         '--config', str(cpath)], cwd=str(repository.parent),
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
print('ready line:', proc.stdout.readline().strip(), flush=True)
adapter = FeatureAdapter(config)
try:
    adapter.start()
    print('started', flush=True)
    rng = np.random.default_rng(1)
    a = rng.standard_normal((16, 1043), dtype=np.float32)
    adapter.submit(a)
    print('submitted', flush=True)
    for i in range(9):
        data, ns = adapter.receive(timeout_s=10)
        print('chunk', i, data.shape, flush=True)
    adapter.terminate()
    print('terminated', flush=True)
    proc.wait(timeout=30)
except BaseException as exc:
    print('EXC', type(exc).__name__, exc, flush=True)
    proc.kill()
finally:
    adapter.close()
    out, err = proc.communicate()
    print('child stdout:', out[-2000:], flush=True)
    print('child stderr:', err[-4000:], flush=True)
