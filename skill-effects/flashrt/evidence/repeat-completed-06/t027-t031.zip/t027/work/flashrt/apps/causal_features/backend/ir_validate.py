"""Express and validate the causal-feature state dependency graph with flashrt.ir.

The graph models the exact chunk-periodic computation:
  conv_silu_1 -> conv_silu_2 -> conv_silu_3
with three *chunk-persistent* per-layer convolution histories (k-1 samples
each).  We validate the graph structurally, print the dependency / pipeline
analysis, and numerically check the SequentialExecutor's chunked output
against the CPU full-sequence oracle across a continuing session and a reset.
"""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from flashrt.ir import (IREdge, IRGraph, IROperator, OpType, SequentialExecutor,
                        StateObject, StreamMode, TensorPort,
                        analyze_cross_chunk_dependencies, summarize_graph)


class ConvSiluLayer(IROperator):
    def __init__(self, name, layer, state_name, pad):
        super().__init__(
            name=name, op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')], outputs=[TensorPort('y')],
            state_reads=[state_name], state_writes=[state_name],
            stream_mode=StreamMode.STREAMING)
        self.layer = layer
        self.state_name = state_name
        self.pad = pad

    @torch.inference_mode()
    def execute(self, inputs, context, state):
        x = inputs['x']
        history = state.get(self.state_name)
        if history is None:
            joined = x
            out = self.layer(joined)
        else:
            joined = torch.cat([history, x], dim=-1)
            out = self.layer(joined)[:, :, history.shape[-1]:]
        state.set(self.state_name, joined[:, :, -self.pad:].clone())
        return {'y': F.silu(out)}


def build_graph(layers):
    graph = IRGraph(name='causal_features')
    pads = [layer._time_causal_padding[0] for layer in layers]
    names = ['conv_silu_1', 'conv_silu_2', 'conv_silu_3']
    states = ['hist_1', 'hist_2', 'hist_3']
    for state_name in states:
        graph.add_state(StateObject(
            name=state_name, scope='chunk_persistent',
            description=f'last k-1 input samples for {state_name} (causal conv history)'))
    for index, name in enumerate(names):
        graph.add_operator(ConvSiluLayer(name, layers[index], states[index], pads[index]))
    graph.add_edge(IREdge('conv_silu_1', 'y', 'conv_silu_2', 'x'))
    graph.add_edge(IREdge('conv_silu_2', 'y', 'conv_silu_3', 'x'))
    graph.external_inputs = [TensorPort('x')]
    graph.external_outputs = [TensorPort('y')]
    graph.chunk_ops = list(names)
    return graph


def main():
    import flashrt
    import causal_features
    repository = Path(flashrt.__file__).resolve().parent.parent
    workloads = Path(causal_features.__file__).resolve().parent.parent
    sys.path.insert(0, str(workloads)); sys.path.insert(0, str(repository))
    from causal_features.model import build_layers, full_sequence_oracle

    config = dict(channels=16, hidden=32, length=1043, chunk=127,
                  weight_seed=703, device='cpu')
    layers = build_layers(repository, config, 'cpu')
    graph = build_graph(layers)

    errors = graph.validate()
    print('graph validation:', 'PASS' if not errors else errors)
    dep = analyze_cross_chunk_dependencies(graph)
    print('state groups:', {k: sorted(v) for k, v in dep.state_groups.items()})
    print('cross-chunk dependencies:',
          [(d.op_a, d.op_b, d.state_name) for d in dep.dependencies])
    print('independent pairs:', dep.independent_pairs)
    print(summarize_graph(graph, {'conv_silu_1': 0.6e-3, 'conv_silu_2': 1.0e-3,
                                  'conv_silu_3': 0.45e-3}))

    rng = np.random.default_rng(703)
    a = rng.standard_normal((config['channels'], config['length']), dtype=np.float32)
    b = rng.standard_normal((config['channels'], config['length']), dtype=np.float32)

    def run_session(inputs):
        executor = SequentialExecutor(graph)
        executor.init_state({'hist_1': None, 'hist_2': None, 'hist_3': None})
        pieces = []
        for features in inputs:
            chunks = []
            for pos in range(0, config['length'], config['chunk']):
                block = torch.from_numpy(features[:, pos:pos + config['chunk']].copy())
                out = executor.run_chunk({'x': block.unsqueeze(0)})['y']
                chunks.append(out.squeeze(0).numpy())
            pieces.append(np.concatenate(chunks, axis=-1))
        return pieces

    session = run_session([a, b, a])
    contexts = [a, np.concatenate([a, b], -1), np.concatenate([a, b, a], -1)]
    ok = True
    for index, (piece, context) in enumerate(zip(session, contexts)):
        oracle = full_sequence_oracle(repository, config, context)[:, -config['length']:]
        err = float(np.max(np.abs(piece - oracle)))
        good = bool(np.allclose(piece, oracle, atol=3e-5, rtol=3e-4))
        ok = ok and good
        print(f'IR session req{index}: abs={err:.3e} allclose={good}')
    replay = run_session([a])[0]
    same = bool(np.array_equal(session[0], replay))
    print(f'IR reset replay bit-identical: {same}')
    print('IR SCHEMA/NUMERIC RESULT:', 'PASS' if (not errors and ok and same) else 'FAIL')
    if errors or not ok or not same:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
