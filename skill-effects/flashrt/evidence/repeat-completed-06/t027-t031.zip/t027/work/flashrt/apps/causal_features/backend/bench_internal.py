"""Microbenchmark of the full-sequence pipeline vs the per-chunk reference.

Measures (large config C=128,H=256,T=16384,chunk=512):
  * pure GPU pipeline: H2D, conv1, conv2, conv3, D2H, total (CUDA-event timed)
  * cudnn.benchmark False vs True
  * chunked (reference-style) GPU loop for comparison
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent


def timed(fn, warmup=3, iters=20):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    events = [(torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True))
              for _ in range(iters)]
    for i in range(iters):
        events[i][0].record()
        fn()
        events[i][1].record()
    torch.cuda.synchronize()
    times = [s.elapsed_time(e) for s, e in events]
    return min(times), sum(times) / len(times), max(times)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=None)
    args = parser.parse_args()
    import flashrt
    import causal_features
    repository = (args.repository or Path(flashrt.__file__).resolve().parent.parent).resolve()
    workloads = Path(causal_features.__file__).resolve().parent.parent
    sys.path.insert(0, str(workloads)); sys.path.insert(0, str(repository))
    from causal_features.model import build_layers

    config = dict(channels=128, hidden=256, length=16384, chunk=512,
                  weight_seed=703, device='cuda:0')
    C, H, T, K = config['channels'], config['hidden'], config['length'], config['chunk']
    device = torch.device('cuda:0')
    layers = build_layers(repository, config, device)
    w = [l.conv.weight for l in layers]
    b = [l.conv.bias for l in layers]
    pads = [l._time_causal_padding[0] for l in layers]
    rng = np.random.default_rng(5)
    x_np = rng.standard_normal((1, C, T), dtype=np.float32)
    x = torch.from_numpy(x_np).to(device)

    print(f'GPU: {torch.cuda.get_device_name(0)}')

    for benchmark in (False, True):
        torch.backends.cudnn.benchmark = benchmark

        def full():
            with torch.inference_mode():
                v = x
                for i in range(3):
                    hist = torch.zeros((1, v.shape[1], pads[i]), device=device)
                    out = F.conv1d(torch.cat([hist, v], dim=-1), w[i], b[i])
                    v = F.silu(out)
                return v
        mn, avg, mx = timed(full)
        print(f'benchmark={benchmark} full graph ms: min={mn:.3f} avg={avg:.3f} max={mx:.3f}')

        inputs = [x, torch.randn((1, H, T), device=device),
                  torch.randn((1, H, T), device=device)]
        for i in range(3):
            def one(i=i):
                with torch.inference_mode():
                    hist = torch.zeros((1, inputs[i].shape[1], pads[i]), device=device)
                    return F.silu(F.conv1d(torch.cat([hist, inputs[i]], dim=-1), w[i], b[i]))
            mn, avg, mx = timed(one)
            print(f'  layer{i} k={pads[i]+1} ms: min={mn:.3f} avg={avg:.3f}')

        def chunked():
            with torch.inference_mode():
                hist = [None, None, None]
                outs = []
                for pos in range(0, T, K):
                    v = x[:, :, pos:pos + K]
                    for i in range(3):
                        joined = v if hist[i] is None else torch.cat([hist[i], v], -1)
                        out = layers[i](joined)
                        if hist[i] is not None:
                            out = out[:, :, hist[i].shape[-1]:]
                        hist[i] = joined[:, :, -pads[i]:].clone()
                        v = F.silu(out)
                    outs.append(v)
                return outs
        mn, avg, mx = timed(chunked, warmup=2, iters=10)
        print(f'benchmark={benchmark} chunked loop ms: min={mn:.3f} avg={avg:.3f} max={mx:.3f}')

    torch.backends.cudnn.benchmark = False
    h = torch.empty_like(x)
    mn, avg, mx = timed(lambda: h.copy_(x))
    print(f'H2D+sync ms min={mn:.3f} avg={avg:.3f}')
    cpu = torch.empty_like(x, device='cpu')
    mn, avg, mx = timed(lambda: cpu.copy_(x))
    print(f'D2H+sync ms min={mn:.3f} avg={avg:.3f}')
    pin = torch.empty_like(x, pin_memory=True)
    mn, avg, mx = timed(lambda: pin.copy_(x))
    print(f'D2H pinned +sync ms min={mn:.3f} avg={avg:.3f}')
    xp = torch.empty_like(x, pin_memory=True)
    xp.copy_(x.cpu())
    y = torch.empty_like(x)
    mn, avg, mx = timed(lambda: y.copy_(xp, non_blocking=True))
    print(f'H2D pinned async ms min={mn:.3f} avg={avg:.3f}')

    import time
    ycpu = x.cpu()
    t0 = time.perf_counter()
    for _ in range(20):
        arr = ycpu.numpy()
    print(f'numpy() {(time.perf_counter()-t0)/20*1e3:.3f} ms')
    t0 = time.perf_counter()
    for _ in range(20):
        out = np.empty((32, C, K), np.float32)
        out[:31] = x_np[:, :31 * K].reshape(C, 31, K).transpose(1, 0, 2)
        out[31, :, :T - 31 * K] = x_np[:, 31 * K:]
    print(f'pad-pack {(time.perf_counter()-t0)/20*1e3:.3f} ms')


if __name__ == '__main__':
    main()
