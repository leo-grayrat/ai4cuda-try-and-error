# causal_features 后端实验记录

## 任务语义

固定三层 `CausalConv1d`（k=5,5,3，C→H→H→C，每层后接 SiLU，权重种子 703）。
每层只依赖过去 k-1 个输入样本，因此跨块状态是三个独立的 `(Cin, k-1)` 历史。
连续请求等价于把输入按时间拼接后整段执行；reset 清空历史。

## IR 状态建模（flashrt/ir）

`ir_validate.py` 用原始 IR 构造 `conv_silu_1 -> conv_silu_2 -> conv_silu_3`，
每个算子声明 `state_reads/state_writes = hist_i`，状态 scope 为 `chunk_persistent`。

- `graph.validate()`：PASS（无环、端口/状态声明一致）。
- `analyze_cross_chunk_dependencies()`：`hist_1/hist_2/hist_3` 各自只被本层读写，
  三对算子跨块互相独立；`find_pipeline_stages()` 得到 3 个流水阶段。
- 结论：单卡上做跨层流水没有收益（层间是同一 chunk 内的数据依赖，
  跨块独立但每层都要等本层上一块历史）。因此优化方向是把“每块三次小卷积”
  合并为“整请求一次三段卷积”，而不是流水并行。
- 注：IR 数值对照脚本首版把外部输入端口命名为 `features` 而算子端口为 `x`，
  首轮在 `_gather_inputs` 处报错；结构校验部分已 PASS，修正端口命名后在
  最终阶段复跑。

## 优化变体与证据

| 变体 | 做法 | 大用例稳态 (C=128,H=256,T=16384,chunk=512) | 开发用例 |
|---|---|---|---|
| reference | 每 chunk 三次 conv + 每块 H2D/D2H | 24–47 ms/请求（均值约 30 ms） | 6–9 ms/请求 |
| v1 整请求单次三段卷积 | 消除 96+ 次小 kernel 与每块往返 | 约 16 ms/请求（execute-010） | 约 1.5–2 ms |
| v2 首块立即发布 + 直写 ring | 首块先算先发，其余整段算完一次性写共享环 | 约 15 ms（execute-011） | 约 1–2 ms |
| v3 分阶段上传 + pinned D2H + 连续主机缓冲 + warm-up | 首块只上传 chunk0；其余用复用 pinned 缓冲 D2H；直接写 ring frame；ready 前预热 cuDNN | 后端内部约 10 ms，适配器观测 13–14 ms；首块 3.5–4.5 ms；块间最大间隔 8–10 ms；冷请求首块 10.8 ms（execute-013） | 后端约 1.2 ms，观测约 2 ms；首块 1.4 ms；块间最大间隔 <0.75 ms |

- 纯 GPU 三段卷积（T=16384）：约 1.9–2.0 ms（bench_internal）。
- 参考实现逐块 GPU 循环本身约 14–21 ms，其余是每块 H2D/D2H 与 Python 开销。
- 大用例数据量 8 MB，输入/输出在 shm、主机、显存之间多次搬运，
  v3 通过“首块单独上传 + 复用 pinned 输出 + 直写 ring”减少一次 8 MB 打包拷贝。
- 20 ms 块间隔预算：v3 稳态最大块间隔约 8–10 ms，冷请求约 10.8 ms，均满足。

## 失败与修正

1. 输出打包 reshape 用了 `total_padded // chunk`（=n_chunks）而不是 `n_chunks-1`，
   尾部块报 `cannot reshape array of size 16688 into shape (16,9,127)`；已改为
   `full=(n_chunks-1)*chunk`。
2. 首版整请求方案冷启动首块约 398 ms（cuDNN 首次初始化）；在 ready 前做一次
   dummy 前向并 `reset()`，把一次性初始化移出计时请求，冷请求首块降到约 10.8 ms。
3. pinned 输出最初复用到 `(C,T)` 的非连续列切片，D2H 变慢；改为 exactly
   `(C, T-chunk)` 连续 pinned 缓冲。
4. 端到端计时包含固定适配器的轮询/拷贝开销（约 3–4 ms），不能与后端内部耗时混同。

## 正确性

- `selftest.py`：六请求序列（冷启动、连续、未 reset 重复输入、reset、reset 后重放、
  另一尾块输入），逐请求与 CPU 全序列 oracle 比较，容差 atol=3e-5/rtol=3e-4；
  v2 全部 PASS，候选与参考实现相对 oracle 的最大绝对误差完全一致
  （开发用例 5.2e-8~7.5e-8，大用例 2.1e-7~2.5e-7），reset 后重放逐位相同，
  七个共享内存对象在退出后全部消失。v3 只改数据搬运/预热，数学路径未变，
  最终阶段复跑确认。
- 官方 `workspace.verify` 使用受保护的参考实现做独立数值对照；官方
  `workspace.benchmark` 做配对 offered-load 扫描。

## 已知限制

- 单卡，IR 的 3 个流水阶段未利用（任务说明多卡要求不适用）。
- 首块必须等 H2D+chunk0 卷积（约 1–4 ms），若未来要求“零延迟块”则需另做增量 kernel。
- 大用例剩余时间主要仍是 8 MB 输出经 shm/适配器的多次拷贝，属于固定 IPC 成本。
- 预热把 cuDNN 初始化放在 ready 之前，后端启动时间增加约 0.4 s；不改变任何结果。

## 文件

- `worker.py`：交付的独立后端入口（`--repository` / `--config`）。
- `ir_validate.py`：IR 状态图构造、结构校验、依赖分析与数值对照。
- `selftest.py`：六请求端到端 / oracle / 重置 / 共享内存清理。
- `bench_internal.py`：纯 GPU 三段卷积 vs 逐块循环微基准。
- `bench_e2e.py`：候选 vs 参考的块间隔与吞吐。
- `prof_run.py`：`CF_PROFILE=1` 后端内部阶段计时与块间隔。
- `probe_env.py` / `probe_paths.py` / `debug_one.py`：环境与首轮调试。
