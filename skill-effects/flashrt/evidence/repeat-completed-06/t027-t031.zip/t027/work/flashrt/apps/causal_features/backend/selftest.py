"""Supplementary end-to-end self test for the optimized worker.

Spawns the standalone candidate backend as a subprocess (exactly the way the
independent controller does: --repository/--config), drives it through the
fixed FeatureAdapter, and checks:

  * six complete requests: cold start, continuation, repeat-without-reset,
    explicit reset, replay-after-reset, and a different tail input;
  * every request against the CPU full-sequence oracle (oracle is run over
    the concatenated session context and sliced to the newest request), both
    absolutely and against the sequential reference backend;
  * reset reproducibility (replay of the first input is bit-identical);
  * all seven shared-memory objects disappear after termination.

Run via workspace.execute (paths are auto-detected), or with
--repository/--workloads explicitly.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parent


def shm_names(prefix):
    return [prefix + '__ctrl', prefix + '_input__meta', prefix + '_input__tensor',
            prefix + '_output__meta', prefix + '_output__tensor',
            prefix + '_metadata__meta', prefix + '_metadata__tensor']


def write_config(config, name):
    path = HERE / name
    path.write_text(json.dumps(config), encoding='utf-8')
    return path


def make_env(repository, workloads):
    env = dict(os.environ)
    parts = [str(Path(workloads).resolve()), str(Path(repository).resolve())]
    if env.get('PYTHONPATH'):
        parts.append(env['PYTHONPATH'])
    env['PYTHONPATH'] = ';'.join(parts)
    return env


def launch(command, repository, workloads, config_path):
    proc = subprocess.Popen(command + ['--repository', str(repository),
                                       '--config', str(config_path)],
                            cwd=str(Path(repository).resolve().parent),
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, env=make_env(repository, workloads))
    line = proc.stdout.readline()
    return proc, line


def run_sequence(command, repository, workloads, config, inputs, do_reset_after=None):
    """inputs: list of (C,T) arrays; returns list of (C,T) replayed outputs."""
    from causal_features.adapter import FeatureAdapter
    cpath = write_config(config, f"selftest_{config['prefix']}.json")
    proc, ready = launch(command, repository, workloads, cpath)
    if 'ready' not in ready:
        proc.kill()
        raise RuntimeError(f'backend did not become ready: {ready!r}')
    adapter = FeatureAdapter(config)
    outputs, timings = [], []
    try:
        adapter.start()
        for index, features in enumerate(inputs):
            if do_reset_after is not None and index == do_reset_after:
                adapter.reset()
            t0 = time.perf_counter()
            adapter.submit(features)
            pieces = []
            while adapter.pending is not None:
                data, _ = adapter.receive(timeout_s=60)
                pieces.append(data)
            timings.append(time.perf_counter() - t0)
            outputs.append(np.concatenate(pieces, axis=-1))
        adapter.terminate()
        proc.wait(timeout=60)
    finally:
        adapter.close()
    out, err = proc.communicate()
    return outputs, timings, out, err


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=None)
    parser.add_argument('--workloads', type=Path, default=None)
    args = parser.parse_args()
    import flashrt
    import causal_features
    repository = (args.repository or Path(flashrt.__file__).resolve().parent.parent).resolve()
    workloads = (args.workloads or Path(causal_features.__file__).resolve().parent.parent).resolve()
    sys.path.insert(0, str(workloads))
    sys.path.insert(0, str(repository))
    from causal_features.model import full_sequence_oracle
    print(f'repository={repository}\nworkloads={workloads}', flush=True)

    rng = np.random.default_rng(703)
    results = []
    for tag, config in [
        ('dev', dict(channels=16, hidden=32, length=1043, chunk=127,
                     weight_seed=703, device='cuda:0')),
        ('large', dict(channels=128, hidden=256, length=16384, chunk=512,
                       weight_seed=703, device='cuda:0')),
    ]:
        config = dict(config)
        config['prefix'] = f'cf_selftest_{tag}_{int(time.time()*1000) % 100000}'
        c, t = config['channels'], config['length']
        a = rng.standard_normal((c, t), dtype=np.float32)
        b = rng.standard_normal((c, t), dtype=np.float32)
        d = rng.standard_normal((c, t), dtype=np.float32)
        inputs = [a, b, b, a, d, b]
        expected_context = [a, np.concatenate([a, b], -1),
                            np.concatenate([a, b, b], -1), a,
                            np.concatenate([a, d], -1),
                            np.concatenate([a, d, b], -1)]

        cand, cand_t, cout, cerr = run_sequence(
            [sys.executable, str(HERE / 'worker.py')], repository, workloads,
            config, inputs, do_reset_after=3)
        ref, ref_t, rout, rerr = run_sequence(
            [sys.executable, '-m', 'causal_features.reference'], repository,
            workloads, config, inputs, do_reset_after=3)
        print(f'{tag} candidate stderr: {cerr.strip()[:300]!r}', flush=True)
        print(f'{tag} reference stderr: {rerr.strip()[:300]!r}', flush=True)

        for index, context in enumerate(expected_context):
            oracle = full_sequence_oracle(repository, config, context)[:, -t:]
            got = cand[index]
            ref_got = ref[index]
            err = float(np.max(np.abs(got - oracle)))
            denom = np.maximum(np.abs(oracle), 1e-6)
            rel = float(np.max(np.abs(got - oracle) / denom))
            ref_err = float(np.max(np.abs(ref_got - oracle)))
            ok = bool(np.allclose(got, oracle, atol=3e-5, rtol=3e-4))
            ref_ok = bool(np.allclose(ref_got, oracle, atol=3e-5, rtol=3e-4))
            results.append((tag, index, err, rel, ref_err, ok))
            print(f'{tag} req{index}: abs={err:.3e} rel={rel:.3e} '
                  f'ref_abs={ref_err:.3e} cand_ok={ok} ref_ok={ref_ok}', flush=True)

        replay_same = bool(np.array_equal(cand[0], cand[3]))
        print(f'{tag} reset replay bit-identical: {replay_same}', flush=True)
        print(f'{tag} candidate per-request s: '
              f'{["%.3f" % x for x in cand_t]}', flush=True)
        print(f'{tag} reference per-request s: '
              f'{["%.3f" % x for x in ref_t]}', flush=True)
        results.append((tag, 'replay', float(replay_same), 0.0, 0.0, replay_same))

        gone = []
        for name in shm_names(config['prefix']):
            from multiprocessing import shared_memory
            try:
                probe = shared_memory.SharedMemory(name=name, create=False)
                probe.close()
                gone.append(False)
            except FileNotFoundError:
                gone.append(True)
        print(f'{tag} shm cleanup: {gone}', flush=True)
        results.append((tag, 'shm', float(all(gone)), 0.0, 0.0, all(gone)))

    bad = [r for r in results if not r[5]]
    print('RESULT:', 'PASS' if not bad else f'FAIL {bad}', flush=True)
    if bad:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
