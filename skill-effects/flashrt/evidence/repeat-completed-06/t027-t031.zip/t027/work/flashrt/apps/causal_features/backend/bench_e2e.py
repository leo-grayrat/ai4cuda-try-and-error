"""End-to-end chunk-gap / throughput measurement through the fixed adapter.

For candidate and reference, large and dev configs:
  * submit 6 complete requests of a session (cold start separated),
  * record time-to-first-chunk and inter-chunk gaps from adapter timestamps,
  * report steady per-request latency and requests/second,
  * check the 20 ms chunk-gap budget.
Also profiles the candidate's in-process phases (H2D / conv / D2H / pack).
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parent


def make_env(repository, workloads):
    env = dict(os.environ)
    parts = [str(workloads), str(repository)]
    if env.get('PYTHONPATH'):
        parts.append(env['PYTHONPATH'])
    env['PYTHONPATH'] = ';'.join(parts)
    return env


def bench_backend(command, repository, workloads, config, inputs):
    from causal_features.adapter import FeatureAdapter
    cpath = HERE / f'bench_{config["prefix"]}.json'
    cpath.write_text(json.dumps(config))
    proc = subprocess.Popen(command + ['--repository', str(repository), '--config', str(cpath)],
                            cwd=str(repository.parent), stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True,
                            env=make_env(repository, workloads))
    ready = proc.stdout.readline()
    if 'ready' not in ready:
        proc.kill()
        raise RuntimeError(ready)
    adapter = FeatureAdapter(config)
    rows = []
    try:
        adapter.start()
        for features in inputs:
            t0 = time.perf_counter()
            adapter.submit(features)
            first = None
            last = None
            count = 0
            while adapter.pending is not None:
                _, ns = adapter.receive(timeout_s=60)
                now = ns / 1e9
                if first is None:
                    first = now
                last = now
                count += 1
            end = time.perf_counter()
            rows.append(dict(first_ms=(first - t0) * 1e3, total_ms=(end - t0) * 1e3,
                             chunks=count, last_ns=last))
        adapter.terminate()
        proc.wait(timeout=60)
    finally:
        adapter.close()
    _, err = proc.communicate()
    return rows, err


def main():
    import flashrt
    import causal_features
    repository = Path(flashrt.__file__).resolve().parent.parent
    workloads = Path(causal_features.__file__).resolve().parent.parent
    sys.path.insert(0, str(workloads)); sys.path.insert(0, str(repository))
    rng = np.random.default_rng(11)
    stamp = int(time.time() * 1000) % 100000
    for tag, cfg in [
        ('dev', dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703)),
        ('large', dict(channels=128, hidden=256, length=16384, chunk=512, weight_seed=703)),
    ]:
        config = dict(cfg, device='cuda:0', prefix=f'cf_bench_{tag}_{stamp}')
        inputs = [rng.standard_normal((config['channels'], config['length']),
                                      dtype=np.float32) for _ in range(6)]
        outs = {}
        for name, command in [
            ('candidate', [sys.executable, str(HERE / 'worker.py')]),
            ('reference', [sys.executable, '-m', 'causal_features.reference']),
        ]:
            c = dict(config, prefix=f'cf_bench_{tag}_{name}_{stamp}')
            rows, err = bench_backend(command, repository, workloads, c, inputs)
            gaps = [rows[i]['first_ms'] for i in range(1, len(rows))]
            steady = [rows[i]['total_ms'] for i in range(1, len(rows))]
            outs[name] = rows
            print(f'{tag} {name}: cold_first_ms={rows[0]["first_ms"]:.2f} '
                  f'cold_total_ms={rows[0]["total_ms"]:.2f} '
                  f'steady_ms={["%.2f" % x for x in steady]} '
                  f'mean={np.mean(steady):.2f} max={np.max(steady):.2f} '
                  f'req/s={1.0/np.mean(steady)*1e3:.1f} '
                  f'max_first_ms={np.max(gaps):.2f} stderr={err.strip()[:80]!r}')
        speedup = np.mean([r['total_ms'] for r in outs['reference'][1:]]) / np.mean(
            [r['total_ms'] for r in outs['candidate'][1:]])
        print(f'{tag} steady speedup candidate vs reference: {speedup:.2f}x')

    # In-process phase profile of candidate pipeline (large config).
    import torch
    import torch.nn.functional as F
    from causal_features.model import build_layers
    config = dict(channels=128, hidden=256, length=16384, chunk=512,
                  weight_seed=703, device='cuda:0')
    C, H, T, K = 128, 256, 16384, 512
    device = torch.device('cuda:0')
    layers = build_layers(repository, config, device)
    w = [l.conv.weight for l in layers]
    b = [l.conv.bias for l in layers]
    pads = [l._time_causal_padding[0] for l in layers]
    x_np = rng.standard_normal((1, C, T), dtype=np.float32)
    x_gpu = torch.from_numpy(x_np).to(device)
    out_gpu = torch.empty((1, C, T), device=device)
    host = torch.empty((1, C, T), dtype=torch.float32, pin_memory=True)
    padded = np.empty((32, C, K), dtype=np.float32)

    def phase(name, fn, iters=30):
        for _ in range(3):
            fn()
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        for _ in range(iters):
            fn()
        torch.cuda.synchronize()
        print(f'  profile {name}: {(time.perf_counter()-t0)/iters*1e3:.3f} ms')

    def h2d():
        x_gpu.copy_(torch.from_numpy(x_np), non_blocking=True)

    def graph():
        with torch.inference_mode():
            v = x_gpu
            for i in range(3):
                h = torch.zeros((1, v.shape[1], pads[i]), device=device)
                v = F.silu(F.conv1d(torch.cat([h, v], -1), w[i], b[i]))
            out_gpu.copy_(v)

    def d2h_pin():
        host.copy_(out_gpu, non_blocking=True)

    def d2h_page():
        out_gpu.cpu()

    def pack():
        arr = out_gpu.numpy() if False else None
        out = np.empty((32, C, K), np.float32)
        out[:31] = padded[:31]
        out[31, :, :T - 31 * K] = padded[31, :, :T - 31 * K]

    def hostpack():
        arr = host.numpy()[0]
        padded[:31] = arr[:, :31 * K].reshape(C, 31, K).transpose(1, 0, 2)
        padded[31, :, :] = 0.0
        padded[31, :, :T - 31 * K] = arr[:, 31 * K:]

    print(f'large candidate phase profile ({torch.cuda.get_device_name(0)})')
    phase('H2D pageable', h2d)
    phase('conv graph + D2H', graph)
    phase('D2H pinned', d2h_pin)
    phase('D2H pageable', d2h_page)
    phase('host numpy pack (8MB)', hostpack)


if __name__ == '__main__':
    main()
