"""Optimized causal_features backend (single GPU).

Semantics are identical to ``causal_features.reference``: three causal
``CausalConv1d`` layers (kernels 5/5/3) each followed by SiLU, with per-layer
history retained across requests.  Optimizations:

1.  **Whole-request convolution.**  The request body is evaluated in one
    three-conv pass instead of one pass per 127/512-sample chunk (96+ tiny GPU
    kernels plus a host round trip each).  With a full k-1 history the padding
    can be dropped entirely: convolution output q covers the same k input
    samples as reference output q+(k-1).  Only the cold-start prefix needs the
    original replicate padding, matching the full-sequence oracle.
2.  **Immediate first chunk, staged upload.**  Chunk 0 is uploaded, computed
    and published first; the remainder is uploaded afterwards and computed in
    one pass.  This keeps time-to-first-chunk and every inter-chunk gap small.
3.  **Bulk, copy-efficient delivery.**  The remainder is copied once into a
    reusable pinned host buffer and written straight into the original shared
    ring frames (no intermediate pack array), data before metadata.
4.  A one-off warm-up pass before ``ready`` pays the cuDNN initialisation cost
    outside of the first measured request; it is reset and has no semantic
    effect.

Usage:
    python worker.py --repository <repo> --config <config.json>
"""
import argparse
import json
import math
import os
from pathlib import Path
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))

    import numpy as np
    import torch
    import torch.nn.functional as F

    from causal_features.adapter import close_buffers, open_buffers
    from causal_features.model import build_layers

    profile = os.environ.get('CF_PROFILE') == '1'

    def trace(record):
        if profile:
            print(json.dumps(record), file=sys.stderr, flush=True)

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = torch.device(config['device'])
    layers = build_layers(args.repository, config, device)
    kernels = [int(layer._time_causal_padding[0]) for layer in layers]
    weights = [layer.conv.weight for layer in layers]
    biases = [layer.conv.bias for layer in layers]
    histories = [None] * len(layers)
    stream = torch.cuda.current_stream(device)

    def reset():
        for index in range(len(histories)):
            histories[index] = None

    @torch.inference_mode()
    def forward(value):
        """value: (1, Cin, L) on device -> (1, C, L) after all three layers."""
        for index, pad in enumerate(kernels):
            history = histories[index]
            if history is None:
                joined = value
                result = layers[index](joined)
                histories[index] = joined[:, :, -pad:].clone()
            elif history.shape[-1] == pad:
                # Full causal context: no padding, first L outputs are exact.
                joined = torch.cat([history, value], dim=-1)
                result = F.conv1d(joined, weights[index], biases[index])
                histories[index] = joined[:, :, -pad:].clone()
            else:
                # Short previous request (< k-1 samples): reference padding
                # path, then drop the history prefix.
                joined = torch.cat([history, value], dim=-1)
                result = layers[index](joined)[:, :, history.shape[-1]:]
                histories[index] = joined[:, :, -pad:].clone()
            value = F.silu(result)
        return value

    channels = int(config['channels'])
    length = int(config['length'])
    chunk = int(config['chunk'])
    n_chunks = math.ceil(length / chunk)
    first = min(chunk, length)
    rest_len = length - first
    tail = length - (n_chunks - 1) * chunk
    valid = [chunk] * n_chunks
    valid[-1] = tail

    host_rest = (torch.empty((channels, rest_len), dtype=torch.float32, pin_memory=True)
                 if rest_len > 0 else None)

    def publish(block, first_index, request_id):
        """Write (C, L) host block as ring frame(s), data before metadata."""
        output = buffers['output']
        count = math.ceil(block.shape[1] / chunk)
        old = output.num
        capacity = output.max_len
        for j in range(count):
            position = (old + j) % capacity
            frame = output.tensor[position]
            lo = j * chunk
            hi = min(lo + chunk, block.shape[1])
            frame[:, :hi - lo] = block[:, lo:hi]
            if hi - lo < chunk:
                frame[:, hi - lo:] = 0
        output.num_arr[0] = old + count
        rows = np.empty((count, 3), dtype=np.int64)
        for j in range(count):
            rows[j, 0] = request_id
            rows[j, 1] = first_index + j
            rows[j, 2] = valid[first_index + j]
        buffers['metadata'].write(rows)

    # Pay cuDNN/kernel initialisation before announcing readiness, then undo
    # every state change so the first real request starts from a clean session.
    if os.environ.get('CF_NO_WARMUP') != '1':
        with torch.inference_mode():
            dummy = torch.zeros((1, channels, length), device=device)
            forward(dummy[:, :, :first])
            if rest_len > 0:
                forward(dummy[:, :, first:])
            reset()
            torch.cuda.synchronize()
            del dummy

    buffers = open_buffers(config, create=True)
    try:
        print(json.dumps({'ready': True, 'device': config['device']}), flush=True)
        consumed = 0
        last_command = 0
        active = False
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            t_start = time.perf_counter()

            head = torch.from_numpy(features[:, :, :first]).to(device, non_blocking=False)
            t_up = time.perf_counter()
            out0 = forward(head)
            block0 = out0.squeeze(0).to('cpu', non_blocking=False).numpy()
            publish(block0, 0, request_id)
            t_first = time.perf_counter()
            del head, out0, block0

            if rest_len > 0:
                rest_gpu = torch.from_numpy(features[:, :, first:]).to(
                    device, non_blocking=False)
                out_rest = forward(rest_gpu)
                host_rest.copy_(out_rest.squeeze(0), non_blocking=True)
                stream.synchronize()
                publish(host_rest.numpy(), 1, request_id)
            t_done = time.perf_counter()
            trace({'request': request_id, 'upload_ms': (t_up - t_start) * 1e3,
                   'first_chunk_ms': (t_first - t_start) * 1e3,
                   'rest_ms': (t_done - t_first) * 1e3,
                   'total_ms': (t_done - t_start) * 1e3})
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
