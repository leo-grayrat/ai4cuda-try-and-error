## 结论摘要

交付物是 `flashrt/apps/causal_features/backend/worker.py`，一个独立后端入口，接受 `--repository` 与 `--config`，完全复用固定的 `causal_features.adapter` IPC 协议（同一控制码 1/3/2、同一 `SharedTensorBuffer` 环形、先数据后元数据），不修改任何共享或参考文件。官方工具已在最终代码上执行：`workspace.verify` 返回 `candidate_run_passed`，六个完整请求全部与受保护的 CPU 全序列 oracle 数值匹配（最大绝对误差 5.2e-8 至 8.2e-8），`cleanup_verified=true`。但性能侧并非全面达标，下面如实说明。

## 假设与证据

固定计算是三段因果卷积（k=5,5,3）加 SiLU，每层只依赖过去 k-1 个样本，所以跨块状态就是三个独立的 `(Cin,k-1)` 历史。我用原 `flashrt.ir` 建图（`backend/ir_validate.py`）：三个算子 `conv_silu_1→2→3`，各自声明 `state_reads/state_writes=hist_i`，scope 为 `chunk_persistent`。结构校验 PASS，依赖分析显示三层跨块互相独立、`find_pipeline_stages` 给出 3 个阶段。由此推断单卡上跨层流水无收益（层间是同一块内的数据依赖），真正的瓶颈是“每块三次小卷积＋每块一次 H2D/D2H”。内部微基准（`bench_internal.py`）印证：T=16384 时纯三段卷积约 1.9–2.0 ms，而参考式逐块 GPU 循环本身就要 14–21 ms。

据此实现的优化：整请求一次三段卷积（有完整历史时直接省去 padding，输出 q 与参考输出 q+(k-1) 同源；只有冷启动前缀用原 replicate padding）；首块先算先发，其余整段算完；输出经复用 pinned 缓冲 D2H 后直接写共享环形帧，省掉一次 8 MB 中间打包拷贝；ready 之前做一次 dummy 前向吃掉 cuDNN 首次初始化。数学路径未变，所以候选与参考实现相对 oracle 的最大误差完全一致，reset 后重放逐位相同（`selftest.py`）。

## 失败与修正

首版整请求方案的打包 reshape 用了 `n_chunks` 而非 `n_chunks-1`，尾部块抛 `cannot reshape`，已修正。纯整请求方案的冷请求首块曾达 398 ms（cuDNN 初始化），改为分阶段上传＋预热后降到约 10.8 ms。pinned 输出最初复用到非连续列切片导致 D2H 变慢，改为严格 `(C,T-chunk)` 连续缓冲。IR 对照脚本首版端口名写成 `features` 而算子端口为 `x`，在 `_gather_inputs` 报错；已改名为 `x`，但开发阶段已用尽请求，该修正版**尚未实际运行**，这是未完成项。

## 性能结果（诚实记录）

官方 `workspace.benchmark` 配对扫描：参考最高通过 100 req/s（200 req/s 时外部队列堆积 54、速率门失败）；候选最高通过 200 req/s（各档外部队列均为 0）。首块输出中位数两者相当（约 1.5–1.6 ms）。但**候选在 50 req/s 档 smoothness 门失败**：输出间隔 p95 19.3 ms、超预算比例 2.0%，略超 20 ms 预算；100/200 req/s 档则全通过（p95 9.5 ms / 4.5 ms，超预算比例 0）。推测是低负载下首块单独上传后其余上传的调度抖动偶发拉长块间隔。自测里大用例稳态最大块间隔约 8–10 ms、冷请求约 10.8 ms，开发用例 <0.75 ms，与官方结果量级一致但未消除该低速率档的尾部。

## 未满足/未完成的要求

1. 候选在 50 req/s 档的 20 ms 块间隔预算存在约 2% 的越界，smoothness 门未通过，属未达标项。
2. 修正后的 `ir_validate.py` 数值对照未再运行（仅结构校验 PASS 有证据）。
3. 大用例剩余时间主要仍是 8 MB 输出经 shm 与固定适配器的多次拷贝，属 IPC 固有限制，未再进一步消除。
4. 单卡场景，IR 识别出的 3 个流水阶段未利用（任务说明多卡要求不适用）。预热使后端启动增加约 0.4 s。

详细记录见 `backend/notes.md`，辅助脚本包括 `selftest.py`、`bench_internal.py`、`bench_e2e.py`、`prof_run.py`、`ir_validate.py`。