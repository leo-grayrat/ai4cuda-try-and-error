# Experiment log — causal_features

Task: continuous causal feature processing, fixed weights (seed 703), three
`CausalConv1d -> SiLU` layers, per-layer convolution history, chunked output.
Correctness oracle: CPU full-sequence `model.full_sequence_oracle` driven
through the fixed adapter; tolerance atol=3e-5, rtol=3e-4.

## Reference behavior / dependency reading

- Per chunk, each layer concatenates its carried input history (`kernel-1`
  columns) with the chunk, convolves causally, slices the new portion, applies
  SiLU, and stores the new tail. State is per-layer and chunk-persistent.
- The only cross-chunk constraint is `history_i(N) -> history_i(N+1)`; the
  three layers' histories are disjoint.
- The adapter publishes a whole request before the worker reads it, and output
  is a ring of `ceil(T/chunk)+4` frames.

## IR (Phase 1–2)

- `ir/ops.py`: `CausalLayerChunk` = one conv+SiLU layer, reads/writes
  `history_<i>` (`chunk_persistent`), `STREAMING`, `EXPOSED`.
- `ir/graph_builder.py`: model graph with 3 ops and fixed-rate 1:1 streaming
  edges; worker graph with one COMPOSITE stage wrapping the model.
- `tests/test_ir.py` (SequentialExecutor): continuation over two requests,
  then reset + replay, plus tail chunk.
  - continuation max|diff| = 6.706e-08, allclose True
  - reset replay max|diff| = 5.215e-08, allclose True, replay matches first
  - tail chunk length 27 covered
  - verdict: **PASS**
- Analysis: 3 independent cross-chunk operator pairs, 3 pipeline stages
  (one per layer, because each owns a separate history), 2 streaming overlaps.
  This is the model-parallel axis; it is not applicable on the single GPU.

## Variants

Names describe the idea, not the iteration order.

### reference_sequential (baseline)
Per-chunk `pipeline.step`: `ceil(T/chunk)*3` conv launches + per-chunk
cat/slice/clone. Dev case = 27 conv launches per request.

### full_sequence_burst (v1)
One causal pass per layer over the whole request, reusing the identical
per-request history recurrence; all chunks written payload-first then
metadata in one multi-frame write.
- `benchmark-003`: candidate highest passing rate 200 (reference 100).
- Candidate gap median dropped to ~0.01 ms (vs reference ~0.55 ms), but at
  50 req/s the cross-request idle produced p95 = 20.02 ms and
  over_budget_fraction = 5.1% → smoothness gate FAIL at that one load.
- Diagnosis: bursting completes a request in ~0.2 ms and then idles for the
  full 20 ms offered period; the gap between the last chunk of one request and
  the first of the next just exceeds the 20 ms budget.

### full_sequence_paced (v2, recommended, `worker.py`)
Same compute, plus: if the previously observed request inter-arrival > 12 ms,
spread the chunks over at most 3 ms (precision busy-wait, avoiding Windows
sleep granularity). High load is never paced.
- `benchmark-005` candidate: all three loads pass rate and smoothness gates;
  highest tested passing rate = 200.
  - 50 req/s: first-out 1.61/2.52 ms, gap 0.53/17.15 ms, 0% over budget
  - 100 req/s: first-out 1.57/2.16 ms, gap 0.008/9.95 ms, 0% over budget
  - 200 req/s: first-out 1.55/2.00 ms, gap 0.006/5.07 ms, 0% over budget
- reference in the same paired run: highest passing rate 100 (rate gate fails
  at 200), gap p95 14.79/3.98/1.62 ms.

## Correctness evidence

- `workspace.verify` (after final worker code): 6/6 requests match CPU oracle,
  max|diff| 5.2e-8 … 8.2e-8, `cleanup_verified: true`.
- `tests/check_large_gpu.py` (large config C=128,H=256,T=16384,chunk=512):
  continuation and reset replay max|diff| = 0.0, **PASS**.
- `tests/test_ir.py`: **PASS**.

## Failures / trade-offs / unfinished

- v1 smoothness failure at low load, fixed by v2 pacing (documented above).
- Pacing uses up to 3 ms of busy-wait per request at low load only; at high
  load it is disabled so it cannot cap throughput.
- Full-sequence batching increases peak activation memory but stays small
  (tens of MB) for the large case; not a constraint on 8 GB.
- Multi-GPU: IR exposes a clean 3-stage layer pipeline, but only one GPU is
  assigned, so no multi-GPU variant was built. Multi-GPU requirements do not
  apply to this observation.
- No separate in-repo benchmark harness was needed: the controller's paired
  reference/candidate sweep provides the latency, sustainable-rate and
  smoothness evidence; the IR and large-config GPU harnesses supplement it.
