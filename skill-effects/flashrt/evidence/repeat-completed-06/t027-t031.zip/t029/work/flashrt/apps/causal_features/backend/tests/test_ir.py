"""Phase 2: execute the IR and compare it to the CPU full-sequence oracle.

The IR models the reference's chunk-periodic recurrence: three exposed
conv+SiLU layers, each owning its own chunk-persistent history state.  We drive
the `SequentialExecutor` chunk by chunk over two continuation requests, then
reset (all histories -> None) and replay the first request.  Every output is
compared against `causal_features.model.full_sequence_oracle`, the protected
CPU full-sequence reference.

Tolerances follow CONTRACT.zh.md: atol=3e-5, rtol=3e-4.  They allow float32
accumulation-order differences between chunked and full-sequence convolution
evaluation while forbidding a change of computation semantics.
"""
import sys
from pathlib import Path

import numpy as np
import torch

from flashrt.paths import repo_root

REPO = repo_root()
sys.path.insert(0, REPO)
sys.path.insert(0, str(Path(REPO) / 'flashrt' / 'apps'))

from causal_features.model import build_layers, full_sequence_oracle  # noqa: E402
from causal_features.backend.ir.graph_builder import (  # noqa: E402
    build_model_graph,
    build_worker_graph,
)
from flashrt.ir import (  # noqa: E402
    SequentialExecutor,
    analyze_cross_chunk_dependencies,
    find_pipeline_stages,
    find_streaming_overlaps,
    summarize_graph,
)

ATOL = 3e-5
RTOL = 3e-4

CONFIG = {
    'channels': 16,
    'hidden': 32,
    'length': 1043,
    'chunk': 127,
    'weight_seed': 703,
    'device': 'cpu',
}


def run_ir(executor, sequence, chunk):
    outputs = []
    with torch.no_grad():
        for start in range(0, sequence.shape[-1], chunk):
            part = torch.from_numpy(
                np.ascontiguousarray(sequence[:, start:start + chunk])
            ).unsqueeze(0)
            result = executor.run_chunk({'features': part}, None)
            outputs.append(result['features'].squeeze(0).numpy())
    return np.concatenate(outputs, axis=-1)


def reset_state(executor, layers):
    executor.init_state({f'history_{i}': None for i in range(len(layers))})


def main():
    torch.manual_seed(1234)
    rng = np.random.default_rng(2026)
    channels = CONFIG['channels']
    length = CONFIG['length']

    layers = build_layers(REPO, CONFIG, 'cpu')
    layers.eval()

    graph = build_model_graph(layers)
    errors = graph.validate()
    print('graph validation errors:', errors)
    assert not errors

    worker_graph = build_worker_graph(layers)
    assert not worker_graph.validate()

    executor = SequentialExecutor(graph)
    reset_state(executor, layers)

    seq_a = rng.standard_normal((channels, length), dtype=np.float32)
    seq_b = rng.standard_normal((channels, length), dtype=np.float32) * 0.5

    # --- Session 1: two continuation requests ---
    session = np.concatenate([seq_a, seq_b], axis=-1)
    oracle = full_sequence_oracle(REPO, CONFIG, session)
    got = run_ir(executor, session, CONFIG['chunk'])
    diff1 = float(np.max(np.abs(got - oracle)))
    ok1 = bool(np.allclose(got, oracle, atol=ATOL, rtol=RTOL))

    # --- reset, then replay the first request (must reproduce request 1) ---
    reset_state(executor, layers)
    oracle_a = full_sequence_oracle(REPO, CONFIG, seq_a)
    got_a = run_ir(executor, seq_a, CONFIG['chunk'])
    diff2 = float(np.max(np.abs(got_a - oracle_a)))
    replay_ok = bool(np.allclose(got_a, got[:, :length], atol=ATOL, rtol=RTOL))
    ok2 = bool(np.allclose(got_a, oracle_a, atol=ATOL, rtol=RTOL))

    # --- tail chunk: last chunk is shorter than the configured chunk ---
    tail_len = length - (length // CONFIG['chunk']) * CONFIG['chunk']
    tail_ok = tail_len > 0 and got.shape[-1] == session.shape[-1]
    print(f'continuation max|diff|={diff1:.3e} allclose={ok1}')
    print(f'reset replay max|diff|={diff2:.3e} allclose={ok2} '
          f'replay_matches_first={replay_ok}')
    print(f'tail chunk length={tail_len} covered={tail_ok}')

    print(summarize_graph(graph, op_latencies={
        f'causal_layer_{i}': 1.0 / len(layers) for i in range(len(layers))
    }))
    dep = analyze_cross_chunk_dependencies(graph)
    print('independent pairs:', dep.independent_pairs)
    print('pipeline stages:', [(s.stage_idx, s.operators) for s in
                               find_pipeline_stages(graph)])
    print('streaming overlaps:', [o.description for o in
                                  find_streaming_overlaps(graph)])
    print('worker graph summary validation:',
          'PASS' if not worker_graph.validate() else 'FAIL')

    verdict = ok1 and ok2 and replay_ok and tail_ok
    print('PASS' if verdict else 'FAIL')
    return 0 if verdict else 1


if __name__ == '__main__':
    sys.exit(main())
