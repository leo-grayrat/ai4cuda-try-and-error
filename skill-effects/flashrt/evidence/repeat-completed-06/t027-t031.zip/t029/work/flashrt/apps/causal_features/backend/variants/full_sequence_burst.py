"""v1 variant: identical full-sequence compute, always bulk-publish.

This reproduces the `full_sequence_burst` behavior measured as benchmark-003:
all chunk payloads are written in one call, then all metadata. It is faster to
drain but leaves a full request-period idle at low offered load, which tripped
the 20 ms smoothness gate at 50 req/s. Keep it as the ablation that motivated
the low-load pacing in `worker.py`; `worker.py` is the recommended entry.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import worker  # noqa: E402


def burst_publish(buffers, padded, metadata, interval):
    del interval
    buffers['output'].write(padded)
    buffers['metadata'].write(metadata)


worker.publish = burst_publish

if __name__ == '__main__':
    worker.main()
