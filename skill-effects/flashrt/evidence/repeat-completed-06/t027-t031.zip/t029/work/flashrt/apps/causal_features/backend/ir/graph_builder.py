"""Build worker-level and model-level IR graphs for causal_features.

Worker level: one COMPOSITE stage that wraps the three-layer causal model and
streams 1:1 chunks to the adapter.

Model level: the three `CausalConv1d -> SiLU` layers as separate exposed
operators connected by fixed-rate 1:1 streaming edges.  State independence is
deliberately NOT shared: each layer owns `history_<i>`, so
`find_pipeline_stages` reports three separate stages that could be pipelined
across chunks (one per device) if more devices were available.
"""
from flashrt.ir import (
    IREdge,
    IRGraph,
    IROperator,
    OpType,
    StateObject,
    StreamMode,
    StreamingInfo,
    StreamingPattern,
    TensorPort,
)

from .ops import CausalLayerChunk


def build_model_graph(layers):
    graph = IRGraph(name="causal_features_model")
    graph.external_inputs = [TensorPort("features")]
    graph.external_outputs = [TensorPort("features")]

    ops = []
    for index, layer in enumerate(layers):
        op = CausalLayerChunk(index, layer)
        graph.add_operator(op)
        graph.add_state(StateObject(
            op.hist_name,
            description=f"last {op.pad} input columns of causal layer {index}",
            scope="chunk_persistent",
        ))
        ops.append(op)

    for src, dst in zip(ops, ops[1:]):
        graph.add_edge(IREdge(
            src_op=src.name, src_port="features",
            dst_op=dst.name, dst_port="features",
            streaming=StreamingInfo(
                pattern=StreamingPattern.FIXED_RATE,
                src_chunk_size=1, dst_chunk_size=1,
                description="layer stream is 1:1 in chunks; downstream can "
                            "consume each chunk as it is produced",
            ),
        ))

    graph.chunk_ops = [op.name for op in ops]
    return graph


def build_worker_graph(layers):
    model = build_model_graph(layers)
    graph = IRGraph(name="causal_features_worker")
    graph.sub_graphs = {model.name: model}
    graph.external_inputs = [TensorPort("features")]
    graph.external_outputs = [TensorPort("features")]

    states = [f"history_{i}" for i in range(len(layers))]
    stage = IROperator(
        name="causal_feature_model",
        op_type=OpType.COMPOSITE,
        inputs=[TensorPort("features")],
        outputs=[TensorPort("features")],
        state_reads=states,
        state_writes=states,
        stream_mode=StreamMode.STREAMING,
        sub_graph=model.name,
    )
    graph.add_operator(stage)
    for i in range(len(layers)):
        graph.add_state(StateObject(f"history_{i}", scope="chunk_persistent"))
    graph.chunk_ops = [stage.name]
    return graph
