"""Operators for the causal_features IR.

Each operator is one `CausalConv1d -> SiLU` layer of the fixed network.  Its
only persistent state is the convolution history that the reference stores per
layer (`self.histories[index]`); that history is the cross-chunk dependency the
IR makes explicit.
"""
import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort


class CausalLayerChunk(IROperator):
    """One causal conv layer evaluated on one chunk, plus SiLU.

    State: `history_<index>` holds the last kernel_size-1 columns of this
    layer's input, exactly like the reference pipeline's per-layer history.
    It is chunk-persistent: chunk N+1 cannot run before chunk N writes it.
    """

    def __init__(self, index, layer):
        self.index = int(index)
        self.layer = layer
        self.pad = int(layer._time_causal_padding[0])
        self.hist_name = f"history_{self.index}"
        super().__init__(
            name=f"causal_layer_{self.index}",
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("features")],
            outputs=[TensorPort("features")],
            state_reads=[self.hist_name],
            state_writes=[self.hist_name],
            stream_mode=StreamMode.STREAMING,
            config={"kernel_size": self.pad + 1},
        )

    def execute(self, inputs, ctx, state):
        value = inputs["features"]
        history = state.get(self.hist_name)
        if history is None:
            joined = value
            out = self.layer(joined)
        else:
            joined = torch.cat([history, value], dim=-1)
            out = self.layer(joined)
            out = out[:, :, history.shape[-1]:]
        if self.pad > 0:
            state.set(self.hist_name, joined[:, :, -self.pad:].clone())
        else:
            state.set(self.hist_name, joined[:, :, :0].clone())
        return {"features": F.silu(out)}
