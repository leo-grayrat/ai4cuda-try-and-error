"""GPU diagnostic: full-sequence worker vs the reference chunk recurrence.

Runs the large configuration (C=128, H=256, T=16384, chunk=512) on the GPU.
The reference `ReferencePipeline.step` is driven one chunk at a time; the
candidate `run_request` evaluates the whole request in one causal pass per
layer.  Both build weights with the same fixed seed.  Covers two continuation
requests plus a reset-and-replay.  This complements the adapter-level
verification with the large case that CONTRACT.zh.md says belongs to the same
task.
"""
import sys
from pathlib import Path

import numpy as np
import torch

from flashrt.paths import repo_root

REPO = repo_root()
sys.path.insert(0, REPO)
sys.path.insert(0, str(Path(REPO) / 'flashrt' / 'apps'))

from causal_features.backend.worker import run_request  # noqa: E402
from causal_features.model import ReferencePipeline, build_layers  # noqa: E402

ATOL = 3e-5
RTOL = 3e-4

CONFIG = {
    'channels': 128,
    'hidden': 256,
    'length': 16384,
    'chunk': 512,
    'weight_seed': 703,
    'device': 'cuda',
}


def reference_session(pipeline, sequences, chunk):
    outs = []
    for seq in sequences:
        pieces = [pipeline.step(seq[:, p:p + chunk])
                  for p in range(0, seq.shape[-1], chunk)]
        outs.append(np.concatenate(pieces, axis=-1))
    return outs


def candidate_session(layers, sequences, device):
    histories = [None] * len(layers)
    outs = []
    for seq in sequences:
        outs.append(run_request(seq, layers, histories, device)
                    .to(torch.float32).cpu().numpy())
    return outs


def main():
    if not torch.cuda.is_available():
        print('FAIL: CUDA is not available for the GPU diagnostic')
        return 1
    device = torch.device(CONFIG['device'])
    rng = np.random.default_rng(7)

    layers = build_layers(REPO, CONFIG, device).eval()
    pipeline = ReferencePipeline(REPO, CONFIG)

    seq_a = rng.standard_normal((128, 16384), dtype=np.float32)
    seq_b = rng.standard_normal((128, 16384), dtype=np.float32) * 0.5

    ref = reference_session(pipeline, [seq_a, seq_b], CONFIG['chunk'])
    cand = candidate_session(layers, [seq_a, seq_b], device)
    diffs = [float(np.max(np.abs(r - c))) for r, c in zip(ref, cand)]
    oks = [bool(np.allclose(r, c, atol=ATOL, rtol=RTOL))
           for r, c in zip(ref, cand)]

    # reset both, replay the first request
    pipeline.reset()
    replay = candidate_session(layers, [seq_a], device)[0]
    ref_a = reference_session(pipeline, [seq_a], CONFIG['chunk'])[0]
    diff_reset = float(np.max(np.abs(ref_a - replay)))
    ok_reset = bool(np.allclose(ref_a, replay, atol=ATOL, rtol=RTOL))

    print('large-config continuation max|diff| =', diffs, 'allclose =', oks)
    print('large-config reset replay max|diff| =', diff_reset,
          'allclose =', ok_reset)
    verdict = all(oks) and ok_reset
    print('PASS' if verdict else 'FAIL')
    return 0 if verdict else 1


if __name__ == '__main__':
    sys.exit(main())
