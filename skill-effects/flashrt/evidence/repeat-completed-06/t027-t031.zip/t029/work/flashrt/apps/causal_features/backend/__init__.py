"""Optimized backend workspace for the causal_features task."""
