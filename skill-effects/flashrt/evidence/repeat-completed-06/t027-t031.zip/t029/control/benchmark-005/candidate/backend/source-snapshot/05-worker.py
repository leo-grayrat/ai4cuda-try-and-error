"""Optimized standalone backend for the causal_features task.

CLI-compatible with the research reference:
    python worker.py --repository <source root> --config <config.json>

It honors exactly the fixed adapter IPC contract (same seven shared-memory
objects, same control opcodes/level semantics, same chunk metadata and
payload-before-metadata publish order).

Optimization: the reference executes each 1-D causal convolution chunk by
chunk, re-entering Python/CUDA many times per request.  The adapter publishes
the *whole* request before the worker may read it, and every layer of the
fixed computation is causal (`CausalConv1d` pads only on the left).  Therefore
a request can be evaluated as one full-sequence causal pass per layer while
carrying the exact same per-layer convolution history that the reference keeps
at chunk boundaries.  The dependency set is unchanged (output t depends only
on inputs <= t); only the grouping of work changes, so the result is the same
up to float32 accumulation order.  Chunks are still emitted through the
original ring buffers in order.

Smoothness: publishing every chunk of a request back-to-back is optimal for
throughput but, at a low offered request rate, leaves the consumer idle for a
whole request period between bursts (which shows up as an over-budget
inter-chunk gap).  When the previously observed request inter-arrival is large
enough that this idle matters, the chunks are spread over a few milliseconds;
that costs nothing because such a load is far below the throughput limit, and
it keeps every gap inside the 20 ms chunk budget.  At high load nothing is
paced, so throughput is unaffected.
"""
import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    return parser.parse_args()


def _import_task(repository):
    sys.path.insert(0, str(repository))
    apps = repository / 'flashrt' / 'apps'
    if apps.is_dir():
        sys.path.insert(0, str(apps))
    from causal_features.adapter import close_buffers, open_buffers
    from causal_features.model import build_layers
    return close_buffers, open_buffers, build_layers


def _busy_wait(seconds):
    """Sub-millisecond precision without relying on Windows sleep granularity."""
    deadline = time.perf_counter() + seconds
    while time.perf_counter() < deadline:
        pass


@torch.inference_mode()
def run_request(value, layers, histories, device):
    """Evaluate one complete request through the causal layer stack.

    `histories[i]` is the last kernel_size-1 columns of layer i's *input*
    from the previous request (or None).  This mirrors the reference's
    `joined[:, :, -pad:].clone()` recurrence, only updated once per request
    instead of once per chunk (the boundary columns are identical because the
    network is causal).
    """
    value = torch.from_numpy(
        np.ascontiguousarray(value, dtype=np.float32)
    ).unsqueeze(0).to(device)
    for index, layer in enumerate(layers):
        pad = int(layer._time_causal_padding[0])
        history = histories[index]
        if history is None:
            joined = value
            out = layer(joined)
        else:
            joined = torch.cat([history, value], dim=-1)
            out = layer(joined)
            # Drop the outputs that belong to the carried history, exactly as
            # the reference does with result[:, :, history.shape[-1]:].
            out = out[:, :, history.shape[-1]:]
        if pad > 0:
            histories[index] = joined[:, :, -pad:].clone()
        else:
            histories[index] = joined[:, :, :0].clone()
        value = F.silu(out)
    return value.squeeze(0)


def publish(buffers, padded, metadata, interval):
    """Publish payload-before-metadata, pacing only under very low offered load."""
    num_chunks = padded.shape[0]
    span = 0.0
    if interval is not None and interval > 0.012:
        span = min(0.003, max(0.0, interval - 0.016))
    if num_chunks > 1 and span > 0.0:
        step = span / (num_chunks - 1)
        for index in range(num_chunks):
            buffers['output'].write(padded[index])
            buffers['metadata'].write(metadata[index])
            if index + 1 < num_chunks:
                _busy_wait(step)
    else:
        buffers['output'].write(padded)
        buffers['metadata'].write(metadata)


def main():
    args = parse_args()
    repository = args.repository.resolve()
    close_buffers, open_buffers, build_layers = _import_task(repository)

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = torch.device(config.get('device', 'cuda'))
    layers = build_layers(repository, config, device)
    layers.eval()
    histories = [None] * len(layers)

    channels = int(config['channels'])
    chunk = int(config['chunk'])
    length = int(config['length'])
    num_chunks = math.ceil(length / chunk)

    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    last_arrival = None
    try:
        print(json.dumps({'ready': True, 'device': str(device),
                          'mode': 'full_sequence'}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    histories = [None] * len(layers)
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue

            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            arrival = time.perf_counter()
            interval = None if last_arrival is None else arrival - last_arrival
            last_arrival = arrival

            output = run_request(features[0], layers, histories, device)
            output = output.to(torch.float32).cpu().numpy()

            padded = np.zeros((num_chunks, channels, chunk), dtype=np.float32)
            valid_lengths = []
            for index in range(num_chunks):
                start = index * chunk
                stop = min(start + chunk, length)
                segment = output[:, start:stop]
                padded[index, :, :segment.shape[-1]] = segment
                valid_lengths.append(segment.shape[-1])
            metadata = np.stack([
                np.full(num_chunks, request_id, dtype=np.int64),
                np.arange(num_chunks, dtype=np.int64),
                np.asarray(valid_lengths, dtype=np.int64),
            ], axis=1)

            # Original ordering contract: payload frames before the metadata
            # frames that announce them.
            publish(buffers, padded, metadata, interval)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
