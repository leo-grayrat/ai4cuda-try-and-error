观察结果（诚实报告，未完成全部要求）。

任务与实现：我在 `flashrt/apps/causal_features/backend/` 下建立了一个独立后端，入口 `backend/worker.py`（只接受 `--repository` 与 `--config`，严格复用原 `causal_features.adapter` 的 IPC：`open_buffers` 创建同一组共享内存、控制码 1/3/2、先发布 payload 再发布 metadata、每块有效长度）。核心在 `backend/core.py`：全部变体共用一个 `Engine`，通过 11 个命名预设（`full`、`chunked_compute`、`spin`、`fastpub`、`view`、`pinned`、`split_first`、`async_chunks`、`cuda_graph`、`graph_async`、`graph_split`）一一对应到 `backend/variants/worker_<name>.py`，每个都可端到端启动。

假设与证据：
1) 计算等价性：参考实现对每块做 3×(cat/conv/slice/clone)+silu，每层历史恰为该层输入的末 k-1 个值；因此对 `[history|request]` 一次整段卷积再整段 D2H，消耗同一组数值。reset 后的第一请求需要 replicate 左填充，等价于用 `v[...,0]` 复制 pad 次作为头部。经验证，这与参考逐位相同：`tests/results/correctness_20261020_023211.json` 显示 4 组配置（dev 16/32/1043/127（含末短块）、tail 250/64、one_chunk_tail 100/127、mid 64/128/2048/256）× 11 个变体共 44 对中 43 对 PASS，且与参考后端的 max|diff| 全为 0.000e+00（容差 atol=3e-5、rtol=3e-4），与 CPU 全序列 oracle 的最大偏差 ≤1.3e-7（reference 本身 7.5e-8，属 float32 累加顺序）。唯一 FAIL 是 `split_first` 在 `one_chunk_tail`（length<chunk、split 前缀吞掉整条请求）超时；我随后在 `patch2.py` 中修复了该分支（`first_end >= length` 时直接返回），但修复后未重跑该配置，故该条目仍应视为未验证。
2) IR：`backend/ir/state_graph.py` 用原始 `flashrt.ir`（`IRGraph`/`IROperator`/`StateObject`）分别构建参考“逐块调度”图与部署“整段流式调度”图，`tests/test_ir.py` 用 `SequentialExecutor` 在六请求序列（连续、不重置重复输入、复位复现、尾块）上执行，两图与参考后端逐块比较均为 0.000e+00，打印 `IR_VERDICT: PASS`。`summarize_graph` 输出已存 `notes/ir_analysis.txt`：3 个 `chunk_persistent` 状态（`history_0..2`），跨块依赖各自自环，层间被识别为相互独立对（5 个流水阶段），无 streaming 边。分析含义：单请求内三层是严格串行乘法链，跨块层面合并路径在宿主往返——这与我选择的“一次整段”方向一致。

失败与未完成项：
- 性能测量全部作废/缺失。`benchmarks/bench.py` 两次运行（`sweep_dev1.json`、`sweep_all1.json`）对 reference 与 11 个变体全部报 `RuntimeError('request or chunk order differs from the contract')`：先是 TightDriver 从游标 0 读而 adapter 已推进，改为从 `metadata.num` 起读后仍然失败，说明参考后端与紧轮询驱动在同一后端进程内交替使用时输出序号不匹配，我的驱动实现有缺陷。结论：我没有任何有效的延迟（首块 median/p95）、可持续输出速率、块间间隔（中位/p95、超 20ms 预算比例）数据；仅完成正确性与 IR 数值比较。
- 因而“推荐变体相对参考必须显著更好且不退化”的定义完成项无法成立：`core.RECOMMENDED = "cuda_graph"` 只是基于正确性 PASS 与实现预期选定，未有任何基准支撑；官方 `workspace.verify`/`workspace.benchmark` 也未能在本轮对最终代码调用（最后一次代码改动是 `patch7.py`，其后的运行仍失败）。
- 未写 `backend/README.md`、未写 `notes/experiment_log.md`（含变体队列、逐块记录、adversarial self-framing 段落），也未做 forbidden-language 机械检索；这属于文档与流程要求的未完成部分。队列中每个变体虽都实际启动并做过正确性比较，但由于没有基准 JSON，按仓库规则都不能算 `measured`。
- 单 GPU 限制下多 GPU 拆分不适用；我不曾尝试跨 GPU 放置。

总结：正确性方向（整段流式一次通过 + 精确历史语义 + 适配器协议不变）已由参考后端与 CPU oracle 双重数值验证（逐位相等），IR 转换与分解也通过 `SequentialExecutor` 验证并记录；但性能目标（首输出延迟、可持续速率与平滑性）与配套文档完全未获有效证据，基准工具仍有缺陷，`split_first` 的边界修复未复测，因此本会话未达到完成标准。