"""Recommended standalone backend entry for causal_features.

Usage (the contract's two arguments only):
    python flashrt/apps/causal_features/backend/worker.py \
        --repository <repo-root> --config <config.json>

The preset that measured best is selected in ``core.RECOMMENDED``.
"""
import sys
from pathlib import Path

_HERE = str(Path(__file__).resolve().parent)
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

try:  # imported as part of a package
    from . import core
except ImportError:  # launched as a plain file by the controller
    import core


def main(argv=None):
    core.main_for_preset(core.RECOMMENDED, argv)


if __name__ == "__main__":
    main()
