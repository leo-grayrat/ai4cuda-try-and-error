"""Phase-2 IR validation: SequentialExecutor vs the protected reference backend.

Both IR graphs (the reference chunk schedule and the whole-request stream
schedule used by the deployment) are executed with the original
``SequentialExecutor`` over the six-request sequence, and compared
chunk-for-chunk with the reference backend driven through the fixed adapter.
"""
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BACKEND = HERE.parent
for _p in (HERE, BACKEND):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import common  # noqa: E402
from common import ATOL, RTOL, Launched, make_config, run_six, scenario_inputs  # noqa: E402
from flashrt.ir import SequentialExecutor, summarize_graph  # noqa: E402
from ir.state_graph import build_graph  # noqa: E402

SHAPE = dict(channels=16, hidden=32, length=1043, chunk=127)


class Context:
    pass


def run_graph(span, pads, layers, payloads, config, device):
    graph = build_graph(span, pads)
    executor = SequentialExecutor(graph)
    executor.init_state({f"history_{i}": None for i in range(len(pads))})
    spans = [(s, min(config["length"], s + config["chunk"]))
             for s in range(0, config["length"], config["chunk"])]
    ctx = Context()
    ctx.layers, ctx.device, ctx.spans = layers, device, spans
    results = []
    for payload_index, reset in common.SIX_REQUEST_PLAN:
        if reset:
            executor.init_state({f"history_{i}": None for i in range(len(pads))})
        features = payloads[payload_index]
        ctx.features = features
        ctx.request = __import__("torch").from_numpy(features).unsqueeze(0).to(device)
        chunks = []
        def _emit(index, value, valid, _spans=spans, _span=span):
            start = 0 if _span == 'chunk' else _spans[index][0]
            chunks.append(value[0].detach().cpu().numpy()[:, start:start + valid])
        ctx.emit = _emit
        if span == "chunk":
            for index, (start, stop) in enumerate(spans):
                ctx.index, ctx.start, ctx.stop = index, start, stop
                executor.run_chunk({}, ctx)
        else:
            executor.run_chunk({}, ctx)
        results.append(np.concatenate(chunks, axis=-1))
    return graph, results


def max_diff(a, b):
    return float(np.abs(a - b).max()) if a.shape == b.shape else float("inf")


def main():
    from causal_features.model import build_layers

    payloads = scenario_inputs(SHAPE["channels"], SHAPE["length"], seed=17 + len("dev"))
    config = make_config(**SHAPE, prefix="cfirdev")
    with Launched("reference", config, "ref_ir") as ref:
        reference_out = [item[0] for item in run_six(ref, payloads)]
        ref_log = str(ref.log_path)
    layers = build_layers(common.REPO, config, config["device"])
    pads = [int(layer._time_causal_padding[0]) for layer in layers]

    verdicts = []
    summaries = []
    for span in ("chunk", "stream"):
        graph, outputs = run_graph(span, pads, layers, payloads, config, config["device"])
        diffs = [max_diff(out, ref) for out, ref in zip(outputs, reference_out)]
        ok = all(d <= ATOL + RTOL for d in diffs)
        verdicts.append(ok)
        print(f"[ir:{span}] PASS={ok} max|diff| vs reference per request: "
              + ", ".join(f"{d:.3e}" for d in diffs), flush=True)
        summaries.append(f"=== summarize_graph({graph.name}) ===\n"
                         + summarize_graph(graph))
    text = "\n\n".join(summaries)
    (BACKEND / "notes").mkdir(parents=True, exist_ok=True)
    (BACKEND / "notes" / "ir_analysis.txt").write_text(text, encoding="utf-8")
    print(text, flush=True)
    print(f"reference_log: {ref_log}", flush=True)
    print(f"IR_VERDICT: {'PASS' if all(verdicts) else 'FAIL'}", flush=True)
    return 0 if all(verdicts) else 1


if __name__ == "__main__":
    sys.exit(main())
