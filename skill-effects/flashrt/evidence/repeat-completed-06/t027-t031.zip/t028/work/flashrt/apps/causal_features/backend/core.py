"""Optimized causal_features streaming backend core (1 x RTX 5060 8 GB, Windows).

Read-only imports only: the fixed computation spec (``causal_features.model``),
the fixed IPC contract (``causal_features.adapter``) and the shared channel
classes it opens.  Nothing outside this workspace is modified.

Reference schedule (``reference.py::main``) for one request of length T:
  for each of ceil(T/chunk) chunks: slice 1 chunk -> 3 x (cat, conv, slice,
  clone) -> silu -> device->host copy -> publish payload -> publish metadata.
That is 12 device ops and one host synchronisation per chunk, i.e. the whole
request is serialised through the host T/chunk times even though the input
frame for the request is published in one piece.

The network is strictly causal and the per-layer state is exactly the last
k-1 values of that layer's input stream (``joined[:, :, -pad:]`` in
reference.py).  Therefore one pass over ``[history | request]`` (history length
== pad == k-1) followed by a slice at index ``pad`` consumes *exactly* the same
values as the chunked schedule, and the replicate pad of the first request after
a reset is reproduced exactly by pre-filling the head with ``v[..., 0]``
repeated ``pad`` times (F.pad(replicate) is literally ``[x0]*pad + x``).

Every optimization lever is a named preset so each measured variant is a
standalone, runnable backend honouring the same adapter protocol:

  compute      'full'    one whole-request three-layer pass (schedule lever)
               'chunked' reference-style per-chunk passes (isolates the
                         per-chunk model lever from the schedule lever)
  read         'copy'    SharedTensorBuffer.read()
               'view'    zero-copy view of the published frame (one in-flight
                         request + payload-published-before-cursor makes the
                         frame immutable for the duration of the request)
  publish      'canonical' SharedTensorBuffer.write()
               'inline'    identical two stores (payload, then cursor) inlined
  poll         'sleep'   reference-style 0.2 ms sleep
               'spin'    busy poll with periodic yield
  pinned       staged pinned host memory for H2D / D2H transfers
  split        N leading chunks computed and published in their own pass
  async_chunks per-chunk D2H with event-ordered publishing
  graph        CUDA-graph replay of the whole three-layer pass (+ D2H)
  direct_conv  hand ``layer.conv`` the already left-padded joined buffer and
               drop the layer's own replicate pad plus the extra slice
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


@dataclass(frozen=True)
class Preset:
    compute: str = "full"          # 'full' | 'chunked'
    read: str = "copy"             # 'copy' | 'view'
    publish: str = "canonical"     # 'canonical' | 'inline'
    poll: str = "sleep"            # 'sleep' | 'spin'
    pinned: bool = False
    split: int = 0                 # leading chunks emitted from their own pass
    async_chunks: bool = False
    graph: bool = False
    graph_d2h: bool = True
    direct_conv: bool = False


PRESETS = {
    # scheduling lever only
    "full": Preset(),
    "chunked_compute": Preset(compute="chunked"),
    # host-path levers, added one at a time
    "spin": Preset(poll="spin"),
    "fastpub": Preset(poll="spin", publish="inline"),
    "view": Preset(poll="spin", publish="inline", read="view"),
    "pinned": Preset(poll="spin", publish="inline", read="view", pinned=True,
                     direct_conv=True),
    # first-output-latency lever
    "split_first": Preset(poll="spin", publish="inline", read="view", pinned=True,
                          direct_conv=True, split=1),
    # streaming / smoothness lever
    "async_chunks": Preset(poll="spin", publish="inline", read="view", pinned=True,
                           direct_conv=True, async_chunks=True),
    # per-chunk model-execution lever
    "cuda_graph": Preset(poll="spin", publish="inline", read="view", pinned=True,
                         direct_conv=True, graph=True),
    "graph_async": Preset(poll="spin", publish="inline", read="view", pinned=True,
                          direct_conv=True, graph=True, graph_d2h=False),
    # combinations
    "graph_split": Preset(poll="spin", publish="inline", read="view", pinned=True,
                          direct_conv=True, graph=True, split=1),
}

RECOMMENDED = "cuda_graph"


class Engine:
    """Whole-request three-layer pass with explicit pad-length layer histories."""

    def __init__(self, repository, config, preset: Preset):
        from causal_features.model import build_layers  # fixed spec, read-only

        self.preset = preset
        self.dev = torch.device(config.get("device") or "cuda")
        self.layers = build_layers(repository, config, self.dev)
        self.channels = int(config["channels"])
        self.length = int(config["length"])
        self.chunk = int(config["chunk"])
        self.pads = [int(layer._time_causal_padding[0]) for layer in self.layers]
        self.in_ch = [int(layer.conv.weight.shape[1]) for layer in self.layers]
        self.spans = [(s, min(self.length, s + self.chunk))
                      for s in range(0, self.length, self.chunk)]
        self.max_pad = max(self.pads)
        self.heads = [None] * len(self.layers)

        pin = bool(preset.pinned)
        self.host_in = torch.empty(self.channels, self.length, pin_memory=pin)
        self.host_in_np = self.host_in.numpy()
        self.host_out = torch.empty(self.channels, self.length, pin_memory=pin)
        self.host_out_np = self.host_out.numpy()
        self.host_chunk = torch.empty(self.channels, self.chunk, pin_memory=pin)
        self.host_chunk_np = self.host_chunk.numpy()
        self.padded = np.zeros((self.channels, self.chunk), dtype=np.float32)
        self.gpu_in = None
        if pin and not preset.graph:
            self.gpu_in = torch.empty(1, self.channels, self.length, device=self.dev)

        self.graph = None
        self.g_join = None
        self.g_head = None
        self.g_fresh = None
        self.g_out = None
        if preset.graph:
            if self.length <= self.max_pad:
                print(json.dumps({"graph": "skipped", "reason": "length <= pad"}),
                      flush=True)
            else:
                try:
                    self._capture()
                    print(json.dumps({"graph": "captured",
                                      "d2h_in_graph": preset.graph_d2h}), flush=True)
                except Exception as exc:  # noqa: BLE001 - degrade, never fail
                    self.graph = None
                    print(json.dumps({"graph": "failed", "error": repr(exc)}),
                          flush=True)

    # ---------------------------------------------------------------- state
    def reset(self):
        self.heads = [None] * len(self.layers)
        if self.g_fresh is not None:
            self.g_fresh.fill_(True)

    # ------------------------------------------------------------ CUDA graph
    @torch.inference_mode()
    def _graph_forward(self):
        fresh = self.g_fresh
        v = self.g_join[0][:, :, self.pads[0]:]
        for index, layer in enumerate(self.layers):
            pad = self.pads[index]
            joined = self.g_join[index]
            if index:
                joined[:, :, pad:].copy_(v)
            joined[:, :, :pad].copy_(
                torch.where(fresh, v[:, :, :1].expand(-1, -1, pad), self.g_head[index]))
            v = F.silu(layer.conv(joined))
            self.g_head[index].copy_(joined[:, :, -pad:])
        self.g_out.copy_(v)
        if self.preset.graph_d2h:
            self.host_out.copy_(self.g_out[0], non_blocking=True)

    def _capture(self):
        dev = self.dev
        self.g_join = [torch.zeros(1, ch, self.length + pad, device=dev)
                       for ch, pad in zip(self.in_ch, self.pads)]
        self.g_head = [torch.zeros(1, ch, pad, device=dev)
                       for ch, pad in zip(self.in_ch, self.pads)]
        self.g_fresh = torch.zeros((), dtype=torch.bool, device=dev)
        self.g_out = torch.empty(1, self.channels, self.length, device=dev)
        self.g_fresh.fill_(True)
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(3):
                self._graph_forward()
        torch.cuda.current_stream().wait_stream(side)
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            self._graph_forward()
        self.graph = graph

    # ------------------------------------------------------------- forward
    @torch.inference_mode()
    def _forward_full(self, x):
        """One pass over [history | x]; consumes the same values as reference.py."""
        if x.shape[-1] == 0:
            return x
        v = x
        for index, layer in enumerate(self.layers):
            pad = self.pads[index]
            head = self.heads[index]
            hl = 0 if head is None else head.shape[-1]
            if head is None:
                joined = v
            else:
                joined = torch.cat([head, v], dim=-1)
            if self.preset.direct_conv and hl == pad:
                out = layer.conv(joined)
            else:
                out = layer(joined)[:, :, hl:]
            tail = joined[:, :, -pad:]
            self.heads[index] = tail.clone() if tail.shape[-1] else tail
            v = F.silu(out)
        return v

    @torch.inference_mode()
    def _forward_step(self, piece):
        """Reference-shaped single-chunk step (used by the split / chunked paths)."""
        v = piece
        for index, layer in enumerate(self.layers):
            pad = self.pads[index]
            head = self.heads[index]
            hl = 0 if head is None else head.shape[-1]
            joined = v if head is None else torch.cat([head, v], dim=-1)
            out = layer(joined)[:, :, hl:]
            tail = joined[:, :, -pad:]
            self.heads[index] = tail.clone() if tail.shape[-1] else tail
            v = F.silu(out)
        return v

    def _input_dev(self):
        if self.gpu_in is not None:
            self.gpu_in.copy_(self.host_in, non_blocking=True)
            return self.gpu_in
        return torch.from_numpy(self.host_in_np).unsqueeze(0).to(self.dev)

    # ------------------------------------------------------------ schedule
    def begin(self, features):
        """Stage the published request frame into pinned/shared host memory."""
        np.copyto(self.host_in_np, features, casting="unsafe")

    def process(self, emit):
        """Run one request, emitting every output chunk through ``emit``."""
        preset = self.preset
        if preset.graph and self.graph is not None:
            self.g_join[0][:, :, self.pads[0]:].copy_(self.host_in, non_blocking=True)
            self.graph.replay()
            if preset.graph_d2h:
                torch.cuda.current_stream().synchronize()
                for index, (start, end) in enumerate(self.spans):
                    emit(index, self.host_out_np[:, start:end], end - start)
            else:
                events = []
                for start, end in self.spans:
                    self.host_out[:, start:end].copy_(self.g_out[0, :, start:end],
                                                      non_blocking=True)
                    event = torch.cuda.Event()
                    event.record()
                    events.append(event)
                for index, ((start, end), event) in enumerate(zip(self.spans, events)):
                    event.synchronize()
                    emit(index, self.host_out_np[:, start:end], end - start)
            self.g_fresh.fill_(False)
            return

        if preset.compute == "chunked":
            x = self._input_dev()
            for index, (start, end) in enumerate(self.spans):
                value = self._forward_step(x[:, :, start:end])
                self.host_chunk[:, :end - start].copy_(value[0], non_blocking=True)
                torch.cuda.current_stream().synchronize()
                emit(index, self.host_chunk_np[:, :end - start], end - start)
            return

        x = self._input_dev()
        first_end = 0
        if preset.split:
            first_end = min(self.length, preset.split * self.chunk)
            for index, (start, end) in enumerate(self.spans):
                if start >= first_end:
                    break
                value = self._forward_step(x[:, :, start:end])
                self.host_chunk[:, :end - start].copy_(value[0], non_blocking=True)
                torch.cuda.current_stream().synchronize()
                emit(index, self.host_chunk_np[:, :end - start], end - start)

        if first_end >= self.length:
            return
        value = self._forward_full(x[:, :, first_end:]) if first_end else self._forward_full(x)
        offset = first_end
        if preset.async_chunks:
            events = []
            for start, end in self.spans:
                if end <= offset:
                    continue
                self.host_out[:, start:end].copy_(value[0, :, start - offset:end - offset],
                                                  non_blocking=True)
                event = torch.cuda.Event()
                event.record()
                events.append(event)
            pending = [span for span in self.spans if span[1] > offset]
            for index, ((start, end), event) in enumerate(zip(pending, events)):
                event.synchronize()
                emit(index + (len(self.spans) - len(pending)),
                     self.host_out_np[:, start:end], end - start)
        else:
            self.host_out[:, offset:].copy_(value[0], non_blocking=True)
            torch.cuda.current_stream().synchronize()
            for index, (start, end) in enumerate(self.spans):
                if end <= offset:
                    continue
                emit(index, self.host_out_np[:, start:end], end - start)


def _make_emitter(buffers, preset: Preset, request_id: int, channels: int, chunk: int):
    """Publish payload first, then metadata, exactly like reference.py."""
    padded = np.zeros((channels, chunk), dtype=np.float32)
    meta = np.zeros(3, dtype=np.int64)
    out_buf, meta_buf = buffers["output"], buffers["metadata"]
    if preset.publish == "inline":
        out_tensor, out_num, out_cap = out_buf.tensor, out_buf.num_arr, out_buf.max_len
        meta_tensor, meta_num, meta_cap = meta_buf.tensor, meta_buf.num_arr, meta_buf.max_len

    def emit(index, source, valid):
        padded[:, :valid] = source
        if valid < chunk:
            padded[:, valid:] = 0.0
        meta[0], meta[1], meta[2] = request_id, index, valid
        if preset.publish == "inline":
            count = int(out_num[0])
            out_tensor[count % out_cap] = padded
            out_num[0] = count + 1
            count = int(meta_num[0])
            meta_tensor[count % meta_cap] = meta
            meta_num[0] = count + 1
        else:
            out_buf.write(padded)
            meta_buf.write(meta)

    return emit


def run(repository, config_path, preset_name: str | None = None,
        preset: Preset | None = None):
    preset = preset or PRESETS[preset_name]
    repository = Path(repository).resolve()
    if str(repository) not in sys.path:
        sys.path.insert(0, str(repository))
    from causal_features.adapter import close_buffers, open_buffers  # fixed contract

    config = json.loads(Path(config_path).read_text(encoding="utf-8"))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    engine = Engine(repository, config, preset)
    buffers = open_buffers(config, create=True)
    control, in_buf = buffers["control"], buffers["input"]
    in_num, in_tensor, in_cap = in_buf.num_arr, in_buf.tensor, in_buf.max_len
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({"ready": True, "device": str(config.get("device")),
                          "preset": preset_name}), flush=True)
        while True:
            opcode = control.value
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    control.commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    control.commit()
                elif opcode == 1:
                    active = True
                    control.commit()
                elif opcode != 0:
                    raise ValueError(f"Unknown control opcode: {opcode}")
            if not active:
                if preset.poll == "sleep":
                    time.sleep(0.0002)
                continue
            count = int(in_num[0])
            if count <= consumed:
                if preset.poll == "sleep":
                    time.sleep(0.0002)
                continue
            if count != consumed + 1:
                raise RuntimeError("Input overwritten before processing")
            if preset.read == "view":
                features = in_tensor[consumed % in_cap]
            else:
                features = in_buf.read(consumed, 1)[1][0]
            engine.begin(features)
            emit = _make_emitter(buffers, preset, consumed, engine.channels, engine.chunk)
            engine.process(emit)
            consumed = count
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({"closed": True}), flush=True)


def _parse_args(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    return parser.parse_args(argv)


def main_for_preset(name: str, argv=None):
    args = _parse_args(argv)
    run(args.repository, args.config, name)
