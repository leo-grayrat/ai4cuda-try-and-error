"""Shared harness utilities: launch a backend, drive it through the fixed adapter.

Nothing here is imported by the backend; it is test/benchmark scaffolding only.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np

BACKEND = Path(__file__).resolve().parents[1]
REPO = BACKEND.parents[3]
REFERENCE = BACKEND.parent / "reference.py"
APPS_DIR = REPO / "flashrt" / "apps"
TMP = BACKEND / "tests" / "tmp"
TMP.mkdir(parents=True, exist_ok=True)
DEVICE = "cuda:0"

# Correctness tolerance fixed by the task contract: atol/rtol allow
# CPU-vs-GPU float32 accumulation-order differences only, not a change of the
# computation.  atol=3e-5 / rtol=3e-4 are the contract's own numbers.
ATOL = 3e-5
RTOL = 3e-4


def make_config(channels, hidden, length, chunk, prefix, seed=703, device=DEVICE):
    return {
        "channels": int(channels),
        "hidden": int(hidden),
        "length": int(length),
        "chunk": int(chunk),
        "weight_seed": int(seed),
        "device": device,
        "prefix": prefix,
    }


def write_config(config, tag):
    path = TMP / f"{tag}_{config['prefix']}.json"
    path.write_text(json.dumps(config), encoding="utf-8")
    return path


class Launched:
    """A backend subprocess plus an attached adapter; always terminates cleanly."""

    def __init__(self, entry, config, tag, timeout_s=240.0):
        self.config = config
        self.entry = entry
        self.ready = threading.Event()
        self.events = []
        self.log_path = TMP / f"{tag}_{config['prefix']}.log"
        cfg_path = write_config(config, tag)
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = "0"
        env["PYTHONPATH"] = os.pathsep.join(
            [str(REPO), str(APPS_DIR), env.get("PYTHONPATH", "")]).strip(os.pathsep)
        if entry == "reference":
            cmd = [sys.executable, "-u", "-m", "causal_features.reference",
                   "--repository", str(REPO), "--config", str(cfg_path)]
        else:
            cmd = [sys.executable, "-u", str(entry),
                   "--repository", str(REPO), "--config", str(cfg_path)]
        flags = 0
        if os.name == "nt":
            flags = subprocess.CREATE_NEW_PROCESS_GROUP
        self._log = open(self.log_path, "w", encoding="utf-8")
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, env=env,
                                     cwd=str(REPO), creationflags=flags,
                                     text=True, bufsize=1)
        self._thread = threading.Thread(target=self._pump, daemon=True)
        self._thread.start()
        self.adapter = None
        self._wait_ready(timeout_s)

    def _pump(self):
        for line in self.proc.stdout:
            self._log.write(line)
            self._log.flush()
            line = line.strip()
            if line.startswith("{"):
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue
                self.events.append(payload)
                if payload.get("ready"):
                    self.ready.set()

    def _wait_ready(self, timeout_s):
        if not self.ready.wait(timeout_s):
            tail = self.log_text()[-3000:]
            self.close()
            raise RuntimeError(f"backend never reported ready; log tail:\n{tail}")
        from causal_features.adapter import FeatureAdapter
        self.adapter = FeatureAdapter(self.config)
        self.adapter.start()

    def log_text(self):
        try:
            self._log.flush()
            return self.log_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""

    # ------------------------------------------------------------- driving
    def drain(self, timeout_s=12.0):
        chunks = []
        first_ns = None
        while self.adapter.pending is not None:
            data, observed_ns = self.adapter.receive(timeout_s=timeout_s)
            if first_ns is None:
                first_ns = observed_ns
            chunks.append(data)
            if self.proc.poll() is not None:
                raise RuntimeError('backend died mid-request; log tail:\n'
                                   + self.log_text()[-2000:])
        return np.concatenate(chunks, axis=-1), first_ns

    def request(self, features, reset=False):
        if reset:
            self.adapter.reset()
        _, published_ns = self.adapter.submit(features)
        output, first_ns = self.drain()
        return output, published_ns, first_ns

    def close(self):
        try:
            if self.adapter is not None and self.proc.poll() is None:
                try:
                    self.adapter.terminate()
                except Exception:  # noqa: BLE001 - still kill below
                    pass
        finally:
            try:
                self.proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=20)
            if self.adapter is not None:
                try:
                    self.adapter.close()
                except Exception:  # noqa: BLE001
                    pass
                self.adapter = None
            self._thread.join(timeout=5)
            self._log.close()
            self.orphan_free = self.proc.poll() is not None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def scenario_inputs(channels, length, seed=0):
    """Six varied request payloads covering the contract's six-request sequence."""
    rng = np.random.default_rng(seed)
    return [rng.standard_normal((channels, length)).astype(np.float32) for _ in range(4)]


# (payload index, reset before) for the contract's six-request sequence:
# continuation, repeated input without reset, explicit reset, tail chunk.
SIX_REQUEST_PLAN = [(0, False), (1, False), (0, False), (0, True), (2, False), (1, True)]


def run_six(backend, payloads):
    outputs = []
    for index, reset in SIX_REQUEST_PLAN:
        output, published_ns, first_ns = backend.request(payloads[index], reset=reset)
        outputs.append((output, published_ns, first_ns))
    return outputs


def compare(candidate, reference):
    """Return (ok, max_abs, max_rel) for two output lists of the same length."""
    ok = len(candidate) == len(reference)
    max_abs, max_rel = 0.0, 0.0
    for (cand, _, _), (ref, _, _) in zip(candidate, reference):
        if cand.shape != ref.shape:
            return False, float("inf"), float("inf")
        diff = np.abs(cand - ref)
        max_abs = max(max_abs, float(diff.max()) if diff.size else 0.0)
        denom = np.maximum(np.abs(ref), 1e-12)
        max_rel = max(max_rel, float((diff / denom).max()) if diff.size else 0.0)
        if not np.allclose(cand, ref, atol=ATOL, rtol=RTOL):
            ok = False
    return ok, max_abs, max_rel
