"""One runnable backend per measured variant (see backend/notes/experiment_log.md).

Each file accepts exactly ``--repository`` and ``--config`` and honours the
fixed ``causal_features.adapter`` protocol; the only difference between them is
the optimization preset selected from ``backend/core.py``.

VARIANTS lists them for the harnesses in backend/tests and backend/benchmarks.
"""
import sys
from pathlib import Path

_HERE = str(Path(__file__).resolve().parent)
_PARENT = str(Path(__file__).resolve().parents[1])
for _p in (_PARENT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import core  # noqa: E402


def main(preset, argv=None):
    core.main_for_preset(preset, argv)


VARIANTS = [
    "full",
    "chunked_compute",
    "spin",
    "fastpub",
    "view",
    "pinned",
    "split_first",
    "async_chunks",
    "cuda_graph",
    "graph_async",
    "graph_split",
]
