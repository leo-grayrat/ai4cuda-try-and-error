"""Phase-4 correctness harness: candidates vs the protected reference, six requests.

Every backend (reference and each variant) is launched as a subprocess, driven
through the fixed ``causal_features.adapter`` protocol with the six-request
sequence (cold request, continuation, repeated input without reset, explicit
reset, continuation after reset, reset + tail chunk), terminated cleanly, and
its outputs are compared chunk-for-chunk against (a) the reference backend and
(b) the CPU full-sequence oracle of the fixed computation.

Tolerance: atol=3e-5, rtol=3e-4 (the task contract's numbers; they allow
CPU/GPU float32 accumulation-order differences only).

Usage:
    python test_correctness.py [--configs dev,tail] [--variants full,spin]
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BACKEND = HERE.parent
for _p in (HERE, BACKEND):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import common  # noqa: E402
from common import ATOL, RTOL, Launched, compare, make_config, run_six, scenario_inputs  # noqa: E402
from variants import VARIANTS  # noqa: E402

CONFIGS = {
    "dev": dict(channels=16, hidden=32, length=1043, chunk=127),
    "tail": dict(channels=16, hidden=32, length=250, chunk=64),
    "one_chunk_tail": dict(channels=8, hidden=16, length=100, chunk=127),
    "mid": dict(channels=64, hidden=128, length=2048, chunk=256),
}


def plan_segments():
    """Split the six-request plan into reset-delimited sessions."""
    segments = []
    for position, (payload, reset) in enumerate(common.SIX_REQUEST_PLAN):
        if reset or not segments:
            segments.append([])
        segments[-1].append((position, payload))
    return segments


def oracle_segments(config, payloads):
    """CPU full-sequence oracle restricted to each reset-delimited session."""
    from causal_features.model import full_sequence_oracle

    result = {}
    for segment in plan_segments():
        joined = np.concatenate([payloads[payload] for _, payload in segment], axis=-1)
        full = full_sequence_oracle(common.REPO, config, joined)
        offset = 0
        for position, payload in segment:
            width = payloads[payload].shape[-1]
            result[position] = full[:, offset:offset + width]
            offset += width
    return result


def diff(a, b):
    if a.shape != b.shape:
        return float("inf")
    d = np.abs(a - b)
    return float(d.max()) if d.size else 0.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--configs", default=",".join(CONFIGS))
    parser.add_argument("--variants", default=",".join(VARIANTS))
    args = parser.parse_args()
    names = [n for n in args.configs.split(",") if n]
    variant_names = [n for n in args.variants.split(",") if n]

    stamp = time.strftime("%Y%m%d_%H%M%S")
    results = {"stamp": stamp, "atol": ATOL, "rtol": RTOL, "configs": {}, "verdicts": []}
    verdict_rows = []
    for name in names:
        shape = CONFIGS[name]
        payloads = scenario_inputs(shape["channels"], shape["length"], seed=17 + len(name))
        ref_cfg = make_config(**shape, prefix=f"cf{name}ref")
        with Launched("reference", ref_cfg, f"ref_{name}") as ref:
            ref_out = run_six(ref, payloads)
            ref_log = str(ref.log_path)
        oracle = oracle_segments(ref_cfg, payloads)
        ref_vs_oracle = max(diff(ref_out[i][0], oracle[i]) for i in range(len(ref_out)))
        ref_self_reset = diff(ref_out[0][0], ref_out[3][0])
        ref_continuation = diff(ref_out[0][0], ref_out[2][0])
        report = {"reference_log": ref_log,
                  "reference_vs_oracle_max_abs": ref_vs_oracle,
                  "reference_reset_reproduction_max_abs": ref_self_reset,
                  "reference_continuation_delta_max_abs": ref_continuation,
                  "variants": {}}
        print(f"[{name}] reference vs CPU oracle max|diff|={ref_vs_oracle:.3e}; "
              f"reset reproduction={ref_self_reset:.3e}; "
              f"continuation delta={ref_continuation:.3e}", flush=True)
        for variant in variant_names:
            entry = BACKEND / "variants" / f"worker_{variant}.py"
            cfg = make_config(**shape, prefix=f"cf{name}{variant}")
            row = {"entry": str(entry)}
            try:
                with Launched(entry, cfg, f"{variant}_{name}") as backend:
                    out = run_six(backend, payloads)
                    row["log"] = str(backend.log_path)
                    row["orphan_free"] = backend.proc.poll() is not None
                ok_ref, max_abs, max_rel = compare(out, ref_out)
                max_oracle = max(diff(out[i][0], oracle[i]) for i in range(len(out)))
                reset_repro = diff(out[0][0], out[3][0])
                cont_delta = diff(out[0][0], out[2][0])
                ok = ok_ref and max_oracle <= ATOL + RTOL * 1.0
                row.update({"ok": bool(ok), "max_abs_vs_reference": max_abs,
                            "max_rel_vs_reference": max_rel,
                            "max_abs_vs_oracle": max_oracle,
                            "reset_repro": reset_repro,
                            "continuation_delta": cont_delta,
                            "shapes": [list(o[0].shape) for o in out]})
                verdict_rows.append(ok)
                print(f"[{name}] {variant:16s} {'PASS' if ok else 'FAIL'} "
                      f"abs={max_abs:.3e} rel={max_rel:.3e} oracle={max_oracle:.3e} "
                      f"reset={reset_repro:.3e} cont={cont_delta:.3e}", flush=True)
            except Exception as exc:  # noqa: BLE001 - a crash is a FAIL, not a skip
                row.update({"ok": False, "error": repr(exc)})
                verdict_rows.append(False)
                print(f"[{name}] {variant:16s} FAIL exception={exc!r}", flush=True)
            report["variants"][variant] = row
        results["configs"][name] = report

    results["verdicts"] = [bool(v) for v in verdict_rows]
    out_dir = BACKEND / "tests" / "results"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"correctness_{stamp}.json"
    path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    overall = bool(verdict_rows) and all(verdict_rows)
    print(f"summary_json: {path}", flush=True)
    print(f"VERDICT: {'PASS' if overall else 'FAIL'} "
          f"({sum(verdict_rows)}/{len(verdict_rows)} variant-config pairs)", flush=True)
    return 0 if overall else 1


if __name__ == "__main__":
    sys.exit(main())
