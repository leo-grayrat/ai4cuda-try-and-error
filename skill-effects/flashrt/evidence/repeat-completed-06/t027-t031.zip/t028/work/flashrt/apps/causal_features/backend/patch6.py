"""Span-aware IR emit, then re-run IR validation and the dev offered-load sweep."""
import subprocess
import sys
from pathlib import Path

path = Path('flashrt/apps/causal_features/backend/tests/test_ir.py')
text = path.read_text(encoding='utf-8')
old = ("        ctx.emit = lambda index, value, valid: chunks.append(\n"
       "            value[0].detach().cpu().numpy()[:, :valid])")
assert text.count(old) == 1
text = text.replace(old, (
    "        def _emit(index, value, valid, _spans=spans, _span=span):\n"
    "            start = 0 if _span == 'chunk' else _spans[index][0]\n"
    "            chunks.append(value[0].detach().cpu().numpy()[:, start:start + valid])\n"
    "        ctx.emit = _emit"))
path.write_text(text, encoding='utf-8')
print('patched emit; running IR validation + dev sweep')
rc = subprocess.run([sys.executable, 'flashrt/apps/causal_features/backend/tests/test_ir.py'],
                    cwd='.').returncode
print('IR rc', rc)
subprocess.run([sys.executable, 'flashrt/apps/causal_features/backend/benchmarks/bench.py',
                 '--configs', 'dev', '--tag', 'dev1'], cwd='.')
sys.exit(0)
