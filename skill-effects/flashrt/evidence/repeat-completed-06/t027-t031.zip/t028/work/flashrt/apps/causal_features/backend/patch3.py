"""Drop declared input ports (ops are driven by ctx; the executor requires an edge otherwise)."""
import subprocess
import sys
from pathlib import Path

path = Path('flashrt/apps/causal_features/backend/ir/state_graph.py')
text = path.read_text(encoding='utf-8')
old = 'inputs=[TensorPort("value")], outputs=[TensorPort("value")],'
assert text.count(old) == 1
text = text.replace(old, 'outputs=[TensorPort("value")],')
old = 'super().__init__(name=f"publish_{span}", op_type=OpType.EXPOSED,\n                         inputs=[TensorPort("value")])'
assert text.count(old) == 1
text = text.replace(old, 'super().__init__(name=f"publish_{span}", op_type=OpType.EXPOSED)')
path.write_text(text, encoding='utf-8')
print('patched state_graph.py; running IR validation')
sys.exit(subprocess.run([sys.executable, 'flashrt/apps/causal_features/backend/tests/test_ir.py'],
                        cwd='.').returncode)
