"""Surgical fix: direct_conv slice identity + fail-fast harness drain."""
from pathlib import Path

core = Path('flashrt/apps/causal_features/backend/core.py')
text = core.read_text(encoding='utf-8')
pairs = [
    ("            v = F.silu(layer.conv(joined)[:, :, 1:])",
     "            v = F.silu(layer.conv(joined))"),
    ("                out = layer.conv(joined)[:, :, 1:]",
     "                out = layer.conv(joined)"),
]
for old, new in pairs:
    assert text.count(old) == 1, (old, text.count(old))
    text = text.replace(old, new)
core.write_text(text, encoding='utf-8')

common = Path('flashrt/apps/causal_features/backend/tests/common.py')
text = common.read_text(encoding='utf-8')
old = "    def drain(self, timeout_s=60.0):"
assert text.count(old) == 1
text = text.replace(old, "    def drain(self, timeout_s=12.0):")
old = "            chunks.append(data)\n        return np.concatenate(chunks, axis=-1), first_ns"
assert text.count(old) == 1
text = text.replace(old, (
    "            chunks.append(data)\n"
    "            if self.proc.poll() is not None:\n"
    "                raise RuntimeError('backend died mid-request; log tail:\\n'\n"
    "                                   + self.log_text()[-2000:])\n"
    "        return np.concatenate(chunks, axis=-1), first_ns"))
common.write_text(text, encoding='utf-8')
print('patched core.py and tests/common.py')
