"""Diagnostic: print the pinned CausalConv1d source, IR surface, device info."""
import ast
import inspect
import json
import time
from pathlib import Path

import torch

root = Path('flashrt/layers/audio.py')
src = root.read_text(encoding='utf-8')
node = next(n for n in ast.parse(src).body if isinstance(n, ast.ClassDef) and n.name == 'CausalConv1d')
print('=== CausalConv1d ===')
print(ast.get_source_segment(src, node))

import flashrt.ir as ir
print('=== flashrt.ir exports ===')
print(sorted(n for n in dir(ir) if not n.startswith('_')))

print('=== torch ===', torch.__version__, 'cuda', torch.cuda.is_available())
if torch.cuda.is_available():
    print('devices', torch.cuda.device_count(), torch.cuda.get_device_name(0))
    print('props', torch.cuda.get_device_properties(0))

print('=== candidate task files ===')
for p in sorted(Path('.').glob('**/*causal*')):
    if '.git' not in p.parts:
        print(p)
for p in sorted(Path('.').glob('**/run_local*')):
    if '.git' not in p.parts:
        print(p)

# quick timing probe of the full-sequence pass on the large case
if torch.cuda.is_available():
    dev = 'cuda'
    torch.manual_seed(703)
    C, H, T = 128, 256, 16384
    from flashrt.layers.audio import CausalConv1d  # type: ignore
    layers = [CausalConv1d(C, H, 5), CausalConv1d(H, H, 5), CausalConv1d(H, C, 3)]
    for l in layers:
        l.to(dev).eval()
    x = torch.randn(1, C, T + 4, device=dev)
    with torch.inference_mode():
        for _ in range(3):
            v = x
            for i, l in enumerate(layers):
                joined = v if i == 0 else torch.cat([v[:, :, :4], v], -1)
                v = torch.nn.functional.silu(l(joined))
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        for _ in range(20):
            v = x
            for i, l in enumerate(layers):
                joined = v if i == 0 else torch.cat([v[:, :, :4], v], -1)
                v = torch.nn.functional.silu(l(joined))
        torch.cuda.synchronize()
        print('large-case 3-layer full pass: %.3f ms' % ((time.perf_counter() - t0) / 20 * 1e3))
        print('pad attr', [l._time_causal_padding for l in layers])
        print('out', tuple(v.shape))
