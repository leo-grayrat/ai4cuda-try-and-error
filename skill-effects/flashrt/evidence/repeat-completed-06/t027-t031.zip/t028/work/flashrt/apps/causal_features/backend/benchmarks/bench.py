"""Offered-load sweep + first-output latency benchmark, paired with the reference.

Two drivers over the *same* shared-memory contract:
  'adapter'  the fixed ``FeatureAdapter`` (exactly what the user's frontend does,
             including its 0.2 ms poll sleeps)
  'tight'    a spin-poll driver applying the same validation rules but without
             sleeps, to expose the backend's own per-chunk cost

Metrics per offered period: achieved request rate, first-chunk latency
(t_first_out - t_in), inter-chunk-gap median / p95 and the fraction of gaps
above the 20 ms chunk-gap budget.

Usage:
    python bench.py [--variants full,spin] [--configs dev] [--tag suffix]
"""
import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BACKEND = HERE.parent
for _p in (HERE, BACKEND, BACKEND / "tests"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from common import Launched, make_config, scenario_inputs  # noqa: E402
from variants import VARIANTS  # noqa: E402

BUDGET_MS = 20.0
SWEEP_MS = [0.0, 2.0, 8.0]
NREQ = 10
CONFIGS = {
    "dev": (dict(channels=16, hidden=32, length=1043, chunk=127), True, NREQ),
    "large": (dict(channels=128, hidden=256, length=16384, chunk=512), False, 4),
}


class AdapterDriver:
    """The fixed adapter, unmodified (what the frontend sees)."""

    def __init__(self, backend):
        self.backend = backend

    @property
    def adapter(self):
        return self.backend.adapter

    @property
    def pending(self):
        return self.adapter.pending is not None

    def submit(self, payload):
        return self.adapter.submit(payload)[1]

    def receive(self):
        return self.adapter.receive(timeout_s=120)

    def reset(self):
        self.adapter.reset()

    def close(self):
        pass


class TightDriver:
    """Same buffers, same checks as the adapter's receive(), but spin-polling."""

    def __init__(self, backend):
        self.backend = backend
        self.config = backend.config
        self.buffers = backend.adapter.buffers
        self.consumed = int(self.buffers['metadata'].num)
        self.pending_request = None

    @property
    def pending(self):
        return self.pending_request is not None

    def submit(self, payload):
        values = np.asarray(payload, dtype=np.float32)
        request_id = self.buffers["input"].write(values) - 1
        published = time.perf_counter_ns()
        self.pending_request = (request_id, 0)
        return published

    def receive(self):
        metadata_buffer = self.buffers["metadata"]
        output_buffer = self.buffers["output"]
        while True:
            next_cursor, metadata = metadata_buffer.read(self.consumed, 1)
            if metadata is None:
                continue
            request_id, chunk_index, valid = map(int, metadata[0])
            if (request_id, chunk_index) != self.pending_request:
                raise RuntimeError("request or chunk order differs from the contract")
            output_cursor, data = output_buffer.read(self.consumed, 1)
            if output_cursor != next_cursor or data is None:
                raise RuntimeError("payload was not published before metadata")
            observed = time.perf_counter_ns()
            self.consumed = next_cursor
            if (chunk_index + 1) * self.config["chunk"] >= self.config["length"]:
                self.pending_request = None
            return data[0, :, :valid], observed

    def reset(self):
        if not self.buffers["control"].send(3, timeout_s=30):
            raise TimeoutError("reset not acknowledged")
        if not self.buffers["control"].send(1, timeout_s=30):
            raise TimeoutError("start not acknowledged")

    def close(self):
        pass


def stats(values):
    if not values:
        return {"n": 0, "median": None, "p95": None, "max": None}
    arr = np.asarray(values, dtype=np.float64)
    return {"n": int(arr.size), "median": float(np.median(arr)),
            "p95": float(np.percentile(arr, 95)), "max": float(arr.max())}


def sweep(driver, payloads, periods, nreq):
    rows = []
    for period_ms in periods:
        first, gaps, completes = [], [], []
        begin = time.perf_counter()
        for index in range(nreq):
            target = begin + index * period_ms / 1000.0
            now = time.perf_counter()
            if target > now:
                time.sleep(target - now)
            submitted = driver.submit(payloads[index % len(payloads)])
            previous = None
            started = time.perf_counter()
            while driver.pending:
                data, observed = driver.receive()
                if previous is None:
                    first.append((observed - submitted) / 1e6)
                else:
                    gaps.append((observed - previous) / 1e6)
                previous = observed
            completes.append(time.perf_counter() - started)
        wall = time.perf_counter() - begin
        over = sum(1 for gap in gaps if gap > BUDGET_MS)
        rows.append({
            "offered_period_ms": period_ms,
            "offered_rps": (1000.0 / period_ms) if period_ms > 0 else None,
            "achieved_rps": nreq / wall if wall > 0 else None,
            "first_chunk_ms": stats(first),
            "request_service_ms": stats(completes),
            "chunk_gap_ms": stats(gaps),
            "gaps_over_budget_fraction": (over / len(gaps)) if gaps else 0.0,
            "n_chunks": len(gaps) + len(first),
        })
    return rows


def summarise(rows):
    clean = [row for row in rows if row["gaps_over_budget_fraction"] == 0.0]
    best = max(clean, key=lambda row: row["achieved_rps"] or 0.0) if clean else None
    saturated = rows[0]
    warm = [row for row in [saturated] if row["first_chunk_ms"]["n"]]
    return {
        "cold_first_chunk_ms": None if not warm else None,
        "max_sustainable_rps": None if best is None else best["achieved_rps"],
        "saturated_rps": saturated["achieved_rps"],
        "first_chunk_ms_at_saturation": saturated["first_chunk_ms"],
        "chunk_gap_ms_at_saturation": saturated["chunk_gap_ms"],
        "over_budget_fraction_at_saturation": saturated["gaps_over_budget_fraction"],
        "best_period_ms": None if best is None else best["offered_period_ms"],
        "best_gap_ms": None if best is None else best["chunk_gap_ms"],
        "best_over_budget_fraction": None if best is None else best["gaps_over_budget_fraction"],
    }


def measure(entry, label, config_name, tag):
    shape, do_sweep, nreq = CONFIGS[config_name]
    result = {"label": label, "entry": str(entry), "config_name": config_name,
              "config": shape, "budget_ms": BUDGET_MS, "drivers": {}}
    cfg = make_config(**shape, prefix=f"cf{config_name}{label}")
    with Launched(entry, cfg, f"{label}_{config_name}_{tag}") as backend:
        payloads = scenario_inputs(shape["channels"], shape["length"], seed=5)
        for driver_name, factory in (("adapter", AdapterDriver), ("tight", TightDriver)):
            driver = factory(backend)
            periods = SWEEP_MS if do_sweep else [0.0]
            rows = sweep(driver, payloads, periods, nreq)
            driver.reset()
            result["drivers"][driver_name] = {"rows": rows, "summary": summarise(rows)}
            driver.close()
        result["log"] = str(backend.log_path)
        result["events"] = backend.events
        result["stderr_tail"] = backend.log_text()[-1200:]
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variants", default=",".join(VARIANTS))
    parser.add_argument("--configs", default="dev,large")
    parser.add_argument("--tag", default=time.strftime("%Y%m%d_%H%M%S"))
    parser.add_argument("--include-reference", action="store_true", default=True)
    args = parser.parse_args()
    variants = [v for v in args.variants.split(",") if v]
    configs = [c for c in args.configs.split(",") if c]
    results = {}
    entries = [("reference", "reference")] if args.include_reference else []
    entries += [(v, BACKEND / "variants" / f"worker_{v}.py") for v in variants]
    for label, entry in entries:
        for config_name in configs:
            started = time.perf_counter()
            try:
                record = measure(entry, label, config_name, args.tag)
            except Exception as exc:  # noqa: BLE001 - record the failure, keep going
                record = {"label": label, "entry": str(entry),
                          "config_name": config_name, "error": repr(exc)}
            record["wall_s"] = time.perf_counter() - started
            results[f"{label}:{config_name}"] = record
            if "error" in record:
                print(f"{label:16s} {config_name:6s} ERROR {record['error']}", flush=True)
                continue
            for driver_name, data in record["drivers"].items():
                s = data["summary"]
                print(f"{label:16s} {config_name:6s} {driver_name:7s} "
                      f"first_med={s['first_chunk_ms_at_saturation']['median']:.3f}ms "
                      f"p95={s['first_chunk_ms_at_saturation']['p95']:.3f}ms "
                      f"sat_rps={s['saturated_rps']:.1f} "
                      f"sustain_rps={(s['max_sustainable_rps'] or 0):.1f} "
                      f"gap_med={s['chunk_gap_ms_at_saturation']['median']:.3f}ms "
                      f"gap_p95={s['chunk_gap_ms_at_saturation']['p95']:.3f}ms "
                      f"over={s['over_budget_fraction_at_saturation']:.3f}", flush=True)
    out_dir = BACKEND / "benchmarks" / "results"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"sweep_{args.tag}.json"
    path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(f"benchmark_json: {path}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
