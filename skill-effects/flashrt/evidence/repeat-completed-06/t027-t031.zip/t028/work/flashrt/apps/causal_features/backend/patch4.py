"""Initialise IR state before the first request too, then re-run validation."""
import subprocess
import sys
from pathlib import Path

path = Path('flashrt/apps/causal_features/backend/tests/test_ir.py')
text = path.read_text(encoding='utf-8')
old = "    executor = SequentialExecutor(graph)\n"
assert text.count(old) == 1
text = text.replace(old, old + "    executor.init_state({f\"history_{i}\": None for i in range(len(pads))})\n")
path.write_text(text, encoding='utf-8')
print('patched test_ir.py; re-running')
sys.exit(subprocess.run([sys.executable, 'flashrt/apps/causal_features/backend/tests/test_ir.py'],
                        cwd='.').returncode)
