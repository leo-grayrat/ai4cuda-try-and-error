"""Layer 0 reads the request slice; later layers consume the previous layer's output."""
import subprocess
import sys
from pathlib import Path

path = Path('flashrt/apps/causal_features/backend/ir/state_graph.py')
text = path.read_text(encoding='utf-8')
old = '        if self.span == "chunk":\n            value = ctx.request[:, :, ctx.start:ctx.stop]'
assert text.count(old) == 1
text = text.replace(old, '        if self.span == "chunk" and self.index == 0:\n'
                         '            value = ctx.request[:, :, ctx.start:ctx.stop]')
path.write_text(text, encoding='utf-8')
print('patched layer input plumbing; re-running')
sys.exit(subprocess.run([sys.executable, 'flashrt/apps/causal_features/backend/tests/test_ir.py'],
                        cwd='.').returncode)
