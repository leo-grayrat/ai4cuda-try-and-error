"""IR conversion of the causal_features reference backend.

The only chunk-persistent state in the pipeline is each layer's causal
convolution history (``reference.py``: ``joined[:, :, -pad:]`` per layer).  Two
graphs are built from the same operator classes with the original
``flashrt.ir`` tools:

  span='chunk'   the reference chunk-at-a-time schedule (12 device ops plus a
                 host synchronisation per chunk)
  span='stream'  the whole-request schedule used by ``backend/core.py``; legal
                 because ``history_<i>`` is exactly the pad-length tail of layer
                 <i>'s input stream, so ``[history | request]`` consumes the
                 same values as the concatenated chunk schedule.

Pipeline order inside a chunk is expressed by the ``chunk_ops`` order plus the
per-layer state declarations (no data edges are declared).
"""
import torch
import torch.nn.functional as F

from flashrt.ir import IRGraph, IROperator, OpType, StateObject, StreamMode, TensorPort


class RequestReader(IROperator):
    """Reads the one request frame published on the adapter input buffer."""

    def __init__(self):
        super().__init__(name="read_request", op_type=OpType.EXPOSED,
                         outputs=[TensorPort("value")])

    def execute(self, inputs, ctx, state):
        ctx.value = torch.from_numpy(ctx.features).unsqueeze(0).to(ctx.device)
        return {"value": ctx.value}


class LayerStep(IROperator):
    """One chunk (or the whole request) of one layer: join history, conv, silu."""

    def __init__(self, index, pad, span):
        super().__init__(name=f"layer{index}_{span}", op_type=OpType.EXPOSED,
                         outputs=[TensorPort("value")],
                         state_reads=[f"history_{index}"],
                         state_writes=[f"history_{index}"],
                         stream_mode=StreamMode.STREAMING,
                         config={"layer": index, "pad": pad, "span": span})
        self.index, self.pad, self.span = index, pad, span

    def execute(self, inputs, ctx, state):
        if self.span == "chunk" and self.index == 0:
            value = ctx.request[:, :, ctx.start:ctx.stop]
        else:
            value = ctx.value
        head = state.get(f"history_{self.index}")
        offset = 0 if head is None else head.shape[-1]
        joined = value if head is None else torch.cat([head, value], dim=-1)
        out = ctx.layers[self.index](joined)[:, :, offset:]
        tail = joined[:, :, -self.pad:]
        state.set(f"history_{self.index}", tail.clone() if tail.shape[-1] else tail)
        ctx.value = F.silu(out)
        return {"value": ctx.value}


class Publisher(IROperator):
    """Publishes payload then metadata, in the adapter's required order."""

    def __init__(self, span):
        super().__init__(name=f"publish_{span}", op_type=OpType.EXPOSED)
        self.span = span

    def execute(self, inputs, ctx, state):
        if self.span == "chunk":
            ctx.emit(ctx.index, ctx.value, ctx.stop - ctx.start)
        else:
            for index, (start, stop) in enumerate(ctx.spans):
                ctx.emit(index, ctx.value, stop - start)
        return {}


def build_graph(span, pads):
    """Build the worker-level IR graph for one of the two schedules."""
    assert span in ("chunk", "stream")
    graph = IRGraph(name=f"causal_features_{span}")
    for index in range(len(pads)):
        graph.add_state(StateObject(f"history_{index}",
                                    "per-layer causal convolution history",
                                    "chunk_persistent"))
    operators = [RequestReader()]
    operators += [LayerStep(index, pad, span) for index, pad in enumerate(pads)]
    operators += [Publisher(span)]
    for operator in operators:
        graph.add_operator(operator)
        graph.chunk_ops.append(operator.name)
    return graph
