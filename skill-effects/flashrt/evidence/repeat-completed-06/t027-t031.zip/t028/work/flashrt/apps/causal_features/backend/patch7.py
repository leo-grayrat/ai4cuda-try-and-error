"""TightDriver must resume at the current ring cursor, then run dev+large sweeps."""
import subprocess
import sys
from pathlib import Path

path = Path('flashrt/apps/causal_features/backend/benchmarks/bench.py')
text = path.read_text(encoding='utf-8')
old = "        self.buffers = backend.adapter.buffers\n        self.consumed = 0\n"
assert text.count(old) == 1
text = text.replace(old, "        self.buffers = backend.adapter.buffers\n"
                         "        self.consumed = int(self.buffers['metadata'].num)\n")
path.write_text(text, encoding='utf-8')
print('patched TightDriver cursor; running sweep')
sys.exit(subprocess.run([sys.executable, 'flashrt/apps/causal_features/backend/benchmarks/bench.py',
                         '--configs', 'dev,large', '--tag', 'all1'], cwd='.').returncode)
