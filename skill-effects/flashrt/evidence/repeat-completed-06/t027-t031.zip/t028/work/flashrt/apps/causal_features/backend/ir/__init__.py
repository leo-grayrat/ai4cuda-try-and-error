"""IR conversion package for the causal_features backend (see state_graph.py)."""
