"""Fix split path when the prefix pass consumes the whole request."""
from pathlib import Path

core = Path('flashrt/apps/causal_features/backend/core.py')
text = core.read_text(encoding='utf-8')
pairs = [
    ("        value = self._forward_full(x[:, :, first_end:]) if first_end else self._forward_full(x)",
     "        if first_end >= self.length:\n"
     "            return\n"
     "        value = self._forward_full(x[:, :, first_end:]) if first_end else self._forward_full(x)"),
    ("        \"\"\"One pass over [history | x]; consumes the same values as reference.py.\"\"\"\n        v = x",
     "        \"\"\"One pass over [history | x]; consumes the same values as reference.py.\"\"\"\n"
     "        if x.shape[-1] == 0:\n            return x\n        v = x"),
]
for old, new in pairs:
    assert text.count(old) == 1, (old[:60], text.count(old))
    text = text.replace(old, new)
core.write_text(text, encoding='utf-8')
print('patched split path')
