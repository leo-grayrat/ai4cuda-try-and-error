"""Variant entry, preset 'graph_split' (see backend/core.py)."""
import sys
from pathlib import Path

_PARENT = str(Path(__file__).resolve().parents[1])
if _PARENT not in sys.path:
    sys.path.insert(0, _PARENT)

import core  # noqa: E402

if __name__ == "__main__":
    core.main_for_preset("graph_split")
