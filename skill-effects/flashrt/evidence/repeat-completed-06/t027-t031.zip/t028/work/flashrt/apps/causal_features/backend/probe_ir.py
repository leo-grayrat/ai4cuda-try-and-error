"""Probe the flashrt.ir constructor signatures before writing the IR conversion."""
import inspect

import flashrt.ir as ir

for obj in (ir.IRGraph.__init__, ir.IROperator.__init__, ir.StateObject.__init__,
            ir.SequentialExecutor.__init__, ir.SequentialExecutor.init_state,
            ir.SequentialExecutor.run_preamble, ir.SequentialExecutor.run_chunk,
            ir.StateStore.get, ir.StateStore.set, ir.IRGraph.add_operator,
            ir.IRGraph.add_edge, ir.summarize_graph):
    print(getattr(obj, '__qualname__', obj), inspect.signature(obj))

print('IRGraph attrs', [a for a in dir(ir.IRGraph) if not a.startswith('_')])
print('StateObject attrs', [a for a in dir(ir.StateObject) if not a.startswith('_')])
print('summary doc', (ir.summarize_graph.__doc__ or '')[:600])

# smoke test: one trivial op through the executor
g = ir.IRGraph(name='smoke')
g.add_operator(ir.ir_operator(name='double', op_type=ir.OpType.EXPOSED,
                              inputs=[ir.TensorPort('x')],
                              outputs=[ir.TensorPort('y')],
                              state_writes=['s'])(
    lambda inputs, ctx, state: (state.set('s', 2.0), {'y': ctx * 2})[1]))
ex = ir.SequentialExecutor(g)
print('exec ok', ex.run_chunk({}, 21.0))
print(ir.summarize_graph(g)[:1500])
