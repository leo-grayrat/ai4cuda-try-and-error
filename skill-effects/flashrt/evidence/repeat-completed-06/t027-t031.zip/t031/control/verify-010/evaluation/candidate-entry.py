"""Standalone optimized backend for the causal_features streaming task.

Contract: exactly the researcher's adapter (``causal_features.adapter``):
seven shared-memory objects, control opcodes 1/3/2, one request in flight,
``(C, T)`` float32 input, ordered ``(C, chunk)`` chunks with
``[request_id, chunk_index, valid]`` metadata published after the payload.

Fixed computation: three ``CausalConv1d`` layers (C->H->H->C, kernels
5/5/3) each followed by SiLU, weights from seed 703 via
``causal_features.model.build_layers``.

Optimization hypotheses (all derived from the IR in ``backend/ir``):

H1  The session state of every layer is only the last ``k-1`` inputs of that
    layer.  Therefore a whole request can be evaluated as one causal
    convolution over ``[history_l | x_l]``; no per-chunk ``torch.cat``,
    slice, ``clone`` or 9x15 small kernel launches are required.
H2  Packed persistent history buffers hold ``[history | segment]`` in place,
    so the hot path performs zero CUDA allocations.
H3  Chunks that are fully computed are published in one bulk ring-buffer
    write (payload first, then metadata), preserving the adapter ordering
    check while removing per-chunk Python/IPC overhead.
H4  A busy-spin control/input poll removes the reference's 200 us sleep
    from both request detection and the drain path.

``--repository``/``--config`` are the only required arguments.  The variant
knobs are read from ``CF_STRATEGY``/``CF_SEGMENT`` so that every measured
variant is a separate launcher over this same, independently verified code
path.
"""
import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np


def _resolve_device(torch, raw):
    if isinstance(raw, int):
        return torch.device('cuda', raw)
    if raw is None:
        return torch.device('cuda')
    text = str(raw).strip()
    if text.isdigit():
        return torch.device('cuda', int(text))
    return torch.device(text)


def _import_task():
    try:
        from causal_features.adapter import open_buffers, close_buffers
        from causal_features.model import build_layers
    except ModuleNotFoundError:
        here = Path(__file__).resolve()
        apps = here.parents[2]  # <repo>/flashrt/apps
        sys.path.insert(0, str(apps))
        from causal_features.adapter import open_buffers, close_buffers
        from causal_features.model import build_layers
    return open_buffers, close_buffers, build_layers


class CausalEngine:
    """Packed-history causal convolution evaluated over request segments."""

    def __init__(self, repository, config, device, segment=None, use_graph=False):
        import torch
        import torch.nn.functional as F
        _, _, build_layers = _import_task()
        self.torch = torch
        self.F = F
        self.device = device
        self.layers = build_layers(repository, config, device)
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        self.length = int(config['length'])
        self.chunk = int(config['chunk'])
        self.n_chunks = (self.length + self.chunk - 1) // self.chunk
        self.pads = [int(layer._time_causal_padding[0]) for layer in self.layers]
        in_ch = [int(layer.conv.in_channels) for layer in self.layers]
        out_ch = [int(layer.conv.out_channels) for layer in self.layers]
        self.in_ch = in_ch
        self.out_ch = out_ch
        if segment is None:
            segment = self.length
        self.segment = max(1, min(int(segment), self.length))
        S = self.segment
        torch.manual_seed(int(config.get('weight_seed', 703)))
        self.x_dev = torch.empty(1, self.channels, self.length, device=device)
        self.z = [torch.empty(1, ic, p + S, device=device, dtype=torch.float32)
                  for ic, p in zip(in_ch, self.pads)]
        self.acts = [torch.empty(1, oc, S, device=device, dtype=torch.float32)
                     for oc in out_ch]
        self.weights = [(layer.conv.weight.detach(), layer.conv.bias.detach())
                        for layer in self.layers]
        self.pinned = device.type == 'cuda'
        self.host_out = torch.empty(self.channels, self.length, pin_memory=self.pinned)
        self.frames = np.zeros((self.n_chunks, self.channels, self.chunk), np.float32)
        self.has_history = False
        self.use_graph = bool(use_graph) and device.type == 'cuda'
        self.seg_in = torch.empty(1, self.channels, S, device=device) if self.use_graph else None
        self._graphs = {}

    # ---- core computation -------------------------------------------------
    def _forward_segment(self, seg, fresh, seg_len):
        """Convolve ``[history | seg]`` for all three layers.

        ``seg`` has shape (1, C, seg_len); the per-layer history prefix lives
        in ``self.z[l][:, :, :p]``.  Returns the last layer's (1, C, seg_len)
        activations.  The prefix is filled by replication of the layer's first
        input sample on a fresh session (this is exactly what the reference's
        ``F.pad(..., mode='replicate')`` does at session start).
        """
        cur = seg
        for index in range(len(self.layers)):
            pad = self.pads[index]
            buf = self.z[index]
            if fresh and pad:
                buf[:, :, :pad].copy_(cur[:, :, :1].expand(-1, -1, pad))
            if pad:
                buf[:, :, pad:pad + seg_len].copy_(cur)
                conv_in = buf[:, :, :pad + seg_len]
            else:
                conv_in = cur
            weight, bias = self.weights[index]
            out = self.F.conv1d(conv_in, weight, bias)
            self.F.silu(out, inplace=True)
            self.acts[index][:, :, :seg_len].copy_(out)
            cur = self.acts[index][:, :, :seg_len]
        return cur

    def _rotate_history(self, seg_len):
        torch = self.torch
        for index in range(len(self.layers)):
            pad = self.pads[index]
            if not pad:
                continue
            buf = self.z[index]
            tail = buf[:, :, :pad + seg_len][:, :, -pad:].clone()
            buf[:, :, :pad].copy_(tail)

    def _graph(self, fresh, seg_len):
        key = (bool(fresh), int(seg_len))
        graph = self._graphs.get(key)
        if graph is not None:
            return graph
        torch = self.torch
        seg = self.seg_in[:, :, :seg_len]
        stream = torch.cuda.Stream()
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for _ in range(3):
                self._forward_segment(seg, fresh, seg_len)
        torch.cuda.current_stream().wait_stream(stream)
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            self._forward_segment(seg, fresh, seg_len)
        self._graphs[key] = graph
        return graph

    def reset(self):
        self.has_history = False

    # ---- publication ------------------------------------------------------
    def _publish(self, buffers, request_id, start, stop):
        data = self.host_out.numpy()
        count = stop - start
        frames = self.frames[start:stop]
        meta = np.empty((count, 3), np.int64)
        for j in range(count):
            index = start + j
            first = index * self.chunk
            valid = min(self.chunk, self.length - first)
            frames[j, :, :valid] = data[:, first:first + valid]
            if valid < self.chunk:
                frames[j, :, valid:] = 0
            meta[j] = (request_id, index, valid)
        # Payload first, metadata second: the adapter checks this order and
        # the per-chunk cursor equality.
        buffers['output'].write(frames)
        buffers['metadata'].write(meta)

    def process_request(self, features, request_id, buffers):
        torch = self.torch
        x = np.ascontiguousarray(features, dtype=np.float32)
        with torch.inference_mode():
            self.x_dev.copy_(torch.from_numpy(x))
            published = 0
            s0 = 0
            while s0 < self.length:
                seg_len = min(self.segment, self.length - s0)
                fresh = not self.has_history
                if self.use_graph:
                    self.seg_in[:, :, :seg_len].copy_(self.x_dev[:, :, s0:s0 + seg_len])
                    self._graph(fresh, seg_len).replay()
                    out = self.acts[-1][:, :, :seg_len]
                else:
                    out = self._forward_segment(
                        self.x_dev[:, :, s0:s0 + seg_len], fresh, seg_len)
                self.host_out[:, s0:s0 + seg_len].copy_(out[0], non_blocking=self.pinned)
                if self.pinned:
                    torch.cuda.current_stream().synchronize()
                self._rotate_history(seg_len)
                self.has_history = True
                s0 += seg_len
                ready = min(self.n_chunks, s0 // self.chunk)
                if ready > published:
                    self._publish(buffers, request_id, published, ready)
                    published = ready
            if published < self.n_chunks:
                self._publish(buffers, request_id, published, self.n_chunks)


def _strategy():
    name = os.environ.get('CF_STRATEGY', 'fullseq').strip() or 'fullseq'
    override = os.environ.get('CF_SEGMENT', '').strip()
    return name, (int(override) if override else None)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--strategy', default=None,
                        help='fullseq | segment | chunk (default from CF_STRATEGY)')
    parser.add_argument('--segment', type=int, default=None)
    args = parser.parse_args(argv)

    repository = args.repository.resolve()
    sys.path.insert(0, str(repository))
    import torch
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    config = json.loads(args.config.read_text(encoding='utf-8'))
    device = _resolve_device(torch, config.get('device', 'cuda'))
    if device.type == 'cuda':
        torch.cuda.set_device(device)

    open_buffers, close_buffers, _ = _import_task()
    buffers = open_buffers(config, create=True)
    try:
        strategy, env_segment = _strategy()
        strategy = args.strategy or strategy
        segment = args.segment if args.segment is not None else env_segment
        use_graph = strategy == 'graph'
        if segment is None:
            if strategy in ('chunk', 'stream_chunk'):
                segment = int(config['chunk'])
            elif strategy in ('segment', 'segment256'):
                segment = 256
        engine = CausalEngine(repository, config, device,
                              segment=segment, use_graph=use_graph)
        consumed, last_command, active = 0, 0, False
        print(json.dumps({'ready': True, 'device': str(device),
                          'strategy': strategy, 'segment': engine.segment}),
              flush=True)
        spin = 0
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                spin += 1
                if spin & 0xFFFF == 0:
                    time_sleep = None  # keep the poll hot; documented in notes
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            engine.process_request(features[0], request_id, buffers)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
