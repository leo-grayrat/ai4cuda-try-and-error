"""Standalone optimized backend for the causal_features streaming task.

Contract: exactly the researcher's adapter (``causal_features.adapter``):
seven shared-memory objects, control opcodes 1/3/2, one request in flight,
``(C, T)`` float32 input, ordered ``(C, chunk)`` chunks with
``[request_id, chunk_index, valid]`` metadata published after the payload.

Fixed computation: three ``CausalConv1d`` layers (C->H->H->C, kernels
5/5/3) each followed by SiLU, weights from seed 703 via
``causal_features.model.build_layers``.

Optimization hypotheses (derived from the IR in ``backend/ir``):

H1  Every layer's session state is only the last ``k-1`` inputs of that
    layer, so a whole request is one causal convolution over
    ``[history_l | x_l]``.  This removes per-chunk ``torch.cat``/slice/clone
    and the reference's 9 x ~15 small kernel launches.
H2  Packed persistent history buffers hold ``[history | segment]`` in place:
    zero CUDA allocations on the hot path and no intermediate activation
    copies (the conv result feeds the next layer directly).
H3  Fully computed chunks are published in one bulk ring-buffer write
    (payload first, metadata second), preserving the adapter's cursor and
    ordering checks while removing per-chunk Python/IPC overhead.
H4  A busy-spin control/input poll removes the reference's 200 us sleep from
    request detection and the drain path.
H5  (``CF_STRATEGY=graph``) the three convolutions, SiLUs, packed-history
    copies and rotation are replayed from one captured CUDA graph.

``--repository``/``--config`` are the only required arguments; the variant
knobs are read from ``CF_STRATEGY``/``CF_SEGMENT`` so every measured variant
is a separate launcher over this same, independently verified code path.
"""
import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np


def _resolve_device(torch, raw):
    if isinstance(raw, int):
        return torch.device('cuda', raw)
    if raw is None:
        return torch.device('cuda')
    text = str(raw).strip()
    if text.isdigit():
        return torch.device('cuda', int(text))
    return torch.device(text)


def _import_task():
    try:
        from causal_features.adapter import open_buffers, close_buffers
        from causal_features.model import build_layers
    except ModuleNotFoundError:
        here = Path(__file__).resolve()
        apps = here.parents[2]  # <repo>/flashrt/apps
        sys.path.insert(0, str(apps))
        from causal_features.adapter import open_buffers, close_buffers
        from causal_features.model import build_layers
    return open_buffers, close_buffers, build_layers


class CausalEngine:
    """Packed-history causal convolution evaluated over request segments."""

    def __init__(self, repository, config, device, segment=None, use_graph=False):
        import torch
        import torch.nn.functional as F
        _, _, build_layers = _import_task()
        self.torch = torch
        self.F = F
        self.device = device
        self.layers = build_layers(repository, config, device)
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        self.length = int(config['length'])
        self.chunk = int(config['chunk'])
        self.n_chunks = (self.length + self.chunk - 1) // self.chunk
        self.pads = [int(layer._time_causal_padding[0]) for layer in self.layers]
        in_ch = [int(layer.conv.in_channels) for layer in self.layers]
        if segment is None:
            segment = self.length
        self.segment = max(1, min(int(segment), self.length))
        S = self.segment
        self.x_dev = torch.empty(1, self.channels, self.length, device=device)
        self.z = [torch.empty(1, ic, p + S, device=device, dtype=torch.float32)
                  for ic, p in zip(in_ch, self.pads)]
        self.weights = [(layer.conv.weight.detach(), layer.conv.bias.detach())
                        for layer in self.layers]
        self.pinned = device.type == 'cuda'
        self.host_out = torch.empty(self.channels, self.length, pin_memory=self.pinned)
        self.frames = np.zeros((self.n_chunks, self.channels, self.chunk), np.float32)
        self.meta = np.empty((self.n_chunks, 3), np.int64)
        self.has_history = False
        self.use_graph = bool(use_graph) and device.type == 'cuda'
        self.seg_in = torch.empty(1, self.channels, S, device=device) if self.use_graph else None
        self._graphs = {}
        if self.use_graph:
            # Capture at session init: the first request of every session is
            # fresh, so capture-time history pollution cannot leak into an
            # output (fresh graphs rewrite the prefix inside the graph).
            self._capture_all()

    # ---- core computation -------------------------------------------------
    def _forward_segment(self, seg, fresh, seg_len):
        """Convolve ``[history | seg]`` through all layers; return (1,C,seg_len).

        ``seg`` has shape (1, C, seg_len).  The per-layer history prefix lives
        in ``self.z[l][:, :, :p]``; a fresh session fills it by replicating the
        layer's first input sample, which is exactly what the reference's
        ``F.pad(..., mode='replicate')`` does at session start.  The conv
        result is passed to the next layer directly (no activation copies).
        """
        cur = seg
        last = len(self.layers) - 1
        for index in range(last + 1):
            pad = self.pads[index]
            buf = self.z[index]
            if pad:
                if fresh:
                    buf[:, :, :pad].copy_(cur[:, :, :1].expand(-1, -1, pad))
                buf[:, :, pad:pad + seg_len].copy_(cur)
                conv_in = buf[:, :, :pad + seg_len]
            else:
                conv_in = cur
            weight, bias = self.weights[index]
            out = self.F.conv1d(conv_in, weight, bias)
            self.F.silu(out, inplace=True)
            if index == last:
                return out
            cur = out

    def _rotate_history(self, seg_len):
        for index in range(len(self.layers)):
            pad = self.pads[index]
            if not pad:
                continue
            buf = self.z[index]
            # Last pad samples of [history | segment]; non-overlapping with
            # the prefix being written.
            buf[:, :, :pad].copy_(buf[:, :, seg_len:seg_len + pad])

    def _step(self, seg, fresh, seg_len):
        out = self._forward_segment(seg, fresh, seg_len)
        self._rotate_history(seg_len)
        return out

    def _graph(self, fresh, seg_len):
        key = (bool(fresh), int(seg_len))
        entry = self._graphs.get(key)
        if entry is not None:
            return entry
        torch = self.torch
        seg = self.seg_in[:, :, :seg_len]
        stream = torch.cuda.Stream()
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for _ in range(3):
                out = self._step(seg, fresh, seg_len)
        torch.cuda.current_stream().wait_stream(stream)
        torch.cuda.synchronize()
        del out
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            out = self._step(seg, fresh, seg_len)
        entry = (graph, out)
        self._graphs[key] = entry
        return entry

    def _capture_all(self):
        sizes = [self.segment]
        remainder = self.length % self.segment
        if remainder and remainder not in sizes:
            sizes.append(remainder)
        for seg_len in sizes:
            for fresh in (True, False):
                self._graph(fresh, seg_len)

    def reset(self):
        self.has_history = False

    # ---- publication ------------------------------------------------------
    def _publish(self, buffers, request_id, start, stop):
        data = self.host_out.numpy()
        count = stop - start
        for j in range(count):
            index = start + j
            first = index * self.chunk
            valid = min(self.chunk, self.length - first)
            self.frames[index, :, :valid] = data[:, first:first + valid]
            if valid < self.chunk:
                self.frames[index, :, valid:] = 0
            self.meta[index] = (request_id, index, valid)
        _ring_write(buffers['output'], self.frames[start:stop])
        _ring_write(buffers['metadata'], self.meta[start:stop])

    def process_request(self, features, request_id, buffers):
        torch = self.torch
        x = np.ascontiguousarray(features, dtype=np.float32)
        with torch.inference_mode():
            self.x_dev.copy_(torch.from_numpy(x))
            published = 0
            s0 = 0
            while s0 < self.length:
                seg_len = min(self.segment, self.length - s0)
                fresh = not self.has_history
                if self.use_graph:
                    self.seg_in[:, :, :seg_len].copy_(self.x_dev[:, :, s0:s0 + seg_len])
                    graph, out = self._graph(fresh, seg_len)
                    graph.replay()
                else:
                    out = self._step(self.x_dev[:, :, s0:s0 + seg_len], fresh, seg_len)
                self.host_out[:, s0:s0 + seg_len].copy_(out[0], non_blocking=self.pinned)
                if self.pinned:
                    torch.cuda.current_stream().synchronize()
                self.has_history = True
                s0 += seg_len
                ready = min(self.n_chunks, s0 // self.chunk)
                if ready > published:
                    self._publish(buffers, request_id, published, ready)
                    published = ready
            if published < self.n_chunks:
                self._publish(buffers, request_id, published, self.n_chunks)


def _ring_write(buffer, frames):
    """Publish ``len(frames)`` frames and advance the buffer's frame counter.

    Equivalent to ``SharedTensorBuffer.write`` for a contiguous run of frames
    starting at the current write cursor, but without its per-frame Python
    loop (the metadata/payload ordering contract is unchanged).
    """
    count = int(frames.shape[0])
    if count <= 0:
        return
    capacity = int(buffer.max_len)
    old = int(buffer.num_arr[0])
    position = old % capacity
    if position + count <= capacity:
        buffer.tensor[position:position + count] = frames
    else:
        head = capacity - position
        buffer.tensor[position:] = frames[:head]
        buffer.tensor[:count - head] = frames[head:]
    buffer.num_arr[0] = old + count


def _strategy():
    name = os.environ.get('CF_STRATEGY', 'graph').strip() or 'graph'
    override = os.environ.get('CF_SEGMENT', '').strip()
    return name, (int(override) if override else None)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--strategy', default=None,
                        help='fullseq | segment | chunk | graph (or CF_STRATEGY)')
    parser.add_argument('--segment', type=int, default=None)
    args = parser.parse_args(argv)

    repository = args.repository.resolve()
    sys.path.insert(0, str(repository))
    import torch
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    config = json.loads(args.config.read_text(encoding='utf-8'))
    device = _resolve_device(torch, config.get('device', 'cuda'))
    if device.type == 'cuda' and device.index is not None:
        torch.cuda.set_device(device)

    open_buffers, close_buffers, _ = _import_task()
    buffers = open_buffers(config, create=True)
    try:
        strategy, env_segment = _strategy()
        strategy = args.strategy or strategy
        segment = args.segment if args.segment is not None else env_segment
        use_graph = strategy == 'graph'
        if segment is None:
            if strategy in ('chunk', 'stream_chunk'):
                segment = int(config['chunk'])
            elif strategy in ('segment', 'segment256'):
                segment = 256
        engine = CausalEngine(repository, config, device,
                              segment=segment, use_graph=use_graph)
        consumed, last_command, active = 0, 0, False
        print(json.dumps({'ready': True, 'device': str(device),
                          'strategy': strategy, 'segment': engine.segment}),
              flush=True)
        while True:
            # Busy spin: H4.  The reference sleeps 200 us per poll here.
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            engine.process_request(features[0], request_id, buffers)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
