"""Shared subprocess/adapter harness for the causal_features backend tests.

Every backend is launched as a subprocess with an explicit environment and
driven only through ``causal_features.adapter``.  All subprocesses are
stopped in ``finally`` blocks and the shared-memory prefix is unique per run.
"""
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path

import numpy as np

ROOT = Path.cwd().resolve()
APPS = ROOT / 'flashrt' / 'apps'
WORKER = APPS / 'causal_features' / 'backend' / 'worker.py'


def make_config(prefix, device='cuda:0', channels=16, hidden=32, length=1043,
                chunk=127, seed=703):
    return {'prefix': prefix, 'device': device, 'channels': channels,
            'hidden': hidden, 'length': length, 'chunk': chunk,
            'weight_seed': seed}


def write_config(config, directory):
    path = Path(directory) / f'config_{config["prefix"]}.json'
    path.write_text(json.dumps(config), encoding='utf-8')
    return path


def stamp():
    return time.strftime('%Y%m%d_%H%M%S')


class Process:
    def __init__(self, argv, env_extra=None):
        env = os.environ.copy()
        env['PYTHONPATH'] = os.pathsep.join(
            [str(ROOT), str(APPS), env.get('PYTHONPATH', '')])
        env.update(env_extra or {})
        self.argv = argv
        self.proc = subprocess.Popen(
            [str(a) for a in argv], cwd=str(ROOT), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            bufsize=1)
        self.out, self.err = [], []
        self._threads = [
            threading.Thread(target=self._pump, args=(self.proc.stdout, self.out), daemon=True),
            threading.Thread(target=self._pump, args=(self.proc.stderr, self.err), daemon=True)]
        for thread in self._threads:
            thread.start()

    @staticmethod
    def _pump(stream, sink):
        try:
            for line in stream:
                sink.append(line.rstrip())
        except Exception:  # noqa: BLE001 - stream closed during teardown
            pass

    def wait_ready(self, timeout=180):
        deadline = time.time() + timeout
        while time.time() < deadline:
            for line in list(self.out):
                try:
                    payload = json.loads(line)
                except Exception:  # noqa: BLE001
                    continue
                if isinstance(payload, dict) and payload.get('ready'):
                    return payload
            if self.proc.poll() is not None:
                raise RuntimeError(
                    f'backend exited before ready: {self.proc.returncode}\n'
                    f'stdout={self.out}\nstderr={self.err}')
            time.sleep(0.005)
        raise TimeoutError(f'backend not ready in {timeout}s; stderr={self.err}')

    def stop(self):
        if self.proc.poll() is None:
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=10)

    def summary(self):
        return {'argv': [str(a) for a in self.argv], 'returncode': self.proc.returncode,
                'stdout': self.out[-40:], 'stderr': self.err[-40:]}


class Session:
    """One backend subprocess + adapter, with guaranteed cleanup."""

    def __init__(self, argv, config, env_extra=None):
        from causal_features.adapter import FeatureAdapter
        self.config = config
        self.process = Process(argv, env_extra)
        self.adapter = None
        try:
            self.ready = self.process.wait_ready()
            self.adapter = FeatureAdapter(config)
        except BaseException:
            self.process.stop()
            raise

    def run(self, requests, reset_before):
        adapter = self.adapter
        records = []
        adapter.start()
        try:
            for index, features in enumerate(requests):
                if reset_before[index]:
                    adapter.reset()
                request_id, published_ns = adapter.submit(features)
                chunks = []
                while adapter.pending is not None:
                    data, observed_ns = adapter.receive(timeout_s=120)
                    chunks.append((data.copy(), observed_ns))
                records.append({'request': index, 'id': request_id,
                                'submitted_ns': published_ns, 'chunks': chunks})
        finally:
            self.close()
        return records

    def close(self):
        if self.adapter is not None:
            try:
                self.adapter.terminate()
            except Exception:  # noqa: BLE001
                pass
            try:
                self.adapter.close()
            except Exception:  # noqa: BLE001
                pass
            self.adapter = None
        self.process.stop()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def scenario(length):
    rng = np.random.default_rng(1234)
    inputs = [rng.standard_normal((16, length), dtype=np.float32) for _ in range(4)]
    plan = [(inputs[0], False), (inputs[1], False), (inputs[1], False),
            (inputs[0], True), (inputs[2], False), (inputs[3], False)]
    requests = [item[0] for item in plan]
    reset_before = [item[1] for item in plan]
    return requests, reset_before


def oracle_chunks(requests, reset_before, config):
    """CPU full-sequence oracle per reset-delimited session segment."""
    from causal_features.model import full_sequence_oracle
    out = []
    session = []
    for features, reset in zip(requests, reset_before):
        if reset and session:
            _emit_session(session, out, config)
            session = []
        session.append(features)
    if session:
        _emit_session(session, out, config)
    return out


def _emit_session(session, out, config):
    from causal_features.model import full_sequence_oracle
    joined = np.concatenate(session, axis=1)
    full = full_sequence_oracle(ROOT, config, joined)
    chunks = []
    offset = 0
    for features in session:
        length = features.shape[1]
        for first in range(0, length, config['chunk']):
            last = min(first + config['chunk'], length)
            chunks.append(full[:, offset + first:offset + last].copy())
        offset += length
    out.append(chunks)


def compare_chunks(left, right, atol, rtol):
    worst = 0.0
    violations = 0
    for record_a, record_b in zip(left, right):
        if len(record_a['chunks']) != len(record_b['chunks']):
            raise AssertionError('chunk count differs')
        for (data_a, _), (data_b, _) in zip(record_a['chunks'], record_b['chunks']):
            assert data_a.shape == data_b.shape, (data_a.shape, data_b.shape)
            tol = atol + rtol * np.abs(data_b)
            diff = np.abs(data_a.astype(np.float64) - data_b.astype(np.float64))
            ratio = np.where(tol > 0, diff / tol, diff)
            worst = max(worst, float(ratio.max()) if ratio.size else 0.0)
            violations += int((diff > tol).sum())
    return worst, violations


def compare_to_oracle(records, oracle, atol, rtol):
    worst = 0.0
    violations = 0
    checked = []
    cursor = 0
    for record in records:
        count = len(record['chunks'])
        expected = oracle[cursor]
        cursor += 1
        assert len(expected) == count, (len(expected), count)
        for (data, _), ref in zip(record['chunks'], expected):
            tol = atol + rtol * np.abs(ref)
            diff = np.abs(data.astype(np.float64) - ref.astype(np.float64))
            ratio = np.where(tol > 0, diff / tol, diff)
            worst = max(worst, float(ratio.max()) if ratio.size else 0.0)
            violations += int((diff > tol).sum())
            checked.append(data.shape)
    return worst, violations, checked


def temp_dir():
    return tempfile.mkdtemp(prefix='causal_features_')


def unique_prefix():
    return 'cf_' + uuid.uuid4().hex[:12]


def oracle_per_request(requests, reset_before, config):
    """CPU full-sequence oracle chunked per request (reset-delimited sessions)."""
    from causal_features.model import full_sequence_oracle
    result = []
    session = []

    def flush():
        if not session:
            return
        joined = np.concatenate(session, axis=1)
        full = full_sequence_oracle(ROOT, config, joined)
        offset = 0
        for features in session:
            length = features.shape[1]
            chunks = []
            for first in range(0, length, config['chunk']):
                last = min(first + config['chunk'], length)
                chunks.append(full[:, offset + first:offset + last].copy())
            offset += length
            result.append(chunks)

    for features, reset in zip(requests, reset_before):
        if reset:
            flush()
            session = []
        session.append(features)
    flush()
    return result
