"""Variant: whole-request pipeline replayed from one captured CUDA graph."""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
os.environ['CF_STRATEGY'] = 'graph'

import worker  # noqa: E402

if __name__ == '__main__':
    worker.main()
