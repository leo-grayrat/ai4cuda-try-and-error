"""Diagnostics: upstream CausalConv1d source, torch/triton/GPU environment."""
import ast
import inspect
import json
import sys
from pathlib import Path


def main():
    repo = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
    src = (repo / 'flashrt/layers/audio.py').read_text(encoding='utf-8')
    tree = ast.parse(src)
    node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'CausalConv1d')
    print(ast.get_source_segment(src, node))
    import torch
    info = {
        'torch': torch.__version__,
        'cuda_available': torch.cuda.is_available(),
        'device_count': torch.cuda.device_count(),
        'cuda_capability': torch.cuda.get_device_capability(0) if torch.cuda.is_available() else None,
        'gpu_name': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        'cudnn': torch.backends.cudnn.version(),
    }
    try:
        import triton
        info['triton'] = triton.__version__
    except Exception as exc:  # noqa: BLE001
        info['triton'] = f'unavailable: {exc}'
    try:
        import flashrt_kernels
        info['flashrt_kernels'] = getattr(flashrt_kernels, '__version__', 'ok')
    except Exception as exc:  # noqa: BLE001
        info['flashrt_kernels'] = f'unavailable: {exc}'
    print(json.dumps(info, indent=2, default=str))


if __name__ == '__main__':
    main()
