"""Correctness harness: candidate backend vs reference backend vs CPU oracle.

Usage:
    python flashrt/apps/causal_features/backend/tests/test_worker.py \
        [--candidate PATH] [--device cuda:0] [--length 1043] [--chunk 127]

The same six-request scenario (continuation, repeated input without reset,
explicit reset, tail chunk) is driven through the unchanged adapter.  The
candidate is compared element-wise both with the reference backend's captured
outputs and with the researcher's CPU full-sequence oracle.
"""
import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

ATOL = 3e-5
RTOL = 3e-4


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', default=str(common.WORKER))
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--length', type=int, default=1043)
    parser.add_argument('--chunk', type=int, default=127)
    parser.add_argument('--channels', type=int, default=16)
    parser.add_argument('--hidden', type=int, default=32)
    args = parser.parse_args()

    directory = common.temp_dir()
    requests, reset_before = common.scenario(args.length)
    reference_config = common.make_config(
        common.unique_prefix(), device=args.device, channels=args.channels,
        hidden=args.hidden, length=args.length, chunk=args.chunk)
    candidate_config = common.make_config(
        common.unique_prefix(), device=args.device, channels=args.channels,
        hidden=args.hidden, length=args.length, chunk=args.chunk)
    ref_cfg_path = common.write_config(reference_config, directory)
    cand_cfg_path = common.write_config(candidate_config, directory)

    reference_argv = [sys.executable, '-m', 'causal_features.reference',
                      '--repository', str(common.ROOT), '--config', str(ref_cfg_path)]
    candidate_argv = [sys.executable, args.candidate,
                      '--repository', str(common.ROOT), '--config', str(cand_cfg_path)]

    reference_records = None
    candidate_records = None
    sessions = []
    try:
        reference = common.Session(reference_argv, reference_config)
        sessions.append(reference)
        reference_records = reference.run(requests, reset_before)
        candidate = common.Session(candidate_argv, candidate_config)
        sessions.append(candidate)
        candidate_records = candidate.run(requests, reset_before)
    finally:
        for session in sessions:
            session.close()

    oracle = common.oracle_per_request(requests, reset_before, reference_config)
    ref_worst, ref_bad = common.compare_chunks(
        reference_records, reference_records, ATOL, RTOL)
    cand_vs_ref_worst, cand_vs_ref_bad = common.compare_chunks(
        candidate_records, reference_records, ATOL, RTOL)
    cand_vs_oracle_worst, cand_vs_oracle_bad, shapes = common.compare_to_oracle(
        candidate_records, oracle, ATOL, RTOL)
    ref_vs_oracle_worst, ref_vs_oracle_bad, _ = common.compare_to_oracle(
        reference_records, oracle, ATOL, RTOL)

    print(f'reference chunks: {sum(len(r["chunks"]) for r in reference_records)}')
    print(f'candidate chunks: {sum(len(r["chunks"]) for r in candidate_records)}')
    print(f'chunk shapes: {sorted(set(shapes))}')
    print(f'reference vs cpu oracle: worst_ratio={ref_vs_oracle_worst:.3f} '
          f'violations={ref_vs_oracle_bad}')
    print(f'candidate vs cpu oracle: worst_ratio={cand_vs_oracle_worst:.3f} '
          f'violations={cand_vs_oracle_bad}')
    print(f'candidate vs reference:  worst_ratio={cand_vs_ref_worst:.3f} '
          f'violations={cand_vs_ref_bad}')
    passed = cand_vs_ref_bad == 0 and cand_vs_oracle_bad == 0
    print('PASS' if passed else 'FAIL')
    for session in sessions:
        info = session.process.summary()
        if info['stdout'] or info['stderr']:
            print(f'backend rc={info["returncode"]} stderr_tail={info["stderr"][-3:]}')
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
