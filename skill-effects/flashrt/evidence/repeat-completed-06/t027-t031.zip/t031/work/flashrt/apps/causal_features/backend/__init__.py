"""Optimized causal_features backend workspace."""
