"""Phase-2 IR validation: SequentialExecutor graph vs reference backend.

The reference is launched on CPU through the unchanged adapter; the IR
executor runs the same six-request scenario with per-layer history state.
Numerical comparison uses atol=1e-6 / rtol=1e-5: both sides execute the same
torch CPU float32 operations in the same order, so only reduction-order noise
from the convolution kernel is expected.
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

from flashrt.ir import SequentialExecutor, summarize_graph  # noqa: E402

ATOL = 1e-6
RTOL = 1e-5


class Context:
    def __init__(self, torch, F, layers):
        self.torch = torch
        self.F = F
        self.layers = layers
        self.pad = 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', default='cpu')
    args = parser.parse_args()
    import torch
    import torch.nn.functional as F
    from causal_features.model import build_layers
    from causal_features.backend.ir.graph_builder import (
        build_model_graph, build_worker_graph)

    directory = common.temp_dir()
    length, chunk = 1043, 127
    requests, reset_before = common.scenario(length)
    config = common.make_config(common.unique_prefix(), device='cpu',
                                channels=16, hidden=32, length=length, chunk=chunk)
    cfg_path = common.write_config(config, directory)
    reference_argv = [sys.executable, '-m', 'causal_features.reference',
                      '--repository', str(common.ROOT), '--config', str(cfg_path)]
    session = None
    try:
        session = common.Session(reference_argv, config)
        reference_records = session.run(requests, reset_before)
    finally:
        if session is not None:
            session.close()

    layers = build_layers(str(common.ROOT), config, 'cpu')
    graph = build_worker_graph(layers)
    executor = SequentialExecutor(graph)
    executor.init_state({f'history_{i}': None for i in range(len(layers))})
    ctx = Context(torch, F, layers)
    records = []
    with torch.inference_mode():
        for index, (features, reset) in enumerate(zip(requests, reset_before)):
            if reset:
                executor.init_state({f'history_{i}': None for i in range(len(layers))})
            chunks = []
            for first in range(0, length, chunk):
                last = min(first + chunk, length)
                values = torch.from_numpy(features[:, first:last].copy()).unsqueeze(0)
                out = executor.run_chunk({'features': values}, ctx)['activations']
                chunks.append((out.squeeze(0).numpy().copy(), 0))
            records.append({'request': index, 'id': index, 'chunks': chunks})

    worst, violations = common.compare_chunks(records, reference_records, ATOL, RTOL)
    print(f'IR executor chunks: {sum(len(r["chunks"]) for r in records)}')
    print(f'IR executor vs reference backend: worst_ratio={worst:.3f} '
          f'violations={violations}')
    summary = summarize_graph(
        graph, {f'layer_{i}_causal_conv': 4e-5 for i in range(len(layers))})
    model_summary = summarize_graph(build_model_graph(0, layers[0]))
    notes = common.ROOT / 'flashrt' / 'apps' / 'causal_features' / 'backend' / 'notes'
    notes.mkdir(parents=True, exist_ok=True)
    (notes / 'ir_analysis.txt').write_text(summary, encoding='utf-8')
    (notes / 'ir_model_analysis.txt').write_text(model_summary, encoding='utf-8')
    print(summary.split('## Cross-Chunk Dependencies')[1][:900])
    passed = violations == 0
    print('PASS' if passed else 'FAIL')
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
