"""Internal timing breakdown for the worker hot path (no IPC)."""
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path.cwd().resolve()
sys.path.insert(0, str(ROOT / 'flashrt' / 'apps'))
sys.path.insert(0, str(ROOT / 'flashrt' / 'apps' / 'causal_features' / 'backend'))

import torch  # noqa: E402
import worker  # noqa: E402

config = {'prefix': 'diag', 'channels': 16, 'hidden': 32, 'length': 1043,
          'chunk': 127, 'weight_seed': 703, 'device': 'cuda'}
torch.backends.cudnn.allow_tf32 = False
torch.backends.cuda.matmul.allow_tf32 = False
engine = worker.CausalEngine(ROOT, config, torch.device('cuda'))


class NullBuffers(dict):
    def __init__(self):
        super().__init__(output=self, metadata=self)

    def write(self, value):
        return 0


x = np.random.default_rng(0).standard_normal((16, 1043), dtype=np.float32)


def bench(fn, n=30):
    fn()
    torch.cuda.synchronize()
    times = []
    for _ in range(n):
        t0 = time.perf_counter_ns()
        fn()
        times.append((time.perf_counter_ns() - t0) / 1e6)
    return {'median': float(np.median(times)), 'p95': float(np.percentile(times, 95))}


result = {}
result['process_request'] = bench(lambda: engine.process_request(x, 0, NullBuffers()))

with torch.inference_mode():
    engine.x_dev.copy_(torch.from_numpy(x))
    result['h2d'] = bench(lambda: engine.x_dev.copy_(torch.from_numpy(x)))
    seg = engine.x_dev
    result['forward'] = bench(lambda: engine._forward_segment(seg, False, 1043))
    out = engine.acts[-1][:, :, :1043]
    result['d2h'] = bench(lambda: engine.host_out.copy_(out[0], non_blocking=True))
    def d2h_sync():
        engine.host_out.copy_(out[0], non_blocking=True)
        torch.cuda.current_stream().synchronize()
    result['d2h_sync'] = bench(d2h_sync)
    result['rotate'] = bench(lambda: engine._rotate_history(1043))
    z = engine.z[0][:, :, :1047]
    w, b = engine.weights[0]
    result['conv1_only'] = bench(lambda: torch.nn.functional.conv1d(z, w, b))
    result['conv1_silu'] = bench(
        lambda: torch.nn.functional.silu(torch.nn.functional.conv1d(z, w, b)))
result['cuda_graph'] = 'not measured here'
print(json.dumps(result, indent=2))
