"""IR operators for the causal_features reference chunk step.

The reference (``causal_features/reference.py`` + ``model.py``) runs, for each
configured chunk and for each of the three ``CausalConv1d`` layers:

    joined  = value if history is None else cat([history, value], dim=-1)
    result  = layer(joined)                    # replicate pad k-1 on the left
    result  = result[..., history_len:]        # drop warm-up outputs
    history = joined[..., -(k-1):].clone()     # per-layer persistent state
    value   = silu(result)

``CausalLayerStep`` is a faithful, executable conversion of that step.  One
instance exists per layer, so the graph exposes each layer's *own* persistent
history as a separate chunk-persistent ``StateObject``.
"""
from flashrt.ir import IROperator, OpType, StreamMode, TensorPort


class CausalLayerStep(IROperator):
    def __init__(self, index, layer):
        pad = int(layer._time_causal_padding[0])
        super().__init__(
            name=f'layer_{index}_causal_conv',
            op_type=OpType.EXPOSED,
            inputs=[TensorPort('features', dtype_hint='float32')],
            outputs=[TensorPort('activations', dtype_hint='float32')],
            state_reads=[f'history_{index}'],
            state_writes=[f'history_{index}'],
            stream_mode=StreamMode.STREAMING,
            config={'kernel_taps': pad + 1,
                    'in_channels': int(layer.conv.in_channels),
                    'out_channels': int(layer.conv.out_channels)},
        )
        self.index = index
        self.layer = layer

    def execute(self, inputs, ctx, state):
        value = inputs['features']
        history = state.get(f'history_{self.index}')
        joined = value if history is None else ctx.torch.cat([history, value], dim=-1)
        result = self.layer(joined)
        if history is not None:
            result = result[:, :, history.shape[-1]:]
        pad = self.layer._time_causal_padding[0]
        state.set(f'history_{self.index}', joined[:, :, -pad:].clone())
        return {'activations': ctx.F.silu(result)}
