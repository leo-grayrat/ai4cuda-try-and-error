"""Variant: true per-chunk packed-history streaming (segment = chunk)."""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
os.environ['CF_STRATEGY'] = 'chunk'

import worker  # noqa: E402

if __name__ == '__main__':
    worker.main()
