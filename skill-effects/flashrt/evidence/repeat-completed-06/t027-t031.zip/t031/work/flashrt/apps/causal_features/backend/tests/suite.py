"""Correctness + offered-load suite over the reference and every variant.

For each backend: drive the six-request scenario through the adapter, compare
with the reference backend and with the researcher's CPU full-sequence oracle,
then run a finite offered-load sweep (50..400 req/s) recording first-output
latency, output-gap distribution and the over-budget fraction (20 ms budget).
"""
import json
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND / 'tests'))
sys.path.insert(0, str(BACKEND / 'benchmarks'))
import common  # noqa: E402
from bench import measure, measure_latency  # noqa: E402

ATOL, RTOL = 3e-5, 3e-4
VARIANTS = [('fullseq', BACKEND / 'worker.py'),
            ('chunk_stream', BACKEND / 'variants' / 'chunk_stream' / 'worker.py'),
            ('segment256', BACKEND / 'variants' / 'segment256' / 'worker.py'),
            ('cuda_graph', BACKEND / 'variants' / 'cuda_graph' / 'worker.py')]


def argv_for(label, config_path):
    if label == 'reference':
        return [sys.executable, '-m', 'causal_features.reference',
                '--repository', str(common.ROOT), '--config', str(config_path)]
    path = dict(VARIANTS)[label]
    return [sys.executable, str(path), '--repository', str(common.ROOT),
            '--config', str(config_path)]


def main():
    length, chunk = 1043, 127
    requests, reset_before = common.scenario(length)
    directory = common.temp_dir()
    oracle_cfg = common.make_config('oracle', device='cpu', length=length, chunk=chunk)
    oracle = common.oracle_per_request(requests, reset_before, oracle_cfg)
    reference_records = {}
    report = {}
    for label, _ in [('reference', None)] + VARIANTS:
        check_cfg = common.make_config(common.unique_prefix(), device='cuda',
                                       length=length, chunk=chunk)
        check_argv = argv_for(label, common.write_config(check_cfg, directory))
        session = common.Session(check_argv, check_cfg)
        try:
            records = session.run(requests, reset_before)
            ready = session.ready
        finally:
            session.close()
        if label == 'reference':
            reference_records = records
        ref_worst, ref_bad = common.compare_chunks(records, reference_records, ATOL, RTOL)
        oracle_worst, oracle_bad, _ = common.compare_to_oracle(records, oracle, ATOL, RTOL)

        bench_cfg = common.make_config(common.unique_prefix(), device='cuda',
                                       length=length, chunk=chunk)
        bench_argv = argv_for(label, common.write_config(bench_cfg, directory))
        session = common.Session(bench_argv, bench_cfg)
        try:
            session.adapter.start()
            latency = measure_latency(session, requests, reset_before, count=10)
            sweeps = [measure(session, requests, reset_before, rate=rate,
                              min_requests=30, duration_s=0.4)
                      for rate in (50, 100, 200, 400)]
        finally:
            session.close()
        passing = [s['achieved_rate'] for s in sweeps
                   if s['achieved_rate'] >= 0.95 * s['offered_rate']]
        report[label] = {'ready': ready, 'correctness_vs_ref': [ref_worst, ref_bad],
                         'correctness_vs_oracle': [oracle_worst, oracle_bad],
                         'latency_ms': latency, 'sweeps': sweeps,
                         'sustainable_rate': max(passing, default=0.0)}
        gaps = latency['gaps_ms']
        print(f'{label:13s} PASS={ref_bad == 0 and oracle_bad == 0} '
              f'first_ms={latency["first_latency_ms"]["median"]:.3f}/'
              f'{latency["first_latency_ms"]["p95"]:.3f} '
              f'gap_ms={gaps.get("median", 0):.4f}/{gaps.get("p95", 0):.3f} '
              f'rate={report[label]["sustainable_rate"]:.0f}/s')
    out_dir = BACKEND / 'benchmarks' / 'results'
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f'suite_{common.stamp()}.json'
    payload = {'config': {'length': length, 'chunk': chunk},
               'chunk_gap_budget_ms': 20.0, 'variants': report}
    out.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    print(f'wrote {out}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
