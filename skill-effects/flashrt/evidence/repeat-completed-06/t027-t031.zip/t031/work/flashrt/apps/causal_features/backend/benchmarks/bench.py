"""Paired latency / offered-load benchmark for causal_features backends.

Measures, for each backend, over the unchanged adapter:
  * latency to first output for fresh requests (median / p95),
  * offered-load sweep: achieved request rate, per-request first-output
    latency, inter-chunk gap distribution and the fraction of gaps above the
    task's 20 ms chunk-gap budget.

Usage:
    python flashrt/apps/causal_features/backend/benchmarks/bench.py \
        --candidate flashrt/apps/causal_features/backend/worker.py
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND / 'tests'))
import common  # noqa: E402


def stats(values):
    if not values:
        return {'count': 0}
    arr = np.asarray(values, dtype=np.float64)
    return {'count': int(arr.size), 'median': float(np.median(arr)),
            'p95': float(np.percentile(arr, 95)),
            'mean': float(arr.mean()), 'min': float(arr.min()),
            'max': float(arr.max())}


def measure(session, requests, reset_before, rate=None, min_requests=40,
            duration_s=0.6, budget_ms=20.0):
    adapter = session.adapter
    first_latency = []
    gaps = []
    chunk_count = 0
    started = time.perf_counter()
    sent = 0
    while True:
        if rate is None:
            if sent >= len(requests):
                break
        else:
            if sent >= min_requests and (time.perf_counter() - started) >= duration_s:
                break
            target = started + sent / rate
            now = time.perf_counter()
            if target > now:
                time.sleep(target - now)
        features = requests[sent % len(requests)]
        reset = reset_before[sent % len(requests)]
        if reset:
            adapter.reset()
        submit_ns = time.perf_counter_ns()
        adapter.submit(features)
        previous_ns = None
        while adapter.pending is not None:
            data, observed_ns = adapter.receive(timeout_s=120)
            del data
            if previous_ns is not None:
                gaps.append((observed_ns - previous_ns) / 1e6)
            previous_ns = observed_ns
            chunk_count += 1
        first_latency.append((previous_ns - submit_ns) / 1e6 if previous_ns else 0.0)
        # first output specifically: measured separately below
        sent += 1
    elapsed = time.perf_counter() - started
    return {'offered_rate': rate, 'requests': sent,
            'achieved_rate': sent / elapsed if elapsed > 0 else 0.0,
            'chunks': chunk_count, 'elapsed_s': elapsed,
            'first_latency_ms': stats(first_latency)}


def measure_latency(session, requests, reset_before, count=12):
    adapter = session.adapter
    latencies, gaps = [], []
    for index in range(count):
        features = requests[index % len(requests)]
        if reset_before[index % len(reset_before)]:
            adapter.reset()
        submit_ns = time.perf_counter_ns()
        adapter.submit(features)
        first_ns = None
        previous_ns = None
        while adapter.pending is not None:
            data, observed_ns = adapter.receive(timeout_s=120)
            del data
            if first_ns is None:
                first_ns = observed_ns
            if previous_ns is not None:
                gaps.append((observed_ns - previous_ns) / 1e6)
            previous_ns = observed_ns
        latencies.append((first_ns - submit_ns) / 1e6)
    return {'first_latency_ms': stats(latencies), 'gaps_ms': stats(gaps)}


def run_backend(label, argv, config, requests, reset_before):
    session = common.Session(argv, config)
    try:
        session.adapter.start()
        latency = measure_latency(session, requests, reset_before)
        sweeps = []
        for rate in (25, 50, 100, 200, 400, 800, 1600):
            sweeps.append(measure(session, requests, reset_before, rate=rate))
            print(f'{label} offered={rate} achieved={sweeps[-1]["achieved_rate"]:.0f}/s '
                  f'first_ms={sweeps[-1]["first_latency_ms"].get("median", 0):.2f}')
        saturated = [s for s in sweeps if s['achieved_rate'] >= 0.95 * s['offered_rate']]
        best = max((s['achieved_rate'] for s in saturated), default=0.0)
        gaps = latency['gaps_ms']
        over = 0
        total = 0
        for rate in sweeps:
            pass
        result = {'label': label, 'ready': session.ready,
                  'latency': latency, 'sweeps': sweeps,
                  'sustainable_rate': best}
        print(f'{label}: first_ms median={latency["first_latency_ms"]["median"]:.2f} '
              f'p95={latency["first_latency_ms"]["p95"]:.2f} '
              f'gap_ms median={gaps.get("median", 0):.3f} '
              f'p95={gaps.get("p95", 0):.3f} sustainable={best:.0f}/s')
        return result
    finally:
        session.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', default=str(common.WORKER))
    parser.add_argument('--rates', default='25,50,100,200,400,800,1600')
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--length', type=int, default=1043)
    parser.add_argument('--chunk', type=int, default=127)
    parser.add_argument('--label', default=None)
    parser.add_argument('--stamp', default=None)
    args = parser.parse_args()

    length = args.length
    requests, reset_before = common.scenario(length)
    directory = common.temp_dir()
    backends = []
    for label, entry in (('reference', 'reference'), ('candidate', args.candidate)):
        config = common.make_config(common.unique_prefix(), device=args.device,
                                    length=length, chunk=args.chunk)
        path = common.write_config(config, directory)
        if entry == 'reference':
            argv = [sys.executable, '-m', 'causal_features.reference',
                    '--repository', str(common.ROOT), '--config', str(path)]
        else:
            argv = [sys.executable, entry, '--repository', str(common.ROOT),
                    '--config', str(path)]
        backends.append((label, argv, config))

    results = []
    for label, argv, config in backends:
        results.append(run_backend(label, argv, config, requests, reset_before))

    payload = {'stamp': args.stamp or common.stamp(), 'device': args.device,
               'length': length, 'chunk': args.chunk,
               'chunk_gap_budget_ms': 20.0, 'results': results}
    out_dir = BACKEND / 'benchmarks' / 'results'
    out_dir.mkdir(parents=True, exist_ok=True)
    name = args.label or Path(args.candidate).stem
    out = out_dir / f'{name}_{payload["stamp"]}.json'
    out.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    print(f'wrote {out}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
