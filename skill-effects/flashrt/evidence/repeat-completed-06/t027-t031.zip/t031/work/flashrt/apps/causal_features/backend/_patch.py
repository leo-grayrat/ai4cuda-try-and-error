"""Final edit: restore the recommended default strategy and write the docs."""
from pathlib import Path

root = Path('flashrt/apps/causal_features/backend')
worker = root / 'worker.py'
text = worker.read_text(encoding='utf-8')
old = "    name = os.environ.get('CF_STRATEGY', 'graph').strip() or 'graph'"
new = "    name = os.environ.get('CF_STRATEGY', 'fullseq').strip() or 'fullseq'"
assert old in text
worker.write_text(text.replace(old, new), encoding='utf-8')

readme = """# causal_features optimized backend (cuda, single RTX 5060 8GB)

Recommended entry: `worker.py`.

    python flashrt/apps/causal_features/backend/worker.py \\
        --repository <repo-root> --config <config.json>

It accepts exactly the reference's two arguments, creates the adapter's seven
shared-memory objects, honors opcodes 1/3/2 (level-valued, repeated resets),
publishes payload before `[request_id, chunk_index, valid]` metadata, and
finishes with `close_buffers(unlink=True)`. It is driven by the unchanged
frontend/adapter.

Implementation: the session state of each `CausalConv1d` layer is only its
last `k-1` inputs, so a request is evaluated as one causal convolution over
`[history_l | x_l]` (replicate-filled at session start) inside persistent GPU
buffers; chunks that are fully computed are published in one bulk ring-buffer
write; the control/input poll busy-spins instead of sleeping.

Variants (each a standalone launcher over the same verified engine):

| launcher | idea | status |
| --- | --- | --- |
| `worker.py` (`CF_STRATEGY=fullseq`) | whole-request packed-history conv, bulk publish, spin poll | recommended |
| `variants/fullseq` | same explicit strategy | measured |
| `variants/chunk_stream` | per-chunk packed-history streaming (no allocations) | measured |
| `variants/segment256` | 256-sample segments | measured |
| `variants/cuda_graph` | three convs+SiLU+history rotation replayed from one CUDA graph | measured (correctness PASS; controller benchmark timed out) |

Tests: `tests/test_worker.py` (candidate vs reference vs CPU oracle),
`tests/test_ir.py` (SequentialExecutor vs reference via `tests/run_ir_validation.py`),
`tests/suite.py` (all variants), `benchmarks/bench.py` (paired load sweep).
"""
(root / 'README.md').write_text(readme, encoding='utf-8')

log = """# Experiment log - causal_features

## IR conversion and validation (2026-10-20)
- Worker graph: 3 EXPOSED chunk ops (`layer_{0,1,2}_causal_conv`), 2 data
  edges (1:1 fixed-rate streaming), 3 chunk-persistent state objects
  (`history_0..2`, the last k-1 inputs of each layer).
- Model graph per layer: join -> replicate pad -> conv -> trim -> SiLU.
- Validation: PASS. `tests/test_ir.py` (launcher `tests/run_ir_validation.py`)
  runs `SequentialExecutor` over a six-request scenario (continuation,
  repeated input without reset, explicit reset, tail chunk) and compares with
  the reference backend driven through the adapter: worst error/tolerance
  ratio 0.033, 0 violations, atol=1e-6 rtol=1e-5 (same CPU fp32 op order).
  Artifact: `notes/ir_analysis.txt`.
- Analysis: 3 pipeline stages (one per layer) because each layer owns a
  separate history; no within-chunk independent pairs (the layers are chained
  by data edges), so cross-chunk overlap is layer pipelining only. The
  critical path is layer0->layer1->layer2 within a chunk, which is why the
  deployments attack per-request kernel count, history handling and polling
  rather than multi-device splitting (single assigned GPU).

## Variant queue (final state)
| # | name | hypothesis | IR basis | status |
| --- | --- | --- | --- | --- |
| 1 | reference | baseline | - | measured (benchmark-013/-020) |
| 2 | fullseq (`worker.py`) | one causal conv per layer per request removes 9x15 launches and cat/clone allocations | separate histories + causal window state | measured, PASS, recommended |
| 3 | chunk_stream | per-chunk streaming without allocations | chunk-periodic ops | measured, PASS |
| 4 | segment256 | 256-sample segments trade launches vs first-output latency | causal window | measured, PASS |
| 5 | cuda_graph | replay convs+SiLU+rotation from one graph | below-IR launch overhead | correctness PASS (verify-019); controller benchmark timed out (benchmark-020) |
| 6 | bulk publish + spin poll | remove per-chunk IPC and 200us sleeps | worker-level scheduling | folded into 2-5, measured |

## Measurements (suite_20261020_025407.json, dev config C=16 H=32 T=1043 chunk=127)
- reference: PASS, first output 1.65 ms median (p95 123 ms incl. cold),
  output-gap median 0.554 ms, sustainable 101 req/s (sweep cap 400).
- fullseq: PASS, first output 0.55 ms median, gap median 4.3 us, 401 req/s.
- chunk_stream: PASS, first 1.08 ms, gap 0.547 ms, 200 req/s.
- segment256: PASS, first 1.01 ms, gap 11.3 us, 201 req/s.
- cuda_graph: PASS, first 0.58 ms, p95 1.12 ms, gap 6.8 us, 402 req/s.
Controller paired sweep (benchmark-013, fullseq): reference highest passing
rate 100 req/s vs candidate 200 req/s (sweep cap); first-output medians
1.64/1.52 ms (ref) vs 1.09/1.08 ms (candidate) at 100/200 req/s.

## Failures and trade-offs
- `variants/cuda_graph`: numerically correct but the controller's paired
  benchmark run did not finish within 180 s (benchmark-020), so it is not the
  recommended entry even though the suite measured it fastest.
- At 50 req/s the controller flags a candidate smoothness failure because
  requests are published instantly and the inter-request idle gap (~20 ms)
  exceeds the 20 ms chunk budget; at 100/200 req/s the candidate passes.
- chunk_stream and segment256 are slower than fullseq on this GPU: per-chunk
  launches and per-segment synchronisations dominate these tiny convolutions.
- Only 4 distinct measured deployment variants (plus the reference anchor)
  were completed, below the 10-variant floor in the upstream workflow; the
  single-GPU assignment makes the multi-GPU placement variants inapplicable.
"""
(root / 'notes').mkdir(exist_ok=True)
(root / 'notes' / 'experiment_log.md').write_text(log, encoding='utf-8')
print('patched default=fullseq; wrote README.md and notes/experiment_log.md')
