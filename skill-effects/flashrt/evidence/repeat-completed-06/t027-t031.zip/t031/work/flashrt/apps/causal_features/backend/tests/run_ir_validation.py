"""Launcher that exposes our IR workspace under ``causal_features.backend``.

The controller's ``causal_features`` package only contains the app-level
modules, so the writable backend tree is registered as synthetic subpackages
in ``sys.modules`` at runtime.  Nothing outside ``backend/`` is modified.
"""
import sys
import types
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND / 'tests'))

for name, path in (('causal_features.backend', BACKEND),
                   ('causal_features.backend.ir', BACKEND / 'ir')):
    module = types.ModuleType(name)
    module.__path__ = [str(path)]
    sys.modules[name] = module

import test_ir  # noqa: E402

if __name__ == '__main__':
    sys.exit(test_ir.main())
