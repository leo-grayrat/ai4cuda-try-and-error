"""IR conversion for causal_features."""
