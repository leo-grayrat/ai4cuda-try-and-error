"""IR graphs for the causal_features app.

``build_worker_graph`` is the executable chunk-periodic graph validated in
``tests/test_ir.py``.  ``build_model_graph`` is a finer view of one exposed
layer (replicate pad -> conv -> drop warm-up -> capture history -> SiLU) used
by the analysis summary; it is not executed.
"""
from flashrt.ir import (IRGraph, IREdge, OpType, StateObject, StreamMode,
                        StreamingInfo, StreamingPattern, TensorPort,
                        ir_operator)

from .ops import CausalLayerStep


def build_worker_graph(layers):
    graph = IRGraph(name='causal_features_chunk')
    for index in range(len(layers)):
        graph.add_state(StateObject(
            f'history_{index}',
            f'last kernel-1 inputs of layer {index} (session-crossing state)',
            scope='chunk_persistent'))
    ops = [CausalLayerStep(index, layer) for index, layer in enumerate(layers)]
    for op in ops:
        graph.add_operator(op)
        graph.chunk_ops.append(op.name)
    for index in range(len(ops) - 1):
        graph.add_edge(IREdge(
            ops[index].name, 'activations', ops[index + 1].name, 'features',
            streaming=StreamingInfo(
                pattern=StreamingPattern.FIXED_RATE, src_chunk_size=1,
                dst_chunk_size=1,
                description='layer-to-layer 1:1 chunk activation stream')))
    graph.external_inputs = [TensorPort('features', dtype_hint='float32')]
    graph.external_outputs = [TensorPort('activations', dtype_hint='float32')]
    return graph


def _pad_op(index):
    @ir_operator(
        name=f'layer_{index}_replicate_pad',
        op_type=OpType.EXPOSED,
        inputs=[TensorPort('features')],
        outputs=[TensorPort('padded')],
        state_reads=[f'history_{index}'],
    )
    def pad(inputs, ctx, state):
        history = state.get(f'history_{index}')
        value = inputs['features']
        joined = value if history is None else ctx.torch.cat([history, value], dim=-1)
        return {'padded': ctx.F.pad(joined, (ctx.pad, 0), mode='replicate')}

    return pad


def _conv_op(index, layer):
    @ir_operator(
        name=f'layer_{index}_conv',
        op_type=OpType.EXPOSED,
        inputs=[TensorPort('padded')],
        outputs=[TensorPort('result')],
    )
    def conv(inputs, ctx, state):
        return {'result': ctx.torch.conv1d(
            inputs['padded'], layer.conv.weight, layer.conv.bias)}

    return conv


def _trim_op(index):
    @ir_operator(
        name=f'layer_{index}_trim_warmup',
        op_type=OpType.EXPOSED,
        inputs=[TensorPort('result')],
        outputs=[TensorPort('trimmed')],
        state_reads=[f'history_{index}'],
    )
    def trim(inputs, ctx, state):
        history = state.get(f'history_{index}')
        result = inputs['result']
        if history is not None:
            result = result[:, :, history.shape[-1]:]
        return {'trimmed': result}

    return trim


def _history_op(index):
    @ir_operator(
        name=f'layer_{index}_capture_history',
        op_type=OpType.EXPOSED,
        inputs=[TensorPort('padded')],
        outputs=[],
        state_writes=[f'history_{index}'],
    )
    def capture(inputs, ctx, state):
        padded = inputs['padded']
        ctx_history = padded[:, :, ctx.history_len:-1] if ctx.pad == 0 else padded
        del ctx_history
        joined = inputs['joined']
        state.set(f'history_{index}', joined[:, :, -ctx.pad:].clone())
        return {}

    return capture


def build_model_graph(index, layer):
    """Fine-grained view of one exposed layer (analysis only)."""
    graph = IRGraph(name=f'layer_{index}_model')
    graph.add_state(StateObject(f'history_{index}',
                                'layer input tail', scope='chunk_persistent'))
    pad = int(layer._time_causal_padding[0])
    # Preamble op publishes the kernel geometry the later ops read.
    @ir_operator(
        name=f'layer_{index}_kernel_geometry', op_type=OpType.EXPOSED,
        outputs=[TensorPort('pad')], state_writes=[f'history_{index}'])
    def geometry(inputs, ctx, state):
        return {'pad': ctx.pad}

    graph.add_operator(geometry)
    graph.preamble_ops.append(geometry.name)
    graph.add_state(StateObject(f'history_{index}', 'layer input tail',
                                scope='chunk_persistent')) if False else None

    @ir_operator(
        name=f'layer_{index}_joined', op_type=OpType.EXPOSED,
        inputs=[TensorPort('features')], outputs=[TensorPort('joined')],
        state_reads=[f'history_{index}'])
    def joined(inputs, ctx, state):
        history = state.get(f'history_{index}')
        value = inputs['features']
        return {'joined': value if history is None else ctx.torch.cat(
            [history, value], dim=-1)}

    @ir_operator(
        name=f'layer_{index}_pad', op_type=OpType.EXPOSED,
        inputs=[TensorPort('joined')], outputs=[TensorPort('padded')])
    def padop(inputs, ctx, state):
        return {'padded': ctx.F.pad(inputs['joined'], (pad, 0), mode='replicate')}

    @ir_operator(
        name=f'layer_{index}_conv', op_type=OpType.EXPOSED,
        inputs=[TensorPort('padded')], outputs=[TensorPort('result')])
    def conv(inputs, ctx, state):
        return {'result': ctx.torch.conv1d(inputs['padded'],
                                           layer.conv.weight, layer.conv.bias)}

    @ir_operator(
        name=f'layer_{index}_silu', op_type=OpType.EXPOSED,
        inputs=[TensorPort('result')], outputs=[TensorPort('activations')],
        state_writes=[f'history_{index}'])
    def silu(inputs, ctx, state):
        history = state.get(f'history_{index}')
        result = inputs['result']
        if history is not None:
            result = result[:, :, history.shape[-1]:]
        return {'activations': ctx.F.silu(result)}

    for op in (joined, padop, conv, silu):
        graph.add_operator(op)
        graph.chunk_ops.append(op.name)
    for src, dst in ((joined, padop), (padop, conv), (conv, silu)):
        graph.add_edge(IREdge(src.name, next(iter(src.outputs)).name,
                              dst.name, next(iter(dst.inputs)).name,
                              streaming=StreamingInfo(
                                  pattern=StreamingPattern.FIXED_RATE,
                                  src_chunk_size=1, dst_chunk_size=1)))
    graph.external_inputs = [TensorPort('features')]
    graph.external_outputs = [TensorPort('activations')]
    return graph
