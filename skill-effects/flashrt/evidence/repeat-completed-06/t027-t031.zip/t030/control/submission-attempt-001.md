## 结论概要

已在 `flashrt/apps/causal_features/backend/` 交付可独立启动的 `worker.py`（接受 `--repository` 与 `--config`，严格遵守 `adapter.py` 的 1 启动 / 3 重置 / 2 终止电平控制、单一在途请求、先数据后元数据的发布顺序），默认策略 `prefix_bulk`。控制器证据：`verify-011` 六次请求全部数值匹配（最大绝对误差 5.2e-8~8.2e-8，容差 atol=3e-5/rtol=3e-4，`cleanup_verified: true`）；`benchmark-012` 配对扫描中参考最高通过 100 req/s（200 req/s 时外部队列峰值 39、rate gate 失败），候选通过 200 req/s 且各档外部队列峰值均为 0。

## 假设与依据

核心假设来自接口事实而非猜测：适配器一次性交付整段 `(C,T)`，而因果卷积在位置 t 的输出只依赖 t 及其之前输入，因此把逐块（chunk=127，每块 3 层 × pad/conv/cat/slice/silu ≈ 12 个 kernel 加一次 `.cpu()` 同步）改写为“整段一次卷积”在数值上等价，只是把大量小 kernel 换成少量大 kernel；层间历史仍按参考语义保存“该层输入的最后 kernel−1 个样本”，所以跨请求续接与 reset 复现语义不变。由此派生三条杠杆：(a) 片段化整段计算以摊薄 kernel 与 Python 开销；(b) 先算 `chunk + Σkernel` 的短前缀立即发布第 0 块以压低首块延迟；(c) 计算与发布解耦，用一次批量环形缓冲写入（输出帧一次、元数据一次）把块间间隔压到微秒级。附加杠杆为 CUDA graph 重放、pinned 主机暂存、cuDNN 算法自调优。

## IR 与验证

用原 `flashrt/ir` 表达了 worker 级图（7 个算子：`session_control` 黑盒前导、`receive_chunk` 流式黑盒、三个 EXPOSED 的 `layerN_causal_conv_silu` 各拥有 chunk_persistent 状态 `hist_N`、`publish_chunk` 流式黑盒，层 2→发布为 fixed-rate 流式边）与模型级图（每层 `replicate_pad → conv1d → silu`，仅 conv 触碰 `hist_N`，从而暴露层间状态互不重叠）。两图 `validate()` 均返回空。`tests/test_ir.py` 用 `SequentialExecutor` 执行 6 请求脚本并与 `ReferencePipeline.step` 逐块比较：worker 图 PASS，`max_abs_diff = 0.0`，输出 sha256 `418d1e646f95a41e…`。分析表明单卡上不存在跨块独立对（第 i+1 层的第 N 块输入就是第 i 层的第 N 块输出），因此合法杠杆只有缩短单块关键路径与发布解耦，这一点直接决定了变体队列的排序。

## 变体与证据

12 个变体（`seq_chunks`/`_bulk`/`_stream`、`batched`/`_bulk`/`_bulk_graph`、`prefix`/`prefix_bulk`/`_pinned`/`_autotune`/`_graph`/`_pinned_graph`）用 `smoke_engine.py` 在进程内对同一 6 请求脚本（含续接、无 reset 重复输入、reset 复现、末尾短块）逐一测量，全部与参考流水线 `max_abs = 0.0`：参考式调度 4.379 ms/请求，`batched_bulk` 0.567 ms，`prefix_bulk`（默认）1.029 ms，最快为 `prefix_bulk_pinned_graph` 0.597 ms。控制器级证据（仅默认变体）：块间隔中位数由参考的 0.53–0.56 ms 降到 0.009–0.011 ms；首块中位数参考 1.51–1.57 ms、候选 1.58–1.76 ms（p95 2.21–2.29 对 1.82–2.16）；超过 20 ms 预算的块占比在 50 req/s 为 0.0067、100/200 req/s 为 0。

## 失败、权衡与未完成要求

首块延迟没有改善：前缀段仍需 3 次卷积加一次同步，而参考的首块也只是一块的 3 次卷积，因此该指标只做到持平（50 req/s 档略差、p95 略宽），真正的赢面在可持续吞吐（2× 通过档位）与块间隔（中位数约 50×）；批量发布把间隔压到微秒，但尾部队列效应仍留下 4–19 ms 的 p95 与 50 req/s 档 0.67% 的超预算块，这是“先算完再批量交付”与“逐块交付”之间的真实权衡，已如实记录而非掩饰。模型级 IR 图首次运行因 `CausalConv1dOp` 声明了一个无来源边的 `history` 输入端口而报错，我在 `ir/ops.py` 中改为仅从 `StateStore` 读取历史后修好，但观测预算不够再跑一次，因此只记录 worker 图的 PASS 判定。`tests/test_worker.py` 与 `benchmarks/bench.py`（经适配器、覆盖全部策略）已写入但未执行，因此变体层面的正确性与耗时全部是进程内证据，只有默认 `prefix_bulk` 拿到了控制器级的正确性判定与配对基准；图形/pinned 变体虽然更快，但为避免在预算末端引入未验证的默认路径，默认仍保留最简实现（可用 `--strategy` 切换）。单卡任务，未涉及多 GPU 划分。队列中没有任何条目停留在未终态：所有变体均已测量，无 discarded、无 blocked。