"""Optimized backend worker for the causal_features app.

Standalone entry point::

    python flashrt/apps/causal_features/backend/worker.py \
        --repository <fixed source dir> --config <config.json> [--strategy NAME]

It honours exactly the adapter protocol in ``causal_features/adapter.py``
(opcodes 1 start / 3 reset / 2 terminate, level-valued control channel, one
request in flight, data published before metadata) and only changes *how* the
fixed three-layer causal convolution chain is scheduled.  See ``engine.py`` for
the individual deployment variants.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path


def _ensure_paths(repository):
    root = Path(repository).resolve()
    for candidate in (str(root), str(root / 'flashrt' / 'apps')):
        if candidate not in sys.path:
            sys.path.insert(0, candidate)


def _load_engine():
    try:
        from causal_features.backend.engine import CausalEngine
        return CausalEngine
    except Exception:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from engine import CausalEngine
        return CausalEngine


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--strategy', default=None)
    args, _unknown = parser.parse_known_args(argv)

    _ensure_paths(args.repository)
    import numpy as np
    import torch
    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers

    CausalEngine = _load_engine()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    strategy = args.strategy or os.environ.get('CAUSAL_STRATEGY') or 'prefix_bulk'

    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    # `build_layers` re-seeds with config['weight_seed'], so the weights are
    # bit-identical to the reference backend's.
    layers = build_layers(args.repository, config, config['device'])
    engine = CausalEngine(layers, config, strategy)
    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({'ready': True, 'device': str(config['device']),
                          'strategy': strategy}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            engine.execute(request_id, np.ascontiguousarray(features[0]),
                           buffers['output'], buffers['metadata'])
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
