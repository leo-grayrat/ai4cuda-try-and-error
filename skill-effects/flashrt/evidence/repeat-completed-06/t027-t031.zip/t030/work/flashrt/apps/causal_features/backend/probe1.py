import ast, inspect, json, sys
from pathlib import Path
import torch

root = Path.cwd()
src = root / 'flashrt/layers/audio.py'
node = next(n for n in ast.parse(src.read_text(encoding='utf-8')).body
            if isinstance(n, ast.ClassDef) and n.name == 'CausalConv1d')
print(ast.unparse(node))
print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), torch.cuda.get_device_name(0))
print('ir modules:', sorted(p.name for p in (root/'flashrt/ir').iterdir()))
