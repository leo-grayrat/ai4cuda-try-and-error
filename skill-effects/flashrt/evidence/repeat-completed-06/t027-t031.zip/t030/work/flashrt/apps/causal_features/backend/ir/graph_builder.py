"""IR graph builders for the causal-features reference computation."""
import torch  # noqa: F401  (kept for symmetry with ops.py / analysis timing)

from flashrt.ir import (IRGraph, IREdge, StateObject, StreamingInfo,
                        StreamingPattern, TensorPort, analyze_cross_chunk_dependencies,
                        compute_critical_path, find_pipeline_stages,
                        find_streaming_overlaps, summarize_graph)

from .ops import (CausalConv1dOp, LayerPass, PublishChunk, ReceiveChunk,
                  ReplicatePad, SessionControl, SiLU)

DEFAULT_KERNELS = (5, 5, 3)


def default_kernels(config):
    return tuple(int(k) for k in config.get('kernels', DEFAULT_KERNELS))


def register(graph, op, preamble=False):
    """Add an operator and pin it to exactly one phase of the graph."""
    graph.add_operator(op)
    for bucket in (graph.preamble_ops, graph.chunk_ops):
        while op.name in bucket:
            bucket.remove(op.name)
    target = graph.preamble_ops if preamble else graph.chunk_ops
    target.append(op.name)
    return op


def build_worker_graph(config):
    """Worker-level graph: control plane plus the three-layer chunk pipeline."""
    kernels = default_kernels(config)
    n_layers = len(kernels)
    chunk = int(config['chunk'])
    graph = IRGraph(name='causal_features_worker')
    graph.add_state(StateObject('session', 'control-plane state', scope='session_init'))
    for i in range(n_layers):
        graph.add_state(StateObject(f'hist_{i}',
                                    f'layer {i} input history ({kernels[i] - 1} samples)',
                                    scope='chunk_persistent'))

    register(graph, SessionControl(n_layers), preamble=True)
    receive = register(graph, ReceiveChunk())
    layers = [register(graph, LayerPass(i, k)) for i, k in enumerate(kernels)]
    publish = register(graph, PublishChunk())

    graph.add_edge(IREdge('session_control', 'active', receive.name, None))
    graph.add_edge(IREdge(receive.name, 'x', layers[0].name, 'x'))
    for i in range(n_layers - 1):
        graph.add_edge(IREdge(layers[i].name, 'y', layers[i + 1].name, 'x'))
    graph.add_edge(IREdge(layers[-1].name, 'y', publish.name, 'y',
                          streaming=StreamingInfo(
                              StreamingPattern.FIXED_RATE, src_chunk_size=chunk,
                              dst_chunk_size=chunk,
                              description='one output chunk per received chunk')))
    graph.external_inputs = [TensorPort('opcode')]
    graph.external_outputs = [TensorPort('y')]
    return graph


def build_model_graph(config):
    """Model-level graph: pad -> conv -> silu per layer, history per conv."""
    kernels = default_kernels(config)
    channels = int(config['channels'])
    hidden = int(config['hidden'])
    dims = [(channels, hidden)] + [(hidden, hidden)] * (len(kernels) - 2) + [(hidden, channels)]
    graph = IRGraph(name='causal_features_layers')
    for i in range(len(kernels)):
        graph.add_state(StateObject(f'hist_{i}',
                                    f'layer {i} input history ({kernels[i] - 1} samples)',
                                    scope='chunk_persistent'))
    previous = None
    for i, kernel in enumerate(kernels):
        pad = register(graph, ReplicatePad(i, kernel))
        conv = register(graph, CausalConv1dOp(i, kernel, *dims[i]))
        silu = register(graph, SiLU(i))
        graph.add_edge(IREdge(pad.name, 'x_padded', conv.name, 'x'))
        graph.add_edge(IREdge(conv.name, 'y', silu.name, 'x'))
        if previous is None:
            graph.external_inputs = [TensorPort('x')]
        else:
            graph.add_edge(IREdge(previous, 'y', pad.name, 'x'))
        previous = silu.name
    graph.external_outputs = [TensorPort('y')]
    return graph


def build_graph(config):
    """Convenience alias: the worker-level graph (default analysis target)."""
    return build_worker_graph(config)


def analyze(graph, op_latencies=None):
    """Full analysis record for the experiment log."""
    stages = find_pipeline_stages(graph)
    overlaps = find_streaming_overlaps(graph)
    cross = analyze_cross_chunk_dependencies(graph)
    lines = [summarize_graph(graph, op_latencies=op_latencies)]
    lines.append(f'pipeline_stages: {[getattr(s, "operators", s) for s in stages]}')
    lines.append(f'streaming_overlaps: {overlaps}')
    lines.append(f'cross_chunk: {cross}')
    if op_latencies:
        path, total = compute_critical_path(graph, op_latencies)
        lines.append(f'critical_path: {path} total={total:.6f}s')
    return '\n'.join(lines)
