# causal_features backend (CUDA, RTX 5060 8GB)

Recommended entry: `backend/worker.py` (strategy default `prefix_bulk`).

Launch (same two flags as the reference; module paths configured by the runner):

```
python flashrt/apps/causal_features/backend/worker.py \
    --repository <fixed source dir> --config <config.json>
```

Optional `--strategy NAME` (or `CAUSAL_STRATEGY`) selects a measured variant:
`seq_chunks, seq_chunks_bulk, seq_chunks_stream, batched, batched_bulk,
batched_bulk_graph, prefix, prefix_bulk, prefix_bulk_pinned,
prefix_bulk_autotune, prefix_bulk_graph, prefix_bulk_pinned_graph`.

What changed relative to the reference: the adapter hands the whole `(C, T)`
request at once, and a causal convolution over a longer segment is
value-identical to convolving it chunk by chunk, so `prefix_bulk` computes a
short prefix (`chunk + sum(kernel)` samples) and publishes chunk 0 immediately,
then computes the remainder in one pass and publishes the rest in a single
batched ring-buffer write (payload first, metadata second). Per-layer input
histories are kept exactly as `ReferencePipeline.step` keeps them, so session
continuation across requests and reset reproduction are unchanged.

Harnesses:
* `tests/test_ir.py` - Phase 2: runs `flashrt.ir.SequentialExecutor` over the
  worker-level and model-level IR graphs and compares with `ReferencePipeline`.
* `tests/test_worker.py` - Phase 4: launches reference + candidate subprocesses
  through `causal_features.adapter` and compares with the CPU full-sequence
  oracle.
* `smoke_engine.py` - fast in-process comparison/timing of every strategy.
* `benchmarks/bench.py` - paired offered-load benchmark harness
  (results in `benchmarks/results/`).

Controller evidence: `verify-011` (6/6 requests numerically matched, cleanup
verified), `benchmark-012` (paired reference/candidate load sweep).
