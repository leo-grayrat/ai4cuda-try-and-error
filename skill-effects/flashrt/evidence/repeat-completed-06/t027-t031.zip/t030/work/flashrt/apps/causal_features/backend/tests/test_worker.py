"""Phase 4 correctness: candidate worker vs the CPU full-sequence oracle.

Launches the reference backend and each candidate strategy as subprocesses,
drives the same 6-request script through the adapter (continuation, repeated
input without reset, reset, tail chunk), and compares chunk-wise against
`causal_features.model.full_sequence_oracle` on the concatenated session input.
"""
import json
import sys
import traceback
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import harness  # noqa: E402

STRATEGIES = ['seq_chunks', 'seq_chunks_bulk', 'seq_chunks_stream', 'batched',
              'batched_bulk', 'batched_bulk_graph', 'prefix', 'prefix_bulk',
              'prefix_bulk_pinned', 'prefix_bulk_autotune', 'prefix_bulk_graph',
              'prefix_bulk_pinned_graph']


def run_one(kind, config, plan, strategy=None):
    with harness.Backend(kind, config, strategy=strategy) as backend:
        records = backend.run_plan(plan)
        stderr = backend.stderr_text()
    alive = harness.shm_still_present(config)
    return records, stderr, alive


def main(strategies=None, channels=16, hidden=32, length=1043, chunk=127):
    strategies = strategies or STRATEGIES
    config = harness.make_config(channels=channels, hidden=hidden,
                                 length=length, chunk=chunk)
    plan = harness.scripted_inputs(config)
    expected = harness.oracle_chunks(str(harness.REPO), config, plan)
    summary = {'config': {k: config[k] for k in ('channels', 'hidden', 'length', 'chunk')},
               'tolerance': {'atol': 3e-5, 'rtol': 3e-4}, 'results': {}}
    all_ok = True

    try:
        ref_records, ref_err, ref_alive = run_one('reference', config, plan)
        ok, details = harness.compare(ref_records, expected)
        print('reference vs oracle:', 'PASS' if ok else 'FAIL', details, flush=True)
        summary['results']['reference'] = {'verdict': 'PASS' if ok else 'FAIL',
                                           'details': details, 'stderr_tail': ref_err[-800:],
                                           'shm_leaked': ref_alive}
        all_ok = all_ok and ok
    except Exception:
        traceback.print_exc()
        ref_records = None
        summary['results']['reference'] = {'verdict': 'ERROR'}
        all_ok = False

    for strategy in strategies:
        cfg = dict(config)
        cfg['prefix'] = f"causal_{strategy}_{np.random.default_rng(0).integers(1 << 20):x}"
        entry = {'verdict': 'ERROR'}
        try:
            records, err, alive = run_one('worker', cfg, plan, strategy=strategy)
            ok, details = harness.compare(records, expected)
            verdict = 'PASS' if ok else 'FAIL'
            if alive:
                verdict = 'FAIL'
            if 'Traceback' in err:
                verdict = 'FAIL'
            diff_vs_ref = None
            if ref_records is not None:
                worst = 0.0
                for a, b in zip(records, ref_records):
                    for ca, cb in zip(a['chunks'], b['chunks']):
                        worst = max(worst, float(np.abs(ca[1] - cb[1]).max()))
                diff_vs_ref = worst
            entry = {'verdict': verdict, 'details': details,
                     'max_abs_diff_vs_reference': diff_vs_ref,
                     'shm_leaked': alive, 'stderr_tail': err[-800:]}
            print(f'{strategy}: {verdict} max_abs_diff_vs_reference={diff_vs_ref} '
                  f'shm_leaked={alive}', flush=True)
            all_ok = all_ok and verdict == 'PASS'
        except Exception as exc:
            traceback.print_exc()
            entry = {'verdict': 'ERROR', 'error': repr(exc)}
        summary['results'][strategy] = entry

    out = HERE / 'worker_correctness.json'
    out.write_text(json.dumps(summary, indent=2), encoding='utf-8')
    verdict = 'PASS' if all_ok else 'FAIL'
    print('VERDICT:', verdict, '(details in', out, ')')
    return 0 if all_ok else 1


if __name__ == '__main__':
    args = sys.argv[1:]
    if args and args[0] == '--large':
        raise SystemExit(main(channels=128, hidden=256, length=16384, chunk=512))
    raise SystemExit(main(strategies=args or None))
