import importlib, inspect, sys
from pathlib import Path
import flashrt.ir as ir
from flashrt.ir import graph as g, executor as ex

for name in ('add_operator', 'add_edge', 'add_state', 'validate'):
    print('IRGraph.' + name, inspect.signature(getattr(g.IRGraph, name)))
for name in ('__init__', 'init_state', 'run_preamble', 'run_chunk'):
    print('SequentialExecutor.' + name, inspect.signature(getattr(ex.SequentialExecutor, name)))
print('StreamingPattern:', [p.value for p in ir.StreamingPattern])
print('StateStore:', inspect.getsource(g.StateStore)[:600])

root = Path.cwd()
for p in (str(root), str(root / 'flashrt' / 'apps')):
    if p not in sys.path:
        sys.path.insert(0, p)
try:
    import causal_features.adapter as ad
    print('adapter ok:', ad.__file__)
except Exception as e:
    print('adapter fail', type(e).__name__, e)
try:
    import causal_features.model as m
    print('model ok:', m.__file__)
except Exception as e:
    print('model fail', type(e).__name__, e)
