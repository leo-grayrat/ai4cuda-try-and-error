"""Phase 2: execute the IR graphs and compare them with the reference pipeline.

The IR executor runs the same 6-request script the adapter harness uses
(continuation, repeated input without reset, reset, tail chunk) and its
per-chunk outputs are compared element-wise with the user's sequential
`ReferencePipeline.step` outputs.
"""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import harness  # noqa: E402

harness.ensure_paths()
from causal_features.model import ReferencePipeline, build_layers  # noqa: E402
from flashrt.ir import SequentialExecutor  # noqa: E402

from causal_features.backend.ir import build_model_graph, build_worker_graph  # noqa: E402
from causal_features.backend.ir.graph_builder import analyze  # noqa: E402

ATOL, RTOL = 3e-5, 3e-4   # CPU/GPU float32 accumulation-order allowance


class Ctx:
    def __init__(self, layers, device):
        self.layers = layers
        self.device = device
        self.chunks = []
        self.chunk_index = 0
        self.published = []
        self.spans = []


def abs_diff(a, b):
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    diff = np.abs(a - b)
    return float(diff.max()), int((diff > ATOL + RTOL * np.abs(b)).sum())


def time_ops(layers, config, device):
    chunk = config['chunk']
    lat = {}
    for i, layer in enumerate(layers):
        joined = torch.zeros(1, layer.conv.in_channels, chunk + 4, device=device)
        start, end = torch.cuda.Event(True), torch.cuda.Event(True)
        start.record()
        layer.conv(joined)
        end.record()
        torch.cuda.synchronize()
        lat[f'layer{i}_causal_conv_silu'] = start.elapsed_time(end) / 1000.0
        lat[f'layer{i}_conv1d'] = lat[f'layer{i}_causal_conv_silu']
        lat[f'layer{i}_replicate_pad'] = 2e-6
        lat[f'layer{i}_silu'] = 2e-6
    lat['receive_chunk'] = 3e-5
    lat['publish_chunk'] = 5e-5
    lat['session_control'] = 1e-6
    return lat


@torch.inference_mode()
def drive(ctx, plan, executor):
    results = []
    for item in plan:
        if item['reset']:
            for code in (3, 1):
                executor.run_preamble({'opcode': code}, ctx)
        ctx.chunks = [torch.from_numpy(item['features'][:, s:e].copy()).unsqueeze(0)
                      .to(ctx.device) for s, e in ctx.spans]
        ctx.published = []
        for index in range(len(ctx.chunks)):
            ctx.chunk_index = index
            executor.run_chunk({'x': ctx.chunks[index]}, ctx)
        results.append([out.squeeze(0).cpu().numpy() for out in ctx.published])
    return results


def initial_state(graph):
    state = {}
    for name in graph.state_objects:
        state[name] = {'active': False} if name == 'session' else None
    return state


def main(device='cuda'):
    config = harness.make_config(device=device)
    repository = str(harness.REPO)
    layers = build_layers(repository, config, device)
    ctx = Ctx(layers, device)
    ctx.spans = [(s, min(config['length'], s + config['chunk']))
                 for s in range(0, config['length'], config['chunk'])]
    plan = harness.scripted_inputs(config)

    reference = ReferencePipeline(repository, config)
    expected = []
    for item in plan:
        if item['reset']:
            reference.reset()
        expected.append([reference.step(item['features'][:, s:e]) for s, e in ctx.spans])

    ok = True
    report = {}
    worker_graph = build_worker_graph(config)
    print('worker graph validate:', worker_graph.validate())
    model_graph = build_model_graph(config)
    print('model graph validate:', model_graph.validate())

    for name, graph in (('worker_graph', worker_graph), ('model_graph', model_graph)):
        executor = SequentialExecutor(graph)
        executor.init_state(initial_state(graph))
        executor.run_preamble({'opcode': 1}, ctx)
        got = drive(ctx, plan, executor)
        worst, bad = 0.0, 0
        for request, want in zip(got, expected):
            if len(request) != len(want):
                print(f'{name}: chunk count mismatch {len(request)} != {len(want)}')
                ok = False
                continue
            for a, b in zip(request, want):
                m, n = abs_diff(a, b)
                worst = max(worst, m)
                bad += n
        digest = hashlib.sha256(np.concatenate(
            [c.ravel() for request in got for c in request]).tobytes()).hexdigest()
        report[name] = {'max_abs_diff': worst, 'over_tolerance_values': bad,
                        'output_sha256': digest}
        print(f'{name}: max_abs_diff={worst:.3e} over_tolerance={bad} '
              f'sha256={digest[:16]}', flush=True)
        if bad:
            ok = False

    latencies = time_ops(layers, config, device)
    notes = HERE.parent / 'notes'
    notes.mkdir(exist_ok=True)
    analysis = analyze(worker_graph, latencies)
    (notes / 'ir_analysis.txt').write_text(analysis + '\n', encoding='utf-8')
    (notes / 'ir_analysis_model.txt').write_text(
        analyze(model_graph, latencies) + '\n', encoding='utf-8')
    print(analysis)

    verdict = 'PASS' if ok else 'FAIL'
    payload = {'verdict': verdict, 'tolerance': {'atol': ATOL, 'rtol': RTOL},
               'graphs': report}
    (HERE / 'ir_validation.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')
    print('VERDICT:', verdict)
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
