"""Causal-feature compute engines (deployment variants).

The reference backend runs one `CausalConv1d` chain per chunk and publishes each
chunk immediately.  The adapter hands the backend the *entire* request `(C, T)`
at once, so the same causal computation can be scheduled very differently while
producing numerically comparable values:

  * `_pass()` keeps the exact reference state semantics: the per-layer history
    is the last `kernel-1` samples of that layer's *input*, exactly what
    `ReferencePipeline.step` stores; the first pass of a session relies on
    `CausalConv1d`'s own replicate padding, identical in both.
  * `forward_full()` runs the three layers over a whole contiguous segment at
    once.  A causal conv output at t only reads inputs <= t, so convolving a
    longer segment is value-identical to convolving it in chunks, while trading
    many small kernels for one large kernel.

Strategies: seq_chunks / seq_chunks_bulk / seq_chunks_stream (reference
schedule, cheaper publishing), batched / batched_bulk / batched_bulk_graph (one
segment pass per request), prefix / prefix_bulk / prefix_bulk_pinned /
prefix_bulk_autotune / prefix_bulk_graph / prefix_bulk_pinned_graph (chunk 0
ships from a short prefix pass before the remainder is computed).
"""
import math

import numpy as np
import torch
import torch.nn.functional as F


class _Graph:
    """CUDA-graph replay of one fixed-length segment pass."""

    @torch.inference_mode()
    def __init__(self, engine, length, hist):
        dev = engine.device
        self.length = int(length)
        self.x = torch.zeros(1, engine.C, self.length, device=dev)
        self.out = torch.empty(1, engine.C, self.length, device=dev)
        prev_hist = engine.hist
        engine.hist = hist
        try:
            side = torch.cuda.Stream()
            side.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(side):
                for _ in range(3):
                    engine.forward_full(self.x)
            torch.cuda.current_stream().wait_stream(side)
            torch.cuda.synchronize()
            self.graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(self.graph):
                y = engine.forward_full(self.x)
                self.out.copy_(y)
            torch.cuda.synchronize()
        finally:
            engine.hist = prev_hist

    @torch.inference_mode()
    def run(self, src):
        self.x.copy_(src)
        self.graph.replay()
        return self.out


class CausalEngine:
    def __init__(self, layers, config, strategy='prefix_bulk'):
        self.layers = layers
        self.strategy = strategy
        self.device = next(layers[0].parameters()).device
        self.C = int(config['channels'])
        self.T = int(config['length'])
        self.chunk = int(config['chunk'])
        self.k = [int(layer._time_causal_padding[0]) for layer in layers]
        self.n_layers = len(layers)
        self.n_chunks = int(math.ceil(self.T / float(self.chunk)))
        self.spans = [(i * self.chunk, min(self.T, (i + 1) * self.chunk))
                      for i in range(self.n_chunks)]
        self.prefix_len = min(self.T, self.chunk + sum(self.k))

        self.pinned = '_pinned' in strategy
        self.use_graph = strategy.endswith('_graph')
        self.autotune = strategy.endswith('_autotune')
        self.streaming = 'stream' in strategy.split('_')
        # With graphs the history buffers must live at fixed addresses, so
        # writes go through copy_ into preallocated tensors.
        self.fixed_hist = self.use_graph

        if self.autotune:
            torch.backends.cudnn.benchmark = True

        self.pad = np.zeros((self.C, self.chunk), dtype=np.float32)
        self.host = np.zeros((self.C, self.T), dtype=np.float32)
        self.bulk = np.zeros((self.n_chunks, self.C, self.chunk), dtype=np.float32)
        self.bulk_meta = np.zeros((self.n_chunks, 3), dtype=np.int64)
        self.hist = [None] * self.n_layers
        self.hist_static = [torch.zeros(1, int(layer.conv.in_channels), self.k[i],
                                        device=self.device)
                            for i, layer in enumerate(layers)]
        self.graphs = {}
        if self.pinned:
            self.pin_in = torch.empty(1, self.C, self.T, pin_memory=True)
            self.pin_out = torch.empty(1, self.C, self.T, pin_memory=True)
        if self.streaming:
            self.copy_stream = torch.cuda.Stream()
            self.stream_bufs = [torch.empty(1, self.C, self.chunk, pin_memory=True)
                                for _ in range(2)]
        self.warmup()

    # ------------------------------------------------------------------ state
    def reset(self):
        self.hist = [None] * self.n_layers

    def _pass(self, index, x):
        layer = self.layers[index]
        k = self.k[index]
        h = self.hist[index]
        if h is None:
            joined = x
        else:
            joined = torch.cat((h, x), dim=-1)
        out = layer(joined)
        if h is not None:
            out = out[..., h.shape[-1]:]
        tail = joined[..., -k:].detach()
        if self.fixed_hist and self.hist[index] is not None:
            self.hist[index].copy_(tail)
        else:
            self.hist[index] = tail.clone()
        return F.silu(out)

    def forward_full(self, x):
        for index in range(self.n_layers):
            x = self._pass(index, x)
        return x

    # ---------------------------------------------------------------- helpers
    def to_gpu(self, features):
        if self.pinned:
            self.pin_in[0].copy_(torch.from_numpy(features))
            return self.pin_in[:, :, :self.T].to(self.device, non_blocking=True)
        return torch.from_numpy(np.ascontiguousarray(features)).unsqueeze(0).to(
            self.device, non_blocking=False)

    def _host_seg(self, seg):
        length = int(seg.shape[-1])
        if self.pinned:
            self.pin_out[:, :, :length].copy_(seg, non_blocking=True)
            torch.cuda.current_stream().synchronize()
            return self.pin_out[0, :, :length].numpy()
        return seg[0].cpu().numpy()

    def to_host(self, out):
        return self._host_seg(out)

    def _graph(self, length):
        graph = self.graphs.get(length)
        if graph is None:
            graph = _Graph(self, length, self.hist_static)
            self.graphs[length] = graph
        return graph

    def segment(self, x, length):
        """One segment pass, replayed from a CUDA graph when possible."""
        if not self.use_graph:
            return self.forward_full(x)
        graph = self._graph(length)
        if self.hist[0] is None:
            # Session start: the reference replicate-pads the first chunk, so
            # run eagerly and then hand the resulting history to the graph.
            out = self.forward_full(x)
            for i in range(self.n_layers):
                self.hist_static[i].copy_(self.hist[i])
            self.hist = self.hist_static
            return out
        if self.hist is not self.hist_static:
            for i in range(self.n_layers):
                self.hist_static[i].copy_(self.hist[i])
            self.hist = self.hist_static
        return graph.run(x)

    # ---------------------------------------------------------------- publish
    def publish_block(self, request_id, index, block, output, metadata):
        valid = int(block.shape[1])
        if valid == self.chunk:
            output.write(block)
        else:
            self.pad[:, :valid] = block
            self.pad[:, valid:] = 0
            output.write(self.pad)
        metadata.write(np.array([request_id, index, valid], dtype=np.int64))

    def stage_block(self, index, block):
        valid = int(block.shape[1])
        self.bulk[index, :, :valid] = block
        if valid < self.chunk:
            self.bulk[index, :, valid:] = 0

    def publish_bulk(self, request_id, first, count, output, metadata):
        for j in range(count):
            index = first + j
            self.bulk_meta[j, 0] = request_id
            self.bulk_meta[j, 1] = index
            self.bulk_meta[j, 2] = self.spans[index][1] - self.spans[index][0]
        output.write(self.bulk[first:first + count])
        metadata.write(self.bulk_meta[:count])

    def _fan_out(self, request_id, first, output, metadata):
        count = self.n_chunks - first
        if self.strategy.endswith('_bulk') or self.strategy.endswith('_graph'):
            for index in range(first, self.n_chunks):
                start, end = self.spans[index]
                self.stage_block(index, self.host[:, start:end])
            self.publish_bulk(request_id, first, count, output, metadata)
        else:
            for index in range(first, self.n_chunks):
                start, end = self.spans[index]
                self.publish_block(request_id, index, self.host[:, start:end],
                                   output, metadata)

    # --------------------------------------------------------------- variants
    @torch.inference_mode()
    def execute(self, request_id, features, output, metadata):
        name = self.strategy
        if name in ('seq_chunks', 'seq_chunks_bulk', 'seq_chunks_stream'):
            return self._run_seq_chunks(request_id, features, output, metadata)
        if name.startswith('batched'):
            return self._run_batched(request_id, features, output, metadata)
        return self._run_prefix(request_id, features, output, metadata)

    def _run_seq_chunks(self, request_id, features, output, metadata):
        x_all = self.to_gpu(features)
        bulk = self.strategy.endswith('_bulk')
        if self.streaming:
            current = torch.cuda.current_stream()
            pending = None
            for index, (start, end) in enumerate(self.spans):
                out = self.forward_full(x_all[..., start:end].contiguous())
                ready = torch.cuda.Event()
                ready.record(current)
                slot = index % 2
                with torch.cuda.stream(self.copy_stream):
                    self.copy_stream.wait_event(ready)
                    self.stream_bufs[slot][..., :end - start].copy_(
                        out[..., :end - start], non_blocking=True)
                    copied = torch.cuda.Event()
                    copied.record(self.copy_stream)
                if pending is not None:
                    prev_slot, prev_event, prev_index, prev_valid = pending
                    prev_event.synchronize()
                    self.publish_block(
                        request_id, prev_index,
                        self.stream_bufs[prev_slot][0, :, :prev_valid].numpy(),
                        output, metadata)
                pending = (slot, copied, index, end - start)
            prev_slot, prev_event, prev_index, prev_valid = pending
            prev_event.synchronize()
            self.publish_block(request_id, prev_index,
                               self.stream_bufs[prev_slot][0, :, :prev_valid].numpy(),
                               output, metadata)
            return
        for index, (start, end) in enumerate(self.spans):
            out = self.forward_full(x_all[..., start:end].contiguous())
            block = self.to_host(out)
            if bulk:
                self.stage_block(index, block)
            else:
                self.publish_block(request_id, index, block, output, metadata)
        if bulk:
            self.publish_bulk(request_id, 0, self.n_chunks, output, metadata)

    def _run_batched(self, request_id, features, output, metadata):
        x_all = self.to_gpu(features)
        out = self.segment(x_all, self.T)
        self.host[:, :] = self.to_host(out)
        self._fan_out(request_id, 0, output, metadata)

    def _run_prefix(self, request_id, features, output, metadata):
        x_all = self.to_gpu(features)
        if self.prefix_len >= self.T:
            out = self.segment(x_all, self.T)
            self.host[:, :] = self.to_host(out)
            self._fan_out(request_id, 0, output, metadata)
            return
        head = self.segment(x_all[..., :self.prefix_len].contiguous(), self.prefix_len)
        self.host[:, :self.prefix_len] = self.to_host(head)
        self.publish_block(request_id, 0, self.host[:, :self.spans[0][1]], output,
                           metadata)
        tail = self.segment(x_all[..., self.prefix_len:].contiguous(),
                            self.T - self.prefix_len)
        self.host[:, self.prefix_len:] = self.to_host(tail)
        self._fan_out(request_id, 1, output, metadata)

    # ----------------------------------------------------------------- warmup
    @torch.inference_mode()
    def warmup(self):
        if self.strategy in ('seq_chunks', 'seq_chunks_bulk', 'seq_chunks_stream'):
            lengths = sorted({end - start for start, end in self.spans})
        elif self.prefix_len < self.T:
            lengths = [self.prefix_len, self.T - self.prefix_len]
        else:
            lengths = [self.T]
        for _ in range(2):
            for length in lengths:
                self.forward_full(torch.zeros(1, self.C, length, device=self.device))
                torch.cuda.synchronize()
                self.reset()
        self.reset()
        if self.use_graph:
            for length in lengths:
                self._graph(length)
            self.reset()
