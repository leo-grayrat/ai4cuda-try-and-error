"""Paired reference/candidate offered-load benchmark.

For every target (the user's reference backend and each candidate strategy) the
harness launches the backend as a subprocess, drives it through the adapter with
varied inputs, and records:

  * t_first_out - t_in per request (median / p95),
  * inter-chunk gaps (median / p95) and the fraction above the 20 ms chunk
    budget,
  * achieved chunk rate and request rate over a burst (finite offered-load
    sweep at depths 4 / 8 / full burst).

Results land in backend/benchmarks/results/<target>_<config>.json.
"""
import json
import statistics
import sys
import time
import traceback
import uuid
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / '..' / 'tests'))
import harness  # noqa: E402

BUDGET_NS = harness.CHUNK_BUDGET_NS
DEPTHS = (4, 8)


def stats(values):
    if not values:
        return {'median': None, 'p95': None, 'count': 0}
    values = sorted(values)
    index = min(len(values) - 1, int(round(0.95 * (len(values) - 1))))
    return {'median': statistics.median(values), 'p95': values[index],
            'count': len(values)}


def burst(config, features_pool, depth):
    plan = [{'features': features_pool[i % len(features_pool)], 'reset': False,
             'session': 0, 'label': f'req{i}'} for i in range(depth)]
    return plan


def summarise(records, config):
    first, gaps, per_request = [], [], []
    total_chunks = 0
    for record in records:
        chunks = record['chunks']
        total_chunks += len(chunks)
        first.append((chunks[0][0] - record['published_ns']) / 1e6)
        per_request.append((chunks[-1][0] - record['published_ns']) / 1e6)
        for a, b in zip(chunks, chunks[1:]):
            gaps.append((b[0] - a[0]) / 1e6)
    wall = (records[-1]['chunks'][-1][0] - records[0]['published_ns']) / 1e9
    return {
        't_first_out_ms': stats(first),
        'inter_chunk_gap_ms': stats(gaps),
        'over_budget_count': sum(1 for g in gaps if g * 1e6 > BUDGET_NS),
        'over_budget_fraction': (sum(1 for g in gaps if g * 1e6 > BUDGET_NS) / len(gaps)
                                 if gaps else 0.0),
        'request_latency_ms': stats(per_request),
        'chunk_rate_per_s': total_chunks / wall if wall > 0 else None,
        'request_rate_per_s': len(records) / wall if wall > 0 else None,
        'wall_s': wall,
        'total_chunks': total_chunks,
    }


def measure(kind, config, strategy=None, depth=16, warmup=2, seed=11):
    rng = np.random.default_rng(seed)
    pool = [rng.standard_normal((config['channels'], config['length'])).astype(np.float32) * 0.7
            for _ in range(4)]
    tag = kind if strategy is None else strategy
    result = {'target': tag, 'kind': kind, 'strategy': strategy,
              'config': {k: config[k] for k in ('channels', 'hidden', 'length', 'chunk')},
              'depth': depth, 'stamp': time.strftime('%Y-%m-%dT%H:%M:%S')}
    try:
        with harness.Backend(kind, config, strategy=strategy) as backend:
            backend.run_plan(burst(config, pool, warmup))
            records = backend.run_plan(burst(config, pool, depth))
            stderr = backend.stderr_text()
        result['stderr_tail'] = stderr[-600:]
        result['summary'] = summarise(records, config)
        result['sweep'] = {}
        for d in DEPTHS:
            if d <= len(records):
                result['sweep'][f'depth_{d}'] = summarise(records[:d], config)
        result['shm_leaked'] = harness.shm_still_present(config)
    except Exception as exc:
        traceback.print_exc()
        result['error'] = repr(exc)
    return result


def main(targets, channels=16, hidden=32, length=1043, chunk=127, depth=16):
    out = Path(__file__).resolve().parent / 'results'
    out.mkdir(parents=True, exist_ok=True)
    rows = {}
    for target in targets:
        config = harness.make_config(channels=channels, hidden=hidden, length=length,
                                     chunk=chunk,
                                     prefix='bench_%s_%s' % (target, uuid.uuid4().hex[:8]))
        kind = 'reference' if target == 'reference' else 'worker'
        result = measure(kind, config, None if kind == 'reference' else target, depth=depth)
        tag = f'{target}_{channels}x{hidden}_{length}_{chunk}'
        (out / f'{tag}.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        rows[target] = result
        summary = result.get('summary', {})
        print(f"[bench] {target:24s} t_first={summary.get('t_first_out_ms')} "
              f"gap={summary.get('inter_chunk_gap_ms')} "
              f"over_budget={summary.get('over_budget_fraction')} "
              f"chunk/s={summary.get('chunk_rate_per_s')}", flush=True)
    base = rows.get('reference', {}).get('summary')
    if base:
        print('\n[bench] deltas vs reference (positive = candidate better)', flush=True)
        for target, result in rows.items():
            if target == 'reference' or 'summary' not in result:
                continue
            cur = result['summary']
            first_gain = (base['t_first_out_ms']['median'] or 0) / (cur['t_first_out_ms']['median'] or 1)
            rate_gain = (cur['chunk_rate_per_s'] or 0) / (base['chunk_rate_per_s'] or 1)
            print(f"[bench] {target:24s} t_first_speedup={first_gain:.2f}x "
                  f"chunk_rate_gain={rate_gain:.2f}x", flush=True)
    (out / 'bench_summary.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    return rows


if __name__ == '__main__':
    args = sys.argv[1:]
    if args and args[0] == '--large':
        main(['reference', 'prefix_bulk', 'batched_bulk', 'seq_chunks'],
             channels=128, hidden=256, length=16384, chunk=512, depth=8)
    else:
        main(['reference'] + (args or [
            'seq_chunks', 'seq_chunks_bulk', 'seq_chunks_stream', 'batched',
            'batched_bulk', 'batched_bulk_graph', 'prefix', 'prefix_bulk',
            'prefix_bulk_pinned', 'prefix_bulk_autotune', 'prefix_bulk_graph',
            'prefix_bulk_pinned_graph']))
