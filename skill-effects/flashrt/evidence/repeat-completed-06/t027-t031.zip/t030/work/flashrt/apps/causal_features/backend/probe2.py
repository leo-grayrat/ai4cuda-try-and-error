import inspect
import flashrt.ir as ir
from flashrt.ir import graph as g, analysis as an, executor as ex, ops_base as ob

for name in ('IRGraph', 'IROperator', 'IREdge', 'StateObject', 'TensorPort', 'StreamingInfo'):
    obj = getattr(g, name)
    try:
        print(name, inspect.signature(obj.__init__))
    except Exception as e:
        print(name, 'ERR', e)
    print('   methods:', [m for m in dir(obj) if not m.startswith('_')])
print()
for mod, names in ((g, ['StateObject']), (an, None), (ex, None)):
    for n, o in vars(mod).items():
        if n.startswith('_'):
            continue
        if inspect.isfunction(o):
            print(mod.__name__, n, inspect.signature(o))
        elif inspect.isclass(o) and o.__module__ == mod.__name__:
            print(mod.__name__, 'class', n)
print('ir exports:', [n for n in dir(ir) if not n.startswith('_')])
print('op_type', list(ir.OpType), 'stream', list(ir.StreamMode))
