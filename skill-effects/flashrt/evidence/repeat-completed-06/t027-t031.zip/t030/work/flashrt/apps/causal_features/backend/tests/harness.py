"""Shared harness: launch a causal_features backend and drive it via the adapter.

Both the reference backend and the candidate worker are launched as
subprocesses with disjoint shared-memory prefixes, driven through
`causal_features.adapter.FeatureAdapter`, and always terminated in a
finally block.
"""
import json
import os
import subprocess
import sys
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]
APP = Path(__file__).resolve().parents[2]
WORKER = Path(__file__).resolve().parents[1] / 'worker.py'
RESULTS = Path(__file__).resolve().parents[1] / 'benchmarks' / 'results'
LOGS = Path(__file__).resolve().parents[1] / 'benchmarks' / 'logs'
CHUNK_BUDGET_NS = 20_000_000


def ensure_paths():
    for candidate in (str(REPO), str(REPO / 'flashrt' / 'apps')):
        if candidate not in sys.path:
            sys.path.insert(0, candidate)


def make_config(channels=16, hidden=32, length=1043, chunk=127, device='cuda',
                prefix=None, seed=703):
    return {
        'channels': int(channels),
        'hidden': int(hidden),
        'length': int(length),
        'chunk': int(chunk),
        'device': device,
        'weight_seed': int(seed),
        'prefix': prefix or ('causal_%s' % uuid.uuid4().hex[:10]),
    }


def write_config(config, directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"config_{config['prefix']}.json"
    path.write_text(json.dumps(config), encoding='utf-8')
    return path


def scripted_inputs(config, count=6, seed=7):
    """A -> A (continuation) -> reset A (reproduces) -> B -> reset C -> C."""
    rng = np.random.default_rng(seed)
    channels, length = config['channels'], config['length']
    pool = [rng.standard_normal((channels, length)).astype(np.float32) * 0.7 for _ in range(4)]
    plan = [
        {'features': pool[0], 'reset': False, 'session': 0, 'label': 'A(cold)'},
        {'features': pool[0], 'reset': False, 'session': 0, 'label': 'A(repeat,continuation)'},
        {'features': pool[0], 'reset': True, 'session': 1, 'label': 'A(after reset)'},
        {'features': pool[1], 'reset': False, 'session': 1, 'label': 'B(continuation)'},
        {'features': pool[2], 'reset': True, 'session': 2, 'label': 'C(after reset)'},
        {'features': pool[3], 'reset': False, 'session': 2, 'label': 'D(continuation)'},
    ]
    return plan[:count]


def oracle_chunks(repository, config, plan):
    """CPU full-sequence oracle applied to each session's concatenated input."""
    ensure_paths()
    from causal_features.model import full_sequence_oracle
    chunk, length = config['chunk'], config['length']
    sessions = {}
    expected = []
    for item in plan:
        sid = item['session']
        sessions[sid] = [] if item['reset'] or sid not in sessions else sessions[sid]
        sessions[sid].append(item['features'])
        joined = np.concatenate(sessions[sid], axis=-1)
        full = full_sequence_oracle(repository, config, joined)
        offset = joined.shape[-1] - length
        window = full[:, offset:]
        pieces = []
        for start in range(0, length, chunk):
            pieces.append(window[:, start:min(length, start + chunk)])
        expected.append(pieces)
    return expected


class Backend:
    def __init__(self, kind, config, strategy=None, log_dir=LOGS, env=None):
        self.kind = kind
        self.config = config
        self.strategy = strategy
        self.dir = Path(log_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.cfg_path = write_config(config, self.dir)
        self.tag = f"{kind}_{config['prefix']}"
        self.stdout = self.dir / f'{self.tag}.stdout.log'
        self.stderr = self.dir / f'{self.tag}.stderr.log'
        self.proc = None
        self.adapter = None
        self.env = env

    def argv(self):
        if self.kind == 'reference':
            return [sys.executable, '-m', 'causal_features.reference',
                    '--repository', str(REPO), '--config', str(self.cfg_path)]
        argv = [sys.executable, str(WORKER), '--repository', str(REPO),
                '--config', str(self.cfg_path)]
        if self.strategy:
            argv += ['--strategy', self.strategy]
        return argv

    def __enter__(self):
        ensure_paths()
        env = os.environ.copy()
        env['PYTHONPATH'] = os.pathsep.join(
            [str(REPO / 'flashrt' / 'apps'), str(REPO)] +
            ([env['PYTHONPATH']] if env.get('PYTHONPATH') else []))
        if self.env:
            env.update(self.env)
        self._out = open(self.stdout, 'w', encoding='utf-8')
        self._err = open(self.stderr, 'w', encoding='utf-8')
        flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
        self.proc = subprocess.Popen(self.argv(), cwd=str(REPO), env=env,
                                     stdout=self._out, stderr=self._err,
                                     creationflags=flags)
        deadline = time.monotonic() + 180
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                raise RuntimeError(f'{self.kind} exited early: '
                                   f'{self.stderr.read_text(encoding="utf-8")[-3000:]}')
            text = self.stdout.read_text(encoding='utf-8', errors='ignore')
            if '"ready": true' in text:
                break
            time.sleep(0.05)
        else:
            raise RuntimeError(f'{self.kind} never became ready')
        from causal_features.adapter import FeatureAdapter
        self.adapter = FeatureAdapter(self.config)
        self.adapter.start()
        return self

    def run_plan(self, plan, timeout=60.0):
        records = []
        for item in plan:
            if item['reset']:
                self.adapter.reset()
            request_id, published_ns = self.adapter.submit(item['features'])
            chunks = []
            while self.adapter.pending is not None:
                data, observed_ns = self.adapter.receive(timeout_s=timeout)
                chunks.append((observed_ns, np.array(data, copy=True)))
            records.append({'label': item['label'], 'request_id': request_id,
                            'published_ns': published_ns, 'chunks': chunks})
        return records

    def __exit__(self, *exc):
        try:
            if self.adapter is not None:
                try:
                    self.adapter.terminate()
                except Exception:
                    pass
        finally:
            if self.proc is not None:
                if self.proc.poll() is None:
                    self.proc.terminate()
                try:
                    self.proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
                    self.proc.wait(timeout=30)
            if self.adapter is not None:
                try:
                    self.adapter.close()
                except Exception:
                    pass
            self._out.close()
            self._err.close()
        return False

    def stderr_text(self):
        try:
            return self.stderr.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            return ''


def compare(records, expected, atol=3e-5, rtol=3e-4):
    """Chunk-wise numerical comparison; returns (ok, details)."""
    details = []
    ok = True
    for record, want in zip(records, expected):
        got = [chunk for _, chunk in record['chunks']]
        if len(got) != len(want):
            ok = False
            details.append({'label': record['label'], 'error': f'chunk count {len(got)} != {len(want)}'})
            continue
        worst_abs = 0.0
        worst_lim = 0.0
        bad = 0
        for a, b in zip(got, want):
            a = np.asarray(a, dtype=np.float64)
            b = np.asarray(b, dtype=np.float64)
            diff = np.abs(a - b)
            limit = atol + rtol * np.abs(b)
            worst_abs = max(worst_abs, float(diff.max()))
            worst_lim = max(worst_lim, float((diff - limit).max()))
            bad += int((diff > limit).sum())
        entry = {'label': record['label'], 'chunks': len(got),
                 'max_abs_diff': worst_abs, 'over_tolerance_values': bad}
        if bad:
            ok = False
        details.append(entry)
    return ok, details


def shm_still_present(config):
    from multiprocessing import shared_memory
    names = [config['prefix'] + '__ctrl']
    for suffix in ('_input', '_output', '_metadata'):
        names += [config['prefix'] + suffix + '__meta', config['prefix'] + suffix + '__tensor']
    alive = []
    for name in names:
        try:
            handle = shared_memory.SharedMemory(name=name, create=False)
        except FileNotFoundError:
            continue
        else:
            handle.close()
            alive.append(name)
    return alive


@contextmanager
def timed(label):
    start = time.perf_counter()
    yield
    print(f'[harness] {label}: {time.perf_counter() - start:.2f}s', flush=True)
