# Experiment log - causal_features

## IR conversion
- Worker graph `causal_features_worker`: 7 operators, 6 edges
  (`session_control` BLACK_BOX preamble; `receive_chunk` BLACK_BOX STREAMING;
  `layer0/1/2_causal_conv_silu` EXPOSED, each owning chunk-persistent
  `hist_N`; `publish_chunk` BLACK_BOX STREAMING with a fixed-rate streaming
  edge from layer2). State: `session` (session_init), `hist_0..2`
  (chunk_persistent). `graph.validate()` -> `[]`.
- Model graph `causal_features_layers`: 9 operators + external input, per layer
  `replicate_pad -> conv1d -> silu`; only `conv1d` touches `hist_N`, so pad and
  silu are ephemeral and the per-layer history objects are disjoint.
  `graph.validate()` -> `[]`.
- Validation (`tests/test_ir.py`, executor output vs `causal_features.model.
  ReferencePipeline.step` over the 6-request script, atol=3e-5 rtol=3e-4):
  worker graph PASS, `max_abs_diff = 0.0`, output sha256 `418d1e646f95a41e...`
  (`tests/ir_validation.json`). The model graph ran into a declared-input bug
  (`layerN_conv1d` declared a `history` port with no feeding edge); fixed in
  `ir/ops.py` (history is read from `StateStore`, not from an edge) after the
  observation budget for another full run was spent - the model graph is
  therefore analysed but its re-run verdict was not recorded.
- Analysis (`notes/ir_analysis.txt`, `notes/ir_analysis_model.txt`): three
  chunk-persistent history objects -> `find_pipeline_stages` partitions the
  chain into per-layer stages; there is no cross-chunk independent pair on a
  single GPU (layer i+1's chunk-N input is layer i's chunk-N output), so the
  only legal single-device levers are (a) shorten the critical path by running
  whole segments instead of per-chunk kernels and (b) ship chunk 0 from a
  prefix pass. `find_streaming_overlaps` reports the fixed-rate
  one-chunk-out-per-chunk-in edge from layer2 to publish_chunk, which is what
  makes publishing decoupled from computing legal.

## Variant queue (all `measured`)
Measured with `smoke_engine.py` (in-process, 4-request script incl. reset;
max_abs vs reference pipeline = 0.0 for every variant; per-request wall time,
dev config C=16 H=32 T=1043 chunk=127):

| variant | idea | per-request ms | status |
| --- | --- | --- | --- |
| `seq_chunks` | reference schedule, preallocated pad buffer | 4.379 | measured |
| `seq_chunks_bulk` | + batched publish | 8.823 | measured |
| `seq_chunks_stream` | + D2H on a side stream | 4.505 | measured |
| `batched` | one segment pass per request | 1.195 | measured |
| `batched_bulk` | + batched publish | 0.567 | measured |
| `batched_bulk_graph` | + CUDA-graph replay | 0.697 | measured |
| `prefix` | chunk 0 from a prefix pass | 1.085 | measured |
| `prefix_bulk` | prefix + batched publish of the rest (**default**) | 1.029 | measured |
| `prefix_bulk_pinned` | + pinned H2D/D2H staging | 1.088 | measured |
| `prefix_bulk_autotune` | + cuDNN algorithm autotune | 1.024 | measured |
| `prefix_bulk_graph` | prefix + CUDA-graph replay | 0.899 | measured |
| `prefix_bulk_pinned_graph` | pinned + graph replay | 0.597 | measured |

Trade-off recorded: the graph/pinned variants are the fastest in-process, but
the default was kept at `prefix_bulk` because it is the simplest path (no CUDA
graph capture, no pinned staging) and it is the one that received the
controller-level verification and benchmark inside this observation budget.
`prefix_bulk_pinned_graph` is selectable with `--strategy`.

## Controller evidence for the recommended entry (`worker.py`, `prefix_bulk`)
- `verify-011`: `candidate_run_passed`, 6/6 requests `numerical_match` vs the
  CPU full-sequence oracle, max abs difference 5.2e-8 .. 8.2e-8 (tolerance
  atol=3e-5/rtol=3e-4), `cleanup_verified: true`.
- `benchmark-012` (paired, finite window, fixed reference-then-candidate
  order): reference highest passing offered rate 100 req/s (at 200 req/s the
  external queue peaked at 39 -> rate gate failed); candidate 200 req/s with
  peak external queue 0 at every load. First-output medians: reference
  1.51-1.57 ms, candidate 1.58-1.76 ms (p95 2.21-2.29 with the reference at
  1.82-2.16) - first-output latency is neutral/slightly higher. Inter-chunk
  gap medians: reference 0.53-0.56 ms, candidate 0.009-0.011 ms; candidate
  over-budget fraction (>20 ms) 0.0067 at 50 req/s and 0.0 at 100/200 req/s.

## Remaining unfinished requirements
- The model-level IR graph's post-fix execution was not re-run (worker graph
  passed; the fix is a declared-input correction in `ir/ops.py`).
- `tests/test_worker.py` and `benchmarks/bench.py` (adapter-level, all
  strategies) were written but not executed; variant evidence is in-process
  only, and only the default `prefix_bulk` has controller-level correctness and
  paired benchmark numbers.
- No variant reached a non-terminal status: every queued variant was measured,
  none was discarded or blocked.
