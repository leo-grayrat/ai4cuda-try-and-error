"""In-process smoke test for every engine strategy (no IPC, no subprocess).

Compares each strategy against the user's sequential ReferencePipeline over a
4-request script (fresh, continuation, reset-reproduction, continuation) and
reports max abs diff plus rough per-request timings.  Fast diagnostic; the
authoritative verdict comes from tests/test_worker.py.
"""
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / 'tests'))
import harness  # noqa: E402

harness.ensure_paths()
from causal_features.model import ReferencePipeline, build_layers  # noqa: E402
from causal_features.backend.engine import CausalEngine  # noqa: E402

STRATEGIES = ['seq_chunks', 'seq_chunks_bulk', 'seq_chunks_stream', 'batched',
              'batched_bulk', 'batched_bulk_graph', 'prefix', 'prefix_bulk',
              'prefix_bulk_pinned', 'prefix_bulk_autotune', 'prefix_bulk_graph',
              'prefix_bulk_pinned_graph']


class FakeBuffer:
    def __init__(self):
        self.frames = []

    def write(self, x):
        self.frames.append(np.array(x, dtype=np.float64, copy=True))
        return len(self.frames)


def decode(out_frames, meta_frames):
    chunks = []
    for payload, meta in zip(out_frames, meta_frames):
        payload = np.asarray(payload)
        for j, row in enumerate(np.atleast_2d(meta)):
            valid = int(row[2])
            block = payload[:, :valid] if payload.ndim == 2 else payload[j][:, :valid]
            chunks.append((int(row[1]), block))
    return chunks


def main(device='cuda', channels=16, hidden=32, length=1043, chunk=127):
    config = harness.make_config(channels=channels, hidden=hidden, length=length,
                                 chunk=chunk, device=device, prefix='smoke')
    rng = np.random.default_rng(5)
    pool = [rng.standard_normal((channels, length)).astype(np.float32) * 0.7 for _ in range(3)]
    plan = [{'features': pool[0], 'reset': False},
            {'features': pool[0], 'reset': False},
            {'features': pool[0], 'reset': True},
            {'features': pool[1], 'reset': False}]
    spans = [(s, min(length, s + chunk)) for s in range(0, length, chunk)]

    reference = ReferencePipeline(str(harness.REPO), config)
    expected = []
    for item in plan:
        if item['reset']:
            reference.reset()
        expected.append([reference.step(item['features'][:, s:e]) for s, e in spans])

    ok_all = True
    for strategy in STRATEGIES:
        torch.backends.cudnn.benchmark = False
        layers = build_layers(str(harness.REPO), config, device)
        try:
            t0 = time.perf_counter()
            engine = CausalEngine(layers, config, strategy)
            init_ms = (time.perf_counter() - t0) * 1e3
        except Exception as exc:
            print(f'{strategy:26s} INIT-ERROR {exc!r}', flush=True)
            ok_all = False
            continue
        worst, bad, times = 0.0, 0, []
        try:
            for item, want in zip(plan, expected):
                if item['reset']:
                    engine.reset()
                out, meta = FakeBuffer(), FakeBuffer()
                t0 = time.perf_counter()
                engine.execute(0, item['features'], out, meta)
                torch.cuda.synchronize()
                times.append((time.perf_counter() - t0) * 1e3)
                got = decode(out.frames, meta.frames)
                if len(got) != len(want):
                    bad += 1
                    print(f'{strategy}: chunk count {len(got)} != {len(want)}')
                    continue
                for index, block in got:
                    ref = want[index]
                    diff = np.abs(np.asarray(block, dtype=np.float64) -
                                  np.asarray(ref, dtype=np.float64))
                    worst = max(worst, float(diff.max()))
                    bad += int((diff > 3e-5 + 3e-4 * np.abs(ref)).sum())
        except Exception as exc:
            print(f'{strategy:26s} RUN-ERROR {exc!r}', flush=True)
            ok_all = False
            continue
        status = 'ok' if bad == 0 else 'MISMATCH'
        print(f'{strategy:26s} {status:9s} max_abs={worst:.3e} bad={bad} '
              f'init={init_ms:7.1f}ms per_req={np.median(times):7.3f}ms', flush=True)
        ok_all = ok_all and bad == 0
    print('SMOKE:', 'PASS' if ok_all else 'FAIL')
    return 0 if ok_all else 1


if __name__ == '__main__':
    args = sys.argv[1:]
    if args and args[0] == '--large':
        raise SystemExit(main(channels=128, hidden=256, length=16384, chunk=512))
    raise SystemExit(main())
