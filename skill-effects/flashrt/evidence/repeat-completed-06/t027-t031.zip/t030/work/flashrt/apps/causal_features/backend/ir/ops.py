"""Executable IR operators for the causal-features reference computation.

worker graph   session_control -> receive_chunk -> layer0 -> layer1 -> layer2
               -> publish_chunk.  `layerN_causal_conv_silu` is EXPOSED and owns
               the chunk-persistent state `hist_N` (that layer's input history,
               exactly what `ReferencePipeline.step` keeps).

model graph    per layer: replicate_pad -> causal_conv1d -> silu.  Only
               `causal_conv1d` touches `hist_N`; pad/silu are ephemeral, which
               is what makes per-layer state independence visible to the
               analysis tools.

Every operator carries its own `execute(inputs, ctx, state)`; the context
object supplies the real `CausalConv1d` modules so `tests/test_ir.py` can
compare executed values against the reference pipeline.
"""
import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort


def _history_key(index):
    return f'hist_{index}'


class SessionControl(IROperator):
    """Control plane: start(1) / terminate(2) / reset(3) on the level channel."""

    def __init__(self, n_layers):
        super().__init__(
            name='session_control', op_type=OpType.BLACK_BOX,
            inputs=[TensorPort('opcode')], outputs=[TensorPort('active')],
            state_reads=['session'],
            state_writes=['session'] + [_history_key(i) for i in range(n_layers)],
            stream_mode=StreamMode.BATCH)
        self.n_layers = n_layers

    def execute(self, inputs, ctx, state):
        opcode = int(inputs['opcode'])
        session = state.get('session')
        if opcode == 3:                      # reset: drop every layer history
            for i in range(self.n_layers):
                state.set(_history_key(i), None)
            session['active'] = False
        elif opcode == 1:                    # start / re-arm after reset
            session['active'] = True
        elif opcode == 2:                    # terminate
            session['active'] = False
        else:
            raise ValueError(f'Unknown control opcode: {opcode}')
        return {'active': session['active']}


class ReceiveChunk(IROperator):
    """Pulls one chunk of the in-flight request from the input ring buffer."""

    def __init__(self):
        super().__init__(
            name='receive_chunk', op_type=OpType.BLACK_BOX, inputs=[],
            outputs=[TensorPort('x', shape_hint=('C', 'chunk'))],
            state_reads=['session'], stream_mode=StreamMode.STREAMING)

    def execute(self, inputs, ctx, state):
        if not state.get('session')['active']:
            return {'x': None}
        return {'x': ctx.chunks[ctx.chunk_index]}


class LayerPass(IROperator):
    """One chunk of one `CausalConv1d` layer plus its SiLU."""

    def __init__(self, index, kernel_size):
        key = _history_key(index)
        super().__init__(
            name=f'layer{index}_causal_conv_silu', op_type=OpType.EXPOSED,
            inputs=[TensorPort('x', shape_hint=('C', 'chunk'))],
            outputs=[TensorPort('y', shape_hint=('H', 'chunk'))],
            state_reads=[key], state_writes=[key], stream_mode=StreamMode.BATCH,
            config={'kernel_size': kernel_size})
        self.index = index
        self.kernel_size = kernel_size

    def execute(self, inputs, ctx, state):
        key = _history_key(self.index)
        layer = ctx.layers[self.index]
        x = inputs['x']
        history = state.get(key)
        joined = x if history is None else torch.cat((history, x), dim=-1)
        out = layer(joined)
        if history is not None:
            out = out[..., history.shape[-1]:]
        state.set(key, joined[..., -layer._time_causal_padding[0]:].detach().clone())
        return {'y': F.silu(out)}


class PublishChunk(IROperator):
    """Publishes one output chunk (payload first, then metadata)."""

    def __init__(self):
        super().__init__(
            name='publish_chunk', op_type=OpType.BLACK_BOX,
            inputs=[TensorPort('y', shape_hint=('C', 'chunk'))], outputs=[],
            state_reads=['session'], stream_mode=StreamMode.STREAMING)

    def execute(self, inputs, ctx, state):
        if not state.get('session')['active']:
            return {}
        ctx.published.append(inputs['y'])
        return {}


class ReplicatePad(IROperator):
    """`F.pad(..., mode='replicate')` applied by `CausalConv1d.forward`."""

    def __init__(self, index, kernel_size):
        super().__init__(
            name=f'layer{index}_replicate_pad', op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')], outputs=[TensorPort('x_padded')],
            stream_mode=StreamMode.BATCH, config={'kernel_size': kernel_size})
        self.index = index
        self.kernel_size = kernel_size

    def execute(self, inputs, ctx, state):
        return {'x_padded': F.pad(inputs['x'], (self.kernel_size - 1, 0),
                                  mode='replicate')}


class CausalConv1dOp(IROperator):
    """The convolution itself; the only op touching the layer history."""

    def __init__(self, index, kernel_size, in_channels, out_channels):
        key = _history_key(index)
        super().__init__(
            name=f'layer{index}_conv1d', op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')], outputs=[TensorPort('y')],
            state_reads=[key], state_writes=[key], stream_mode=StreamMode.BATCH,
            config={'kernel_size': kernel_size, 'in_channels': in_channels,
                    'out_channels': out_channels})
        self.index = index
        self.kernel_size = kernel_size

    def execute(self, inputs, ctx, state):
        key = _history_key(self.index)
        layer = ctx.layers[self.index]
        x = inputs['x']
        history = state.get(key)
        joined = x if history is None else torch.cat((history, x), dim=-1)
        out = layer.conv(joined)
        if history is not None:
            out = out[..., history.shape[-1]:]
        state.set(key, joined[..., -(self.kernel_size - 1):].detach().clone())
        return {'y': out}


class SiLU(IROperator):
    def __init__(self, index):
        super().__init__(
            name=f'layer{index}_silu', op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')], outputs=[TensorPort('y')],
            stream_mode=StreamMode.BATCH)
        self.index = index

    def execute(self, inputs, ctx, state):
        return {'y': F.silu(inputs['x'])}
