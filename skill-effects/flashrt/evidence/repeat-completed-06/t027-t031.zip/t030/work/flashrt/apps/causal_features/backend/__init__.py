"""Writable workspace for the causal_features app (agent backend)."""
