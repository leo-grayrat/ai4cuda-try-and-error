"""Optimized causal_features backend (single GPU).

Divergence from flashrt/apps/causal_features/reference.py:
  The reference iterates the request chunk-by-chunk. For every chunk it does a
  host->device copy of the chunk, a per-layer ``torch.cat`` of the 4-wide
  history, a ``.clone()`` of the new history and a device->host copy of the
  chunk. That is ~ceil(T/chunk) full Python/CUDA round trips per request and it
  recomputes the 3 causal convolutions once per chunk.

  This worker computes the WHOLE (C, T) request in one batched GPU pass. The
  layers are strictly causal (CausalConv1d pads only on the left), so evaluating
  the full sequence and cropping is bit-for-bit the same math as evaluating it
  chunk-by-chunk with cross-chunk history. Per-layer convolution history is kept
  resident on the GPU across requests within a session (reset clears it), which
  reproduces "consecutive requests == concatenated sequence" from the contract.
  Only the finished (C, T) output makes one device->host copy, then all chunks
  are published in order (output payload before metadata, per the adapter).

The adapter protocol (control opcodes 1 start / 3 reset / 2 terminate, one
request in flight, output ring capacity ceil(T/chunk)+4) is honored exactly.
"""
import argparse
import json
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))

    import numpy as np
    import torch
    import torch.nn.functional as F
    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = config['device']
    channels = int(config['channels'])
    length = int(config['length'])
    chunk = int(config['chunk'])

    layers = build_layers(args.repository, config, device)
    pads = [layer._time_causal_padding[0] for layer in layers]
    histories = [None] * len(layers)

    @torch.inference_mode()
    def run_sequence(features_np):
        """(channels, length) float32 numpy -> (channels, length) device tensor."""
        x = torch.from_numpy(np.ascontiguousarray(features_np)).unsqueeze(0).to(device)
        for i, layer in enumerate(layers):
            hist = histories[i]
            joined = x if hist is None else torch.cat([hist, x], dim=-1)
            out = layer(joined)
            # CausalConv1d.forward is length-preserving, so `out` spans
            # (hist_len + T) columns; the last T are this request's outputs.
            out = out[:, :, -x.shape[-1]:]
            histories[i] = joined[:, :, -pads[i]:].clone()
            x = F.silu(out)
        return x

    def reset():
        for i in range(len(histories)):
            histories[i] = None

    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({'ready': True, 'device': device}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor

            output = run_sequence(features[0])          # (1, channels, length) on GPU
            out_np = output.squeeze(0).to('cpu').numpy()  # one device->host copy

            for index, position in enumerate(range(0, length, chunk)):
                valid = min(chunk, length - position)
                padded = np.zeros((channels, chunk), dtype=np.float32)
                padded[:, :valid] = out_np[:, position:position + valid]
                buffers['output'].write(padded)
                buffers['metadata'].write(np.array([request_id, index, valid], dtype=np.int64))
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
