"""Standalone backend worker for the causal_features application.

    python worker.py --repository <repo-root> --config <config.json>

Same launch surface, shared-memory contract and control opcodes as
flashrt/apps/causal_features/reference.py; the optional extra config key
"strategy" selects a measured variant from cfcore.STRATEGIES (default:
cfcore.DEFAULT_STRATEGY).
"""
import argparse
import json
from pathlib import Path
import sys
import time


def _import_task_modules(repository):
    sys.path.insert(0, str(repository.resolve()))
    try:
        from causal_features.adapter import open_buffers, close_buffers
        from causal_features.model import build_layers
    except ImportError:                                    # pragma: no cover
        from flashrt.apps.causal_features.adapter import open_buffers, close_buffers
        from flashrt.apps.causal_features.model import build_layers
    return open_buffers, close_buffers, build_layers


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--strategy', type=str, default=None)
    args = parser.parse_args()

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import torch

    import cfcore

    open_buffers, close_buffers, build_layers = _import_task_modules(args.repository)
    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = bool(config.get('cudnn_benchmark', False))
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = config.get('device', 'cuda')
    if device != 'cpu':
        torch.cuda.set_device(torch.device(device).index or 0)
    strategy = args.strategy or config.get('strategy') or cfcore.DEFAULT_STRATEGY
    # Buffers first: the driving adapter attaches while graphs are compiled.
    buffers = open_buffers(config, create=True)
    publisher = cfcore.Publisher(buffers)
    control = buffers['control']
    inputs = buffers['input']
    try:
        layers = build_layers(args.repository, config, device)
        runtime = cfcore.Runtime(layers, config, strategy)
        if device != 'cpu':
            torch.cuda.synchronize(torch.device(device).index or 0)
        print(json.dumps({'ready': True, 'device': device, 'strategy': runtime.strategy,
                          'channels': config['channels'], 'hidden': config.get('hidden'),
                          'length': config['length'], 'chunk': config['chunk']}), flush=True)
        consumed, last_command, active, idle = 0, 0, False, 0
        with torch.no_grad():
            while True:
                opcode = control.recv()
                if opcode != last_command:
                    last_command = opcode
                    if opcode == 2:
                        control.commit()
                        break
                    if opcode == 3:
                        runtime.reset()
                        active = False
                        idle = 0
                        control.commit()
                    elif opcode == 1:
                        active = True
                        control.commit()
                    elif opcode != 0:
                        raise ValueError(f'Unknown control opcode: {opcode}')
                if not active:
                    time.sleep(0.0002)
                    continue
                if int(inputs.num) <= consumed:
                    idle += 1
                    if idle > 20000:          # spin briefly, then back off
                        time.sleep(0.0002)
                    continue
                idle = 0
                request_id = consumed
                consumed = int(inputs.num)
                # The frame is consumed in place (input ring capacity is 1):
                # the producer cannot overwrite it before this request's last
                # chunk is published, and it is copied to the GPU first.
                runtime.request(inputs.tensor[0], request_id, publisher)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
