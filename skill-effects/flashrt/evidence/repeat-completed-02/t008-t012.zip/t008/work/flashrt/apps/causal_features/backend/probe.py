"""Diagnostic probe: IR API signatures, GPU info, reference-pipeline timing."""
import inspect
import json
import time

import torch

import flashrt.ir as ir
from flashrt.ir import graph as irg


def sig(obj, name=None):
    try:
        return f"{name or obj.__name__}{inspect.signature(obj)}"
    except Exception as exc:  # pragma: no cover
        return f"{name or obj}: <no signature: {exc}>"


print("--- torch ---")
print("torch", torch.__version__, "cuda", torch.cuda.is_available())
if torch.cuda.is_available():
    print("device", torch.cuda.get_device_name(0), torch.cuda.get_device_properties(0).total_memory)

print("--- ir exports ---")
print([n for n in dir(ir) if not n.startswith('_')])

print("--- signatures ---")
print(sig(irg.IRGraph.__init__, 'IRGraph.__init__'))
for m in ('add_operator', 'add_edge', 'add_state', 'add_state_object', 'to_summary'):
    if hasattr(irg.IRGraph, m):
        print(sig(getattr(irg.IRGraph, m), 'IRGraph.' + m))
print(sig(irg.IROperator.__init__, 'IROperator.__init__'))
print(sig(irg.IREdge.__init__, 'IREdge.__init__'))
print(sig(irg.StateObject.__init__, 'StateObject.__init__'))
print(sig(irg.TensorPort.__init__, 'TensorPort.__init__'))
print(sig(ir.SequentialExecutor.__init__, 'SequentialExecutor.__init__'))
for m in ('init_state', 'run_preamble', 'run_chunk'):
    print(sig(getattr(ir.SequentialExecutor, m), 'SequentialExecutor.' + m))
for fn in ('summarize_graph', 'find_pipeline_stages', 'find_streaming_overlaps',
           'analyze_cross_chunk_dependencies', 'compute_critical_path'):
    if hasattr(ir, fn):
        print(sig(getattr(ir, fn), fn))

print("--- reference pipeline timing ---")
import sys
sys.path.insert(0, '.')
from flashrt.apps.causal_features.model import ReferencePipeline

for cfg in ({'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
             'weight_seed': 703, 'device': 'cuda'},
            {'channels': 128, 'hidden': 256, 'length': 16384, 'chunk': 512,
             'weight_seed': 703, 'device': 'cuda'}):
    pipe = ReferencePipeline('.', cfg)
    x = torch.randn(cfg['channels'], cfg['length'], dtype=torch.float32).numpy()
    pipe.reset()
    # warmup on one full request
    for pos in range(0, cfg['length'], cfg['chunk']):
        pipe.step(x[:, pos:pos + cfg['chunk']])
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(5):
        pipe.reset()
        for pos in range(0, cfg['length'], cfg['chunk']):
            pipe.step(x[:, pos:pos + cfg['chunk']])
        torch.cuda.synchronize()
    dt = (time.perf_counter() - t0) / 5
    nchunks = (cfg['length'] + cfg['chunk'] - 1) // cfg['chunk']
    print(json.dumps({'cfg': {k: cfg[k] for k in ('channels', 'hidden', 'length', 'chunk')},
                      'request_s': round(dt, 6), 'chunks': nchunks,
                      'per_chunk_ms': round(dt / nchunks * 1e3, 3)}))

print("--- plain conv timing on GPU (whole request, fp32) ---")
import torch.nn.functional as F
for cfg in ({'channels': 16, 'hidden': 32, 'length': 1043},
            {'channels': 128, 'hidden': 256, 'length': 16384}):
    C, H, T = cfg['channels'], cfg['hidden'], cfg['length']
    x = torch.randn(1, C, T, device='cuda')
    ws = [torch.randn(H, C, 5, device='cuda'), torch.randn(H, H, 5, device='cuda'),
          torch.randn(C, H, 3, device='cuda')]
    bs = [torch.randn(H, device='cuda'), torch.randn(H, device='cuda'), torch.randn(C, device='cuda')]
    def run():
        v = x
        for w, b in zip(ws, bs):
            v = F.silu(F.conv1d(F.pad(v, (w.shape[-1] - 1, 0), mode='replicate'), w, b))
        return v
    for _ in range(5):
        run()
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(20):
        run()
    torch.cuda.synchronize()
    print(json.dumps({'cfg': cfg, 'full_seq_ms': round((time.perf_counter() - t0) / 20 * 1e3, 4)}))
