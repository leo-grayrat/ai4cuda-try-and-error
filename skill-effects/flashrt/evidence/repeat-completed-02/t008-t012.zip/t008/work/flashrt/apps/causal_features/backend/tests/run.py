"""Argument-free driver for the harness (this environment cannot pass CLI args).

Reads tests/fixtures/tmp/plan.json:
    {"correct": ["dev"], "bench": ["dev"], "strategies": [...], "n_request": 10}
Each strategy is isolated so one failure cannot abort the sweep.
"""
import json
import os
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOG = HERE / 'fixtures' / 'tmp' / 'run.log'
LOG.parent.mkdir(parents=True, exist_ok=True)

_raw = open(LOG, 'wb', buffering=0)
sys.stdout.flush()
sys.stderr.flush()
os.dup2(_raw.fileno(), 1)
os.dup2(_raw.fileno(), 2)
sys.stdout = os.fdopen(1, 'w', buffering=1, errors='replace')
sys.stderr = os.fdopen(2, 'w', buffering=1, errors='replace')

status = 0
t_start = time.time()
try:
    sys.path.insert(0, str(HERE))
    import harness
    plan = json.loads((HERE / 'fixtures' / 'tmp' / 'plan.json').read_text())
    strategies = plan.get('strategies', ['hybrid_graph'])
    cases = plan.get('cases', ['dev'])
    n_request = plan.get('n_request', 10)
    results = {'correct': {}, 'bench': {}}
    for stage in ('correct', 'bench'):
        if not plan.get(stage):
            continue
        print(f'=== {stage.upper()} cases={plan[stage]} ===', flush=True)
        for s in strategies:
            t0 = time.time()
            try:
                if stage == 'correct':
                    r = harness.correctness(plan[stage], [s])
                else:
                    r = harness.benchmark(plan[stage], [s], dts=plan.get('dts'),
                                          n_request=n_request)
                results[stage].update(r)
            except BaseException:
                print(f'  !! {s} raised', flush=True)
                traceback.print_exc()
            print(f'  -- {s} took {time.time() - t0:.1f}s', flush=True)
    print('=== TABLE ===', flush=True)
    for key, rec in results['bench'].items():
        rows = rec['sweeps']
        low = min(rows, key=lambda r: abs(r['offered_rate'] - 500.0))
        print(f'{key:28s} sust={rec["sustainable_rate"]:8.1f}/s '
              f'first@500/s med={low["first_med_ms"]:.3f} p95={low["first_p95_ms"]:.3f} '
              f'gap med={low["gap_med_ms"]:.3f} p95={low["gap_p95_ms"]:.3f} '
              f'req med={low["request_med_ms"]:.3f} | '
              f'first@31/s med={rows[0]["first_med_ms"]:.3f} '
              f'req@31/s med={rows[0]["request_med_ms"]:.3f}', flush=True)
    (HERE / 'fixtures' / 'tmp' / 'results.json').write_text(json.dumps(
        {'correct': results['correct'],
         'bench': {k: {kk: vv for kk, vv in v.items() if kk != 'sweeps'}
                   for k, v in results['bench'].items()}}, indent=1))
    print('DONE', flush=True)
except BaseException:
    traceback.print_exc()
    status = 1
print(f'total {time.time() - t_start:.1f}s', flush=True)

sys.stdout.flush()
sys.stderr.flush()
data = LOG.read_bytes().decode('utf-8', 'replace')
LOG.write_text(data, encoding='utf-8')
sys.exit(status)
