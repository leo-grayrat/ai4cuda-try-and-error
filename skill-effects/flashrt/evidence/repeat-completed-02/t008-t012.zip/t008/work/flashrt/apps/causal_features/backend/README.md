# causal_features backend

`worker.py` is a drop-in replacement for `causal_features.reference`:

    python flashrt/apps/causal_features/backend/worker.py \
        --repository <repo-root> --config <config.json>

It creates exactly the shared-memory objects the app's adapter expects
(`<prefix>__ctrl`, `_input`, `_output`, `_metadata`), honours opcodes 1/3/2
(start/reset/terminate) with the same level semantics as the reference, and
publishes output payload before metadata for every chunk.

Recommended variant: `hybrid_graph` (default). Optional config key
`strategy` or `--strategy` selects another measured variant from
`cfcore.STRATEGIES`: `chunk_graph`, `whole_graph`, `hybrid_eager`,
`whole_eager`, `chunk_eager`, `hybrid_graph_gpu`, `hybrid_graph_mm`,
`whole_graph_mm`, `chunk_graph_mm`, `hybrid_graph_split`, `ref_like`.

Files: `cfcore.py` (streaming chain, CUDA-graph segments, publisher,
strategies), `ir/state_graph.py` (IR conversion + validation),
`tests/harness.py` + `tests/run.py` (correctness/benchmark),
`benchmarks/results/` (per-run JSON + backend logs),
`notes/experiment_log.md`, `notes/ir_analysis.txt`.
