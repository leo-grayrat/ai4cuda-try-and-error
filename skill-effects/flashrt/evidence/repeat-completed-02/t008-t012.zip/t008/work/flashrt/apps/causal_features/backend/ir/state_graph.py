"""Phase 1-2: IR state graph for causal_features, validated by execution.

The reference chain is three causal conv layers whose only cross-chunk state is
each layer's own `kernel-1` sample input history.  The graph below makes those
three state objects explicit (`chunk_persistent`), which is exactly what the
streaming/pipelining analysis needs: the layers form a serial per-chunk chain
and each layer's history is private, so `analyze_cross_chunk_dependencies`
must find *no* cross-chunk constraint between different layers.

Validation (this script, when executed): the SequentialExecutor is run over the
same 6-request session (continuation, repeated input without reset, reset, tail
chunk) used by the deployment harness, and its per-chunk outputs are compared
against (a) the CPU full-sequence oracle from causal_features.model and (b) the
research reference backend driven through the shared adapter.

    python ir/state_graph.py --repository <repo> --config <config.json>
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from flashrt.ir import (IRGraph, IROperator, IREdge, StateObject, TensorPort, OpType,
                        StreamMode, SequentialExecutor, summarize_graph,
                        analyze_cross_chunk_dependencies, find_pipeline_stages,
                        compute_critical_path)

BACKEND = Path(__file__).resolve().parents[1]
TOL_ATOL, TOL_RTOL = 3e-5, 3e-4


class CausalLayerOp(IROperator):
    """One causal conv layer + SiLU; its input history is chunk-persistent."""

    def __init__(self, index):
        super().__init__(name=f'causal_layer_{index}', op_type=OpType.EXPOSED,
                         inputs=[TensorPort('value', ('batch', 'channels', 'time'))],
                         outputs=[TensorPort('value_out', ('batch', 'channels', 'time'))],
                         state_reads=[f'hist_{index}'], state_writes=[f'hist_{index}'],
                         stream_mode=StreamMode.STREAMING, config={'index': index})
        self.index = index

    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.index]
        p = layer._time_causal_padding[0]          # kernel-1
        v = inputs.get('value')
        if v is None:
            v = ctx.value
        n = v.shape[-1]
        hist = state.get(f'hist_{self.index}')
        j = torch.empty(1, v.shape[1], p + n, device=v.device, dtype=v.dtype)
        if ctx.fresh:                              # reference: no history yet,
            j[:, :, :p].copy_(v[:, :, :1].expand(-1, -1, p))   # replicate pad
        else:
            j[:, :, :p].copy_(hist)
        j[:, :, p:] = v
        y = F.silu(F.conv1d(j, layer.conv.weight, layer.conv.bias))
        hist.copy_(j[:, :, n:n + p])               # joined[..., -p:]
        return {'value_out': y}


class EmitChunk(IROperator):
    def __init__(self):
        super().__init__(name='emit_chunk', op_type=OpType.EXPOSED,
                         inputs=[TensorPort('value_out', ('batch', 'channels', 'time'))],
                         outputs=[TensorPort('chunk', ('batch', 'channels', 'time'))],
                         stream_mode=StreamMode.STREAMING)

    def execute(self, inputs, ctx, state):
        return {'chunk': inputs['value_out']}


def build_graph(num_layers):
    graph = IRGraph(name='causal_features_layer_state')
    for i in range(num_layers):
        graph.add_state(StateObject(f'hist_{i}',
                                    f'last kernel-1 input samples of layer {i}',
                                    'chunk_persistent'))
    layers = [CausalLayerOp(i) for i in range(num_layers)]
    emit = EmitChunk()
    for op in layers + [emit]:
        graph.add_operator(op)
        if op.name not in graph.chunk_ops:
            graph.chunk_ops.append(op.name)
    for i in range(num_layers - 1):
        graph.add_edge(IREdge(layers[i].name, 'value_out', layers[i + 1].name, 'value'))
    graph.add_edge(IREdge(layers[-1].name, 'value_out', emit.name, 'value_out'))
    graph.external_inputs = [TensorPort('value', ('batch', 'channels', 'time'))]
    graph.external_outputs = [TensorPort('chunk', ('batch', 'channels', 'time'))]
    return graph


class Ctx:
    def __init__(self, layers, device):
        self.layers = layers
        self.device = device
        self.fresh = True
        self.value = None
        self.chunk_idx = 0


def initial_state(layers, device):
    return {f'hist_{i}': torch.zeros(1, layer.conv.in_channels,
                                     layer._time_causal_padding[0],
                                     device=device, dtype=torch.float32)
            for i, layer in enumerate(layers)}


def run_ir(layers, config, requests):
    """Run the IR graph over the session; returns one concatenated array per
    reset-delimited session."""
    device = config.get('device', 'cuda')
    graph = build_graph(len(layers))
    executor = SequentialExecutor(graph)
    executor.init_state(initial_state(layers, device))
    ctx = Ctx(layers, device)
    sessions, current = [], None
    chunk = config['chunk']
    for item in requests:
        if item.get('reset'):
            executor.init_state(initial_state(layers, device))
            ctx.fresh = True
            current = None
        if current is None:
            current = []
            sessions.append(current)
        frame = item['features']
        total = frame.shape[-1]
        for idx, start in enumerate(range(0, total, chunk)):
            valid = min(chunk, total - start)
            ctx.value = torch.from_numpy(
                np.ascontiguousarray(frame[:, start:start + valid])).unsqueeze(0).to(device)
            ctx.fresh = ctx.fresh and idx == 0
            ctx.chunk_idx = idx
            out = executor.run_chunk({'value': ctx.value}, ctx)
            current.append(out['chunk'].squeeze(0).cpu().numpy())
    return [np.concatenate(sess, axis=-1) for sess in sessions]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repository', type=Path, default=None)
    ap.add_argument('--config', type=Path, default=None)
    args = ap.parse_args()

    sys.path.insert(0, str(BACKEND))
    sys.path.insert(0, str(BACKEND / 'tests'))
    import flashrt.paths as fpaths
    repo = args.repository or Path(fpaths.repo_root())
    sys.path.insert(0, str(repo))
    from causal_features.model import build_layers, full_sequence_oracle
    import harness

    config = json.loads(args.config.read_text(encoding='utf-8')) if args.config \
        else dict(harness.CASES['dev'])
    layers = build_layers(repo, config, config.get('device', 'cuda'))
    requests = harness.default_requests('dev')
    want = harness.oracle_sessions('dev', requests)

    t0 = time.time()
    got = run_ir(layers, config, requests)
    print(f'IR executor ran {len(requests)} requests in {time.time() - t0:.2f}s')
    ok_ir, stats_ir = harness.compare(got, want, 'ir-vs-oracle')
    print(f'IR-EXECUTOR-VS-CPU-ORACLE: {"PASS" if ok_ir else "FAIL"} {stats_ir}')

    ref, _, _ = harness.drive('reference', 'dev', harness.tag('irref'), requests)
    ok_ref, stats_ref = harness.compare(got, ref, 'ir-vs-reference')
    print(f'IR-EXECUTOR-VS-REFERENCE-BACKEND: {"PASS" if ok_ref else "FAIL"} {stats_ref}')
    print(f'VERDICT: {"PASS" if (ok_ir and ok_ref) else "FAIL"} '
          f'(atol={TOL_ATOL}, rtol={TOL_RTOL}; float32 accumulation order only)')

    graph = build_graph(len(layers))
    lats = {f'causal_layer_{i}': 0.001 for i in range(len(layers))}
    lats['emit_chunk'] = 0.0001
    text = summarize_graph(graph, op_latencies=lats)
    (BACKEND / 'notes' / 'ir_analysis.txt').write_text(text, encoding='utf-8')
    print('ANALYSIS (sanitised; full text in notes/ir_analysis.txt):')
    print(text.encode('ascii', 'replace').decode('ascii')[:2500])
    dep = analyze_cross_chunk_dependencies(graph)
    print('cross-chunk deps:', str(dep).encode('ascii', 'replace').decode('ascii')[:800])
    print('pipeline stages:', str(find_pipeline_stages(graph)).encode(
        'ascii', 'replace').decode('ascii')[:600])
    print('critical path:', compute_critical_path(graph, lats))


if __name__ == '__main__':
    main()
