"""Adapter-driven correctness + benchmark harness for the causal_features app.

Launches the research reference backend and/or candidate backends as
subprocesses, drives them through the app's shared adapter, compares outputs
against the CPU full-sequence oracle (and against the reference), and runs a
finite offered-load sweep with a 20 ms chunk-gap budget.

Run through tests/run.py (this environment cannot pass CLI arguments).
"""
import glob
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

import flashrt.paths as fpaths
from flashrt.apps.causal_features.adapter import FeatureAdapter
from flashrt.apps.causal_features.model import full_sequence_oracle

BACKEND = Path(__file__).resolve().parents[1]
APPS_DIR = Path(fpaths.app_dir('causal_features')).parent
RESULTS = BACKEND / 'benchmarks' / 'results'
TMP = BACKEND / 'tests' / 'fixtures' / 'tmp'
TOL_ATOL = 3e-5      # contract tolerance: CPU/GPU float32 accumulation order
TOL_RTOL = 3e-4
GAP_BUDGET_MS = 20.0

CASES = {
    'dev': dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703,
                device='cuda'),
    'big': dict(channels=128, hidden=256, length=16384, chunk=512, weight_seed=703,
                device='cuda'),
}

_SEQ = [0]


def repo_root():
    return str(fpaths.repo_root())


def tag(t):
    _SEQ[0] += 1
    return f'cf{os.getpid() % 1000}{_SEQ[0]:03d}{t}'[:40]


def write_config(case, prefix, strategy=None):
    cfg = dict(CASES[case])
    cfg['prefix'] = prefix
    if strategy:
        cfg['strategy'] = strategy
    TMP.mkdir(parents=True, exist_ok=True)
    path = TMP / f'{prefix}.json'
    path.write_text(json.dumps(cfg), encoding='utf-8')
    return cfg, path


def clean_shm(prefix):
    if not os.path.isdir('/dev/shm'):
        return
    for path in glob.glob(f'/dev/shm/{prefix}*'):
        try:
            os.unlink(path)
        except OSError:
            pass


def launch(kind, case, prefix, strategy=None):
    cfg, path = write_config(case, prefix, strategy)
    env = os.environ.copy()
    env['PYTHONPATH'] = str(APPS_DIR) + os.pathsep + env.get('PYTHONPATH', '')
    env.setdefault('CUDA_VISIBLE_DEVICES', '0')
    if kind == 'reference':
        cmd = [sys.executable, '-m', 'causal_features.reference',
               '--repository', repo_root(), '--config', str(path)]
    else:
        cmd = [sys.executable, str(BACKEND / 'worker.py'),
               '--repository', repo_root(), '--config', str(path)]
    clean_shm(prefix)
    RESULTS.mkdir(parents=True, exist_ok=True)
    log = open(RESULTS / f'backend_{prefix}.log', 'w', encoding='utf-8')
    proc = subprocess.Popen(cmd, cwd=repo_root(), env=env, stdout=log,
                            stderr=subprocess.STDOUT, start_new_session=True)
    return proc, cfg, log


def stop(proc, log, prefix):
    try:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                if os.name == 'nt':
                    proc.kill()
                else:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                proc.wait()
    finally:
        log.close()
        clean_shm(prefix)


def drive(kind, case, prefix, requests, strategy=None, timeout=120):
    """requests: list of dict(features=np.ndarray, reset=bool).

    Returns (sessions, timings): sessions is a list (one per reset-delimited
    session) of the concatenated (C, k*length) outputs, timings one row per
    request."""
    proc, cfg, log = launch(kind, case, prefix, strategy)
    adapter = FeatureAdapter({'prefix': prefix, 'channels': cfg['channels'],
                              'length': cfg['length'], 'chunk': cfg['chunk']})
    sessions, timings = [], []
    try:
        adapter.start()
        current = None
        for item in requests:
            if item.get('reset'):
                adapter.reset()
                current = None
            if current is None:
                current = []
                sessions.append(current)
            rid, published_ns = adapter.submit(item['features'])
            chunks, marks = [], []
            while True:
                data, observed_ns = adapter.receive(timeout_s=timeout)
                chunks.append(data)
                marks.append(observed_ns)
                if adapter.pending is None:
                    break
            current.append((rid, chunks))
            timings.append(dict(request=rid, published_ns=published_ns, marks=marks))
        adapter.terminate()
    finally:
        try:
            adapter.close()
        except Exception:
            pass
        stop(proc, log, prefix)
    flat = [np.concatenate([np.concatenate(chunks, axis=-1) for _, chunks in sess], axis=-1)
            for sess in sessions]
    return flat, timings, cfg


def default_requests(case, seed=7):
    cfg = CASES[case]
    rng = np.random.default_rng(seed)
    shape = (cfg['channels'], cfg['length'])
    a = rng.standard_normal(shape, dtype=np.float32)
    b = rng.standard_normal(shape, dtype=np.float32) * 0.5 + 0.25
    c = rng.standard_normal(shape, dtype=np.float32) * 2.0
    d = rng.standard_normal(shape, dtype=np.float32) - 1.0
    # 3 requests, repeated input without reset, then reset and 3 more
    return [dict(features=a), dict(features=b), dict(features=a),
            dict(features=a, reset=True), dict(features=c), dict(features=d)]


def oracle_sessions(case, requests):
    cfg = CASES[case]
    sessions, current = [], None
    for item in requests:
        if item.get('reset'):
            current = None
        if current is None:
            current = []
            sessions.append(current)
        current.append(item['features'])
    return [full_sequence_oracle(repo_root(), cfg, np.concatenate(s, axis=-1))
            for s in sessions]


def compare(got_sessions, want_sessions, label=''):
    if len(got_sessions) != len(want_sessions):
        print(f'  {label}: session count {len(got_sessions)} != {len(want_sessions)}')
        return False, {}
    worst_abs = worst_rel = 0.0
    ok = True
    for si, (g, w) in enumerate(zip(got_sessions, want_sessions)):
        if g.shape != w.shape:
            print(f'  {label}: session {si} shape {g.shape} != {w.shape}')
            return False, {}
        diff = np.abs(g.astype(np.float64) - w.astype(np.float64))
        worst_abs = max(worst_abs, float(diff.max()))
        worst_rel = max(worst_rel, float((diff / np.maximum(np.abs(w.astype(np.float64)),
                                                           1e-12)).max()))
        ok = ok and bool(np.allclose(g, w, atol=TOL_ATOL, rtol=TOL_RTOL))
    return ok, dict(max_abs=worst_abs, max_rel=worst_rel)


def correctness(cases, strategies, seed=7):
    report = {}
    for case in cases:
        requests = default_requests(case, seed)
        want = oracle_sessions(case, requests)
        print(f'== correctness case={case} ({len(requests)} requests) ==', flush=True)
        entry = {}
        got_ref, _, _ = drive('reference', case, tag('ref'), requests)
        ok_ref, stats_ref = compare(got_ref, want, 'reference-vs-oracle')
        print(f'  reference            : {"PASS" if ok_ref else "FAIL"} {stats_ref}', flush=True)
        entry['reference'] = dict(passed=ok_ref, **stats_ref)
        for strat in strategies:
            got, _, _ = drive('candidate', case, tag('c' + strat[:6]), requests, strat)
            ok, stats = compare(got, want, f'{strat}-vs-oracle')
            oks, stats_s = compare(got, got_ref, f'{strat}-vs-reference')
            print(f'  {strat:21s}: oracle {"PASS" if ok else "FAIL"} {stats}'
                  f' | reference {"PASS" if oks else "FAIL"} {stats_s}', flush=True)
            entry[strat] = dict(passed=ok, vs_reference=oks, **stats)
        report[case] = entry
    return report


def sweep(adapter, cfg, dt_s, n_request):
    rng = np.random.default_rng(11)
    pool = [rng.standard_normal((cfg['channels'], cfg['length']), dtype=np.float32)
            for _ in range(4)]
    t0 = time.perf_counter()
    late = 0
    rows = []
    for k in range(n_request):
        target = t0 + k * dt_s
        now = time.perf_counter()
        if now < target:
            time.sleep(target - now)
        else:
            late += 1
        rid, published_ns = adapter.submit(pool[k % len(pool)])
        marks = []
        while True:
            _, observed_ns = adapter.receive(timeout_s=120)
            marks.append(observed_ns)
            if adapter.pending is None:
                break
        rows.append((published_ns, marks))
    end = time.perf_counter()
    first = [(m[0] - p) / 1e6 for p, m in rows]
    gaps = [(b - a) / 1e6 for _, m in rows for a, b in zip(m[:-1], m[1:])]
    total = [(m[-1] - p) / 1e6 for p, m in rows]
    n_out = sum(len(m) for _, m in rows)

    def pct(xs, q):
        return float(np.percentile(xs, q)) if xs else float('nan')

    return dict(offered_rate=1.0 / dt_s, achieved_rate=n_out / (end - t0),
                request_rate=n_request / (end - t0), late=late,
                first_med_ms=pct(first, 50), first_p95_ms=pct(first, 95),
                gap_med_ms=pct(gaps, 50), gap_p95_ms=pct(gaps, 95),
                gap_max_ms=max(gaps) if gaps else 0.0,
                gap_over_budget=sum(1 for g in gaps if g > GAP_BUDGET_MS) / max(1, len(gaps)),
                request_med_ms=pct(total, 50), request_p95_ms=pct(total, 95))


def benchmark(cases, strategies, dts=None, n_request=10):
    out = {}
    stamp = time.strftime('%Y%m%d_%H%M%S')
    for case in cases:
        cfg = CASES[case]
        offered = dts or [0.032, 0.016, 0.008, 0.004, 0.002, 0.001, 0.0005]
        for kind, strat in [('reference', None)] + [('candidate', s) for s in strategies]:
            name = strat or 'reference'
            prefix = tag('b' + name[:8])
            proc, bcfg, log = launch(kind, case, prefix, strat)
            adapter = FeatureAdapter({'prefix': prefix, 'channels': cfg['channels'],
                                      'length': cfg['length'], 'chunk': cfg['chunk']})
            rows = []
            try:
                adapter.start()
                sweep(adapter, bcfg, 0.008, 2)      # warm-up
                for dt in offered:
                    rows.append(sweep(adapter, bcfg, dt, n_request))
                adapter.terminate()
            finally:
                try:
                    adapter.close()
                except Exception:
                    pass
                stop(proc, log, prefix)
            sustained = [r['offered_rate'] for r in rows
                         if r['late'] == 0
                         and r['achieved_rate'] >= 0.97 * r['offered_rate']
                         and r['gap_over_budget'] == 0.0]
            rec = dict(case=case, strategy=name, sweeps=rows,
                       sustainable_rate=max(sustained) if sustained else 0.0,
                       gap_budget_ms=GAP_BUDGET_MS, timestamp=stamp)
            out[f'{case}:{name}'] = rec
            RESULTS.mkdir(parents=True, exist_ok=True)
            (RESULTS / f'{case}_{name}_{stamp}.json').write_text(
                json.dumps(rec, indent=1), encoding='utf-8')
            r0 = rows[0]
            print(f'  {case:4s} {name:21s} sust={rec["sustainable_rate"]:8.1f}/s '
                  f'first_med={r0["first_med_ms"]:.3f}ms first_p95={r0["first_p95_ms"]:.3f}ms '
                  f'gap_med={r0["gap_med_ms"]:.3f}ms gap_p95={r0["gap_p95_ms"]:.3f}ms '
                  f'over={r0["gap_over_budget"]:.3f} req_med={r0["request_med_ms"]:.3f}ms',
                  flush=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / f'summary_{"_".join(cases)}_{stamp}.json').write_text(
        json.dumps(out, indent=1), encoding='utf-8')
    return out
