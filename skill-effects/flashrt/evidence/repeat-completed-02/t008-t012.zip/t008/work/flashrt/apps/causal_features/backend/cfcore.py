"""Streaming core for the causal_features application.

Reference semantics (flashrt/apps/causal_features/reference.py + model.py):
  for each layer i (CausalConv1d, pad_mode='replicate', left pad = kernel-1):
      joined = cat(hist_i, chunk)          # hist_i has kernel-1 samples
      y      = layer_i(joined)             # replicate pad + conv1d
      hist_i = joined[..., -(kernel-1):]   # updated for the next chunk
      value  = silu(y[:, :, len(hist_i):]) # drop the history part
  i.e. out[p] = conv(joined[p : p+kernel]): a "valid" convolution over the
  joined buffer, so the left padding never reaches a kept output position.

We exploit that identity: keep hist_i of length kernel-1 in a flat scratch
buffer j = [hist_i | v] and take the *unpadded* conv1d, whose output length is
exactly len(v).  For the first chunk of a session (hist empty in the reference)
we pre-fill hist_i with replicate copies of v[..., 0], which reproduces
F.pad(..., mode='replicate') exactly (tests/test_ir.py re-derives it).

All per-layer state stays resident on the GPU: nothing except the request
features and the published chunks crosses PCIe.
"""
import numpy as np
import torch
import torch.nn.functional as F


def conv1d_cudnn(layer, j):
    return F.conv1d(j, layer.conv.weight, layer.conv.bias)


def conv1d_matmul(layer, j):
    """Same math as k cuBLAS matmuls, without materialising an im2col buffer."""
    w = layer.conv.weight           # (H, C, k)
    b = layer.conv.bias
    n = j.shape[-1] - (w.shape[-1] - 1)
    xs = j[0].transpose(0, 1)       # (n + k - 1, C)
    acc = None
    for t in range(w.shape[-1]):
        term = xs[t:t + n] @ w[:, :, t].t()
        acc = term if acc is None else acc + term
    return (acc + b).t().unsqueeze(0)


class Chain:
    """Three causal conv layers with GPU-resident per-layer history."""

    def __init__(self, layers, device, conv='cudnn'):
        self.layers = list(layers)
        self.device = device
        self.in_ch = [l.conv.in_channels for l in self.layers]
        self.out_ch = [l.conv.out_channels for l in self.layers]
        self.pad = [l._time_causal_padding[0] for l in self.layers]  # kernel-1
        self.conv = conv1d_cudnn if conv == 'cudnn' else conv1d_matmul
        self.hist = [torch.zeros(1, c, p, device=device, dtype=torch.float32)
                     for c, p in zip(self.in_ch, self.pad)]

    def forward(self, x, out, scratch, fresh):
        v = x
        n = x.shape[-1]
        for i, layer in enumerate(self.layers):
            p = self.pad[i]
            j = scratch[i][:, :, :p + n]
            if fresh:
                j[:, :, :p].copy_(v[:, :, :1].expand(-1, -1, p))
            else:
                j[:, :, :p].copy_(self.hist[i])
            j[:, :, p:p + n].copy_(v)
            v = F.silu(self.conv(layer, j))
            # last p samples of [hist | v] == joined[..., -p:].clone()
            self.hist[i].copy_(j[:, :, n:n + p])
        out.copy_(v)
        return out


class Segment:
    """Static-shape piece of a request.  The input is a fixed-offset view of the
    request buffer, the output a private static buffer, so one CUDA graph can be
    captured per (segment, fresh-history) combination."""

    def __init__(self, chain, request_buf, offset, n):
        self.offset = offset
        self.n = n
        self.inp = request_buf[:, :, offset:offset + n]
        self.out = torch.zeros(1, chain.out_ch[-1], n, device=chain.device,
                               dtype=torch.float32)
        self.scratch = [torch.zeros(1, c, p + n, device=chain.device, dtype=torch.float32)
                        for c, p in zip(chain.in_ch, chain.pad)]
        self.graphs = {}
        self.eager = False

    def capture(self, chain, fresh):
        try:
            stream = torch.cuda.Stream(device=chain.device)
            stream.wait_stream(torch.cuda.current_stream(device=chain.device))
            with torch.cuda.stream(stream):
                for _ in range(2):
                    chain.forward(self.inp, self.out, self.scratch, fresh)
            torch.cuda.current_stream(device=chain.device).wait_stream(stream)
            torch.cuda.synchronize(device=chain.device)
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                chain.forward(self.inp, self.out, self.scratch, fresh)
            self.graphs[fresh] = graph
        except Exception as exc:                      # pragma: no cover
            self.eager = True
            print(f'{{"capture_failed": "{type(exc).__name__}"}}', flush=True)

    def run(self, chain, fresh):
        graph = self.graphs.get(fresh)
        if graph is not None:
            graph.replay()
        else:
            chain.forward(self.inp, self.out, self.scratch, fresh)
        return self.out


class Publisher:
    """Publishes chunks on the adapter's output/metadata rings, data first."""

    def __init__(self, buffers):
        self.out = buffers['output']
        self.meta = buffers['metadata']
        self.slots = [self.out.tensor[i] for i in range(self.out.max_len)]
        self.mslots = [self.meta.tensor[i] for i in range(self.meta.max_len)]
        self.tslots = [torch.from_numpy(np.ascontiguousarray(s)) for s in self.slots]
        self.base = 0
        self.req = 0

    def begin(self, request_id):
        self.base = int(self.out.num)
        self.req = int(request_id)

    def host(self, idx, valid, arr):
        g = self.base + idx
        pos = g % self.out.max_len
        self.slots[pos][:, :valid] = arr[:, :valid]
        self.out.num_arr[0] = g + 1
        m = self.mslots[pos]
        m[0] = self.req
        m[1] = idx
        m[2] = valid
        self.meta.num_arr[0] = g + 1

    def gpu(self, idx, valid, tensor):
        g = self.base + idx
        pos = g % self.out.max_len
        self.tslots[pos][:, :valid].copy_(tensor[0][:, :valid])
        self.out.num_arr[0] = g + 1
        m = self.mslots[pos]
        m[0] = self.req
        m[1] = idx
        m[2] = valid
        self.meta.num_arr[0] = g + 1


def ceil_div(a, b):
    return (a + b - 1) // b


# name -> (segmentation, cuda_graph, publish_path, conv_impl, h2d)
STRATEGIES = {
    'ref_like':            ('chunk',  False, 'host', 'cudnn',  'full'),
    'chunk_eager':         ('chunk',  False, 'host', 'cudnn',  'full'),
    'chunk_graph':         ('chunk',  True,  'host', 'cudnn',  'full'),
    'whole_eager':         ('whole',  False, 'host', 'cudnn',  'full'),
    'whole_graph':         ('whole',  True,  'host', 'cudnn',  'full'),
    'hybrid_eager':        ('hybrid', False, 'host', 'cudnn',  'full'),
    'hybrid_graph':        ('hybrid', True,  'host', 'cudnn',  'full'),
    'hybrid_graph_gpu':    ('hybrid', True,  'gpu',  'cudnn',  'full'),
    'hybrid_graph_mm':     ('hybrid', True,  'host', 'matmul', 'full'),
    'whole_graph_mm':      ('whole',  True,  'host', 'matmul', 'full'),
    'chunk_graph_mm':      ('chunk',  True,  'host', 'matmul', 'full'),
    'hybrid_graph_split':  ('hybrid', True,  'host', 'cudnn',  'split'),
}
DEFAULT_STRATEGY = 'hybrid_graph'


class Runtime:
    def __init__(self, layers, config, strategy=DEFAULT_STRATEGY):
        self.device = config.get('device', 'cuda')
        self.T = int(config['length'])
        self.chunk = int(config['chunk'])
        self.K = ceil_div(self.T, self.chunk)
        self.strategy = strategy if strategy in STRATEGIES else DEFAULT_STRATEGY
        (self.seg_mode, self.use_graph, self.publish,
         conv_mode, self.h2d) = STRATEGIES[self.strategy]
        self.chain = Chain(layers, self.device, conv_mode)
        self.C = self.chain.in_ch[0]
        # K*chunk so that every segment is a full static shape; the tail region
        # past `length` stays zero and its outputs are never published.
        self.x_gpu = torch.zeros(1, self.C, self.K * self.chunk,
                                 device=self.device, dtype=torch.float32)
        self.segments = {}
        if self.seg_mode == 'chunk':
            offsets = [i * self.chunk for i in range(self.K)]
            lengths = [self.chunk] * self.K
        elif self.seg_mode == 'whole':
            offsets, lengths = [0], [self.T]
        else:                                       # hybrid: chunk 0, then rest
            if self.T <= self.chunk:
                offsets, lengths = [0], [self.T]
            else:
                offsets = [0, self.chunk]
                lengths = [self.chunk, self.T - self.chunk]
        self.plan = list(zip(offsets, lengths))
        self.ref_hist = [None] * len(self.chain.layers)
        self.fresh = True
        if self.use_graph:
            for offset, n in self.plan:
                seg = self.segment(offset, n)
                seg.capture(self.chain, True)
                seg.capture(self.chain, False)
            torch.cuda.synchronize(self.device)

    def segment(self, offset, n):
        key = (offset, n)
        seg = self.segments.get(key)
        if seg is None:
            seg = Segment(self.chain, self.x_gpu, offset, n)
            self.segments[key] = seg
        return seg

    def reset(self):
        self.fresh = True
        for h in self.chain.hist:
            h.zero_()
        self.ref_hist = [None] * len(self.chain.layers)

    def _copy_in(self, frame, offset, n):
        self.x_gpu[0, :, offset:offset + n].copy_(
            torch.from_numpy(frame[:, offset:offset + n]))

    def request(self, frame, request_id, publisher):
        publisher.begin(request_id)
        if self.strategy == 'ref_like':
            self._request_reference(frame, publisher)
        else:
            if self.h2d == 'full':
                self._copy_in(frame, 0, self.T)
            published = 0
            for seg_index, (offset, n) in enumerate(self.plan):
                if self.h2d == 'split':
                    self._copy_in(frame, offset, n)
                fresh = self.fresh and seg_index == 0
                out = self.segment(offset, n).run(self.chain, fresh)
                host = out[0].cpu().numpy() if self.publish == 'host' else None
                while published < self.K:
                    start = published * self.chunk
                    valid = min(self.chunk, self.T - start)
                    if start + valid > offset + n:
                        break
                    rel = start - offset
                    if host is not None:
                        publisher.host(published, valid, host[:, rel:rel + valid])
                    else:
                        publisher.gpu(published, valid, out[:, :, rel:rel + valid])
                    published += 1
            if self.seg_mode == 'chunk':
                self._fix_tail_history()
        self.fresh = False

    def _fix_tail_history(self):
        """The tail chunk is computed at full chunk length (zero padded); the
        history must still hold the true last samples of the request."""
        tail = self.T - (self.K - 1) * self.chunk
        if tail == self.chunk:
            return
        seg = self.segments[((self.K - 1) * self.chunk, self.chunk)]
        for i, p in enumerate(self.chain.pad):
            self.chain.hist[i].copy_(seg.scratch[i][:, :, tail:tail + p])

    def _request_reference(self, frame, publisher):
        """Reference algorithm verbatim (concat + clone + pad + slice)."""
        for idx in range(self.K):
            start = idx * self.chunk
            valid = min(self.chunk, self.T - start)
            value = torch.from_numpy(frame[:, start:start + valid]).unsqueeze(0).to(self.device)
            for i, layer in enumerate(self.chain.layers):
                history = self.ref_hist[i]
                joined = value if history is None else torch.cat([history, value], dim=-1)
                result = layer(joined)
                if history is not None:
                    result = result[:, :, history.shape[-1]:]
                self.ref_hist[i] = joined[:, :, -layer._time_causal_padding[0]:].clone()
                value = F.silu(result)
            publisher.host(idx, valid, value.squeeze(0).cpu().numpy())
