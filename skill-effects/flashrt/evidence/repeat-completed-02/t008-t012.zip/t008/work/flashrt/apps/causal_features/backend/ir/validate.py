"""Run the IR state-graph validation with autograd disabled, then persist the
experiment log and README (the phase-2 verdict is captured from the run)."""
import contextlib
import io
import runpy
import sys
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
BACKEND = HERE.parent
(BACKEND / 'notes').mkdir(parents=True, exist_ok=True)
torch.set_grad_enabled(False)

buf = io.StringIO()
status = 0
with contextlib.redirect_stdout(buf):
    try:
        runpy.run_path(str(HERE / 'state_graph.py'), run_name='__main__')
    except BaseException:
        import traceback
        traceback.print_exc()
        status = 1
text = buf.getvalue()
print(text.encode('ascii', 'replace').decode('ascii'))

verdict = [ln for ln in text.splitlines() if ln.startswith('VERDICT')]
irline = [ln for ln in text.splitlines() if ln.startswith('IR-EXECUTOR')]
log = HERE.parent / 'notes' / 'experiment_log.md'
log.write_text(LOG := f"""# causal_features — experiment log

## IR Conversion (phase 1-2)
- Worker graph: 4 operators, 3 data edges (`ir/state_graph.py`).
  - Black-box stages: none (the whole chain is exposed).
  - Exposed stages: `causal_layer_0/1/2` (causal conv1d + SiLU), `emit_chunk`.
  - Streaming edges: every layer edge is 1 chunk in -> 1 chunk out (rate 1:1);
    no rate conversion, no BATCH barrier.
- Model graph: one graph `causal_features_layer_state`, 4 ops / 3 edges.
  - State objects: `hist_0`, `hist_1`, `hist_2`, all `chunk_persistent`
    (kernel-1 input samples per layer; the only cross-chunk state).
  - Chunk-periodic operators: all four (one execution per emitted chunk).
- IR validation: {"PASS" if status == 0 else "FAIL"} — `ir/state_graph.py` run through
  `ir/validate.py`, `SequentialExecutor` vs CPU full-sequence oracle and vs the
  reference backend driven through the adapter, 6 requests (continuation,
  repeated input without reset, reset + replay, short tail chunk).
  - evidence: `tests/fixtures/tmp` harness logs, this file's IR lines:
  - {" / ".join(irline)[:400]}
  - tolerance atol=3e-5, rtol=3e-4 (float32 accumulation order only; the
    reference itself deviates from the CPU oracle by max_abs 1.49e-07).
- Analysis (`notes/ir_analysis.txt`, produced by `summarize_graph`):
  - Pipeline stages: the three layers share *no* state, so the tool groups them
    into a single stage per chunk; layer i of chunk k+1 may overlap layer j!=i
    of chunk k (independent-pair result) because each `hist_i` is private.
  - Critical path: causal_layer_0 -> 1 -> 2 -> emit_chunk (serial per chunk;
    the measured per-chunk GPU time is ~20 us, so the serial chain is not the
    bottleneck: Python/launch/PCIe overhead is).
  - Streaming overlaps: none reported (1:1 edges); the real leverage the IR
    exposes is (a) cross-chunk independence of layer histories and (b) that all
    three layers of one chunk can be collapsed into one launch domain.

## Deployment iteration
Hardware: 1x RTX 5060 Laptop 8 GB, Windows, torch 2.11.0+cu128, case `dev`
(C=16, H=32, T=1043, chunk=127, 9 chunks/request incl. 27-sample tail).
Harness: `tests/harness.py` via `tests/run.py` (adapter-driven subprocesses,
CPU full-sequence oracle + reference backend, 20 ms chunk-gap budget).
All numbers below are from the `dev` case at the lowest offered load of the
sweep (dt=2 ms, 500 req/s offered) — `tests/fixtures/tmp/run.log`,
`benchmarks/results/dev_<strategy>_*.json`.

| # | variant | hypothesis / IR basis | correctness | first_med ms | gap_med ms | req_med ms | status |
|---|---------|----------------------|-------------|--------------|------------|------------|--------|
| 1 | reference (anchor) | research sequential baseline | PASS (vs oracle) | 1.528 | 0.527 | 5.256 | measured |
| 2 | `ref_like` | my plumbing reproduces the reference bit-exactly (control experiment) | PASS (max_abs 0.0) | 1.165 | 0.562 | 6.308 | measured |
| 3 | `chunk_eager` | per-chunk GPU-resident history removes the cat/clone/D2H per layer (streaming layer) | PASS | 0.529 | 0.524 | 4.218 | measured |
| 4 | `chunk_graph` | + CUDA graph per chunk kills launch overhead (IR: serial 3-op chain is launch bound) | PASS | 0.529 | 0.007 | 1.147 | measured |
| 5 | `whole_eager` | one full-request pass amortises launches over 9 chunks | PASS | 1.027 | 0.007 | 1.092 | measured |
| 6 | `whole_graph` | + CUDA graph on the whole request (publish path dominates) | PASS | 0.540 | 0.005 | 0.584 | measured |
| 7 | `hybrid_eager` | publish chunk 0 first (latency), then the rest in one pass | PASS | 0.513 | 0.004 | 1.079 | measured |
| 8 | `hybrid_graph` | chunk-0 graph + remainder graph: best of both axes (recommended) | PASS (max_abs 0.0) | 0.542 | 0.006 | 0.588 | measured |
| 9 | `hybrid_graph_gpu` | zero-copy publish: D2H straight into the shm ring per chunk | PASS | 0.545 | 0.007 | 1.156 | measured |
| 10 | `hybrid_graph_mm` | conv as kernel_size cuBLAS matmuls (matmul formulation, in-graph) | PASS (1.5e-07) | 0.497 | 0.007 | 0.556 | measured |
| 11 | `whole_graph_mm` | matmul formulation without the hybrid split | PASS (1.5e-07) | 0.546 | 0.006 | 0.594 | measured |
| 12 | `chunk_graph_mm` | matmul formulation at chunk granularity (smoothness test) | PASS (1.5e-07) | 0.537 | 0.007 | 1.165 | measured |
| 13 | `hybrid_graph_split` | per-segment H2D (prefix copied before chunk 0) for big-case latency | PASS | 0.529 | 0.004 | 0.559 | measured |

Rationale for ordering: launch/serialisation overhead dominates the dev case
(IR critical path is short), so graph-capture variants were ranked first,
then publish-path and conv-formulation levers, then combinations.

Results / trade-offs (all measured, no estimates):
- The recommended `hybrid_graph` cuts first-chunk latency 1.53 -> 0.54 ms
  (-65%) and full-request completion 5.26 -> 0.59 ms (-89%), and collapses the
  inter-chunk gap from 0.53 ms to 0.006 ms with 0/48 gaps over the 20 ms budget.
- `chunk_*` variants keep per-chunk cadence (gap p95 0.55 ms, still inside
  budget) but pay 2x the request time of the hybrid/whole variants: publishing
  each chunk from the GPU costs more than one bulk D2H.
- `whole_*` delays chunk 0 until the whole request is computed; at the dev
  shape that costs only ~0.3 ms of extra GPU work, but it scales with `length`,
  so `hybrid_*` is the safer shape-general choice.
- `hybrid_graph_mm` is 8% faster on request time and equal on latency, but its
  conv is a different accumulation order (max_abs 1.5e-07 vs reference, well
  inside tolerance) and its advantage is inside run-to-run noise; the
  bit-exact cudnn variant stays the default.
- `sustainable_rate` in the JSON is reported as 0 by my harness: its pacing
  check counts a request as "late" whenever `time.sleep` overshoots the target
  (Windows timer granularity), so even the reference scores 0 while its
  `late`/`over_budget` columns show no load-related misses. The load-capacity
  numbers must therefore be read from `request_med_ms` (candidate 0.56 ms ->
  ~1800 req/s vs reference 5.26 ms -> ~190 req/s) and from the paired
  controller-side sweep.

## Known gaps in this session
- `big` case (C=128, H=256, T=16384, chunk=512) was not measured end-to-end;
  only the eager GPU probe (1.95 ms full-sequence conv) and the reference
  probe (20.6 ms/request) exist, in `probe.py` output.
- One harness defect (sustainable-rate pacing on Windows) is documented above
  and was not repaired for lack of observation budget.
""", encoding='utf-8')

(BACKEND / 'README.md').write_text("""# causal_features backend

`worker.py` is a drop-in replacement for `causal_features.reference`:

    python flashrt/apps/causal_features/backend/worker.py \\
        --repository <repo-root> --config <config.json>

It creates exactly the shared-memory objects the app's adapter expects
(`<prefix>__ctrl`, `_input`, `_output`, `_metadata`), honours opcodes 1/3/2
(start/reset/terminate) with the same level semantics as the reference, and
publishes output payload before metadata for every chunk.

Recommended variant: `hybrid_graph` (default). Optional config key
`strategy` or `--strategy` selects another measured variant from
`cfcore.STRATEGIES`: `chunk_graph`, `whole_graph`, `hybrid_eager`,
`whole_eager`, `chunk_eager`, `hybrid_graph_gpu`, `hybrid_graph_mm`,
`whole_graph_mm`, `chunk_graph_mm`, `hybrid_graph_split`, `ref_like`.

Files: `cfcore.py` (streaming chain, CUDA-graph segments, publisher,
strategies), `ir/state_graph.py` (IR conversion + validation),
`tests/harness.py` + `tests/run.py` (correctness/benchmark),
`benchmarks/results/` (per-run JSON + backend logs),
`notes/experiment_log.md`, `notes/ir_analysis.txt`.
""", encoding='utf-8')
print(f'wrote {log} and README')
sys.exit(status)
