"""Optimized streaming backend for the two-branch causal-feature task.

The reference worker processes one 127-sample chunk at a time and pays a
host<->device round trip plus a fresh NumPy padding copy for every chunk.
Causal convolution is shift invariant, so a complete request (and, via the
persisted histories, every request since the last reset) is one causal
sequence.  This worker therefore evaluates a whole request with one host
upload and one device download while keeping the per-layer histories on the
device.

Variants are selected with config["variant"] or BRANCH_FEATURES_VARIANT:

  full_fused (default) : two fused 5-tap convolutions over the request
  graph                : same maths captured in one CUDA graph (after the
                         first eager request of a session/reset)
  full                 : four separate causal convolutions over the request
  chunked              : reference-shaped per-chunk maths, tensors kept on GPU
  stream               : per-chunk maths, publish immediately (lowest first out)
  cpu_full / cpu_fused : same kernels on the CPU (no PCIe transfers)

The fused weights merge the two branches: a0 (C->H, k=5) and b0 (C->H, k=3)
share the input stream, and a1 (H->C, k=3) / b1 (H->C, k=5) become one
block-diagonal (2C, 2H, 5) convolution.  A k=3 causal kernel occupies the
last three taps of a 5-tap causal window; the unused taps are exactly zero.

The adapter contract (control opcodes, ring buffers, metadata order and tail
chunk padding) is exactly the one implemented by
flashrt/apps/branch_features/reference.py.
"""
import argparse
import json
import math
import os
import sys
import time
from pathlib import Path


class Pipeline:
    def __init__(self, layers, config, device, variant):
        import torch
        self.torch = torch
        self.F = torch.nn.functional
        self.layers = layers
        self.device = device
        self.variant = variant
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        self.length = int(config['length'])
        self.chunk = int(config['chunk'])
        self.n_chunks = math.ceil(self.length / self.chunk)
        c, h = self.channels, self.hidden
        a0, a1, b0, b1 = layers['a0'], layers['a1'], layers['b0'], layers['b1']
        w0 = torch.zeros(2 * h, c, 5, device=device, dtype=a0.conv.weight.dtype)
        w0[:h] = a0.conv.weight
        w0[h:, :, 2:] = b0.conv.weight
        self.w0 = w0
        self.b0 = torch.cat([a0.conv.bias, b0.conv.bias]).to(device)
        w1 = torch.zeros(2 * c, 2 * h, 5, device=device, dtype=a1.conv.weight.dtype)
        w1[:c, :h, 2:] = a1.conv.weight
        w1[c:, h:] = b1.conv.weight
        self.w1 = w1
        self.b1 = torch.cat([a1.conv.bias, b1.conv.bias]).to(device)
        self.sep = {}
        for name in ('a0', 'a1', 'b0', 'b1'):
            layer = layers[name]
            self.sep[name] = (layer.conv.weight.to(device), layer.conv.bias.to(device),
                              layer._time_causal_padding[0])
        self.use_graph = variant == 'graph' and device != 'cpu'
        self.graph = None
        self.gx = self.gout = self.gh0 = self.gh1 = None
        self.reset()

    def reset(self):
        self.hist0 = None
        self.hist1 = None
        self.hist = {name: None for name in self.sep}

    # -- shared helpers -------------------------------------------------
    def _to_device(self, values):
        t = self.torch.from_numpy(values[0].copy()).unsqueeze(0)
        return t if self.device == 'cpu' else t.to(self.device)

    def _causal(self, x, weight, bias, pad, history):
        F = self.F
        if history is None:
            joined = F.pad(x, (pad, 0), mode='replicate')
        else:
            joined = self.torch.cat([history, x], dim=-1)
        return F.conv1d(joined, weight, bias), joined[:, :, -pad:]

    # -- whole-request implementations ----------------------------------
    def run(self, values):
        t = self._to_device(values)
        if self.variant == 'full_fused':
            out = self._full_fused(t)
        elif self.variant == 'full':
            out = self._full_separate(t)
        elif self.variant == 'graph':
            out = self._full_fused(t) if not self.use_graph else self._graph_step(t)
        else:
            out = self._chunked(t)
        return out

    def _full_fused(self, x):
        F, torch = self.F, self.torch
        c = self.channels
        y0, h0 = self._causal(x, self.w0, self.b0, 4, self.hist0)
        self.hist0 = h0.clone()
        z = F.silu(y0)
        y1, h1 = self._causal(z, self.w1, self.b1, 4, self.hist1)
        self.hist1 = h1.clone()
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return gate * y1[:, :c] + (1 - gate) * y1[:, c:] + 0.1 * x

    def _full_separate(self, x):
        F = self.F
        a, h = self._causal(x, *self.sep['a0'], self.hist['a0'])
        self.hist['a0'] = h.clone()
        a = F.silu(a)
        a, h = self._causal(a, *self.sep['a1'], self.hist['a1'])
        self.hist['a1'] = h.clone()
        b, h = self._causal(x, *self.sep['b0'], self.hist['b0'])
        self.hist['b0'] = h.clone()
        b = F.silu(b)
        b, h = self._causal(b, *self.sep['b1'], self.hist['b1'])
        self.hist['b1'] = h.clone()
        gate = self.torch.sigmoid(x.mean(dim=1, keepdim=True))
        return gate * a + (1 - gate) * b + 0.1 * x

    # -- CUDA-graph path -------------------------------------------------
    def _graph_body(self):
        F, torch = self.F, self.torch
        c, h = self.channels, self.hidden
        j0 = torch.cat([self.gh0, self.gx], dim=-1)
        y0 = F.conv1d(j0, self.w0, self.b0)
        self.gh0.copy_(j0[:, :, -4:])
        j1 = torch.cat([self.gh1, F.silu(y0)], dim=-1)
        y1 = F.conv1d(j1, self.w1, self.b1)
        self.gh1.copy_(j1[:, :, -4:])
        gate = torch.sigmoid(self.gx.mean(dim=1, keepdim=True))
        self.gout.copy_(gate * y1[:, :c] + (1 - gate) * y1[:, c:] + 0.1 * self.gx)

    def _capture(self):
        torch = self.torch
        c, h, t = self.channels, self.hidden, self.length
        self.gx = torch.empty((1, c, t), device=self.device)
        self.gout = torch.empty((1, c, t), device=self.device)
        self.gh0 = torch.empty((1, c, 4), device=self.device)
        self.gh1 = torch.empty((1, 2 * h, 4), device=self.device)
        self.gh0.copy_(self.hist0)
        self.gh1.copy_(self.hist1)
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(3):
                self._graph_body()
        torch.cuda.current_stream().wait_stream(side)
        self.gh0.copy_(self.hist0)  # warm-up advanced the histories; restore
        self.gh1.copy_(self.hist1)
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            self._graph_body()
        self.graph = graph

    def _graph_step(self, x):
        if self.hist0 is None or self.graph is None:
            out = self._full_fused(x)
            if self.graph is None:
                try:
                    self._capture()
                except Exception:
                    self.use_graph = False
                    self.graph = None
            else:
                self.gh0.copy_(self.hist0)
                self.gh1.copy_(self.hist1)
            return out
        self.gx.copy_(x)
        self.graph.replay()
        return self.gout

    # -- chunk-shaped implementations (same calls as the reference) ------
    def _step_exact(self, x):
        F = self.F
        a, h = self._causal(x, *self.sep['a0'], self.hist['a0'])
        self.hist['a0'] = h
        a = F.silu(a)
        a, h = self._causal(a, *self.sep['a1'], self.hist['a1'])
        self.hist['a1'] = h
        b, h = self._causal(x, *self.sep['b0'], self.hist['b0'])
        self.hist['b0'] = h
        b = F.silu(b)
        b, h = self._causal(b, *self.sep['b1'], self.hist['b1'])
        self.hist['b1'] = h
        gate = self.torch.sigmoid(x.mean(dim=1, keepdim=True))
        return gate * a + (1 - gate) * b + 0.1 * x

    def _chunked(self, x):
        t = self.torch
        out = t.empty((1, self.channels, self.length), device=x.device, dtype=x.dtype)
        for pos in range(0, self.length, self.chunk):
            end = min(pos + self.chunk, self.length)
            out[:, :, pos:end] = self._step_exact(x[:, :, pos:end])
        return out

    def step(self, values):
        """One chunk at a time (streaming variant)."""
        return self._step_exact(self._to_device(values))


def publish_whole(buffers, out, request_id, config, np):
    """Publish every chunk of a finished request without intermediate waits."""
    t = out.detach().to('cpu').numpy()[0]
    channels, length, chunk = int(config['channels']), int(config['length']), int(config['chunk'])
    n = math.ceil(length / chunk)
    padded = np.zeros((n, channels, chunk), dtype=np.float32)
    meta = np.empty((n, 3), dtype=np.int64)
    for i in range(n):
        start = i * chunk
        valid = min(chunk, length - start)
        padded[i, :, :valid] = t[:, start:start + valid]
        meta[i] = (request_id, i, valid)
    # Payload first, then metadata: the adapter's read() relies on that order.
    buffers['output'].write(padded)
    buffers['metadata'].write(meta)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    repository = args.repository.resolve()
    sys.path.insert(0, str(repository))
    import numpy as np
    import torch
    from branch_features.adapter import open_buffers, close_buffers
    from branch_features.model import build_layers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    variant = os.environ.get('BRANCH_FEATURES_VARIANT') or config.get('variant') or 'graph'
    device = 'cpu' if variant.startswith('cpu_') else config.get('device', 'cuda')
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    layers = build_layers(str(repository), config, device)
    pipeline = Pipeline(layers, config, device, variant)
    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    sleep_s = 0.00005
    try:
        print(json.dumps({'ready': True, 'device': device, 'variant': variant,
                          'task': 'branch_features'}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    pipeline.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(sleep_s)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(sleep_s)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id, consumed = consumed, next_cursor
            if variant == 'stream':
                for index, position in enumerate(range(0, config['length'], config['chunk'])):
                    with torch.inference_mode():
                        output = pipeline.step(features[:, :, position:position + config['chunk']])
                    output = output[0].detach().to('cpu').numpy()
                    padded = np.zeros((config['channels'], config['chunk']), dtype=np.float32)
                    padded[:, :output.shape[-1]] = output
                    buffers['output'].write(padded)
                    buffers['metadata'].write(
                        np.array([request_id, index, output.shape[-1]], dtype=np.int64))
            else:
                with torch.inference_mode():
                    out = pipeline.run(features)
                publish_whole(buffers, out, request_id, config, np)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
