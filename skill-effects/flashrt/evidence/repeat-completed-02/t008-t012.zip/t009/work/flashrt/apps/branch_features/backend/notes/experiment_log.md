# branch_features backend — experiment log

## IR Conversion (Phase 1–2)

- Worker-level view: the reference backend is a single stage. It reads one
  complete `(C=16, T=1043)` request, then sequentially runs 9 chunk
  evaluations (`chunk=127`, tail 27) and publishes one output chunk per
  evaluation. There are no other exposed/black-box stages and no rate
  conversion.
- Model graph (`ir/graph_builder.py`, `ir/ops.py`): 7 EXPOSED operators,
  6 data edges, 4 `chunk_persistent` state objects.
  - `conv_a0` (C→H, k=5, state `hist_a0`)
  - `silu_a`
  - `conv_a1` (H→C, k=3, state `hist_a1`)
  - `conv_b0` (C→H, k=3, state `hist_b0`)
  - `silu_b`
  - `conv_b1` (H→C, k=5, state `hist_b1`)
  - `gate_merge` = sigmoid(mean_c(features))·A + (1−gate)·B + 0.1·features
- State independence: the four histories are disjoint. Branches A and B share
  no state, so they are parallel work until `gate_merge`; every convolution is
  its own pipeline stage under `find_pipeline_stages` because no history is
  shared. `gate_merge` is the only join.
- Chunk-periodic ops: all 7 run once per chunk; histories persist across
  requests and are cleared by reset. This is exactly why a request is one
  causal sequence: a chunk boundary is an artificial scheduling boundary, not
  a mathematical one (replicate padding only exists at the true session start
  where the history is `None`).
- IR validation: **PASS** via `tests/test_ir.py` (run by
  `run_ir_validation.py`): `SequentialExecutor` over 2 complete requests vs
  the reference backend launched through the adapter.
  - correctness artifact: `tests/fixtures/ir_result.json` (max_abs ≈ 1e-7,
    tolerance 1e-4 justified by fp32 CPU-vs-CUDA convolution accumulation
    order).
  - analysis artifact: `notes/ir_analysis.txt` (`summarize_graph`).
- IR analysis consequences used below:
  - no shared state between branches → branch fusion and whole-request
    evaluation preserve every data/state dependency;
  - only cross-chunk dependencies are the four private histories →
    device-resident histories are legal and remove 8 of 9 host↔device round
    trips per request;
  - gate/merge depends on both branches and current features → it remains the
    single critical-path join.

## Variant Queue (last updated 2026-10-20)

| # | name | hypothesis | IR basis | predicted impact | status |
|---|------|------------|----------|------------------|--------|
| 1 | `full_fused` | Whole-request evaluation + merged branch convolutions removes 8/9 chunk round trips | disjoint histories; shift-invariant causal conv | throughput ↑↑, first-out ~equal | measured |
| 2 | `full` | Whole-request evaluation with 4 separate convs isolates the fusion lever | same | throughput ↑, fusion Δ small | measured |
| 3 | `chunked` | Keep reference chunk maths but keep tensors on device (isolates transfer cost) | chunk-persistent histories | throughput ↑ vs reference, ↓ vs full | measured |
| 4 | `stream` | Publish each chunk immediately to minimise first-output latency | streaming output edge | first-out ↓, throughput ↓ (9 D2H) | measured |
| 5 | `cpu_fused` | Co-locate the tiny model on CPU to remove PCIe entirely | same graph, different placement | first-out/throughput trade-off | measured |
| 6 | `cpu_full` | CPU with separate convs isolates fusion on CPU | same | slower than CPU full? compare | measured |
| 7 | `graph` | CUDA graph replay removes per-launch Python/driver overhead of the fused graph | all ops static-shaped per request | throughput ↑↑, first-out ↓ | measured |

Rationale for ordering: IR analysis ranks removal of per-chunk round trips
first (largest state/data-dependency win), branch fusion second (independent
state), placement third (tiny tensors), and launch-overhead capture last.
All rows are terminal; no row was removed.

## Deployment iteration records

Baseline and all numbers below come from
`benchmarks/results/branch_features_sweep_20261020_005000.json` (reference +
six variants, same hardware: RTX 5060) and
`benchmarks/results/branch_features_sweep_20261020_011701.json` (full_fused
vs graph). Offered-load sweep: 50/100/200/400/800/1600 requests/s, 24 varied
inputs per rate, 20 ms chunk-gap budget.

### reference (baseline)
- Correctness: PASS against CPU full-sequence oracle (`verify.py` output in
  `tests/fixtures/verify_result.json`; reference and candidate have identical
  max_abs 3.576e-07).
- Saturated near 90 requests/s (9 chunks each ⇒ ≈810 chunks/s).
- first-out median ≈ 2.0 ms, p95 ≈ 2.6 ms; service median ≈ 11.2 ms.
- Inter-chunk gap median ≈ 1.10 ms, p95 ≈ 1.69 ms, fraction > 20 ms = 0.

### full_fused
- Correctness: PASS (`verify.py`, max_abs 3.576e-07).
- Saturated 611–760 requests/s; first-out median ≈ 1.5 ms, p95 ≈ 2.0 ms;
  service median ≈ 1.62 ms.
- Gaps median ≈ 0.005 ms, p95 ≈ 0.012 ms, >20 ms = 0.
- Δ vs reference: ≈7–8× request throughput, first-out ~1.3× better.

### full
- PASS (`verify.py`, same max_abs). Saturated ≈554 requests/s, service
  ≈1.65 ms. Fusion alone is a small win over `full_fused` (≈10% throughput).

### chunked
- PASS (`verify.py`). Service ≈5.4 ms, saturated ≈170 requests/s, first-out
  ≈5.5 ms. Shows that per-chunk GPU launches (36 conv launches) dominate even
  with device-resident tensors; whole-request batching is the larger lever.

### stream
- PASS (`verify.py`). First-out ≈1.6–2.0 ms but service ≈9–10 ms and
  saturated ≈105 requests/s. Publishing per chunk costs a D2H sync per chunk;
  no first-output benefit over `full_fused` because the fused conv already
  completes in ~0.5 ms.

### cpu_fused
- PASS (`verify.py` variant). Service ≈3.2 ms, saturated ≈310 requests/s.
  Removing PCIe helps versus reference but CPU convolution is slower than the
  GPU fused graph.

### cpu_full
- PASS (`verify.py` variant). Service ≈2.1–2.6 ms, saturated ≈390–430
  requests/s; faster than `cpu_fused` because block-diagonal CPU convolutions
  waste arithmetic.

### graph (recommended)
- Correctness: PASS (`tests/verify_graph.py`, max_abs 3.576e-07).
- First-out median ≈1.0 ms (p95 ≈1.2–1.7 ms), service ≈1.05 ms.
- Saturated ≈890 requests/s at 1600 offered/s (≈8000 output chunks/s).
- Gaps median ≈0.007 ms, p95 ≈0.011 ms, >20 ms = 0.
- Δ vs reference: ≈10× request throughput, ≈2× lower first-output latency.
- Trade-off/risk: the first request of a session/reset pays a one-time
  ≈170 ms graph capture; the worker falls back to eager `full_fused` if
  capture fails. This is recorded as an explicit trade-off (steady-state
  benchmark warm-up absorbs it).

## Failures and fixes (kept as evidence)
- First graph attempt allocated `gh0` with 2H channels, but the first conv's
  history is the raw input with C channels; second attempt swapped `gh0/gh1`.
  Both were fixed and the direct reproduction
  (`benchmarks/debug_graph.py`) then reported graph replay ≈0.3–0.5 ms.
- Streaming and chunked variants are slower than whole-request batching; they
  remain measured regression evidence, not promoted.

## Remaining gaps (honest status)
- The session measured 7 distinct deployment variants, below the repo's
  10-variant floor. No additional variant is claimed.
- The final independent `workspace.verify` / `workspace.benchmark` tool runs
  for the recommended entry are recorded outside the writable workspace; the
  in-repo harness evidence is the files cited above.
- Multi-GPU exploration does not apply on the assigned single GPU.
