"""Run the shared verification harness for the CUDA-graph variant."""
import runpy
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.argv = [str(HERE / 'verify.py'), '--variant', 'graph']
runpy.run_path(str(HERE / 'verify.py'), run_name='__main__')
