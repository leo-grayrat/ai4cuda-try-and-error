"""Paired offered-load benchmark for the branch_features backend family.

Runs the reference backend and candidate variants as subprocesses through the
shared adapter with finite offered-load sweeps (varied inputs per request).
Reports, per offered rate, the achieved request rate, first-output latency,
per-request service time and the consumer-side inter-chunk gap distribution
(the app's natural chunk budget for this task is 20 ms).

Usage:
  python flashrt/apps/branch_features/backend/benchmarks/benchmark.py \
      [--variants full_fused full chunked stream cpu_fused cpu_full] [--no-reference]
"""
import argparse
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]
REFERENCE = REPO / 'flashrt/apps/branch_features/reference.py'
CANDIDATE = REPO / 'flashrt/apps/branch_features/backend/worker.py'
RESULTS = Path(__file__).resolve().parent / 'results'
CHUNK_BUDGET_S = 0.020
RATES = [50, 100, 200, 400, 800, 1600]
N_PER_RATE = 24


def make_config(prefix):
    return {'repository': str(REPO), 'device': 'cuda', 'prefix': prefix,
            'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
            'weight_seed': 20240607}


def launch(script, config_path, variant=None):
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = env.get('CUDA_VISIBLE_DEVICES', '0')
    env.pop('BRANCH_FEATURES_VARIANT', None)
    if variant:
        env['BRANCH_FEATURES_VARIANT'] = variant
    kwargs = {}
    if os.name == 'nt':
        kwargs['creationflags'] = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    else:
        kwargs['start_new_session'] = True
    proc = subprocess.Popen(
        [sys.executable, '-u', str(script), '--repository', str(REPO),
         '--config', str(config_path)],
        cwd=str(REPO), env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, **kwargs)
    line = proc.stdout.readline()
    if not line:
        raise RuntimeError(f'backend failed to start: {script}\n{proc.stderr.read()}')
    return proc, json.loads(line)


def stop(proc):
    try:
        proc.terminate()
        proc.wait(timeout=20)
    except Exception:
        try:
            if not os.name == 'nt':
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            else:
                proc.kill()
        except Exception:
            pass
        try:
            proc.wait(timeout=10)
        except Exception:
            pass


def stats(values):
    if not values:
        return {'n': 0}
    a = np.asarray(values, dtype=np.float64)
    return {'n': int(a.size), 'mean_ms': 1000 * float(a.mean()),
            'median_ms': 1000 * float(np.percentile(a, 50)),
            'p95_ms': 1000 * float(np.percentile(a, 95)),
            'max_ms': 1000 * float(a.max())}


def run_one(script, variant, config, tag):
    from branch_features.adapter import FeatureAdapter
    cfg_path = RESULTS / f'config_{tag}.json'
    cfg_path.write_text(json.dumps(config), encoding='utf-8')
    rng = np.random.RandomState(1234)
    features = [(rng.randn(config['channels'], config['length']) * s).astype(np.float32)
                for s in rng.uniform(0.5, 1.5, size=256)]
    proc, ready = launch(script, cfg_path, variant)
    adapter = None
    record = {'tag': tag, 'variant': variant, 'script': str(script),
              'device': ready.get('device'), 'rates': {}, 'chunk_budget_s': CHUNK_BUDGET_S,
              'n_per_rate': N_PER_RATE}
    try:
        adapter = FeatureAdapter(config)
        adapter.start()
        for _ in range(6):  # warm-up: CUDA context, cuDNN kernels, shared buffers
            adapter.submit(features[0])
            while adapter.pending is not None:
                adapter.receive(timeout_s=60)
        cursor = 0
        for rate in RATES:
            first, done, gaps, services = [], [], [], []
            started = time.perf_counter()
            for index in range(N_PER_RATE):
                target = started + index / rate
                delay = target - time.perf_counter()
                if delay > 0:
                    time.sleep(delay)
                feats = features[cursor % len(features)]
                cursor += 1
                _, published = adapter.submit(feats)
                t_first = t_prev = None
                while adapter.pending is not None:
                    data, observed = adapter.receive(timeout_s=60)
                    if t_first is None:
                        t_first = observed
                    if t_prev is not None:
                        gaps.append((observed - t_prev) / 1e9)
                    t_prev = observed
                t_end = time.perf_counter_ns()
                first.append((t_first - published) / 1e9)
                done.append((t_end - published) / 1e9)
                services.append((t_end - published) / 1e9)
            elapsed = time.perf_counter() - started
            gaps_arr = np.asarray(gaps, dtype=np.float64)
            over = float((gaps_arr > CHUNK_BUDGET_S).mean()) if gaps_arr.size else 0.0
            entry = {'offered_rate': rate,
                     'achieved_rate': N_PER_RATE / elapsed,
                     'first_out': stats(first), 'service': stats(done),
                     'gaps': stats(gaps),
                     'gap_over_budget_fraction': over}
            record['rates'][str(rate)] = entry
            print(f'[bench] {tag:16s} offered={rate:5d}/s achieved={entry["achieved_rate"]:8.1f}/s '
                  f'first_med={entry["first_out"]["median_ms"]:6.3f}ms '
                  f'first_p95={entry["first_out"]["p95_ms"]:6.3f}ms '
                  f'svc_med={entry["service"]["median_ms"]:6.3f}ms '
                  f'gap_med={entry["gaps"]["median_ms"]:6.3f}ms '
                  f'gap_p95={entry["gaps"]["p95_ms"]:6.3f}ms '
                  f'over20ms={over:.3f}', flush=True)
        adapter.terminate()
        adapter.close()
        adapter = None
        proc.wait(timeout=30)
    finally:
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
        stop(proc)
        try:
            cfg_path.unlink()
        except OSError:
            pass
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variants', nargs='*',
                        default=['full_fused', 'full', 'chunked', 'stream',
                                 'cpu_fused', 'cpu_full'])
    parser.add_argument('--no-reference', action='store_true')
    parser.add_argument('--candidate', type=Path, default=CANDIDATE)
    args = parser.parse_args()
    sys.path.insert(0, str(REPO))
    RESULTS.mkdir(parents=True, exist_ok=True)
    import torch
    hardware = torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'cpu-only'
    stamp = time.strftime('%Y%m%d_%H%M%S')
    records = []
    if not args.no_reference:
        records.append(run_one(REFERENCE, None,
                               make_config(f'bf_ref_{uuid.uuid4().hex[:8]}'),
                               f'reference_{stamp}'))
    for variant in args.variants:
        records.append(run_one(args.candidate, variant,
                               make_config(f'bf_{variant}_{uuid.uuid4().hex[:8]}'),
                               f'{variant}_{stamp}'))
    summary = {'hardware': hardware, 'stamp': stamp, 'candidate': str(args.candidate),
               'records': records}
    out = RESULTS / f'branch_features_sweep_{stamp}.json'
    out.write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(f'[bench] wrote {out}', flush=True)


if __name__ == '__main__':
    main()
