"""Benchmark the CUDA-graph variant against full_fused in one sweep."""
import runpy
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.argv = [str(HERE / 'benchmark.py'), '--variants', 'full_fused', 'graph',
            '--no-reference']
runpy.run_path(str(HERE / 'benchmark.py'), run_name='__main__')
