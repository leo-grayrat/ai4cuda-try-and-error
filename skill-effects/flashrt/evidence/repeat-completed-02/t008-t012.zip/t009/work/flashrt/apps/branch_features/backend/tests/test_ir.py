"""Phase 2 IR validation: SequentialExecutor vs the reference backend.

The reference backend is launched as a subprocess and driven through the
shared adapter by tests/verify.py's scenario runner.  The IR executor is run
over the same chunks on the CPU; both outputs are compared element-wise.
Also prints summarize_graph() output so the deployment decisions can cite it.
"""
import json
import math
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]
BACKEND = Path(__file__).resolve().parents[1]
TESTS = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(BACKEND))
sys.path.insert(0, str(TESTS))

import torch
from flashrt.ir import SequentialExecutor, summarize_graph
from branch_features.model import build_layers
from verify import REFERENCE, make_config, run_scenario
from ir.graph_builder import build_model_graph
from ir.graph_builder import HISTORY_NAMES

ATOL = 1e-4  # fp32 CUDA convs vs fp32 CPU convs reorder accumulation


def main():
    from branch_features.model import ReferencePipeline  # noqa: F401  (weights oracle)
    config = make_config('ir_validation')
    rng = np.random.RandomState(11)
    scenario = [(rng.randn(16, 1043).astype(np.float32), False),
                (rng.randn(16, 1043).astype(np.float32), False)]
    ref_outputs, ready = run_scenario(REFERENCE, config, scenario)
    print(f'[ir] reference banner: {ready}', flush=True)

    layers = build_layers(str(REPO), config, 'cpu')
    graph = build_model_graph(layers)
    print(f'[ir] graph: {len(graph.operators)} ops, {len(graph.edges)} edges, '
          f'{len(graph.state_objects)} state objects', flush=True)
    executor = SequentialExecutor(graph)
    executor.init_state({name: None for name in HISTORY_NAMES.values()})

    class Ctx:
        pass
    ctx = Ctx()
    worst = 0.0
    for request_index, (features, _reset) in enumerate(scenario):
        chunks = []
        for position in range(0, config['length'], config['chunk']):
            piece = torch.from_numpy(features[:, position:position + config['chunk']].copy()).unsqueeze(0)
            with torch.inference_mode():
                out = executor.run_chunk({'features': piece}, ctx)['merged']
            chunks.append(out[0].numpy().copy())
        got = np.concatenate(chunks, axis=-1)
        want = ref_outputs[request_index]
        diff = float(np.abs(got - want).max())
        worst = max(worst, diff)
        print(f'[ir] request {request_index}: max_abs={diff:.3e}', flush=True)
    summary = summarize_graph(graph)
    out_dir = BACKEND / 'notes'
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / 'ir_analysis.txt').write_text(str(summary), encoding='utf-8')
    print(summary, flush=True)
    verdict = 'PASS' if worst <= ATOL else 'FAIL'
    result = {'verdict': verdict, 'max_abs': worst, 'atol': ATOL,
              'graph_ops': len(graph.operators), 'graph_edges': len(graph.edges),
              'reference_ready': ready}
    (TESTS / 'fixtures' / 'ir_result.json').write_text(json.dumps(result, indent=2),
                                                       encoding='utf-8')
    print(f'[ir] verdict: {verdict} (max_abs={worst:.3e}, atol={ATOL})', flush=True)
    return 0 if verdict == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
