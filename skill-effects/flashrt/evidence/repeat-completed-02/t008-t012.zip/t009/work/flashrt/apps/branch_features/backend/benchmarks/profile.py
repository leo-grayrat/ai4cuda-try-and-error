"""Micro-profile of backend-side costs (no adapter, no subprocess)."""
import sys
import time
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]
BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(BACKEND))

import torch
from branch_features.model import build_layers
from worker import Pipeline, publish_whole

config = {'repository': str(REPO), 'device': 'cuda', 'channels': 16, 'hidden': 32,
          'length': 1043, 'chunk': 127, 'weight_seed': 20240607}
torch.backends.cudnn.benchmark = False
layers = build_layers(str(REPO), config, 'cuda')
x1 = np.random.RandomState(0).randn(1, 16, 1043).astype(np.float32)
x = x1[0]


def timed(fn, n=200):
    for _ in range(10):
        fn()
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(n):
        fn()
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / n * 1e3


for variant in ('full_fused', 'full', 'chunked'):
    pipe = Pipeline(layers, config, 'cuda', variant)
    with torch.inference_mode():
        full_ms = timed(lambda: pipe.run(x1))
        pipe.reset()
        pipe.run(x1)
        torch.cuda.synchronize()
        xfer_ms = timed(lambda: pipe._to_device(x1))
        out = pipe.run(x1)
        torch.cuda.synchronize()
        d2h_ms = timed(lambda: out.detach().to('cpu').numpy(), n=100)
    print(f'{variant:12s} run={full_ms:7.3f}ms  h2d={xfer_ms:7.3f}ms  d2h={d2h_ms:7.3f}ms')

# publish cost with throwaway shared buffers
from branch_features.adapter import open_buffers, close_buffers
cfg = dict(config, prefix=f'prof_{int(time.time()*1000)}')
bufs = open_buffers(cfg, create=True)
try:
    out = torch.randn(1, 16, 1043, device='cuda')
    t0 = time.perf_counter()
    for i in range(500):
        publish_whole(bufs, out, i, cfg, np)
    print(f'publish_whole per request: {(time.perf_counter()-t0)/500*1e3:.3f}ms')
finally:
    close_buffers(bufs, unlink=True)
