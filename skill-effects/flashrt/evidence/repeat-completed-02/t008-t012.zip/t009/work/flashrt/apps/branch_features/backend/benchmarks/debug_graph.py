"""Direct debug of the CUDA-graph variant (no adapter)."""
import sys
import time
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]
BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(BACKEND))
import torch
from branch_features.model import build_layers
from worker import Pipeline

config = {'repository': str(REPO), 'device': 'cuda', 'channels': 16, 'hidden': 32,
          'length': 1043, 'chunk': 127, 'weight_seed': 20240607}
layers = build_layers(str(REPO), config, 'cuda')
pipe = Pipeline(layers, config, 'cuda', 'graph')
x = np.random.RandomState(0).randn(1, 16, 1043).astype(np.float32)
with torch.inference_mode():
    for index in range(5):
        t0 = time.perf_counter()
        out = pipe.run(x)
        torch.cuda.synchronize()
        print(f'request {index}: {(time.perf_counter()-t0)*1e3:.2f}ms '
              f'graph={pipe.graph is not None}', flush=True)
        time.sleep(0.1)
print('ok', flush=True)
