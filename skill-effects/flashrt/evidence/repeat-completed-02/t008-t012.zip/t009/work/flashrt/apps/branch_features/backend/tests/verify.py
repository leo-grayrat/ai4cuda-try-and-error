"""End-to-end correctness harness: candidate backend vs CPU full-sequence oracle.

Launches the user's reference backend and the candidate backend as separate
subprocesses, drives both through the shared branch_features adapter with the
same six-request scenario (continuation, repeated input without reset, reset,
tail chunks) and compares every reconstructed request against an independent
CPU full-sequence oracle.

Usage:
  python flashrt/apps/branch_features/backend/tests/verify.py \
      --candidate flashrt/apps/branch_features/backend/worker.py [--variant NAME]
"""
import argparse
import json
import math
import os
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[5]
REFERENCE = REPO / 'flashrt/apps/branch_features/reference.py'
FIXTURES = Path(__file__).resolve().parent / 'fixtures'


def make_config(prefix):
    return {'repository': str(REPO), 'device': 'cuda', 'prefix': prefix,
            'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
            'weight_seed': 20240607}


def launch(script, config_path, variant=None):
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = env.get('CUDA_VISIBLE_DEVICES', '0')
    env.pop('BRANCH_FEATURES_VARIANT', None)
    if variant:
        env['BRANCH_FEATURES_VARIANT'] = variant
    kwargs = {}
    if os.name == 'nt':
        kwargs['creationflags'] = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    else:
        kwargs['start_new_session'] = True
    proc = subprocess.Popen(
        [sys.executable, '-u', str(script), '--repository', str(REPO),
         '--config', str(config_path)],
        cwd=str(REPO), env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, **kwargs)
    line = proc.stdout.readline()
    if not line:
        err = proc.stderr.read()
        raise RuntimeError(f'backend failed to start: {script}\n{err}')
    ready = json.loads(line)
    if not ready.get('ready'):
        raise RuntimeError(f'unexpected backend banner: {line}')
    return proc, ready


def stop(proc):
    try:
        proc.terminate()
        proc.wait(timeout=20)
    except Exception:
        try:
            if os.name == 'nt':
                proc.kill()
            else:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except Exception:
            pass
        try:
            proc.wait(timeout=10)
        except Exception:
            pass


def run_scenario(script, config, scenario, variant=None):
    """scenario: list of (features, reset_before). Returns list of (C,T) arrays."""
    (FIXTURES).mkdir(parents=True, exist_ok=True)
    cfg_path = FIXTURES / f'config_{config["prefix"]}.json'
    cfg_path.write_text(json.dumps(config), encoding='utf-8')
    from branch_features.adapter import FeatureAdapter
    proc, ready = launch(script, cfg_path, variant)
    adapter = None
    outputs = []
    try:
        adapter = FeatureAdapter(config)
        adapter.start()
        for features, do_reset in scenario:
            if do_reset:
                adapter.reset()
            adapter.submit(features)
            chunks = []
            while adapter.pending is not None:
                data, _ = adapter.receive(timeout_s=60)
                chunks.append(np.asarray(data, dtype=np.float32).copy())
            outputs.append(np.concatenate(chunks, axis=-1))
        adapter.terminate()
        adapter.close()
        adapter = None
        proc.wait(timeout=30)
    finally:
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
        stop(proc)
        try:
            cfg_path.unlink()
        except OSError:
            pass
    return outputs, ready


def oracle_groups(scenario):
    """CPU full-sequence oracle for each reset-delimited group."""
    from branch_features.model import full_sequence_oracle
    groups, current, start = [], [], 0
    for index, (features, do_reset) in enumerate(scenario):
        if do_reset and current:
            groups.append((start, index, current))
            current, start = [], index
        current.append(features)
    if current:
        groups.append((start, len(scenario), current))
    result = []
    config = make_config('oracle')
    for _, _, feats in groups:
        joined = np.concatenate(feats, axis=-1)
        full = np.asarray(full_sequence_oracle(str(REPO), config, joined), dtype=np.float32)
        offset = 0
        for item in feats:
            width = item.shape[-1]
            result.append(full[:, offset:offset + width].copy())
            offset += width
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path,
                        default=REPO / 'flashrt/apps/branch_features/backend/worker.py')
    parser.add_argument('--variant', default=None)
    parser.add_argument('--atol', type=float, default=1e-4)
    parser.add_argument('--rtol', type=float, default=1e-4)
    args = parser.parse_args()
    sys.path.insert(0, str(REPO))

    rng = np.random.RandomState(7)
    length, channels = 1043, 16

    def sample(scale=1.0):
        return (rng.randn(channels, length) * scale).astype(np.float32)

    r1, r2 = sample(), sample(0.7)
    scenario = [
        (r1, False),          # first request after start
        (r2, False),          # continuation, no reset
        (r2.copy(), False),   # repeated input without reset
        (sample(1.3), True),  # reset clears all four histories
        (sample(), False),    # continuation after reset
        (sample(0.5), False), # another continuation; every request has a tail
    ]
    print(f'[verify] scenario: {len(scenario)} requests, length={length}, chunk=127, '
          f'tail={length % 127}', flush=True)
    manifest = {'scenario': 'six_requests', 'candidate': str(args.candidate),
                'variant': args.variant, 'atol': args.atol, 'rtol': args.rtol}
    failures = 0
    verdicts = {}
    for label, script, variant in (
            ('reference', REFERENCE, None),
            ('candidate', args.candidate, args.variant)):
        print(f'[verify] running {label}: {script}', flush=True)
        outputs, ready = run_scenario(script, make_config(f'bf_{label}_{uuid.uuid4().hex[:10]}'),
                                      scenario, variant)
        verdicts[label] = (outputs, ready)
    oracle = oracle_groups(scenario)
    for label in ('reference', 'candidate'):
        outputs, ready = verdicts[label]
        if len(outputs) != len(oracle):
            print(f'[verify] FAIL {label}: got {len(outputs)} outputs, expected {len(oracle)}')
            failures += 1
            continue
        worst_abs, worst_rel, worst_idx = 0.0, 0.0, -1
        stats = []
        for index, (got, want) in enumerate(zip(outputs, oracle)):
            if got.shape != want.shape:
                print(f'[verify] FAIL {label} request {index}: shape {got.shape} != {want.shape}')
                failures += 1
                stats.append(None)
                continue
            diff = np.abs(got - want)
            denom = np.maximum(np.abs(want), 1e-6)
            rel = float(np.max(diff / denom))
            mx = float(diff.max())
            stats.append((mx, rel))
            if mx > worst_abs:
                worst_abs, worst_rel, worst_idx = mx, rel, index
        close = all(s is not None and s[0] <= args.atol + args.rtol * 1.0 for s in stats)
        print(f'[verify] {label}: ready={ready.get("variant", "reference")} '
              f'max_abs={worst_abs:.3e} (request {worst_idx}) max_rel={worst_rel:.3e}', flush=True)
        for index, stat in enumerate(stats):
            if stat is not None:
                print(f'[verify]   request {index}: max_abs={stat[0]:.3e} max_rel={stat[1]:.3e}')
        if not close:
            failures += 1
        manifest[label] = {'max_abs': worst_abs, 'max_rel': worst_rel,
                           'per_request': stats, 'ready': ready}
    manifest['verdict'] = 'PASS' if failures == 0 else 'FAIL'
    (FIXTURES / 'verify_result.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(f'[verify] verdict: {manifest["verdict"]}  '
          f'(atol={args.atol}, rtol={args.rtol}; tolerance justified by fp32 convolution '
          f'accumulation order differing between CPU oracle and CUDA kernels)', flush=True)
    return 0 if failures == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
