# branch_features backend

Recommended entry: `flashrt/apps/branch_features/backend/worker.py`.
It is a standalone backend that speaks the unchanged `branch_features.adapter`
contract (the same one used by `branch_features.reference`).

## Launch (standalone, repo root)

```bash
python flashrt/apps/branch_features/backend/worker.py \
  --repository <repo-root> \
  --config <config.json>
```

`<config.json>` is the same runtime config the reference worker consumes:
`device`, `prefix`, `channels`, `hidden`, `length`, `chunk`, `weight_seed`.
The worker creates the shared-memory control/input/output/metadata buffers,
prints a `{"ready": true, ...}` banner, and serves the adapter control
opcodes (1 start, 2 terminate, 3 reset).

The unchanged frontend under `flashrt/apps/branch_features/frontend/` can be
pointed at this exact launch surface; nothing in the adapter or frontend was
modified.

### Variant selection (development lever, not required by the frontend)

`config["variant"]` or the `BRANCH_FEATURES_VARIANT` environment variable
selects one of: `graph` (default; two fused convolutions captured in one CUDA
graph), `full_fused`, `full`, `chunked`, `stream`, `cpu_fused`, `cpu_full`.
An unsupported CUDA-graph capture falls back to `full_fused` automatically.

## What changed

The reference evaluates one 127-sample chunk at a time with a host->device
upload and a device->host download per chunk. Causal convolution is shift
invariant and the four histories are chunk-persistent, so a whole request is
one causal sequence. The recommended worker:

1. keeps the four convolution histories on the device,
2. evaluates the whole request with two block-diagonal 5-tap convolutions
   (a0+b0 share the input stream; a1+b1 form one block-diagonal kernel),
3. downloads the whole request output once and publishes all 9 chunks in one
   output-ring and one metadata-ring write,
4. captures the fused request computation in a CUDA graph and replays it on
   later requests.

## Evidence

- `tests/verify.py`: six-request end-to-end comparison against the protected
  reference backend and the independent CPU full-sequence oracle
  (`tests/fixtures/verify_result.json`).
- `tests/verify_graph.py`: same harness for the default CUDA-graph variant.
- `tests/test_ir.py`: Phase-2 `SequentialExecutor` validation and
  `summarize_graph()` output (`notes/ir_analysis.txt`).
- `benchmarks/benchmark.py`: paired reference/candidate offered-load sweep,
  inter-chunk gap distributions and 20 ms budget accounting
  (`benchmarks/results/*.json`).
- `notes/experiment_log.md`: hypotheses, IR basis, per-variant results and the
  remaining gaps.
