"""Fix the IR harness scenario unpacking and run the Phase-2 validation."""
import runpy
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
test_ir = HERE / 'tests' / 'test_ir.py'
text = test_ir.read_text(encoding='utf-8')
old = '    for request_index, features in enumerate(scenario):'
new = '    for request_index, (features, _reset) in enumerate(scenario):'
assert text.count(old) == 1
test_ir.write_text(text.replace(old, new), encoding='utf-8')
sys.argv = [str(test_ir)]
runpy.run_path(str(test_ir), run_name='__main__')
