"""IR graph for the two-branch causal-feature model (Phases 1-2)."""
from flashrt.ir import IRGraph, IREdge, StateObject, TensorPort

from .ops import CausalConvOp, GateMergeOp, SiluOp

HISTORY_NAMES = {'a0': 'hist_a0', 'a1': 'hist_a1', 'b0': 'hist_b0', 'b1': 'hist_b1'}


def build_model_graph(layers):
    """Build the model-level graph: two independent causal branches + gate.

    Branch A: a0 (C->H, k=5) -> SiLU -> a1 (H->C, k=3)
    Branch B: b0 (C->H, k=3) -> SiLU -> b1 (H->C, k=5)
    The four convolutions own disjoint chunk-persistent histories; only the
    final gate/merge joins the branches, so A and B are data-parallel work.
    """
    graph = IRGraph(name='branch_features_model')
    graph.external_inputs = [TensorPort('features')]
    graph.external_outputs = [TensorPort('merged')]
    for name in HISTORY_NAMES.values():
        graph.add_state(StateObject(name=name, scope='chunk_persistent',
                                    description='last k-1 convolution inputs'))

    ops = [
        CausalConvOp('conv_a0', layers['a0'], HISTORY_NAMES['a0'], 'features'),
        SiluOp('silu_a'),
        CausalConvOp('conv_a1', layers['a1'], HISTORY_NAMES['a1']),
        CausalConvOp('conv_b0', layers['b0'], HISTORY_NAMES['b0'], 'features'),
        SiluOp('silu_b'),
        CausalConvOp('conv_b1', layers['b1'], HISTORY_NAMES['b1']),
        GateMergeOp('gate_merge'),
    ]
    for op in ops:
        graph.add_operator(op)
    graph.chunk_ops = [op.name for op in ops]

    def edge(src, src_port, dst, dst_port):
        graph.add_edge(IREdge(src, src_port, dst, dst_port))

    edge('conv_a0', 'y', 'silu_a', 'x')
    edge('silu_a', 'y', 'conv_a1', 'x')
    edge('conv_b0', 'y', 'silu_b', 'x')
    edge('silu_b', 'y', 'conv_b1', 'x')
    edge('conv_a1', 'y', 'gate_merge', 'a')
    edge('conv_b1', 'y', 'gate_merge', 'b')
    return graph
