"""IR operators for the branch_features model. Phases 1-2."""
import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort


class CausalConvOp(IROperator):
    """One causal convolution with its own cross-chunk input history."""

    def __init__(self, name, layer, history_name, input_name='x'):
        super().__init__(
            name=name, op_type=OpType.EXPOSED,
            inputs=[TensorPort(input_name)], outputs=[TensorPort('y')],
            state_reads=[history_name], state_writes=[history_name],
            stream_mode=StreamMode.BATCH,
            config={'kernel': layer._time_causal_padding[0] + 1})
        self.layer = layer
        self.history_name = history_name
        self.input_name = input_name

    def execute(self, inputs, ctx, state):
        x = inputs[self.input_name]
        history = state.get(self.history_name)
        joined = x if history is None else torch.cat([history, x], dim=-1)
        out = self.layer(joined)
        pad = self.layer._time_causal_padding[0]
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        state.set(self.history_name, joined[:, :, -pad:].clone() if pad else None)
        return {'y': out}


class SiluOp(IROperator):
    def __init__(self, name):
        super().__init__(name=name, op_type=OpType.EXPOSED,
                         inputs=[TensorPort('x')], outputs=[TensorPort('y')])

    def execute(self, inputs, ctx, state):
        return {'y': F.silu(inputs['x'])}


class GateMergeOp(IROperator):
    """sigmoid(mean_c(features)) * A + (1-gate) * B + 0.1 * features."""

    def __init__(self, name):
        super().__init__(
            name=name, op_type=OpType.EXPOSED,
            inputs=[TensorPort('features'), TensorPort('a'), TensorPort('b')],
            outputs=[TensorPort('merged')])

    def execute(self, inputs, ctx, state):
        features = inputs['features']
        gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
        merged = gate * inputs['a'] + (1 - gate) * inputs['b'] + 0.1 * features
        return {'merged': merged}
