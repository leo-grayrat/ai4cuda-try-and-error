from pathlib import Path

root = Path(__file__).resolve().parent
w = root / "workerlib.py"
text = w.read_text(encoding="utf-8")
text = text.replace(
    "        y0 = y0[:, :, self.k:]\n",
    "        if use_history:\n            y0 = y0[:, :, self.k:]\n",
)
text = text.replace(
    "        y1 = y1[:, :, self.k:]\n",
    "        if use_history:\n            y1 = y1[:, :, self.k:]\n",
)
w.write_text(text, encoding="utf-8")

g = root / "ir" / "graph_builder.py"
text = g.read_text(encoding="utf-8")
text = text.replace(
    "        y = y[:, :, 4:]\n",
    "        if history is not None:\n            y = y[:, :, 4:]\n",
)
g.write_text(text, encoding="utf-8")
print("patched")
