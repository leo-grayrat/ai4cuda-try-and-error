"""IR conversion of branch_features: reference chunk graph and fused graph.

The reference graph mirrors branch_features.reference exactly: four
independent causal convolutions, each with its own chunk-persistent history
state, two SiLU activations, and a gate+merge step.  The fused graph mirrors
the optimized worker: the two k=5/k=3 branch heads are combined into one
16->64 k=5 convolution (k=3 weights zero-left-padded) and the two branch
tails into one grouped 64->32 k=5 convolution, with two fused histories.

State dependencies are declared on the operators so the IR analysis tools
can derive cross-chunk independence and pipeline stages.
"""
import torch
import torch.nn.functional as F

from flashrt.ir.graph import (
    IRGraph,
    IREdge,
    IROperator,
    OpType,
    StateObject,
    StreamMode,
    StreamingInfo,
    StreamingPattern,
    TensorPort,
)


class ReferenceConv(IROperator):
    """One CausalConv1d from the reference, with its own history state."""

    def __init__(self, op_name, layer, history_name):
        super().__init__(
            name=op_name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("features")],
            outputs=[TensorPort("y")],
            state_reads=[history_name],
            state_writes=[history_name],
            stream_mode=StreamMode.STREAMING,
        )
        self.layer = layer
        self.history_name = history_name

    def execute(self, inputs, ctx, state):
        x = inputs["features"]
        history = state.get(self.history_name)
        joined = x if history is None else torch.cat([history, x], dim=-1)
        out = self.layer(joined)
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        state.set(self.history_name, joined[:, :, -self.layer._time_causal_padding[0]:].clone())
        return {"y": out}


class Silu(IROperator):
    def __init__(self, op_name):
        super().__init__(
            name=op_name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("features")],
            outputs=[TensorPort("y")],
            stream_mode=StreamMode.STREAMING,
        )

    def execute(self, inputs, ctx, state):
        return {"y": F.silu(inputs["features"])}


class GateMerge(IROperator):
    def __init__(self, op_name):
        super().__init__(
            name=op_name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("features"), TensorPort("branch_a"), TensorPort("branch_b")],
            outputs=[TensorPort("out")],
            stream_mode=StreamMode.BATCH,
        )

    def execute(self, inputs, ctx, state):
        features = inputs["features"]
        gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
        out = gate * inputs["branch_a"] + (1.0 - gate) * inputs["branch_b"] + 0.1 * features
        return {"out": out}


class FusedHead(IROperator):
    def __init__(self, op_name, layers, history_name):
        a0, b0 = layers["a0"], layers["b0"]
        self.weight = torch.cat(
            [a0.conv.weight.detach(), F.pad(b0.conv.weight.detach(), (2, 0))], dim=0
        ).contiguous()
        self.bias = torch.cat([a0.conv.bias.detach(), b0.conv.bias.detach()], dim=0).contiguous()
        super().__init__(
            name=op_name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("features")],
            outputs=[TensorPort("y")],
            state_reads=[history_name],
            state_writes=[history_name],
            stream_mode=StreamMode.BATCH,
        )
        self.history_name = history_name

    def execute(self, inputs, ctx, state):
        x = inputs["features"]
        history = state.get(self.history_name)
        joined = x if history is None else torch.cat([history, x], dim=-1)
        y = F.conv1d(F.pad(joined, (4, 0), mode="replicate"), self.weight, self.bias)
        if history is not None:
            y = y[:, :, 4:]
        state.set(self.history_name, joined[:, :, -4:])
        return {"y": y}


class FusedTail(IROperator):
    def __init__(self, op_name, layers, history_name):
        a1, b1 = layers["a1"], layers["b1"]
        self.weight = torch.cat(
            [F.pad(a1.conv.weight.detach(), (2, 0)), b1.conv.weight.detach()], dim=0
        ).contiguous()
        self.bias = torch.cat([a1.conv.bias.detach(), b1.conv.bias.detach()], dim=0).contiguous()
        super().__init__(
            name=op_name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("features")],
            outputs=[TensorPort("y")],
            state_reads=[history_name],
            state_writes=[history_name],
            stream_mode=StreamMode.BATCH,
        )
        self.history_name = history_name

    def execute(self, inputs, ctx, state):
        x = inputs["features"]
        history = state.get(self.history_name)
        joined = x if history is None else torch.cat([history, x], dim=-1)
        y = F.conv1d(
            F.pad(joined, (4, 0), mode="replicate"), self.weight, self.bias, groups=2
        )
        if history is not None:
            y = y[:, :, 4:]
        state.set(self.history_name, joined[:, :, -4:])
        return {"y": y}


class FusedMerge(IROperator):
    def __init__(self, op_name, channels):
        super().__init__(
            name=op_name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("features"), TensorPort("branch_y")],
            outputs=[TensorPort("out")],
            stream_mode=StreamMode.BATCH,
        )
        self.channels = channels

    def execute(self, inputs, ctx, state):
        features = inputs["features"]
        y = inputs["branch_y"]
        gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
        out = gate * y[:, : self.channels] + (1.0 - gate) * y[:, self.channels:] + 0.1 * features
        return {"out": out}


def _streaming(chunk):
    return StreamingInfo(
        pattern=StreamingPattern.FIXED_RATE,
        src_chunk_size=chunk,
        dst_chunk_size=chunk,
        description="one feature chunk per adapter output slot",
    )


def build_reference_graph(layers, config):
    """Reference chunk-periodic dependency graph (four independent histories)."""
    chunk = int(config["chunk"])
    graph = IRGraph(name="branch_features_reference_chunk")
    for name in ("a0_hist", "a1_hist", "b0_hist", "b1_hist"):
        graph.add_state(StateObject(name, "last kernel-1 inputs of one conv branch",
                                    scope="chunk_persistent"))

    ops = {
        "conv_a0": ReferenceConv("conv_a0", layers["a0"], "a0_hist"),
        "conv_a1": ReferenceConv("conv_a1", layers["a1"], "a1_hist"),
        "conv_b0": ReferenceConv("conv_b0", layers["b0"], "b0_hist"),
        "conv_b1": ReferenceConv("conv_b1", layers["b1"], "b1_hist"),
        "silu_a": Silu("silu_a"),
        "silu_b": Silu("silu_b"),
        "gate_merge": GateMerge("gate_merge"),
    }
    for op in ops.values():
        graph.add_operator(op)
    graph.add_edge(IREdge("conv_a0", "y", "silu_a", "features"))
    graph.add_edge(IREdge("silu_a", "y", "conv_a1", "features"))
    graph.add_edge(IREdge("conv_b0", "y", "silu_b", "features"))
    graph.add_edge(IREdge("silu_b", "y", "conv_b1", "features"))
    graph.add_edge(IREdge("conv_a1", "y", "gate_merge", "branch_a", streaming=_streaming(chunk)))
    graph.add_edge(IREdge("conv_b1", "y", "gate_merge", "branch_b", streaming=_streaming(chunk)))
    graph.external_inputs = [TensorPort("features")]
    graph.external_outputs = [TensorPort("out")]
    graph.chunk_ops = [
        "conv_a0", "silu_a", "conv_a1", "conv_b0", "silu_b", "conv_b1", "gate_merge",
    ]
    return graph


def build_fused_graph(layers, config):
    """Optimized full-request graph with two fused branch-pair convolutions."""
    graph = IRGraph(name="branch_features_fused_full_sequence")
    graph.add_state(StateObject("f0_hist", "last 4 raw input features", scope="chunk_persistent"))
    graph.add_state(StateObject("f1_hist", "last 4 activated hidden features", scope="chunk_persistent"))
    ops = [
        FusedHead("fused_head", layers, "f0_hist"),
        Silu("fused_silu"),
        FusedTail("fused_tail", layers, "f1_hist"),
        FusedMerge("fused_merge", int(config["channels"])),
    ]
    for op in ops:
        graph.add_operator(op)
    graph.add_edge(IREdge("fused_head", "y", "fused_silu", "features"))
    graph.add_edge(IREdge("fused_silu", "y", "fused_tail", "features"))
    graph.add_edge(IREdge("fused_tail", "y", "fused_merge", "branch_y",
                          streaming=_streaming(int(config["length"]))))
    graph.external_inputs = [TensorPort("features")]
    graph.external_outputs = [TensorPort("out")]
    graph.chunk_ops = ["fused_head", "fused_silu", "fused_tail", "fused_merge"]
    return graph
