from pathlib import Path

p = Path(__file__).resolve().parent / "workerlib.py"
s = p.read_text(encoding="utf-8")

s = s.replace("import json\nimport os", "import json\nimport math\nimport os")

s = s.replace(
    "def load_task_module(name, repository):",
    "def _wait_until(deadline):\n"
    "    while True:\n"
    "        remaining = deadline - time.perf_counter()\n"
    "        if remaining <= 0:\n"
    "            return\n"
    "        if remaining > 0.002:\n"
    "            time.sleep(remaining - 0.001)\n"
    "\n\n"
    "def load_task_module(name, repository):",
)

s = s.replace(
    "        self.has_history = False\n        self.ref_histories",
    "        self.has_history = False\n        self.pace_period_s = None\n        self.ref_histories",
)

s = s.replace(
    "    def run_request(self, features_np, buffers, request_id):",
    "    def run_request(self, features_np, buffers, request_id, pace_period_s=None):",
)

old = (
    "        out = self._process_full(features_np)\n"
    "        for index, pos in enumerate(range(0, self.T, self.chunk)):\n"
    "            valid = min(self.chunk, self.T - pos)\n"
    "            self._emit(out[:, pos:pos + valid], buffers, request_id, index)\n"
)
new = (
    "        out = self._process_full(features_np)\n"
    "        n_chunks = math.ceil(self.T / self.chunk)\n"
    "        gap = 0.0\n"
    "        if pace_period_s:\n"
    "            # Spread this request's chunks over most of the recently\n"
    "            # observed inter-arrival period so successive output chunks\n"
    "            # stay smooth. The first chunk is never delayed.\n"
    "            span = max(0.0, min(0.016, pace_period_s - 0.004))\n"
    "            gap = span / max(1, n_chunks - 1)\n"
    "        started = time.perf_counter()\n"
    "        for index, pos in enumerate(range(0, self.T, self.chunk)):\n"
    "            if gap:\n"
    "                _wait_until(started + index * gap)\n"
    "            valid = min(self.chunk, self.T - pos)\n"
    "            self._emit(out[:, pos:pos + valid], buffers, request_id, index)\n"
)
assert old in s
s = s.replace(old, new)

s = s.replace(
    "    consumed, last_command, active = 0, 0, False",
    "    consumed, last_command, active = 0, 0, False\n    last_read = None",
)
s = s.replace(
    "                if opcode == 3:\n                    engine.reset()\n                    active = False",
    "                if opcode == 3:\n                    engine.reset()\n                    last_read = None\n                    active = False",
)
old2 = (
    "            request_id, consumed = consumed, next_cursor\n"
    "            engine.run_request(features[0], buffers, request_id)\n"
)
new2 = (
    "            now = time.perf_counter()\n"
    "            period = None\n"
    "            if last_read is not None:\n"
    "                interval = now - last_read\n"
    "                if 0.0005 < interval < 0.5:\n"
    "                    period = interval\n"
    "            last_read = now\n"
    "            request_id, consumed = consumed, next_cursor\n"
    "            engine.run_request(features[0], buffers, request_id, period)\n"
)
assert old2 in s
s = s.replace(old2, new2)

p.write_text(s, encoding="utf-8")
print("patched pacing")
