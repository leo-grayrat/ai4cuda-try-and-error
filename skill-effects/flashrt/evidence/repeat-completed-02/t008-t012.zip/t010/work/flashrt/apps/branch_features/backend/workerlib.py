"""Shared implementation for branch_features streaming workers.

Task: two independent causal-convolution branches over a (C, T) feature
sequence, gated by the channel mean of the current input:
    A = a1(silu(a0(x))), B = b1(silu(b0(x)))
    out = sigmoid(mean_c(x)) * A + (1 - gate) * B + 0.1 * x

Reference semantics: each conv keeps its own last (kernel-1) inputs across
chunks and across requests within a session; reset clears all histories.

This module offers several execution strategies behind the exact same
adapter protocol (see branch_features.adapter):
  * eager4        - reference-equivalent per-chunk schedule, four convs.
  * chunked_fused - per-chunk schedule, but a0/a1 and b0/b1 are fused into
                    two grouped convolution calls (zero-padded shorter
                    kernels), full 4-way history collapsed to two buffers.
  * fused_eager   - the same fused math but over the whole request sequence
                    in one shot (causal conv with k-1 history is exactly
                    equivalent to the per-chunk recurrence).
  * fused_graph   - fused_eager captured in a CUDA graph (recommended).
  * cpu_fused_eager - fused full-sequence on CPU.
  * fused_graph_spin - fused_graph with a short busy-poll window.
"""
import argparse
import importlib
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


def _wait_until(deadline):
    while True:
        remaining = deadline - time.perf_counter()
        if remaining <= 0:
            return
        if remaining > 0.002:
            time.sleep(remaining - 0.001)


def load_task_module(name, repository):
    """Import a task package module the same way the reference worker does."""
    repo = str(Path(repository).resolve())
    if repo not in sys.path:
        sys.path.insert(0, repo)
    try:
        return importlib.import_module(f"branch_features.{name}")
    except ModuleNotFoundError:
        return importlib.import_module(f"flashrt.apps.branch_features.{name}")


class BranchEngine:
    def __init__(self, repository, config, strategy="fused_graph"):
        self.config = dict(config)
        self.strategy = strategy
        self.C = int(config["channels"])
        self.H = int(config["hidden"])
        self.T = int(config["length"])
        self.chunk = int(config["chunk"])
        self.k = 4  # kernel-1 for the longest (5-tap) causal convolutions

        if strategy.startswith("cpu"):
            self.device = torch.device("cpu")
            torch.set_num_threads(int(config.get("cpu_threads", 4)))
        else:
            self.device = torch.device(config["device"])

        self.model_mod = load_task_module("model", repository)
        self.layers = self.model_mod.build_layers(repository, config, str(self.device))
        self.layers.eval()
        for parameter in self.layers.parameters():
            parameter.requires_grad_(False)

        self._fuse_weights()
        self.use_graph = (
            strategy in ("fused_graph", "fused_graph_spin")
            and self.device.type == "cuda"
        )
        self._reset_all()
        if self.use_graph:
            try:
                self._capture_graphs()
            except Exception as exc:  # graph capture is an optimization, never a contract
                print(json.dumps({"graph_capture_failed": repr(exc)}), flush=True)
                self.use_graph = False
                self._reset_all()

        pin = self.device.type == "cuda"
        self._out_host = torch.empty(1, self.C, self.T, pin_memory=pin)
        self._in_host = torch.empty(1, self.C, self.T, pin_memory=pin)
        self._padded = np.zeros((self.C, self.chunk), dtype=np.float32)
        self._meta = np.zeros((3,), dtype=np.int64)

    # ------------------------------------------------------------------ setup
    def _fuse_weights(self):
        """Fuse the two branch heads / tails into grouped, zero-padded convs.

        A same-length kernel alignment is obtained by left-padding the k=3
        weights with two zero taps.  The second conv sees (2H) channels and
        uses groups=2 so branch A and branch B never mix.
        """
        a0, a1 = self.layers["a0"], self.layers["a1"]
        b0, b1 = self.layers["b0"], self.layers["b1"]
        self.w0 = torch.cat(
            [a0.conv.weight.detach(), F.pad(b0.conv.weight.detach(), (2, 0))], dim=0
        ).contiguous()
        self.b0 = torch.cat(
            [a0.conv.bias.detach(), b0.conv.bias.detach()], dim=0
        ).contiguous()
        self.w1 = torch.cat(
            [F.pad(a1.conv.weight.detach(), (2, 0)), b1.conv.weight.detach()], dim=0
        ).contiguous()
        self.b1 = torch.cat(
            [a1.conv.bias.detach(), b1.conv.bias.detach()], dim=0
        ).contiguous()

    def _reset_all(self):
        device = self.device
        self.h0 = torch.zeros(1, self.C, self.k, device=device)
        self.h1 = torch.zeros(1, 2 * self.H, self.k, device=device)
        self.has_history = False
        self.pace_period_s = None
        self.ref_histories = {name: None for name in ("a0", "a1", "b0", "b1")}

    def reset(self):
        self._reset_all()

    # --------------------------------------------------------------- fused op
    def _forward_fused(self, x, use_history):
        """One causal pass over x (1, C, L) -> out (1, C, L), new histories."""
        if use_history:
            joined0 = torch.cat([self.h0, x], dim=-1)
        else:
            joined0 = x
        y0 = F.conv1d(F.pad(joined0, (self.k, 0), mode="replicate"), self.w0, self.b0)
        if use_history:
            y0 = y0[:, :, self.k:]
        act = F.silu(y0)

        if use_history:
            joined1 = torch.cat([self.h1, act], dim=-1)
        else:
            joined1 = act
        y1 = F.conv1d(
            F.pad(joined1, (self.k, 0), mode="replicate"), self.w1, self.b1, groups=2
        )
        if use_history:
            y1 = y1[:, :, self.k:]

        branch_a = y1[:, : self.C]
        branch_b = y1[:, self.C:]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        out = gate * branch_a + (1.0 - gate) * branch_b + 0.1 * x
        return out, joined0[:, :, -self.k:], joined1[:, :, -self.k:]

    def _capture_graphs(self):
        """Capture two static graphs: session-first (no history) and steady."""
        self._gx = torch.zeros(1, self.C, self.T, device=self.device)
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            with torch.no_grad():
                for _ in range(3):
                    self._forward_fused(self._gx, False)
                    self._forward_fused(self._gx, True)
        torch.cuda.current_stream().wait_stream(side)
        torch.cuda.synchronize()
        self._graph0, self._gout0 = self._capture_one(False)
        self._graph1, self._gout1 = self._capture_one(True)

    def _capture_one(self, use_history):
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            out, new_h0, new_h1 = self._forward_fused(self._gx, use_history)
            self.h0.copy_(new_h0)
            self.h1.copy_(new_h1)
        return graph, out

    # ------------------------------------------------------------ strategies
    def _conv_reference(self, name, x):
        layer = self.layers[name]
        history = self.ref_histories[name]
        joined = x if history is None else torch.cat([history, x], dim=-1)
        out = layer(joined)
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        self.ref_histories[name] = joined[
            :, :, -layer._time_causal_padding[0]:
        ].clone()
        return out

    def _step_eager4(self, chunk_np):
        x = torch.from_numpy(np.ascontiguousarray(chunk_np)).unsqueeze(0).to(self.device)
        with torch.no_grad():
            branch_a = self._conv_reference(
                "a1", F.silu(self._conv_reference("a0", x))
            )
            branch_b = self._conv_reference(
                "b1", F.silu(self._conv_reference("b0", x))
            )
            out = self.model_mod.gate_and_merge(x, branch_a, branch_b)
        return out[0].cpu().numpy()

    def _step_chunked_fused(self, chunk_np):
        x = torch.from_numpy(np.ascontiguousarray(chunk_np)).unsqueeze(0).to(self.device)
        with torch.no_grad():
            out, new_h0, new_h1 = self._forward_fused(x, self.has_history)
        self.h0, self.h1 = new_h0, new_h1
        self.has_history = True
        return out[0].cpu().numpy()

    def _process_full(self, features_np):
        if self.use_graph:
            torch.from_numpy(features_np)  # validate dtype/shape early
            self._in_host.copy_(torch.from_numpy(features_np))
            self._gx.copy_(self._in_host, non_blocking=True)
            graph = self._graph1 if self.has_history else self._graph0
            out = self._gout1 if self.has_history else self._gout0
            graph.replay()
            self._out_host.copy_(out, non_blocking=True)
            torch.cuda.current_stream().synchronize()
            self.has_history = True
            return self._out_host[0].numpy()

        x = torch.from_numpy(np.ascontiguousarray(features_np)).unsqueeze(0).to(self.device)
        with torch.no_grad():
            out, new_h0, new_h1 = self._forward_fused(x, self.has_history)
        self.h0, self.h1 = new_h0, new_h1
        self.has_history = True
        if self.device.type == "cuda":
            self._out_host.copy_(out)
            torch.cuda.current_stream().synchronize()
            return self._out_host[0].numpy()
        return out[0].numpy()

    # --------------------------------------------------------------- emitting
    def _emit(self, out_np, buffers, request_id, index):
        valid = int(out_np.shape[-1])
        padded = self._padded
        padded[:, :valid] = out_np
        if valid < self.chunk:
            padded[:, valid:] = 0.0
        buffers["output"].write(padded)
        self._meta[0] = request_id
        self._meta[1] = index
        self._meta[2] = valid
        buffers["metadata"].write(self._meta)

    def run_request(self, features_np, buffers, request_id, pace_period_s=None):
        if self.strategy == "eager4":
            for index, pos in enumerate(range(0, self.T, self.chunk)):
                out = self._step_eager4(features_np[:, pos:pos + self.chunk])
                self._emit(out, buffers, request_id, index)
            return
        if self.strategy == "chunked_fused":
            for index, pos in enumerate(range(0, self.T, self.chunk)):
                out = self._step_chunked_fused(features_np[:, pos:pos + self.chunk])
                self._emit(out, buffers, request_id, index)
            return
        out = self._process_full(features_np)
        n_chunks = math.ceil(self.T / self.chunk)
        gap = 0.0
        if pace_period_s:
            # Spread this request's chunks over most of the recently
            # observed inter-arrival period so successive output chunks
            # stay smooth. The first chunk is never delayed.
            span = max(0.0, min(0.016, pace_period_s - 0.004))
            gap = span / max(1, n_chunks - 1)
        started = time.perf_counter()
        for index, pos in enumerate(range(0, self.T, self.chunk)):
            if gap:
                _wait_until(started + index * gap)
            valid = min(self.chunk, self.T - pos)
            self._emit(out[:, pos:pos + valid], buffers, request_id, index)


def main(default_strategy):
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--strategy", default=None)
    args = parser.parse_args()

    config = json.loads(args.config.read_text(encoding="utf-8"))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    strategy = args.strategy or os.environ.get("BRANCH_WORKER_STRATEGY") or default_strategy
    spin = strategy == "fused_graph_spin"

    engine = BranchEngine(args.repository, config, strategy)
    adapter = load_task_module("adapter", args.repository)
    buffers = adapter.open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    last_read = None
    try:
        print(
            json.dumps(
                {
                    "ready": True,
                    "device": str(engine.device),
                    "task": "branch_features",
                    "strategy": strategy,
                    "cuda_graph": bool(engine.use_graph),
                }
            ),
            flush=True,
        )
        while True:
            opcode = buffers["control"].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers["control"].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    last_read = None
                    active = False
                    buffers["control"].commit()
                elif opcode == 1:
                    active = True
                    buffers["control"].commit()
                elif opcode != 0:
                    raise ValueError(f"Unknown control opcode: {opcode}")
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers["input"].read(consumed, 1)
            if features is None:
                if spin:
                    deadline = time.perf_counter() + 0.0005
                    while features is None and time.perf_counter() < deadline:
                        next_cursor, features = buffers["input"].read(consumed, 1)
                if features is None:
                    time.sleep(0.00005)
                    continue
            if next_cursor != consumed + 1:
                raise RuntimeError("Input overwritten before processing")
            now = time.perf_counter()
            period = None
            if last_read is not None:
                interval = now - last_read
                if 0.0005 < interval < 0.5:
                    period = interval
            last_read = now
            request_id, consumed = consumed, next_cursor
            engine.run_request(features[0], buffers, request_id, period)
    finally:
        adapter.close_buffers(buffers, unlink=True)
        print(json.dumps({"closed": True}), flush=True)
