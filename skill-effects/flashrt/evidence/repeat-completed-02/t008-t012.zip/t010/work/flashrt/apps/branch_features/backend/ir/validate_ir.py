"""Phase-2 IR validation: execute the IR graphs and compare with the CPU oracle.

Run from the repo root:  python flashrt/apps/branch_features/backend/ir/validate_ir.py
Prints PASS/FAIL for (a) the reference chunk-periodic graph and (b) the fused
full-sequence graph, over a two-request continuation session plus an
independent post-reset request.  Also prints the IR analysis summary that
motivated the deployment variants.
"""
import hashlib
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from graph_builder import build_fused_graph, build_reference_graph
except ImportError:  # imported as a package
    from .graph_builder import build_fused_graph, build_reference_graph

from flashrt.ir import SequentialExecutor
from flashrt.paths import repo_root


def task_module(name):
    try:
        return __import__(f"branch_features.{name}", fromlist=[name])
    except ModuleNotFoundError:
        return __import__(f"flashrt.apps.branch_features.{name}", fromlist=[name])


CONFIG = {
    "weight_seed": 20240517,
    "channels": 16,
    "hidden": 32,
    "length": 1043,
    "chunk": 127,
    "device": "cuda",
}

TOL = 1e-5  # fp32 CUDA conv vs CPU oracle: different accumulation order only.


def make_features(rng):
    return rng.standard_normal((CONFIG["channels"], CONFIG["length"]), dtype=np.float32)


def diff(a, b):
    delta = np.abs(a - b)
    return float(delta.max()), float(delta.mean())


def digest(array):
    return hashlib.sha256(np.ascontiguousarray(array, dtype=np.float32).tobytes()).hexdigest()[:16]


def run_reference_ir(layers, requests):
    graph = build_reference_graph(layers, CONFIG)
    executor = SequentialExecutor(graph)
    executor.init_state({name: None for name in ("a0_hist", "a1_hist", "b0_hist", "b1_hist")})
    outputs = []
    device = next(iter(layers.parameters())).device
    for request in requests:
        pieces = []
        for pos in range(0, CONFIG["length"], CONFIG["chunk"]):
            chunk = torch.from_numpy(request[:, pos:pos + CONFIG["chunk"]]).unsqueeze(0).to(device)
            pieces.append(executor.run_chunk({"features": chunk})["out"])
        outputs.append(torch.cat(pieces, dim=-1)[0].detach().cpu().numpy())
    return graph, outputs


def run_fused_ir(layers, requests):
    graph = build_fused_graph(layers, CONFIG)
    executor = SequentialExecutor(graph)
    executor.init_state({"f0_hist": None, "f1_hist": None})
    device = next(iter(layers.parameters())).device
    outputs = []
    for request in requests:
        x = torch.from_numpy(request).unsqueeze(0).to(device)
        out = executor.run_chunk({"features": x})["out"]
        outputs.append(out[0].detach().cpu().numpy())
    return graph, outputs


def oracle_for(repository, requests):
    """CPU full-sequence oracle over the concatenated session."""
    concat = np.concatenate(requests, axis=-1)
    full = task_module("model").full_sequence_oracle(repository, CONFIG, concat)
    pieces, pos = [], 0
    for request in requests:
        pieces.append(full[:, pos:pos + request.shape[-1]])
        pos += request.shape[-1]
    return pieces


def check(label, actual, expected):
    worst = 0.0
    mean = 0.0
    for got, want in zip(actual, expected):
        d, m = diff(got, want)
        worst = max(worst, d)
        mean = max(mean, m)
    ok = worst <= TOL
    print(f"[{label}] max_abs={worst:.3e} max_mean_abs={mean:.3e} tol={TOL:.1e} "
          f"hash={digest(np.concatenate(actual, axis=-1))} "
          f"oracle_hash={digest(np.concatenate(expected, axis=-1))} "
          f"{'PASS' if ok else 'FAIL'}")
    return ok


def main():
    repository = str(repo_root())
    model = task_module("model")
    layers = model.build_layers(repository, CONFIG, CONFIG["device"])
    layers.eval()

    rng = np.random.default_rng(7)
    session = [make_features(rng), make_features(rng)]
    after_reset = [make_features(rng)]

    session_expected = oracle_for(repository, session)
    reset_expected = oracle_for(repository, after_reset)

    graph_ref, ref_session = run_reference_ir(layers, session)
    _, ref_reset = run_reference_ir(layers, after_reset)
    graph_fused, fused_session = run_fused_ir(layers, session)
    _, fused_reset = run_fused_ir(layers, after_reset)

    ok_ref = check("reference-chunk IR session", ref_session, session_expected)
    ok_ref_reset = check("reference-chunk IR after reset", ref_reset, reset_expected)
    ok_fused = check("fused full-sequence IR session", fused_session, session_expected)
    ok_fused_reset = check("fused full-sequence IR after reset", fused_reset, reset_expected)

    print("\n=== IR analysis: reference chunk graph ===")
    try:
        from flashrt.ir.analysis import (
            analyze_cross_chunk_dependencies,
            find_pipeline_stages,
            find_streaming_overlaps,
            summarize_graph,
        )
        try:
            print(summarize_graph(graph_ref))
        except Exception as exc:  # still print the primitive analyses
            print(f"summarize_graph unavailable: {exc!r}")
        print("pipeline_stages:", json.dumps(find_pipeline_stages(graph_ref), default=str))
        print("cross_chunk:", json.dumps(analyze_cross_chunk_dependencies(graph_ref), default=str))
        print("streaming_overlaps:", json.dumps(find_streaming_overlaps(graph_ref), default=str))
    except Exception as exc:
        print(f"analysis failed: {exc!r}")
        ok_ref = False

    print("\n=== IR analysis: fused graph ===")
    try:
        from flashrt.ir.analysis import (
            analyze_cross_chunk_dependencies,
            find_pipeline_stages,
        )
        print("pipeline_stages:", json.dumps(find_pipeline_stages(graph_fused), default=str))
        print("cross_chunk:", json.dumps(analyze_cross_chunk_dependencies(graph_fused), default=str))
    except Exception as exc:
        print(f"analysis failed: {exc!r}")
        ok_fused = False

    verdict = ok_ref and ok_ref_reset and ok_fused and ok_fused_reset
    print(f"\nIR VALIDATION: {'PASS' if verdict else 'FAIL'}")
    return 0 if verdict else 1


if __name__ == "__main__":
    sys.exit(main())
