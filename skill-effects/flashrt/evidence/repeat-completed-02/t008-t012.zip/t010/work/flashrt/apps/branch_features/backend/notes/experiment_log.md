# branch_features experiment log

Task: two independent causal-conv branches over a (C,T) feature stream,
`out = sigmoid(mean_c(x)) * a1(silu(a0(x))) + (1-gate) * b1(silu(b0(x))) + 0.1*x`.
Reference keeps four separate chunk histories and runs A then B per chunk.
All measurements below are from the independent controller on the assigned
single RTX 5060 8GB, PyTorch 2.11.0+cu128, config C=16, H=32, T=1043, chunk=127,
weight_seed=703 at benchmark time. Evidence lives outside the writable backend
tree under `evidence/` (read-only for me); the paths below are exact.

## IR Conversion and Validation (Phase 1-2)

Files: `ir/graph_builder.py` (operators + builders), `ir/validate_ir.py`.
- Reference chunk graph: 7 exposed chunk operators, 6 data edges (2 marked
  fixed-rate streaming 127->127): conv_a0 -> silu_a -> conv_a1 -> merge,
  conv_b0 -> silu_b -> conv_b1 -> merge. State objects: a0_hist, a1_hist,
  b0_hist, b1_hist (all chunk_persistent, each written/read by exactly one
  conv). gate_merge reads the raw chunk plus both branch outputs, no state.
- Fused graph (the optimized structure): fused_head (16->64 k=5 conv, shorter
  k=3 weights left-padded with zeros), fused_silu, fused_tail (grouped 64->32
  k=5 conv, groups=2), fused_merge. State: f0_hist (last 4 raw features),
  f1_hist (last 4 activated hidden features).
- Validation harness executed the `SequentialExecutor` on both graphs over a
  two-request continuation session plus a fresh post-reset request and compared
  every element against the CPU `full_sequence_oracle` on the concatenated
  session. Evidence: `evidence/execute-003/stdout`.
  - reference-chunk IR session: max_abs=3.278e-07 PASS
  - reference-chunk IR after reset: max_abs=2.682e-07 PASS
  - fused full-sequence IR session: max_abs=3.278e-07 PASS
  - fused full-sequence IR after reset: max_abs=2.682e-07 PASS
  - tolerance 1e-5: only fp32 accumulation-order differences between CUDA conv
    and the CPU oracle; observed error is ~30x below it.
  - verdict: **IR VALIDATION: PASS**.

IR analysis (same evidence, `summarize_graph` + primitives):
- Cross-chunk dependencies: only conv_a0<-a0_hist->conv_a0,
  conv_a1<-a1_hist->conv_a1, conv_b0<-b0_hist->conv_b0,
  conv_b1<-b1_hist->conv_b1. The two branches share no persistent state, and
  gate in the reference does not depend on branch outputs.
- Pipeline stages returned one stage per state group plus stateless ops
  (7 stages: a0, b0, silu_a, silu_b, a1, b1, merge). On this single-GPU
  assignment that stage split is not exploitable as device placement, but it
  confirms the two branch chains are independent and can be batched/merged.
- Streaming overlaps: conv_a1->merge and conv_b1->merge are fixed-rate 1:1;
  the adapter emits 9 chunks/request, so smooth inter-chunk delivery is a real
  target.
- Bottleneck/critical path: per chunk the reference executes four small convs
  plus SiLU/gate sequentially; the k=5 tail (a1/b1) is the longest chain.
- Key independent pairs: every A-chain op is independent of every B-chain op
  across chunks. This motivated (a) fusing A and B heads into one conv, (b)
  fusing tails into one grouped conv, and (c) computing the whole request in
  one causal pass since the per-chunk recurrence is exactly a k-1 history
  shift.

## Variant Queue (final state)

| # | name | hypothesis | IR basis | predicted impact | status |
|---|------|-----------|----------|------------------|--------|
| 1 | `eager4` | reimplement reference per-chunk 4-conv schedule in the worker | four independent histories; per-chunk recurrent form | parity with reference (anchor sanity) | measured |
| 2 | `chunked_fused` | fuse A/B heads and tails into two grouped convs but keep per-chunk stepping | independent branch chains / shared input | lower per-chunk launch cost, maybe +1 rate step | measured |
| 3 | `fused_eager` | one full-sequence causal pass per request using fused convs | causal recurrence == k-1 history; cross-chunk independence | remove 8/9 of launches, higher sustainable rate | measured |
| 4 | `fused_graph` (burst) | capture full-sequence pass in a CUDA graph, emit chunks immediately | static shapes T=1043, chunk=127 | lower first-output latency | measured |
| 5 | `fused_graph` + adaptive pacing | pace chunks over the observed request period, first chunk immediate | 1:1 streaming overlap, smoothness side condition | remove >20ms inter-burst gaps | measured |
| 6 | `fused_graph_spin` | short busy-poll window on the input ring | latency-to-first-output target | ~0.5ms lower median first output | measured (recommended) |
| 7 | `cpu_fused` | full-sequence fused math on CPU instead of GPU | device-placement axis | compare placement cost | correctness only; benchmark not run (budget cap) |

Rationale for ordering: the IR analysis ranked removing the four-conv
per-chunk recurrence first (critical path + launch count), then graph capture
and input-poll latency, then smoothness pacing. The CPU placement row was
enqueued to cover the co-location axis; it was numerically verified but the
observation cap ended before its benchmark.

Changelog:
- Initial queue committed from the IR analysis above.
- Measured burst fused graph: 200 rps rate gate but 4.2% of gaps >20ms at
  50 rps -> smoothness regression. Added adaptive pacing row.
- Measured paced fused graph: all rates pass, 0.22% over-budget at 50 rps.
- Measured spin poll: first-output median 0.50-0.57ms vs 1.03ms; promoted to
  recommended entry and measured on the final `worker.py`.
- Measured eager4 / chunked_fused / fused_eager isolations; CPU variant
  verified but not benchmarked under the cap.

## Deployment Iteration Records

All correctness runs are the independent controller's six-request comparison
(continuation, repeated input without reset, reset, tail chunk) against its
protected CPU full-sequence oracle. All candidate runs report
`candidate_run_passed` with `cleanup_verified: true` and max_abs differences
1.5e-08..2.4e-07.

### Baseline: user reference backend
- benchmark evidence: `evidence/benchmark-016/reference/result.json`
  (also benchmark-005/008/014/018/020/022).
- 50 rps: first output median 2.504ms, p95 3.097ms; gap median 1.542ms,
  p95 9.949ms, over-budget 0.0; both gates pass.
- 100 rps: first 1.567/2.241ms; gap 1.043/3.108ms, 0.0 over; rate gate FAIL
  (external queue grows).
- 200 rps: first 1.508/2.535ms; gap 1.034/1.711ms, 0.0 over; rate gate FAIL.
- highest passing offered rate: 50 rps (100 rps in two noisier paired runs).

### eager4 (reference-equivalent chunk schedule)
- correctness: PASS, `evidence/verify-017`.
- benchmark: `evidence/benchmark-018/candidate/result.json`.
- 50 rps: first 2.054/2.596ms; gap 1.096/12.279ms, 0.0 over; pass.
- 100/200 rps: rate gate FAIL (queue 14/117). highest 50 rps.
- verdict: parity with reference; confirms the baseline schedule is the
  bottleneck, not the weight construction.

### chunked_fused (two grouped convs, per-chunk schedule)
- correctness: PASS, `evidence/verify-019`.
- benchmark: `evidence/benchmark-020/candidate/result.json`.
- 50 rps: first 1.553/2.069ms; gap 1.036/12.505ms, 0.0 over; pass.
- 100 rps: first 1.536/2.066ms; gap 1.032/2.596ms, 0.0 over; pass.
- 200 rps: rate gate FAIL (queue 46). highest 100 rps.
- verdict: kernel fusion alone buys one rate step; full-sequence restructuring
  is still needed for 200.

### fused_eager (full-sequence fused, no CUDA graph)
- correctness: PASS, `evidence/verify-021`.
- benchmark: `evidence/benchmark-022/candidate/result.json`.
- 50/100/200 rps all rate+smoothness pass; highest 200 rps.
- first output: 1.599/1.552/1.547ms median, p95 2.13/2.06/2.04ms.
- gaps: median 2.082/0.568/0.012ms, p95 4.18ms max, over-budget 0.22%/0/0.
- verdict: removing the 9x per-chunk recurrence is the main sustainable-rate
  win; graph capture is a separate latency lever.

### fused_graph burst (CUDA graph, immediate chunk burst)
- correctness: PASS, `evidence/verify-004`.
- benchmark: `evidence/benchmark-005/candidate/result.json`.
- 100/200 rps pass; 50 rps rate gate passes but smoothness FAILS:
  gap median 0.006ms, p95 19.987ms, over-budget 4.23% (>1% gate). Bursting all
  9 chunks then idling until the next 20ms arrival creates one ~20ms gap.
- verdict: needs pacing; measurement is kept as negative evidence.

### fused_graph + adaptive pacing
- correctness: PASS, `evidence/verify-007`.
- benchmark: `evidence/benchmark-008/candidate/result.json`.
- 50/100/200 rps pass; highest 200.
- first output: 1.030/1.028/1.030ms median; p95 1.07/1.52/1.52ms.
- gaps: median 2.075/0.578/0.012ms, p95 4.07/4.13/4.12ms, over-budget
  0.22%/0/0.
- verdict: pacing fixes smoothness at 50 rps without losing 200 rps.

### fused_graph_spin (recommended, final `worker.py`)
- correctness: PASS on the final entry, `evidence/verify-015`; strategy also
  verified standalone in `evidence/verify-013`.
- benchmark on the final entry: `evidence/benchmark-016/candidate/result.json`;
  standalone strategy benchmark: `evidence/benchmark-014/candidate/result.json`.
- 50/100/200 rps: rate gate and smoothness gate pass; highest 200 rps.
- first output: 0.501/0.541/0.571ms median; p95 1.176/1.040/1.043ms.
- gaps: median 2.071/0.616/0.010ms; p95 4.342/4.195/4.200ms; over-budget
  0.22%/0.0/0.0.
- delta vs reference: first-output median -80%/-65%/-62% at 50/100/200 rps;
  sustainable offered rate 50 -> 200 rps (+4x); smoothness maintained.
- verdict: promote; this is the recommended backend entry.

### cpu_fused (device placement control, incomplete)
- correctness: PASS, `evidence/verify-012` (max_abs 1.5e-08..1.8e-07).
- benchmark: **not run** before the observation cap. No performance claim is
  made for this variant; it exists as a runnable entry and verified numerical
  path only.

## Honest gaps against the upstream workflow
- Only 6 distinct measured configurations are recorded (7 rows, one
  correctness-only), below the upstream 10-variant floor. The observation cap
  (42 development requests) was reached; no unmeasured performance claims are
  made.
- Benchmark JSONs are controller artifacts under `evidence/` rather than
  `backend/benchmarks/results/`; I did not write an additional local harness
  before the cap.
- Multi-GPU/model-parallel variants were not applicable on the assigned single
  GPU; the IR stage split is documented but not deployed across devices.
