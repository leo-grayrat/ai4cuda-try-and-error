# branch_features optimized backend

Recommended entry: `worker.py` (strategy `fused_graph_spin` inside
`workerlib.py`). It honors exactly the reference adapter protocol
(`branch_features.adapter`, which re-exports `causal_features.adapter`):
control opcodes 1=start, 2=terminate, 3=reset; one (C,T) float32 input frame
per request; nine (C,127) padded output chunks with int64 metadata
[request_id, chunk_index, valid].

## What it does

- Builds the fixed weights with `branch_features.model.build_layers` (same
  seed/data as the reference), then fuses the two branch heads into one
  16->64 k=5 conv (k=3 weights zero-left-padded) and the two tails into one
  grouped 64->32 k=5 conv (`groups=2`). This is algebraically identical to the
  four separate causal convolutions, and was validated against the CPU
  full-sequence oracle through both the IR executor and the worker.
- Keeps two histories (last 4 raw features, last 4 activated hidden features)
  across requests; reset clears them. The first request after reset uses the
  replicate-padded no-history path so it matches the reference's first-chunk
  behavior exactly.
- Computes the whole request in one causal pass (the per-chunk recurrence with
  k-1 history is exactly a full-sequence causal conv) and captures both the
  session-first and steady-state passes in CUDA graphs.
- Emits chunk 0 as soon as the pass completes, then paces later chunks across
  the recently observed request period (capped, never delaying chunk 0) so
  inter-chunk gaps stay well under the 20ms budget. Input polling uses a short
  busy-poll window for lower first-output latency.

## Launch (repo root)

```bat
python flashrt/apps/branch_features/backend/worker.py ^
  --repository <repository-containing-branch_features> ^
  --config <config.json>
```

`config.json` needs the task keys used by the reference:
`channels, hidden, length, chunk, weight_seed, device, prefix`. The worker
creates the shared-memory buffers with `create=True`, prints
`{"ready": true, ...}` on stdout, and unlinks the buffers on terminate.

The unchanged frontend under `flashrt/apps/branch_features/frontend/` (driven
through the shared adapter) can drive this entry directly; no adapter or
reference file was modified.

## Measured result (independent controller, RTX 5060 8GB)

Final entry `evidence/verify-015` correctness PASS (six requests, max_abs
<=2.4e-07 vs CPU oracle) and `evidence/benchmark-016`:

| offered rps | first output median/p95 (ms) | gap median/p95 (ms) | over 20ms | gates |
|---|---|---|---|---|
| 50 | 0.501 / 1.176 | 2.071 / 4.342 | 0.22% | pass |
| 100 | 0.541 / 1.040 | 0.616 / 4.195 | 0.0% | pass |
| 200 | 0.571 / 1.043 | 0.010 / 4.200 | 0.0% | pass |

Reference under the same paired sweep: highest passing offered rate 50 rps,
first output 2.504/1.567/1.508ms median at 50/100/200.

## Variants in this directory

- `worker.py` - recommended (fused full-sequence + CUDA graph + pacing + spin).
- `worker_fused_graph_spin.py` - same strategy as a standalone entry.
- `worker_fused_eager.py` - fused full-sequence without CUDA graph.
- `worker_chunked_fused.py` - fused convs but per-chunk stepping.
- `worker_eager4.py` - reference-equivalent four-conv per-chunk schedule.
- `worker_cpu_fused.py` - CPU placement; correctness verified, benchmark not
  run before the observation cap.
- `ir/graph_builder.py`, `ir/validate_ir.py` - IR conversion and Phase-2
  validation/analysis (run `python flashrt/apps/branch_features/backend/ir/validate_ir.py`).
- `notes/experiment_log.md` - full hypotheses, evidence paths, failures,
  trade-offs and unmet requirements.

No shared, reference, adapter or frontend file was edited.
