"""Recommended branch_features worker.

Fused causal convolutions over the whole request, CUDA-graph replay for the
session-first and steady-state variants, adaptive output pacing, and a short
busy-poll window on the input ring.  Strategy selection lives in workerlib.py;
this entry is the exact file the independent controller verifies/benchmarks.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from workerlib import main  # noqa: E402

if __name__ == "__main__":
    main(default_strategy="fused_graph_spin")
