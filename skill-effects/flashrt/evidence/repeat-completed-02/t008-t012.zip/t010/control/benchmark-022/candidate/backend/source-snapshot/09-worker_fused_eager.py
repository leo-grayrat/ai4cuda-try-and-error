"""Variant: full-sequence fused convolutions, eager PyTorch (no CUDA graph)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from workerlib import main  # noqa: E402

if __name__ == "__main__":
    main(default_strategy="fused_eager")
