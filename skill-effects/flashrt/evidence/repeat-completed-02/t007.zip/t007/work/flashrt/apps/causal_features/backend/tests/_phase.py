"""One phase per call (the harness budget is per-call): edit PHASE/ENTRIES."""
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import harness  # noqa: E402
import sweep  # noqa: E402

PHASE = "correctness"
ENTRIES = ["fullseq_prealloc", "fullseq_chunkpub", "head_split",
           "layer_streams", "cold_nowarm"]
CASE = "dev"


def run_correctness():
    print("kill:", harness.kill_stragglers(), flush=True)
    state = sweep.load_state()
    sweep.ensure_reference(CASE, state)
    todo = [v for v in ENTRIES if f"corr:{CASE}:{v}" not in state["done"]]
    print("todo:", todo, flush=True)
    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = {ex.submit(sweep.correctness_task, CASE, v, state): v for v in todo}
        for fut in as_completed(futs):
            v = futs[fut]
            try:
                case, variant, verdict, line, log = fut.result()
                print(line, flush=True)
                state["done"][f"corr:{case}:{variant}"] = {"verdict": verdict, "log": log}
            except Exception as exc:
                print(f"[corr] {v}: ERROR {exc}", flush=True)
                state["done"][f"corr:{CASE}:{v}"] = {"verdict": "ERROR", "error": str(exc)}
            sweep.save_state(state)


def bench_one(variant, n_latency=6, n_sat=16, periods=(0.0, 0.001)):
    cfg = harness.make_config(CASE)
    data = harness.measure(sweep.entry_of(variant), cfg, n_latency=n_latency,
                           n_sat=n_sat, periods=periods)
    data["case"] = CASE
    data["variant"] = variant
    data["config"] = {k: v for k, v in cfg.items() if k != "prefix"}
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = sweep.RES / f"{CASE}_{variant}_{stamp}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return data, path


def run_bench():
    print("kill:", harness.kill_stragglers(), flush=True)
    state = sweep.load_state()
    t0 = time.time()
    for variant in ENTRIES:
        key = f"bench:{CASE}:{variant}"
        if key in state["done"]:
            print("skip", variant, flush=True)
            continue
        if time.time() - t0 > 145:
            print("budget reached", flush=True)
            break
        try:
            data, path = bench_one(variant)
            s = data["summary"]
            print(f"[bench] {CASE} {variant}: first_out p50={s['first_out_p50_ms']:.3f} "
                  f"p95={s['first_out_p95_ms']:.3f} ms | sat={s['saturated_req_s']:.1f} req/s "
                  f"({s['saturated_chunks_s']:.0f} chunks/s) | total p50={s['total_p50_ms']:.3f} ms "
                  f"| gap p50={s['chunk_gap_p50_ms']:.3f} p95={s['chunk_gap_p95_ms']:.3f} "
                  f"over20ms={s['chunk_gap_over_20ms_frac']:.3f} | {path.name}", flush=True)
            state["done"][key] = {"json": str(path), "summary": s}
        except Exception as exc:
            print(f"[bench] {variant}: ERROR {exc}", flush=True)
            state["done"][key] = {"error": str(exc)}
        sweep.save_state(state)
    print("phase done", flush=True)


if __name__ == "__main__":
    (run_bench if PHASE == "bench" else run_correctness)()
