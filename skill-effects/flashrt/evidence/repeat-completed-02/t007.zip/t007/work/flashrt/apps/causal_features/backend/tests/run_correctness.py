"""Run the correctness sweep (workspace.execute passes no CLI arguments)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import harness

OPTS = {"cases": "dev", "entries": "all"}
sys.argv = ["harness", "correctness", "--cases", OPTS["cases"], "--entries", OPTS["entries"]]
harness.main()
