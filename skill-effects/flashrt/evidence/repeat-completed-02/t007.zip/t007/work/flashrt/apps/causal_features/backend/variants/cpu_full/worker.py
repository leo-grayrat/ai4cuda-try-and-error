"""Standalone causal_features backend entry (cpu_full)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from core import main

if __name__ == "__main__":
    main('cpu_full')
