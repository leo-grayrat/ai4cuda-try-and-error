from pathlib import Path

# ---- core.py: history length is the *pad* amount, not the kernel size
p = Path("flashrt/apps/causal_features/backend/core.py")
s = p.read_text(encoding="utf-8")
old = '''    def run_layer(self, i, x, use_buf=False):
        w, b, k = self.w[i], self.bias[i], self.k[i]
        h = self.hist[i]
        if h is None:
            joined = x
        elif use_buf:
            key = (i, x.shape[-1])
            j = self.bufs.get(key)
            if j is None:
                j = torch.empty((1, w.shape[0], k - 1 + x.shape[-1]),
                                device=x.device, dtype=x.dtype)
                self.bufs[key] = j
            j[:, :, :k - 1].copy_(h)
            j[:, :, k - 1:].copy_(x)
            joined = j
        else:
            joined = torch.cat([h, x], dim=-1)
        out = F.conv1d(F.pad(joined, (k - 1, 0), mode="replicate"), w, b)
        if h is not None:
            out = out[..., h.shape[-1]:]
        self.hist[i] = joined[..., -(k - 1):].clone()
        return F.silu(out)
'''
new = '''    def run_layer(self, i, x, use_buf=False):
        w, b, pad = self.w[i], self.bias[i], self.k[i]
        h = self.hist[i]
        if h is None:
            joined = x
        elif use_buf:
            key = (i, x.shape[-1])
            j = self.bufs.get(key)
            if j is None:
                j = torch.empty((1, w.shape[0], pad + x.shape[-1]),
                                device=x.device, dtype=x.dtype)
                self.bufs[key] = j
            j[:, :, :pad].copy_(h)
            j[:, :, pad:].copy_(x)
            joined = j
        else:
            joined = torch.cat([h, x], dim=-1)
        out = F.conv1d(F.pad(joined, (pad, 0), mode="replicate"), w, b)
        if h is not None:
            out = out[..., h.shape[-1]:]
        self.hist[i] = joined[..., -pad:].clone()
        return F.silu(out)
'''
assert old in s
s = s.replace(old, new)
p.write_text(s, encoding="utf-8")

# ---- harness.py: fail fast when a backend dies during startup
h = Path("flashrt/apps/causal_features/backend/tests/harness.py")
t = h.read_text(encoding="utf-8")
old_spawn = '''    proc = spawn(command(entry, cfg_path))
'''
new_spawn = '''    proc = spawn(command(entry, cfg_path))
    deadline = time.time() + 3.0
    while time.time() < deadline:
        if proc.poll() is not None:
            _o, _e = proc.communicate()
            raise RuntimeError(f"backend exited rc={proc.returncode}: {_e[-1500:]}")
        time.sleep(0.02)
'''
assert t.count(old_spawn) == 2, t.count(old_spawn)
t = t.replace(old_spawn, new_spawn)
h.write_text(t, encoding="utf-8")
print("patched core+harness")
