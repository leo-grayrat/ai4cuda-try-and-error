from pathlib import Path

p = Path("flashrt/apps/causal_features/backend/tests/sweep.py")
s = p.read_text(encoding="utf-8")
old = '''        ensure_reference("dev", state) if "corr:dev:*" not in done else None
'''
new = '''        for case in sorted({c for c, _ in todo}, key=lambda c: c != "dev"):
            ensure_reference(case, state)
'''
assert old in s
s = s.replace(old, new)
p.write_text(s, encoding="utf-8")
print("sweep patched")
