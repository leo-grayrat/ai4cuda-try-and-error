from pathlib import Path

p = Path("flashrt/apps/causal_features/backend/tests/harness.py")
s = p.read_text(encoding="utf-8")

old = '''        for _ in range(n_latency):
            x = fresh()
            adapter.submit(x)
            first = None
            stamps = []
            while adapter.pending is not None:
                _, ts = adapter.receive(timeout_s=600)
                stamps.append(ts)
                if first is None:
                    first = ts
            data["latency_ms"].append((first - adapter.buffers and 0) or 0)
            data["latency_ms"][-1] = (stamps[0] - _last_published[0]) / 1e6
            data["total_ms"].append((stamps[-1] - _last_published[0]) / 1e6)
'''
new = '''        for _ in range(n_latency):
            x = fresh()
            _, pub_ns = adapter.submit(x)
            stamps = []
            while adapter.pending is not None:
                _, ts = adapter.receive(timeout_s=180)
                stamps.append(ts)
            data["latency_ms"].append((stamps[0] - pub_ns) / 1e6)
            data["total_ms"].append((stamps[-1] - pub_ns) / 1e6)
'''
assert old in s
s = s.replace(old, new)

old2 = '''                late.append(max(0.0, now - next_t))
                adapter.submit(fresh())
                first = None
                while adapter.pending is not None:
                    _, ts = adapter.receive(timeout_s=600)
                    if first is None:
                        first = ts
                lat.append((first - _last_published[0]) / 1e6)
'''
new2 = '''                late.append(max(0.0, now - next_t))
                _, pub_ns = adapter.submit(fresh())
                first = None
                while adapter.pending is not None:
                    _, ts = adapter.receive(timeout_s=180)
                    if first is None:
                        first = ts
                lat.append((first - pub_ns) / 1e6)
'''
assert old2 in s
s = s.replace(old2, new2)

old3 = '''        entries = (["reference"] if args.entries == "all" else []) + entries'''
new3 = '''        entries = entries'''
assert old3 in s
s = s.replace(old3, new3)
p.write_text(s, encoding="utf-8")
print("harness patched")
