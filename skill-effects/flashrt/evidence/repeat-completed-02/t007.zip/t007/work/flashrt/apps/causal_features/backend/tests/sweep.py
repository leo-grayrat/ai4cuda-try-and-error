"""Idempotent correctness + benchmark sweep with a soft wall-clock budget.

Each ``workspace.execute`` call is bounded, and every backend launch pays the
full CUDA/torch start-up cost, so this driver keeps its own on-disk state and
resumes where the previous call stopped.

  phase 1: correctness (parallel, 4 backends at a time) against the cached
           outputs of the protected reference backend and the CPU oracle
  phase 2: paired benchmark sweeps (strictly serial, no GPU contention)
"""
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import harness

RES = harness.RESULTS
STATE_PATH = RES / "sweep_state.json"
BUDGET = 140.0
CASES = {
    "dev": harness.VARIANTS,
    "large": ["hybrid", "head_split", "cpu_full"],
}
BENCH_CASES = {"dev": harness.VARIANTS, "large": ["hybrid", "head_split"]}


def load_state():
    if STATE_PATH.exists():
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    return {"done": {}}


def save_state(state):
    STATE_PATH.write_text(json.dumps(state, indent=2), encoding="utf-8")


def entry_of(variant):
    return "reference" if variant == "reference" else f"variants/{variant}/worker.py"


def ensure_reference(case, state):
    """Capture (once) the protected reference outputs and the CPU oracle."""
    path = RES / f"reference_{case}.npz"
    cfg = harness.make_config(case)
    script = harness.dataset(cfg)
    if not path.exists():
        oracle = harness.oracle_outputs(cfg, script)
        ref, out, err = harness.episode("reference", cfg, script)
        arrays = {}
        k = 0
        for i, step in enumerate(script):
            if step[0] == "reset":
                continue
            arrays[f"o{k}"] = oracle[i]
            arrays[f"r{k}"] = ref[i][0]
            k += 1
        np.savez(path, **arrays)
        log = RES / f"reference_{case}.log"
        log.write_text(f"reference vs CPU oracle: "
                       f"{all(harness.compare(o, r)[0] for o, r in zip(oracle, [x[0] if x else None for x in ref]) if o is not None)}\n"
                       f"--- stdout ---\n{out}\n--- stderr ---\n{err}\n", encoding="utf-8")
    data = np.load(path)
    return cfg, script, data


def correctness_task(case, variant, state):
    cfg, script, data = ensure_reference(case, state)
    cfg = dict(cfg)
    cfg["prefix"] = harness.make_config(case)["prefix"]
    t0 = time.time()
    got, out, err = harness.episode(entry_of(variant), cfg, script)
    ok_o = ok_r = True
    max_abs = max_rel = 0.0
    k = 0
    for step, g in zip(script, got):
        if step[0] == "reset":
            continue
        o = data[f"o{k}"]
        r = data[f"r{k}"]
        k += 1
        a, b, c = harness.compare(g[0], o)
        ok_o &= a
        max_abs = max(max_abs, b)
        max_rel = max(max_rel, c)
        ok_r &= harness.compare(g[0], r)[0]
    verdict = "PASS" if (ok_o and ok_r) else "FAIL"
    line = (f"[{case}] {variant}: {verdict} vs_oracle={ok_o} vs_reference={ok_r} "
            f"max_abs={max_abs:.3e} max_rel={max_rel:.3e} "
            f"tail_chunk={any(s[0] == 'input' and s[1].shape[1] % cfg['chunk'] for s in script)}")
    log = RES / f"correctness_{case}_{variant}.log"
    log.write_text(line + f"\nwall={time.time() - t0:.1f}s\n--- stdout ---\n{out}\n"
                           f"--- stderr ---\n{err}\n", encoding="utf-8")
    return case, variant, verdict, line, str(log)


def bench_task(case, variant, n_latency=8, n_sat=20):
    cfg = harness.make_config(case)
    data = harness.measure(entry_of(variant), cfg, n_latency=n_latency, n_sat=n_sat,
                           periods=(0.0, 0.001, 0.004))
    data["case"] = case
    data["variant"] = variant
    data["config"] = {k: v for k, v in cfg.items() if k != "prefix"}
    s = data["summary"]
    print(f"[bench] {case} {variant}: first_out p50={s['first_out_p50_ms']:.3f} "
          f"p95={s['first_out_p95_ms']:.3f} ms | sat={s['saturated_req_s']:.1f} req/s "
          f"({s['saturated_chunks_s']:.0f} chunks/s) | total p50={s['total_p50_ms']:.3f} ms "
          f"| gap p50={s['chunk_gap_p50_ms']:.3f} p95={s['chunk_gap_p95_ms']:.3f} "
          f"over20ms={s['chunk_gap_over_20ms_frac']:.3f}", flush=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = RES / f"{case}_{variant}_{stamp}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return case, variant, path


def main():
    t_start = time.time()
    killed = harness.kill_stragglers()
    if killed:
        print(f"killed {killed} straggler backend processes", flush=True)
    state = load_state()
    done = state["done"]

    todo = [(case, v) for case, vs in CASES.items() for v in vs
            if f"corr:{case}:{v}" not in done]
    if todo:
        for case in sorted({c for c, _ in todo}, key=lambda c: c != "dev"):
            ensure_reference(case, state)
        batch = todo[:8]
        with ThreadPoolExecutor(max_workers=4) as ex:
            futs = {ex.submit(correctness_task, c, v, state): (c, v) for c, v in batch}
            for fut in as_completed(futs):
                case, variant = futs[fut]
                try:
                    case, variant, verdict, line, log = fut.result()
                    print(line, flush=True)
                    done[f"corr:{case}:{variant}"] = {"verdict": verdict, "log": log}
                except Exception as exc:
                    print(f"[{case}] {variant}: ERROR {exc}", flush=True)
                    done[f"corr:{case}:{variant}"] = {"verdict": "ERROR", "error": str(exc)}
                save_state(state)
        print(f"correctness batch done in {time.time() - t_start:.0f}s; "
              f"{len(todo) - len(batch)} correctness tasks queued", flush=True)
        return

    ref_key = "bench:dev:reference"
    tasks = [(case, v) for case, vs in BENCH_CASES.items() for v in vs
             if f"bench:{case}:{v}" not in done]
    if not tasks:
        print("SWEEP COMPLETE", flush=True)
        return
    # reference first so the anchor is never missing
    tasks.sort(key=lambda t: (t[1] != "reference", t[0] != "dev"))
    for case, variant in tasks:
        if time.time() - t_start > BUDGET:
            print("budget reached, resume in next call", flush=True)
            return
        try:
            case, variant, path = bench_task(case, variant)
            done[f"bench:{case}:{variant}"] = {"json": str(path)}
        except Exception as exc:
            print(f"[bench] {case} {variant}: ERROR {exc}", flush=True)
            done[f"bench:{case}:{variant}"] = {"error": str(exc)}
        save_state(state)
    print("SWEEP COMPLETE", flush=True)


if __name__ == "__main__":
    main()
