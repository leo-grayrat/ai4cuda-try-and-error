"""Optimized streaming backend core for the causal_features task.

Reference behaviour (flashrt/apps/causal_features/reference.py): the three
CausalConv1d layers are evaluated strictly chunk-by-chunk on the GPU; every
chunk performs a host round trip (``.cpu().numpy()``), a fresh zero-padded
numpy allocation and two shared-memory publishes, and the device is
synchronised once per chunk.

This module keeps the arithmetic identical (same pinned weights from
``causal_features.model.build_layers``, same causal history semantics, same
chunk boundaries / metadata) and attacks the *scheduling* of that work:

  * histories stay resident on the device (no per-chunk ``torch.cat``),
  * the three layers run over the whole request instead of per chunk,
  * a single pinned staging buffer + one stream sync per request,
  * the output ring is published with one bulk write,
  * the first chunk can be published before the tail has finished,
  * tiny requests may be evaluated on the CPU (no PCIe round trip at all),
  * a three-stream wavefront pipelines the layers across chunks.

Everything here was derived from the IR graph in ``backend/ir`` (per-layer
input histories are the only chunk-persistent state; the three layers are
chained inside a chunk, so only the cross-chunk direction is free).
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

DEFAULT_STRATEGY = "hybrid"

STRATEGIES = (
    "ref_replica",
    "chunk_pinned",
    "fullseq",
    "fullseq_prealloc",
    "fullseq_chunkpub",
    "head_split",
    "cpu_full",
    "hybrid",
    "layer_streams",
    "cold_nowarm",
)


# --------------------------------------------------------------------------
# environment / repository resolution
# --------------------------------------------------------------------------
def resolve_repository(repository):
    """Make ``causal_features`` importable and return a root holding flashrt/.

    The reference backend does ``sys.path.insert(0, repository)`` and then
    reads ``<repository>/flashrt/layers/audio.py`` (the pinned CausalConv1d
    source).  Depending on how the caller lays out the pinned snapshot the
    task package may sit next to ``flashrt/`` or under ``flashrt/apps``; both
    layouts are accepted.
    """
    repo = Path(repository).resolve()
    for cand in (repo, repo / "flashrt" / "apps"):
        if (cand / "causal_features").is_dir():
            sys.path.insert(0, str(cand))
    sys.path.insert(0, str(repo))
    if (repo / "flashrt" / "layers" / "audio.py").exists():
        return repo
    try:  # fall back to the installed pinned package layout
        import flashrt  # noqa: F401

        pkg = Path(flashrt.__file__).resolve().parent.parent
        if (pkg / "flashrt" / "layers" / "audio.py").exists():
            return pkg
    except Exception:
        pass
    raise FileNotFoundError(f"cannot locate flashrt/layers/audio.py under {repo}")


def _device_of(config):
    dev = config.get("device", "cuda")
    if isinstance(dev, int):
        return torch.device("cuda", dev)
    if str(dev) in ("cuda", "gpu"):
        return torch.device("cuda")
    return torch.device(str(dev))


# --------------------------------------------------------------------------
# the fixed network (per-layer input history, exactly the reference semantics)
# --------------------------------------------------------------------------
class CausalNet:
    """Three stacked CausalConv1d+SiLU layers with chunk-persistent history.

    ``hist[i]`` always holds the last ``k-1`` *inputs* of layer ``i`` (the
    same tensor the reference stores in ``self.histories[index]``).  Feeding
    ``cat(hist, x)`` through ``F.pad(replicate)`` + conv + slice is
    element-wise identical to the reference's per-chunk recurrence and also
    to a full-sequence evaluation of the same causal network.
    """

    def __init__(self, layers, device):
        self.layers = layers
        self.w = [layer.conv.weight for layer in layers]
        self.bias = [layer.conv.bias for layer in layers]
        self.k = [int(layer._time_causal_padding[0]) for layer in layers]
        self.device = device
        self.hist = [None] * len(layers)
        self.bufs = {}

    def reset(self):
        self.hist = [None] * len(self.layers)

    def run_layer(self, i, x, use_buf=False):
        w, b, pad = self.w[i], self.bias[i], self.k[i]
        h = self.hist[i]
        if h is None:
            joined = x
        elif use_buf:
            key = (i, x.shape[-1])
            j = self.bufs.get(key)
            if j is None:
                j = torch.empty((1, w.shape[0], pad + x.shape[-1]),
                                device=x.device, dtype=x.dtype)
                self.bufs[key] = j
            j[:, :, :pad].copy_(h)
            j[:, :, pad:].copy_(x)
            joined = j
        else:
            joined = torch.cat([h, x], dim=-1)
        out = F.conv1d(F.pad(joined, (pad, 0), mode="replicate"), w, b)
        if h is not None:
            out = out[..., h.shape[-1]:]
        self.hist[i] = joined[..., -pad:].clone()
        return F.silu(out)

    def run(self, x, use_buf=False):
        for i in range(len(self.w)):
            x = self.run_layer(i, x, use_buf)
        return x


# --------------------------------------------------------------------------
# output publication (protocol-exact: data frame first, metadata afterwards)
# --------------------------------------------------------------------------
class Publisher:
    def __init__(self, buffers, config):
        self.b = buffers
        self.C = int(config["channels"])
        self.T = int(config["length"])
        self.chunk = int(config["chunk"])
        self.n = int(math.ceil(self.T / self.chunk))
        self.stage = np.zeros((self.n, self.C, self.chunk), dtype=np.float32)
        self.meta = np.zeros((self.n, 3), dtype=np.int64)
        self.valid = [min(self.chunk, self.T - i * self.chunk) for i in range(self.n)]

    def publish_from(self, out2d, start, rid):
        """Publish chunks ``start..n-1`` from a contiguous ``(C, rest)`` array."""
        off = start * self.chunk
        for i in range(start, self.n):
            v = self.valid[i]
            frame = self.stage[i]
            s = i * self.chunk - off
            frame[:, :v] = out2d[:, s:s + v]
            if v < self.chunk:
                frame[:, v:] = 0.0
            self.meta[i, 0] = rid
            self.meta[i, 1] = i
            self.meta[i, 2] = v
        if self.n > start:
            self.b["output"].write(self.stage[start:self.n])
            self.b["metadata"].write(self.meta[start:self.n])

    def publish_chunk(self, out2d, i, rid):
        v = self.valid[i]
        frame = self.stage[i]
        frame[:, :v] = out2d[:, :v]
        if v < self.chunk:
            frame[:, v:] = 0.0
        self.meta[i, 0] = rid
        self.meta[i, 1] = i
        self.meta[i, 2] = v
        self.b["output"].write(frame)
        self.b["metadata"].write(self.meta[i])


# --------------------------------------------------------------------------
# strategies
# --------------------------------------------------------------------------
class Ctx:
    def __init__(self, repository, config, device):
        self.repository = repository
        self.config = config
        self.device = device
        self.total = int(math.ceil(config["length"] / config["chunk"]))
        self._layers = None
        self._layers_cpu = None

    @property
    def layers(self):
        if self._layers is None:
            from causal_features.model import build_layers

            self._layers = build_layers(self.repository, self.config, self.device)
        return self._layers

    @property
    def layers_cpu(self):
        if self._layers_cpu is None:
            from causal_features.model import build_layers

            self._layers_cpu = build_layers(self.repository, self.config, "cpu")
        return self._layers_cpu


class GpuStrategy:
    use_buf = False
    bulk = True
    do_warm = True

    def __init__(self, ctx):
        self.ctx = ctx
        self.cfg = ctx.config
        self.dev = ctx.device
        self.C = int(self.cfg["channels"])
        self.T = int(self.cfg["length"])
        self.chunk = int(self.cfg["chunk"])
        self.n = ctx.total
        self.net = CausalNet(ctx.layers, self.dev)
        self.pin_in = torch.empty((1, self.C, self.T), dtype=torch.float32, pin_memory=True)
        self.pin_out = torch.empty((1, self.C, self.T), dtype=torch.float32, pin_memory=True)
        self.gpu_in = torch.empty((1, self.C, self.T), dtype=torch.float32, device=self.dev)

    # -- helpers ---------------------------------------------------------
    def reset(self):
        self.net.reset()

    def load(self, inp):
        self.pin_in[0].copy_(torch.from_numpy(inp))
        self.gpu_in.copy_(self.pin_in, non_blocking=True)

    def warm(self):
        if not self.do_warm:
            return
        with torch.inference_mode():
            n = min(self.T, 4 * self.chunk)
            x = torch.zeros((1, self.C, n), dtype=torch.float32, device=self.dev)
            out = self.net.run(x, self.use_buf)
            self.pin_out[0, :, :n].copy_(out[0], non_blocking=False)
            torch.cuda.current_stream().synchronize()
            self.net.reset()
            self.pin_in.zero_()
            self.load(self.pin_in[0].numpy()[:, :self.T])
            torch.cuda.current_stream().synchronize()


class ChunkPinned(GpuStrategy):
    """Per-chunk eval (removes cat allocs only); one sync + publish per chunk."""

    def process(self, inp, rid, pub):
        self.load(inp)
        pos = 0
        for i in range(self.n):
            v = pub.valid[i]
            x = self.gpu_in.narrow(2, pos, v).contiguous()
            out = self.net.run(x, self.use_buf)
            self.pin_out[0, :, :v].copy_(out[0], non_blocking=False)
            torch.cuda.current_stream().synchronize()
            pub.publish_chunk(self.pin_out[0].numpy()[:, :v], i, rid)
            pos += v


class FullSeq(GpuStrategy):
    """Whole request in one layered pass; single sync; chunked publication."""

    def process(self, inp, rid, pub):
        self.load(inp)
        out = self.net.run(self.gpu_in, self.use_buf)
        self.pin_out.copy_(out, non_blocking=True)
        torch.cuda.current_stream().synchronize()
        pub.publish_from(self.pin_out[0].numpy(), 0, rid)


class FullSeqChunkPub(FullSeq):
    """Full-sequence eval but the ring is published frame by frame."""

    def process(self, inp, rid, pub):
        self.load(inp)
        out = self.net.run(self.gpu_in, self.use_buf)
        self.pin_out.copy_(out, non_blocking=True)
        torch.cuda.current_stream().synchronize()
        host = self.pin_out[0].numpy()
        pos = 0
        for i in range(self.n):
            v = pub.valid[i]
            pub.publish_chunk(host[:, pos:pos + v], i, rid)
            pos += v


class HeadSplit(GpuStrategy):
    """Publish chunk 0 after a head-only pass while the tail is still running."""

    use_buf = True

    def __init__(self, ctx):
        super().__init__(ctx)
        self.head = min(self.chunk, self.T)
        self.pin_head = torch.empty((1, self.C, self.head), dtype=torch.float32, pin_memory=True)
        rest = self.T - self.head
        self.rest = rest
        if rest > 0:
            self.pin_tail = torch.empty((1, self.C, rest), dtype=torch.float32, pin_memory=True)
            self.ev0 = torch.cuda.Event()
            self.ev1 = torch.cuda.Event()

    def process(self, inp, rid, pub):
        self.load(inp)
        stream = torch.cuda.current_stream()
        x0 = self.gpu_in.narrow(2, 0, self.head).contiguous()
        out0 = self.net.run(x0, True)
        self.pin_head.copy_(out0, non_blocking=True)
        if self.rest <= 0:
            stream.synchronize()
            pub.publish_from(self.pin_head[0].numpy(), 0, rid)
            return
        self.ev0.record()
        xt = self.gpu_in.narrow(2, self.head, self.rest).contiguous()
        outt = self.net.run(xt, True)
        self.pin_tail.copy_(outt, non_blocking=True)
        self.ev1.record()
        self.ev0.synchronize()
        pub.publish_chunk(self.pin_head[0].numpy(), 0, rid)
        self.ev1.synchronize()
        pub.publish_from(self.pin_tail[0].numpy(), 1, rid)


class LayerStreams(GpuStrategy):
    """Three CUDA streams, one per layer; chunks advance as a wavefront.

    IR basis: within a chunk the three layers are chained by data edges, but
    each layer touches only its own chunk-persistent history, so layer j of
    chunk k can run concurrently with layer j+1 of chunk k-1.  One stream per
    layer plus per-(layer, chunk) events realises exactly that wavefront.
    """

    use_buf = True

    def __init__(self, ctx):
        super().__init__(ctx)
        self.n_layers = len(ctx.layers)
        self.streams = [torch.cuda.Stream() for _ in range(self.n_layers)]
        self.ev = [[torch.cuda.Event() for _ in range(self.n)] for _ in range(self.n_layers)]
        self.ev_out = [torch.cuda.Event() for _ in range(self.n)]
        self.inbuf = [torch.empty((1, self.C, min(self.chunk, self.T - i * self.chunk)),
                                  dtype=torch.float32, device=self.dev) for i in range(self.n)]
        self.pin_chunk = torch.empty((self.n, self.C, self.chunk), dtype=torch.float32)
        self.ev_in = torch.cuda.Event()

    def process(self, inp, rid, pub):
        cur = torch.cuda.current_stream()
        self.pin_in[0].copy_(torch.from_numpy(inp))
        self.gpu_in.copy_(self.pin_in, non_blocking=True)
        pos = 0
        for i in range(self.n):
            v = pub.valid[i]
            self.inbuf[i].copy_(self.gpu_in.narrow(2, pos, v))
            pos += v
        self.ev_in.record(cur)
        for i in range(self.n):
            v = pub.valid[i]
            prev = self.inbuf[i]
            for j in range(self.n_layers):
                st = self.streams[j]
                st.wait_event(self.ev_in)
                if i > 0:
                    st.wait_event(self.ev[j][i - 1])
                if j > 0:
                    st.wait_event(self.ev[j - 1][i])
                with torch.cuda.stream(st):
                    out = self.net.run_layer(j, prev, True)
                    if j == self.n_layers - 1:
                        self.pin_chunk[i, :, :v].copy_(out[0, :, :v], non_blocking=True)
                        self.ev_out[i].record(st)
                self.ev[j][i].record(st)
                prev = out
        for i in range(self.n):
            self.ev_out[i].synchronize()
            pub.publish_chunk(self.pin_chunk[i, :, :pub.valid[i]].numpy(), i, rid)


class CpuFull:
    """Whole request on the CPU: no H2D/D2H transfer, no device sync."""

    do_warm = True

    def __init__(self, ctx, threads=None):
        self.ctx = ctx
        self.cfg = ctx.config
        if threads is None:
            threads = int(os.environ.get("CAUSAL_CPU_THREADS", self.cfg.get("threads", 4)))
        torch.set_num_threads(max(1, threads))
        self.threads = max(1, threads)
        self.net = CausalNet(ctx.layers_cpu, torch.device("cpu"))

    def reset(self):
        self.net.reset()

    def warm(self):
        if not self.do_warm:
            return
        with torch.inference_mode():
            x = torch.zeros((1, int(self.cfg["channels"]), min(int(self.cfg["length"]), 4 * int(self.cfg["chunk"]))),
                            dtype=torch.float32)
            self.net.run(x, False)
            self.net.reset()

    def process(self, inp, rid, pub):
        x = torch.from_numpy(inp).unsqueeze(0)
        out = self.net.run(x, False)
        pub.publish_from(out[0].numpy(), 0, rid)


class Hybrid:
    """Adaptive: CPU for tiny requests, GPU head-split otherwise."""

    def __init__(self, ctx):
        self.ctx = ctx
        self.cfg = ctx.config
        C = int(self.cfg["channels"])
        H = int(self.cfg["hidden"])
        T = int(self.cfg["length"])
        self.macs = float(T) * 5.0 * (2.0 * C * H + H * H)
        self.threshold = float(os.environ.get("CAUSAL_HYBRID_MACS", 2.0e9))
        self.gpu = None
        self.cpu = None
        if _device_of(self.cfg).type == "cuda":
            self.gpu = HeadSplit(ctx)
        self.cpu = CpuFull(ctx)

    def reset(self):
        if self.gpu is not None:
            self.gpu.reset()
        self.cpu.reset()

    def warm(self):
        if self.gpu is not None:
            self.gpu.warm()
        self.cpu.warm()

    def process(self, inp, rid, pub):
        if self.gpu is None or self.macs < self.threshold:
            self.cpu.process(inp, rid, pub)
        else:
            self.gpu.process(inp, rid, pub)


class RefReplica:
    """Literal reference pipeline (in-process anchor)."""

    def __init__(self, ctx):
        from causal_features.model import ReferencePipeline

        self.pipe = ReferencePipeline(ctx.repository, ctx.config)

    def reset(self):
        self.pipe.reset()

    def warm(self):
        pass

    def process(self, inp, rid, pub):
        pos = 0
        for i in range(pub.n):
            v = pub.valid[i]
            out = self.pipe.step(inp[:, pos:pos + v])
            pub.publish_chunk(out, i, rid)
            pos += v


def make_strategy(name, ctx):
    if name == "ref_replica":
        return RefReplica(ctx)
    if name == "chunk_pinned":
        return ChunkPinned(ctx)
    if name == "fullseq":
        return FullSeq(ctx)
    if name == "fullseq_prealloc":
        s = FullSeq(ctx)
        s.use_buf = True
        return s
    if name == "fullseq_chunkpub":
        s = FullSeqChunkPub(ctx)
        s.use_buf = True
        return s
    if name == "head_split":
        return HeadSplit(ctx)
    if name == "cpu_full":
        return CpuFull(ctx)
    if name == "hybrid":
        return Hybrid(ctx)
    if name == "layer_streams":
        return LayerStreams(ctx)
    if name == "cold_nowarm":
        s = FullSeq(ctx)
        s.use_buf = True
        s.do_warm = False
        return s
    raise ValueError(f"unknown strategy {name!r}; known: {STRATEGIES}")


# --------------------------------------------------------------------------
# worker entry
# --------------------------------------------------------------------------
def main(strategy=None, argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--repository", type=Path, required=True)
    ap.add_argument("--config", type=Path, required=True)
    ap.add_argument("--strategy", default=None)
    args = ap.parse_args(argv)

    repository = resolve_repository(args.repository)
    config = json.loads(args.config.read_text(encoding="utf-8"))
    from causal_features.adapter import close_buffers, open_buffers

    name = args.strategy or strategy or os.environ.get("CAUSAL_STRATEGY") or DEFAULT_STRATEGY
    torch.set_num_threads(int(config.get("threads", 2)))
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = _device_of(config)
    ctx = Ctx(repository, config, device)
    strat = make_strategy(name, ctx)
    strat.warm()

    buffers = open_buffers(config, create=True)
    pub = Publisher(buffers, config)
    consumed, last_command, active, spin = 0, 0, False, 0
    try:
        print(json.dumps({"ready": True, "device": str(device), "strategy": name}), flush=True)
        with torch.inference_mode():
            while True:
                opcode = buffers["control"].recv()
                if opcode != last_command:
                    last_command = opcode
                    if opcode == 2:
                        buffers["control"].commit()
                        break
                    if opcode == 3:
                        strat.reset()
                        active = False
                        buffers["control"].commit()
                    elif opcode == 1:
                        active = True
                        buffers["control"].commit()
                    elif opcode != 0:
                        raise ValueError(f"Unknown control opcode: {opcode}")
                if not active:
                    time.sleep(0.00005)
                    continue
                next_cursor, features = buffers["input"].read(consumed, 1)
                if features is None:
                    spin += 1
                    if spin > 4000:
                        time.sleep(0.0001)
                        spin = 0
                    continue
                spin = 0
                if next_cursor != consumed + 1:
                    raise RuntimeError("Input overwritten before processing")
                request_id = consumed
                consumed = next_cursor
                strat.process(features[0], request_id, pub)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({"closed": True}), flush=True)


if __name__ == "__main__":
    main()
