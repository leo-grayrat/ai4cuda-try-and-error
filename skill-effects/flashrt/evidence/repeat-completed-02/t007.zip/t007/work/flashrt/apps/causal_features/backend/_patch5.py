from pathlib import Path

h = Path("flashrt/apps/causal_features/backend/tests/harness.py")
s = h.read_text(encoding="utf-8")
old = '''def spawn(cmd):'''
new = '''def kill_stragglers():
    """Kill backend processes left over by an interrupted harness run."""
    try:
        import psutil
    except Exception:
        return 0
    me = os.getpid()
    killed = 0
    for proc in psutil.process_iter(["pid", "cmdline"]):
        try:
            if proc.info["pid"] == me:
                continue
            cmd = " ".join(proc.info.get("cmdline") or [])
        except Exception:
            continue
        if "causal_features" in cmd and "backend" in cmd and (
                "worker.py" in cmd or "causal_features.reference" in cmd):
            try:
                proc.kill()
                killed += 1
            except Exception:
                pass
    return killed


def spawn(cmd):'''
assert old in s
s = s.replace(old, new, 1)
h.write_text(s, encoding="utf-8")

w = Path("flashrt/apps/causal_features/backend/tests/sweep.py")
t = w.read_text(encoding="utf-8")
old2 = '''    t_start = time.time()
    state = load_state()'''
new2 = '''    t_start = time.time()
    killed = harness.kill_stragglers()
    if killed:
        print(f"killed {killed} straggler backend processes", flush=True)
    state = load_state()'''
assert old2 in t
t = t.replace(old2, new2)
w.write_text(t, encoding="utf-8")

# trim the sweep bench cost: startup dominates, requests are cheap
old3 = '''def bench_task(case, variant, n_latency=10, n_sat=30):'''
new3 = '''def bench_task(case, variant, n_latency=8, n_sat=20):'''
assert old3 in t
t = t.replace(old3, new3)
old4 = '''                           periods=(0.0, 0.001, 0.002, 0.004))'''
new4 = '''                           periods=(0.0, 0.001, 0.004))'''
assert old4 in t
t = t.replace(old4, new4)
w.write_text(t, encoding="utf-8")
print("stroke")
