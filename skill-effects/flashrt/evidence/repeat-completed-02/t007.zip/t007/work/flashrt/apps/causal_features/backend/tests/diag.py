"""Launch a candidate worker directly and print its output (diagnostic)."""
import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import harness

ENTRIES = ["variants/fullseq/worker.py", "variants/chunk_pinned/worker.py"]
for entry in ENTRIES:
    cfg = harness.make_config("dev")
    cfgp = harness.BACKEND / "tests" / "_tmp" / "diag.json"
    cfgp.parent.mkdir(parents=True, exist_ok=True)
    cfgp.write_text(json.dumps(cfg), encoding="utf-8")
    harness.cleanup_shm(cfg["prefix"])
    proc = harness.spawn(harness.command(entry, cfgp))
    time.sleep(12)
    alive = proc.poll() is None
    out, err = harness.stop(proc)
    harness.cleanup_shm(cfg["prefix"])
    print(f"=== {entry} alive={alive} rc={proc.returncode}")
    print("--- stdout ---")
    print(out[-4000:])
    print("--- stderr ---")
    print(err[-6000:])
