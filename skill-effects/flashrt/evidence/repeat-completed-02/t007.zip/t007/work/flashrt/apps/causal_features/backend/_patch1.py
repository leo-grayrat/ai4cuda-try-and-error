import io
from pathlib import Path

p = Path(__file__).resolve().parent / "core.py"
s = p.read_text(encoding="utf-8")

# ---- replace GpuStrategy.warm (everything from the warm def up to ChunkPinned)
a = s.index("    def warm(self):\n        if not self.do_warm:")
b = s.index("class ChunkPinned(")
new_warm = '''    def warm(self):
        if not self.do_warm:
            return
        with torch.inference_mode():
            n = min(self.T, 4 * self.chunk)
            x = torch.zeros((1, self.C, n), dtype=torch.float32, device=self.dev)
            out = self.net.run(x, self.use_buf)
            self.pin_out[0, :, :n].copy_(out[0], non_blocking=False)
            torch.cuda.current_stream().synchronize()
            self.net.reset()
            self.pin_in.zero_()
            self.load(self.pin_in[0].numpy()[:, :self.T])
            torch.cuda.current_stream().synchronize()


'''
s = s[:a] + new_warm + s[b:]

# ---- replace LayerStreams with a clean static-buffer wavefront
a = s.index("class LayerStreams(")
b = s.index("class CpuFull:")
new_ls = '''class LayerStreams(GpuStrategy):
    """Three CUDA streams, one per layer; chunks advance as a wavefront.

    IR basis: within a chunk the three layers are chained by data edges, but
    each layer touches only its own chunk-persistent history, so layer j of
    chunk k can run concurrently with layer j+1 of chunk k-1.  One stream per
    layer plus per-(layer, chunk) events realises exactly that wavefront.
    """

    use_buf = True

    def __init__(self, ctx):
        super().__init__(ctx)
        self.n_layers = len(ctx.layers)
        self.streams = [torch.cuda.Stream() for _ in range(self.n_layers)]
        self.ev = [[torch.cuda.Event() for _ in range(self.n)] for _ in range(self.n_layers)]
        self.ev_out = [torch.cuda.Event() for _ in range(self.n)]
        self.inbuf = [torch.empty((1, self.C, min(self.chunk, self.T - i * self.chunk)),
                                  dtype=torch.float32, device=self.dev) for i in range(self.n)]
        self.pin_chunk = torch.empty((self.n, self.C, self.chunk), dtype=torch.float32)
        self.ev_in = torch.cuda.Event()

    def process(self, inp, rid, pub):
        cur = torch.cuda.current_stream()
        self.pin_in[0].copy_(torch.from_numpy(inp))
        self.gpu_in.copy_(self.pin_in, non_blocking=True)
        pos = 0
        for i in range(self.n):
            v = pub.valid[i]
            self.inbuf[i].copy_(self.gpu_in.narrow(2, pos, v))
            pos += v
        self.ev_in.record(cur)
        for i in range(self.n):
            v = pub.valid[i]
            prev = self.inbuf[i]
            for j in range(self.n_layers):
                st = self.streams[j]
                st.wait_event(self.ev_in)
                if i > 0:
                    st.wait_event(self.ev[j][i - 1])
                if j > 0:
                    st.wait_event(self.ev[j - 1][i])
                with torch.cuda.stream(st):
                    out = self.net.run_layer(j, prev, True)
                    if j == self.n_layers - 1:
                        self.pin_chunk[i, :, :v].copy_(out[0, :, :v], non_blocking=True)
                        self.ev_out[i].record(st)
                self.ev[j][i].record(st)
                prev = out
        for i in range(self.n):
            self.ev_out[i].synchronize()
            pub.publish_chunk(self.pin_chunk[i, :, :pub.valid[i]].numpy(), i, rid)


'''
s = s[:a] + new_ls + s[b:]
p.write_text(s, encoding="utf-8")
print("patched", len(s))
