import runpy
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
runpy.run_path(str(HERE / "_patch5.py"), run_name="__patch__")
sys.path.insert(0, str(HERE / "tests"))
import sweep  # noqa: E402

t0 = time.time()
sweep.main()
print(f"[go] sweep call wall={time.time() - t0:.0f}s", flush=True)
