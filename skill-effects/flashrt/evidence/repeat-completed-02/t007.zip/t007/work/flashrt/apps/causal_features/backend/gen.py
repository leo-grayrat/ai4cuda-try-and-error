"""Generate the small backend files (worker entries, IR package, notes, configs)."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

ENTRY = '''"""Standalone causal_features backend entry ({name})."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[{depth}]))
from core import main

if __name__ == "__main__":
    main({strat!r})
'''

(ROOT / "worker.py").write_text(ENTRY.format(name="recommended", depth=0, strat="hybrid"), encoding="utf-8")
(ROOT / "__init__.py").write_text("", encoding="utf-8")

VARIANTS = [
    "ref_replica", "chunk_pinned", "fullseq", "fullseq_prealloc", "fullseq_chunkpub",
    "head_split", "cpu_full", "hybrid", "layer_streams", "cold_nowarm",
]
for v in VARIANTS:
    d = ROOT / "variants" / v
    d.mkdir(parents=True, exist_ok=True)
    (d / "__init__.py").write_text("", encoding="utf-8")
    (d / "worker.py").write_text(ENTRY.format(name=v, depth=2, strat=v), encoding="utf-8")

CFG = {
    "dev": dict(prefix="causal_dev", channels=16, hidden=32, length=1043, chunk=127,
                weight_seed=703, device="cuda"),
    "large": dict(prefix="causal_large", channels=128, hidden=256, length=16384, chunk=512,
                  weight_seed=703, device="cuda"),
}
(ROOT / "configs").mkdir(exist_ok=True)
for name, cfg in CFG.items():
    (ROOT / "configs" / f"{name}.json").write_text(json.dumps(cfg, indent=2), encoding="utf-8")

# ---------------------------------------------------------------- IR package
ir = ROOT / "ir"
ir.mkdir(exist_ok=True)
(ir / "__init__.py").write_text("", encoding="utf-8")
(ir / "ops.py").write_text('''"""IR operators for the causal_features pipeline (phase 1)."""
import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort, ir_operator


class CausalLayerChunk(IROperator):
    """One CausalConv1d+SiLU layer over one chunk.

    state hist_<i> holds the last k-1 *inputs* of layer i; the reference
    (reference.py:ReferencePipeline.step) stores exactly this tensor, which is
    the only chunk-persistent state of the pipeline.
    """

    def __init__(self, index, out_channels, kernel, dtype="float32"):
        name = f"causal_layer_{index}"
        super().__init__(
            name=name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("x")],
            outputs=[TensorPort("y")],
            state_reads=[f"hist_{index}"],
            state_writes=[f"hist_{index}"],
            stream_mode=StreamMode.BATCH,
            config={"kernel": kernel, "out_channels": out_channels},
        )
        self.index = index
        self.k = kernel - 1

    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.index]
        x = inputs["x"]
        h = state.get(f"hist_{self.index}")
        joined = x if h is None else torch.cat([h, x], dim=-1)
        out = F.conv1d(F.pad(joined, (self.k, 0), mode="replicate"),
                       layer.conv.weight, layer.conv.bias)
        if h is not None:
            out = out[..., h.shape[-1]:]
        state.set(f"hist_{self.index}", joined[..., -self.k:].clone())
        return {"y": F.silu(out)}


@ir_operator(
    name="ingest_request",
    op_type=OpType.EXPOSED,
    inputs=[TensorPort("request")],
    outputs=[TensorPort("x")],
)
def ingest_request(inputs, ctx, state):
    return {"x": inputs["request"]}


@ir_operator(
    name="publish_chunk",
    op_type=OpType.EXPOSED,
    inputs=[TensorPort("y")],
    outputs=[TensorPort("chunk")],
    stream_mode=StreamMode.STREAMING,
)
def publish_chunk(inputs, ctx, state):
    return {"chunk": inputs["y"]}
''', encoding="utf-8")

(ir / "graph_builder.py").write_text('''"""IR graphs for the causal_features application."""
from flashrt.ir import (IREdge, IRGraph, OpType, StateObject, StreamMode,
                        StreamingInfo, StreamingPattern, TensorPort)

from causal_features.backend.ir.ops import (CausalLayerChunk, ingest_request,
                                            publish_chunk)


def build_model_graph(config):
    """Model-level graph: three exposed causal layers, per-layer input history."""
    g = IRGraph(name="causal_model")
    C, H = config["channels"], config["hidden"]
    kernels = [5, 5, 3]
    shapes = [(C, H), (H, H), (H, C)]
    for i in range(3):
        g.add_state(StateObject(f"hist_{i}", f"last k-1 inputs of layer {i}",
                                scope="chunk_persistent"))
        g.add_operator(CausalLayerChunk(i, shapes[i][1], kernels[i]))
    g.add_edge(IREdge("causal_layer_0", "y", "causal_layer_1", "x",
                      StreamingInfo(StreamingPattern.FIXED_RATE,
                                    config["chunk"], config["chunk"],
                                    "same-rate chunk boundary inside the request")))
    g.add_edge(IREdge("causal_layer_1", "y", "causal_layer_2", "x",
                      StreamingInfo(StreamingPattern.FIXED_RATE,
                                    config["chunk"], config["chunk"])))
    g.external_inputs = [TensorPort("x")]
    g.external_outputs = [TensorPort("y")]
    g.chunk_ops = ["causal_layer_0", "causal_layer_1", "causal_layer_2"]
    return g


def build_worker_graph(config):
    """Worker-level graph: request ingest -> exposed model -> chunk publish."""
    g = IRGraph(name="causal_worker")
    g.add_operator(ingest_request)
    g.add_operator(publish_chunk)
    g.add_operator(CausalLayerChunk(0, config["hidden"], 5, ).__class__ and None) if False else None
    g.external_inputs = [TensorPort("request")]
    g.external_outputs = [TensorPort("chunk")]
    g.sub_graphs["causal_model"] = build_model_graph(config)
    g.preamble_ops = []
    g.add_edge(IREdge("ingest_request", "x", "publish_chunk", "y"),
               )
    g.edges[-1] = IREdge("ingest_request", "x", "publish_chunk", "y",
                         StreamingInfo(StreamingPattern.FIXED_RATE,
                                       config["length"], config["chunk"],
                                       "one request (length samples) is emitted "
                                       "as ceil(length/chunk) output chunks"))
    g.chunk_ops = ["ingest_request", "publish_chunk"]
    return g
''', encoding="utf-8")

# ---------------------------------------------------------------- notes stub
(ROOT / "notes").mkdir(exist_ok=True)
(ROOT / "notes" / "experiment_log.md").write_text("# causal_features backend — experiment log\n", encoding="utf-8")
(ROOT / "benchmarks" / "results").mkdir(parents=True, exist_ok=True)
(ROOT / "tests" / "fixtures").mkdir(parents=True, exist_ok=True)
print("generated")
