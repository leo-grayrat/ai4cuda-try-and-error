"""IR operators for the causal_features pipeline (phase 1)."""
import torch
import torch.nn.functional as F

from flashrt.ir import IROperator, OpType, StreamMode, TensorPort, ir_operator


class CausalLayerChunk(IROperator):
    """One CausalConv1d+SiLU layer over one chunk.

    state hist_<i> holds the last k-1 *inputs* of layer i; the reference
    (reference.py:ReferencePipeline.step) stores exactly this tensor, which is
    the only chunk-persistent state of the pipeline.
    """

    def __init__(self, index, out_channels, kernel, dtype="float32"):
        name = f"causal_layer_{index}"
        super().__init__(
            name=name,
            op_type=OpType.EXPOSED,
            inputs=[TensorPort("x")],
            outputs=[TensorPort("y")],
            state_reads=[f"hist_{index}"],
            state_writes=[f"hist_{index}"],
            stream_mode=StreamMode.BATCH,
            config={"kernel": kernel, "out_channels": out_channels},
        )
        self.index = index
        self.k = kernel - 1

    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.index]
        x = inputs["x"]
        h = state.get(f"hist_{self.index}")
        joined = x if h is None else torch.cat([h, x], dim=-1)
        out = F.conv1d(F.pad(joined, (self.k, 0), mode="replicate"),
                       layer.conv.weight, layer.conv.bias)
        if h is not None:
            out = out[..., h.shape[-1]:]
        state.set(f"hist_{self.index}", joined[..., -self.k:].clone())
        return {"y": F.silu(out)}


@ir_operator(
    name="ingest_request",
    op_type=OpType.EXPOSED,
    inputs=[TensorPort("request")],
    outputs=[TensorPort("x")],
)
def ingest_request(inputs, ctx, state):
    return {"x": inputs["request"]}


@ir_operator(
    name="publish_chunk",
    op_type=OpType.EXPOSED,
    inputs=[TensorPort("y")],
    outputs=[TensorPort("chunk")],
    stream_mode=StreamMode.STREAMING,
)
def publish_chunk(inputs, ctx, state):
    return {"chunk": inputs["y"]}
