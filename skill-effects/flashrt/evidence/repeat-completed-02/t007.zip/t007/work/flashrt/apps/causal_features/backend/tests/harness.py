"""Subprocess harness for the causal_features backend.

Drives the protected reference backend and candidate workers through the
fixed adapter (flashrt/apps/causal_features/adapter.py), collects every output
chunk, compares against the CPU full-sequence oracle, and measures
latency-to-first-output / chunk-gap / sustainable-rate targets.

Usage (from the repo root):
    python flashrt/apps/causal_features/backend/tests/harness.py correctness
    python flashrt/apps/causal_features/backend/tests/harness.py bench
"""
import argparse
import json
import math
import os
import secrets
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path

import numpy as np

BACKEND = Path(__file__).resolve().parents[1]
_HERE = BACKEND.parents  # backend -> causal_features -> apps -> flashrt -> repo
REPO = Path(os.environ.get("CAUSAL_REPOSITORY", str(BACKEND.parents[3]))).resolve()
if not (REPO / "flashrt" / "layers" / "audio.py").exists():
    REPO = Path.cwd().resolve()

for _p in (str(REPO), str(REPO / "flashrt" / "apps")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from causal_features.adapter import FeatureAdapter  # noqa: E402
from causal_features.model import full_sequence_oracle  # noqa: E402

RESULTS = BACKEND / "benchmarks" / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

VARIANTS = [
    "ref_replica", "chunk_pinned", "fullseq", "fullseq_prealloc", "fullseq_chunkpub",
    "head_split", "cpu_full", "hybrid", "layer_streams", "cold_nowarm",
]

ATOL = 3e-5
RTOL = 3e-4

CASES = {
    "dev": dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703),
    "large": dict(channels=128, hidden=256, length=16384, chunk=512, weight_seed=703),
}


def make_config(case, device="cuda", **extra):
    cfg = dict(CASES[case])
    cfg["device"] = device
    cfg["prefix"] = "cfs_" + secrets.token_hex(4)
    cfg.update(extra)
    return cfg


def shm_names(prefix):
    names = [prefix + "__ctrl"]
    for buf in ("input", "output", "metadata"):
        names += [f"{prefix}_{buf}__meta", f"{prefix}_{buf}__tensor"]
    return names


def cleanup_shm(prefix):
    from multiprocessing import shared_memory

    for name in shm_names(prefix):
        try:
            shm = shared_memory.SharedMemory(name=name, create=False)
            shm.close()
            shm.unlink()
        except Exception:
            pass


def child_env():
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = os.environ.get("CAUSAL_GPU", "0")
    env["PYTHONPATH"] = os.pathsep.join(
        [str(REPO / "flashrt" / "apps"), str(REPO)] +
        ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
    env.setdefault("PYTHONUNBUFFERED", "1")
    return env


def command(entry, cfg_path):
    if entry == "reference":
        return [sys.executable, "-u", "-m", "causal_features.reference",
                "--repository", str(REPO), "--config", str(cfg_path)]
    return [sys.executable, "-u", str(BACKEND / entry),
            "--repository", str(REPO), "--config", str(cfg_path)]


def kill_stragglers():
    """Kill backend processes left over by an interrupted harness run."""
    try:
        import psutil
    except Exception:
        return 0
    me = os.getpid()
    killed = 0
    for proc in psutil.process_iter(["pid", "cmdline"]):
        try:
            if proc.info["pid"] == me:
                continue
            cmd = " ".join(proc.info.get("cmdline") or [])
        except Exception:
            continue
        if "causal_features" in cmd and "backend" in cmd and (
                "worker.py" in cmd or "causal_features.reference" in cmd):
            try:
                proc.kill()
                killed += 1
            except Exception:
                pass
    return killed


def kill_stragglers():
    """Kill backend processes left over by an interrupted harness run."""
    try:
        import psutil
    except Exception:
        return 0
    me = os.getpid()
    killed = 0
    for proc in psutil.process_iter(["pid", "cmdline"]):
        try:
            if proc.info["pid"] == me:
                continue
            cmd = " ".join(proc.info.get("cmdline") or [])
        except Exception:
            continue
        if "causal_features" in cmd and "backend" in cmd and (
                "worker.py" in cmd or "causal_features.reference" in cmd):
            try:
                proc.kill()
                killed += 1
            except Exception:
                pass
    return killed


def spawn(cmd):
    kwargs = dict(cwd=str(REPO), env=child_env(), stdout=subprocess.PIPE,
                  stderr=subprocess.PIPE, text=True)
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    return subprocess.Popen(cmd, **kwargs)


def stop(proc, timeout=30):
    out = err = ""
    try:
        proc.terminate()
        try:
            out, err = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            out, err = proc.communicate(timeout=timeout)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    return out, err


def episode(entry, cfg, script, cfg_dir=None, timeout_s=600):
    """Launch a backend, drive ``script`` through the adapter, return outputs.

    ``script`` is a list of ('input', ndarray) or ('reset',).
    Outputs: list aligned with script; each input entry is
    (values (C,T), chunk_receive_times_ns list) and reset entries are None.
    """
    cfg_dir = cfg_dir or (BACKEND / "tests" / "_tmp")
    cfg_dir.mkdir(parents=True, exist_ok=True)
    cfg_path = cfg_dir / f"{cfg['prefix']}.json"
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
    cleanup_shm(cfg["prefix"])
    proc = spawn(command(entry, cfg_path))
    deadline = time.time() + 3.0
    while time.time() < deadline:
        if proc.poll() is not None:
            _o, _e = proc.communicate()
            raise RuntimeError(f"backend exited rc={proc.returncode}: {_e[-1500:]}")
        time.sleep(0.02)
    adapter = None
    outs = []
    try:
        adapter = FeatureAdapter(cfg)
        adapter.start()
        for step in script:
            if step[0] == "reset":
                adapter.reset()
                outs.append(None)
                continue
            values = step[1]
            adapter.submit(values)
            chunks, stamps = [], []
            while adapter.pending is not None:
                data, ts = adapter.receive(timeout_s=timeout_s)
                chunks.append(data)
                stamps.append(ts)
            outs.append((np.concatenate(chunks, axis=1) if chunks else None, stamps))
        adapter.terminate()
        try:
            proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            raise RuntimeError("backend did not exit after terminate")
    finally:
        out, err = stop(proc)
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
        cleanup_shm(cfg["prefix"])
        cfg_path.unlink(missing_ok=True)
        if proc.poll() is None:
            raise RuntimeError("backend process still alive after cleanup")
    return outs, out, err


def oracle_outputs(cfg, script):
    """CPU full-sequence oracle; consecutive requests form one causal stream."""
    groups, cur = [], []
    for step in script:
        if step[0] == "reset":
            if cur:
                groups.append(cur)
                cur = []
        else:
            cur.append(step[1])
    if cur:
        groups.append(cur)
    oracle = []
    for grp in groups:
        joined = np.concatenate(grp, axis=1)
        out = full_sequence_oracle(REPO, cfg, joined)
        off = 0
        for g in grp:
            n = g.shape[1]
            oracle.append(out[:, off:off + n])
            off += n
    res, k = [], 0
    for step in script:
        if step[0] == "reset":
            res.append(None)
        else:
            res.append(oracle[k])
            k += 1
    return res


def dataset(cfg, seed=20240607):
    rng = np.random.default_rng(seed)
    C, T = cfg["channels"], cfg["length"]
    a = (rng.standard_normal((C, T)) * 0.6).astype(np.float32)
    b = (rng.standard_normal((C, T)) * 0.6).astype(np.float32)
    c = (rng.standard_normal((C, T)) * 0.6).astype(np.float32)
    # six complete requests: continuation, repeated input, reset, tail chunk
    return [("input", a), ("input", b), ("input", b), ("reset",),
            ("input", a), ("input", c)]


def compare(got, want):
    diff = np.abs(got.astype(np.float64) - want.astype(np.float64))
    denom = np.maximum(np.abs(want.astype(np.float64)), 1e-12)
    ok = np.allclose(got, want, atol=ATOL, rtol=RTOL)
    return ok, float(diff.max()), float((diff / denom).max())


def correctness(cases, entries, tag="correctness"):
    report = {}
    for case in cases:
        cfg = make_config(case)
        script = dataset(cfg)
        oracle = oracle_outputs(cfg, script)
        ref, ref_out, ref_err = episode("reference", cfg, script)
        ref_vs_oracle = all(
            compare(g[0], o)[0] for g, o in zip(ref, oracle) if o is not None)
        print(f"[{case}] reference vs CPU oracle: {'PASS' if ref_vs_oracle else 'FAIL'}",
              flush=True)
        report[f"{case}/reference"] = {"vs_oracle": ref_vs_oracle,
                                       "stdout": ref_out, "stderr": ref_err}
        for entry in entries:
            label = entry if entry == "reference" else Path(entry).parent.name + "/" + Path(entry).name
            cfg_run = dict(cfg)
            cfg_run["prefix"] = "cfs_" + secrets.token_hex(4)
            try:
                got, out, err = episode(entry, cfg_run, script)
            except Exception as exc:
                print(f"[{case}] {label}: FAIL ({exc})", flush=True)
                report[f"{case}/{label}"] = {"verdict": "FAIL", "error": str(exc)}
                continue
            ok_o, abs_o, rel_o = True, 0.0, 0.0
            ok_r, abs_r, rel_r = True, 0.0, 0.0
            for g, o, r in zip(got, oracle, ref):
                if o is None:
                    continue
                o1, a1, r1 = compare(g[0], o)
                o2, a2, r2 = compare(g[0], r[0])
                ok_o &= o1
                ok_r &= o2
                abs_o = max(abs_o, a1)
                rel_o = max(rel_o, r1)
                abs_r = max(abs_r, a2)
                rel_r = max(rel_r, r2)
            has_tail = any(g is not None and g[0].shape[1] % cfg["chunk"] for g in got)
            verdict = "PASS" if (ok_o and ok_r) else "FAIL"
            line = (f"[{case}] {label}: {verdict} vs_oracle={ok_o} vs_reference={ok_r} "
                    f"max_abs={abs_o:.3e} max_rel={rel_o:.3e} tail_chunk={has_tail}")
            print(line, flush=True)
            log = RESULTS / f"{tag}_{case}_{label.replace('/', '_')}.log"
            log.write_text(line + "\n\n--- backend stdout ---\n" + out +
                           "\n--- backend stderr ---\n" + err, encoding="utf-8")
            report[f"{case}/{label}"] = {
                "verdict": verdict, "vs_oracle": bool(ok_o), "vs_reference": bool(ok_r),
                "max_abs": abs_o, "max_rel": rel_o, "tail_chunk": bool(has_tail),
                "log": str(log), "returncode": None,
            }
    (RESULTS / f"{tag}_summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def _percentiles(values, ps=(50, 95)):
    if not values:
        return {p: float("nan") for p in ps}
    arr = np.asarray(values, dtype=np.float64)
    return {p: float(np.percentile(arr, p)) for p in ps}


def measure(entry, cfg, n_latency=12, n_sat=40, periods=(0.0, 0.0005, 0.001, 0.002, 0.004),
            seed=7):
    rng = np.random.default_rng(seed)
    C, T, chunk = cfg["channels"], cfg["length"], cfg["chunk"]
    n_chunks = math.ceil(T / chunk)

    def fresh():
        return (rng.standard_normal((C, T)) * 0.6).astype(np.float32)

    cfg_path = BACKEND / "tests" / "_tmp" / f"{cfg['prefix']}.json"
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
    cleanup_shm(cfg["prefix"])
    proc = spawn(command(entry, cfg_path))
    deadline = time.time() + 3.0
    while time.time() < deadline:
        if proc.poll() is not None:
            _o, _e = proc.communicate()
            raise RuntimeError(f"backend exited rc={proc.returncode}: {_e[-1500:]}")
        time.sleep(0.02)
    adapter = None
    data = {"entry": entry, "case": None, "latency_ms": [], "total_ms": [],
            "chunk_gaps_ms": [], "saturated": {}, "sweeps": [], "errors": []}
    try:
        adapter = FeatureAdapter(cfg)
        adapter.start()
        for _ in range(3):  # warmup, not recorded
            adapter.submit(fresh())
            while adapter.pending is not None:
                adapter.receive(timeout_s=600)

        for _ in range(n_latency):
            x = fresh()
            _, pub_ns = adapter.submit(x)
            stamps = []
            while adapter.pending is not None:
                _, ts = adapter.receive(timeout_s=180)
                stamps.append(ts)
            data["latency_ms"].append((stamps[0] - pub_ns) / 1e6)
            data["total_ms"].append((stamps[-1] - pub_ns) / 1e6)
            data["chunk_gaps_ms"].extend(
                [float((stamps[i + 1] - stamps[i]) / 1e6) for i in range(len(stamps) - 1)])

        # saturated offered load: submit again immediately after the drain
        t0 = time.perf_counter()
        n = n_sat
        for _ in range(n):
            adapter.submit(fresh())
            while adapter.pending is not None:
                adapter.receive(timeout_s=600)
        wall = time.perf_counter() - t0
        data["saturated"] = {"requests": n, "wall_s": wall,
                             "requests_per_s": n / wall,
                             "chunks_per_s": n * n_chunks / wall}

        for period in periods:
            n = 15 if period > 0 else n_sat
            next_t = time.perf_counter()
            late = []
            lat = []
            t0 = time.perf_counter()
            for _ in range(n):
                now = time.perf_counter()
                if next_t > now:
                    time.sleep(next_t - now)
                late.append(max(0.0, now - next_t))
                _, pub_ns = adapter.submit(fresh())
                first = None
                while adapter.pending is not None:
                    _, ts = adapter.receive(timeout_s=180)
                    if first is None:
                        first = ts
                lat.append((first - pub_ns) / 1e6)
                next_t += period
            wall = time.perf_counter() - t0
            data["sweeps"].append({
                "offered_period_ms": period * 1e3,
                "requests": n,
                "achieved_req_s": n / wall,
                "p50_latency_ms": _percentiles(lat)[50],
                "p95_latency_ms": _percentiles(lat)[95],
                "max_start_lateness_ms": float(max(late) * 1e3),
            })

        adapter.terminate()
        try:
            proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            raise RuntimeError("backend did not exit after terminate")
    finally:
        out, err = stop(proc)
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
        cleanup_shm(cfg["prefix"])
        cfg_path.unlink(missing_ok=True)
        data["stderr_tail"] = err[-2000:]
        data["stdout_tail"] = out[-2000:]
    lat_p = _percentiles(data["latency_ms"])
    tot_p = _percentiles(data["total_ms"])
    gap_p = _percentiles(data["chunk_gaps_ms"])
    data["summary"] = {
        "first_out_p50_ms": lat_p[50], "first_out_p95_ms": lat_p[95],
        "total_p50_ms": tot_p[50], "total_p95_ms": tot_p[95],
        "chunk_gap_p50_ms": gap_p[50], "chunk_gap_p95_ms": gap_p[95],
        "chunk_gap_over_20ms_frac": float(np.mean(
            np.asarray(data["chunk_gaps_ms"]) > 20.0)) if data["chunk_gaps_ms"] else float("nan"),
        "saturated_req_s": data["saturated"]["requests_per_s"],
        "saturated_chunks_s": data["saturated"]["chunks_per_s"],
    }
    return data


_last_published = [0]


def bench(cases, entries, n_latency=12, n_sat=40):
    global _last_published
    all_data = {}
    old_submit = FeatureAdapter.submit

    for case in cases:
        for entry in entries:
            label = "reference" if entry == "reference" else Path(entry).parent.name
            cfg = make_config(case)
            print(f"[bench] {case} {label} ...", flush=True)
            data = measure(entry, cfg, n_latency=n_latency, n_sat=n_sat)
            data["case"] = case
            data["variant"] = label
            data["config"] = cfg
            s = data["summary"]
            print(f"[bench] {case} {label}: first_out p50={s['first_out_p50_ms']:.3f}ms "
                  f"p95={s['first_out_p95_ms']:.3f}ms | sat={s['saturated_req_s']:.1f} req/s "
                  f"({s['saturated_chunks_s']:.0f} chunks/s) | total p50={s['total_p50_ms']:.3f}ms "
                  f"| gap p50={s['chunk_gap_p50_ms']:.3f} p95={s['chunk_gap_p95_ms']:.3f} "
                  f"over20ms={s['chunk_gap_over_20ms_frac']:.3f}", flush=True)
            stamp = time.strftime("%Y%m%d_%H%M%S")
            path = RESULTS / f"{case}_{label}_{stamp}.json"
            path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            data["json"] = str(path)
            all_data[f"{case}/{label}"] = data
            (RESULTS / "bench_summary.json").write_text(
                json.dumps({k: v["summary"] | {"json": v["json"]} for k, v in all_data.items()},
                           indent=2), encoding="utf-8")
    return all_data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["correctness", "bench"])
    ap.add_argument("--cases", default="dev")
    ap.add_argument("--entries", default="all")
    ap.add_argument("--n-latency", type=int, default=12)
    ap.add_argument("--n-sat", type=int, default=40)
    args = ap.parse_args()
    cases = args.cases.split(",")
    if args.entries == "all":
        entries = ["variants/%s/worker.py" % v for v in VARIANTS]
    elif args.entries == "reference":
        entries = ["reference"]
    else:
        entries = [e if e == "reference" else e for e in args.entries.split(",")]
    if args.mode == "correctness":
        entries = entries
        report = correctness(cases, entries)
        bad = [k for k, v in report.items() if v.get("verdict") == "FAIL" or v.get("vs_oracle") is False]
        print("OVERALL:", "PASS" if not bad else f"FAIL {bad}", flush=True)
    else:
        bench(cases, entries, n_latency=args.n_latency, n_sat=args.n_sat)


if __name__ == "__main__":
    main()
