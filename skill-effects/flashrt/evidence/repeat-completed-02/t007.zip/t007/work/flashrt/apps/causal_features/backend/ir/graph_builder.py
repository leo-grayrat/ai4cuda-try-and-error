"""IR graphs for the causal_features application."""
from flashrt.ir import (IREdge, IRGraph, OpType, StateObject, StreamMode,
                        StreamingInfo, StreamingPattern, TensorPort)

from causal_features.backend.ir.ops import (CausalLayerChunk, ingest_request,
                                            publish_chunk)


def build_model_graph(config):
    """Model-level graph: three exposed causal layers, per-layer input history."""
    g = IRGraph(name="causal_model")
    C, H = config["channels"], config["hidden"]
    kernels = [5, 5, 3]
    shapes = [(C, H), (H, H), (H, C)]
    for i in range(3):
        g.add_state(StateObject(f"hist_{i}", f"last k-1 inputs of layer {i}",
                                scope="chunk_persistent"))
        g.add_operator(CausalLayerChunk(i, shapes[i][1], kernels[i]))
    g.add_edge(IREdge("causal_layer_0", "y", "causal_layer_1", "x",
                      StreamingInfo(StreamingPattern.FIXED_RATE,
                                    config["chunk"], config["chunk"],
                                    "same-rate chunk boundary inside the request")))
    g.add_edge(IREdge("causal_layer_1", "y", "causal_layer_2", "x",
                      StreamingInfo(StreamingPattern.FIXED_RATE,
                                    config["chunk"], config["chunk"])))
    g.external_inputs = [TensorPort("x")]
    g.external_outputs = [TensorPort("y")]
    g.chunk_ops = ["causal_layer_0", "causal_layer_1", "causal_layer_2"]
    return g


def build_worker_graph(config):
    """Worker-level graph: request ingest -> exposed model -> chunk publish."""
    g = IRGraph(name="causal_worker")
    g.add_operator(ingest_request)
    g.add_operator(publish_chunk)
    g.add_operator(CausalLayerChunk(0, config["hidden"], 5, ).__class__ and None) if False else None
    g.external_inputs = [TensorPort("request")]
    g.external_outputs = [TensorPort("chunk")]
    g.sub_graphs["causal_model"] = build_model_graph(config)
    g.preamble_ops = []
    g.add_edge(IREdge("ingest_request", "x", "publish_chunk", "y"),
               )
    g.edges[-1] = IREdge("ingest_request", "x", "publish_chunk", "y",
                         StreamingInfo(StreamingPattern.FIXED_RATE,
                                       config["length"], config["chunk"],
                                       "one request (length samples) is emitted "
                                       "as ceil(length/chunk) output chunks"))
    g.chunk_ops = ["ingest_request", "publish_chunk"]
    return g
