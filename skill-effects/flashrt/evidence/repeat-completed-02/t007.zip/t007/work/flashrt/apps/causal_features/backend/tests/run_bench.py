"""Run the paired benchmark sweep (workspace.execute passes no CLI arguments)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import harness

OPTS = {"cases": "dev", "entries": "all", "n_latency": 12, "n_sat": 40}
sys.argv = ["harness", "bench", "--cases", OPTS["cases"], "--entries", OPTS["entries"],
            "--n-latency", str(OPTS["n_latency"]), "--n-sat", str(OPTS["n_sat"])]
harness.main()
