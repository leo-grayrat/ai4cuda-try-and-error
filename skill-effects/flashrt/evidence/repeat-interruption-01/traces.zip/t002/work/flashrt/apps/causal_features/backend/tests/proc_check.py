import os, subprocess, sys, time
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
t0 = time.time()
try:
    import psutil
    hits = []
    for p in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            cmd = ' '.join(p.info['cmdline'] or [])
        except Exception:
            continue
        if 'causal_features' in cmd or 'worker.py' in cmd or 'harness' in cmd:
            hits.append((p.info['pid'], p.info['name'], cmd[:160]))
    print('psutil hits', hits)
except Exception as exc:
    print('psutil unavailable', exc)
try:
    out = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,used_memory',
                          '--format=csv,noheader'], capture_output=True, text=True, timeout=20)
    print('nvidia-smi compute apps:', out.stdout.strip(), out.stderr.strip()[:200])
except Exception as exc:
    print('nvidia-smi failed', exc)
print('elapsed', time.time() - t0)
