import sys
sys.stdout.reconfigure(encoding='utf-8')
import inspect
import flashrt.ir as ir
print('exports:', [n for n in dir(ir) if not n.startswith('_')])
from flashrt.ir import graph, analysis, executor, ops_base
for obj in [graph.IRGraph, graph.IROperator, graph.IREdge, graph.StateObject, graph.TensorPort,
            graph.StreamingInfo, executor.SequentialExecutor]:
    print('\n==', obj.__name__)
    try:
        print('init', inspect.signature(obj.__init__))
    except Exception as e:
        print(e)
for fn in ['add_operator', 'add_edge', 'add_state', 'summary', 'run_preamble', 'run_chunk',
           'init_state', 'add_external_input', 'add_external_output']:
    for cls in [graph.IRGraph, executor.SequentialExecutor]:
        if hasattr(cls, fn):
            print(cls.__name__ + '.' + fn, inspect.signature(getattr(cls, fn)))
for fn in ['analyze_cross_chunk_dependencies', 'find_pipeline_stages', 'find_streaming_overlaps',
           'compute_critical_path', 'summarize_graph']:
    if hasattr(analysis, fn):
        print(fn, inspect.signature(getattr(analysis, fn)))
print('\nops_base:', [n for n in dir(ops_base) if not n.startswith('_')])
print('ir_operator', inspect.signature(ops_base.ir_operator))
print('\nOpType', list(ir.OpType))
print('StreamMode', list(ir.StreamMode))
print('\nIRGraph attrs:', [n for n in dir(graph.IRGraph) if not n.startswith('_')])
print('IROperator attrs:', [n for n in dir(graph.IROperator) if not n.startswith('_')])
