"""Local subprocess harness for causal_features backends.

Modes
-----
correctness : six-request session (continuation, repeat without reset, reset
              reproduction, tail chunk) compared against the CPU full-sequence
              oracle supplied by causal_features.model.
bench       : latency-to-first-output and a finite offered-load sweep with
              inter-chunk-gap statistics (20 ms chunk-gap budget).

The backend is always launched as a subprocess and driven through the shared
adapter.  Everything is cleaned up in a finally block.
"""
import argparse
import json
import os
import statistics
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

import numpy as np

REPO = Path.cwd()
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / 'flashrt' / 'apps'))

CASES = {
    'dev': dict(channels=16, hidden=32, length=1043, chunk=127),
    'large': dict(channels=128, hidden=256, length=16384, chunk=512),
}


def make_config(case, variant, prefix, device='cuda'):
    cfg = dict(CASES[case])
    cfg.update(prefix=prefix, device=device, weight_seed=703, variant=variant,
               num_threads=2, warmup=True)
    return cfg


def pct(values, q):
    if not values:
        return None
    return float(np.percentile(np.asarray(values, dtype=np.float64), q))


class Backend:
    def __init__(self, entry, config, gpu='0', module=False, cwd=REPO):
        self.config = config
        self.cfg_path = Path('flashrt/apps/causal_features/backend/tests') / (
            'tmp_cfg_' + config['prefix'] + '.json')
        self.cfg_path.write_text(json.dumps(config), encoding='utf-8')
        env = os.environ.copy()
        env['CUDA_VISIBLE_DEVICES'] = str(gpu)
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONPATH'] = os.pathsep.join(
            [str(REPO / 'flashrt' / 'apps'), str(REPO), env.get('PYTHONPATH', '')])
        if module:
            cmd = [sys.executable, '-m', entry, '--repository', str(REPO),
                   '--config', str(self.cfg_path.resolve())]
        else:
            cmd = [sys.executable, str(entry), '--repository', str(REPO),
                   '--config', str(self.cfg_path.resolve())]
        self.proc = subprocess.Popen(
            cmd, cwd=str(cwd), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding='utf-8', errors='replace',
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0,
            preexec_fn=None if os.name == 'nt' else os.setsid)
        self.ready = threading.Event()
        self.lines = []
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        try:
            for line in self.proc.stdout:
                self.lines.append(line.rstrip())
                if '"ready"' in line:
                    self.ready.set()
        except Exception:
            pass

    def wait_ready(self, timeout=90):
        return self.ready.wait(timeout)

    def close(self):
        self.ready.set()
        try:
            if self.proc.poll() is None:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
                    self.proc.wait()
        finally:
            try:
                self.cfg_path.unlink()
            except FileNotFoundError:
                pass


def drive(request_inputs, adapter, reset_before=None, on_chunk=None):
    outputs = []
    for index, x in enumerate(request_inputs):
        if reset_before is not None and index == reset_before:
            adapter.reset()
        request_id, published_ns = adapter.submit(x)
        chunks, stamps = [], []
        while adapter.pending is not None:
            data, observed_ns = adapter.receive(timeout_s=120)
            chunks.append(data)
            stamps.append(observed_ns)
            if on_chunk is not None:
                on_chunk(request_id, len(chunks) - 1, observed_ns, published_ns)
        outputs.append(dict(chunks=chunks, published_ns=published_ns, stamps=stamps))
    return outputs


def oracle_session(inputs, case):
    from causal_features.model import full_sequence_oracle
    cfg = dict(CASES[case])
    cfg['weight_seed'] = 703
    joined = np.concatenate(inputs, axis=-1)
    out = full_sequence_oracle(str(REPO), cfg, joined)
    pieces, pos = [], 0
    for x in inputs:
        pieces.append(out[:, pos:pos + x.shape[-1]])
        pos += x.shape[-1]
    return pieces


def run_correctness(entry, case, variant, module=False, device='cuda'):
    from causal_features.adapter import FeatureAdapter
    rng = np.random.default_rng(20240703)
    c, length = CASES[case]['channels'], CASES[case]['length']
    xs = [rng.standard_normal((c, length), dtype=np.float32) for _ in range(4)]
    session_a = [xs[0], xs[1], xs[1]]
    session_b = [xs[0], xs[2], xs[3]]
    config = make_config(case, variant, 'cf_corr_' + uuid.uuid4().hex[:8], device=device)
    backend = Backend(entry, config, module=module)
    adapter = None
    verdict = 'FAIL'
    max_abs, max_rel_excess, compared = 0.0, -1.0, 0
    repro = 0.0
    try:
        if not backend.wait_ready(180):
            print('backend did not become ready; stdout=', backend.lines)
            return False, {}
        adapter = FeatureAdapter(config)
        adapter.start()
        got_a = drive(session_a, adapter)
        got_b = drive(session_b, adapter, reset_before=0)
        for got, ref in ((got_a, oracle_session(session_a, case)),
                         (got_b, oracle_session(session_b, case))):
            for req, ref_piece in zip(got, ref):
                pos = 0
                for chunk in req['chunks']:
                    valid = chunk.shape[-1]
                    r = ref_piece[:, pos:pos + valid]
                    pos += valid
                    diff = np.abs(chunk - r)
                    max_abs = max(max_abs, float(diff.max()))
                    excess = diff - (3e-5 + 3e-4 * np.abs(r))
                    max_rel_excess = max(max_rel_excess, float(excess.max()))
                    compared += 1
        for a, b in zip(got_a[0]['chunks'], got_b[0]['chunks']):
            repro = max(repro, float(np.abs(a - b).max()))
        nchunks = (CASES[case]['length'] + CASES[case]['chunk'] - 1) // CASES[case]['chunk']
        ok = compared == 6 * nchunks and max_rel_excess <= 0.0 and repro <= 1e-6
        verdict = 'PASS' if ok else 'FAIL'
    finally:
        try:
            if adapter is not None:
                adapter.terminate()
                adapter.close()
        except Exception as exc:
            print('terminate warning:', exc)
        backend.close()
    print(f'CORRECTNESS {verdict} case={case} variant={variant} chunks={compared} '
          f'max_abs={max_abs:.3e} max_tolerance_excess={max_rel_excess:.3e} '
          f'reset_repro_max_abs={repro:.3e}')
    print('backend stdout:', backend.lines)
    return verdict == 'PASS', dict(max_abs=max_abs, chunks=compared, repro=repro)


def run_bench(entry, case, variant, module=False, json_out=None, gpu='0', device='cuda'):
    from causal_features.adapter import FeatureAdapter
    rng = np.random.default_rng(91)
    c, length, chunk = CASES[case]['channels'], CASES[case]['length'], CASES[case]['chunk']
    xs = [rng.standard_normal((c, length), dtype=np.float32) for _ in range(4)]
    config = make_config(case, variant, 'cf_bench_' + uuid.uuid4().hex[:8], device=device)
    backend = Backend(entry, config, gpu=gpu, module=module)
    adapter = None
    result = dict(case=case, variant=variant, device=config['device'],
                  length=length, chunk=chunk, n_chunks=(length + chunk - 1) // chunk,
                  gpu=gpu, budget_ms=20.0)
    try:
        if not backend.wait_ready(180):
            print('backend did not become ready; stdout=', backend.lines)
            return False, result
        adapter = FeatureAdapter(config)
        adapter.start()
        drive([xs[0]], adapter)  # warmup, not measured

        lat, chunk_gap_ms = [], []
        for i in range(12):
            got = drive([xs[i % len(xs)]], adapter)[0]
            lat.append((got['stamps'][0] - got['published_ns']) / 1e6)
            chunk_gap_ms.extend(np.diff(got['stamps']) / 1e6)
        result['t_first_out_ms'] = dict(median=pct(lat, 50), p95=pct(lat, 95),
                                        min=min(lat), max=max(lat), n=len(lat))
        result['single_request_chunk_gap_ms'] = dict(
            median=pct(chunk_gap_ms, 50), p95=pct(chunk_gap_ms, 95),
            over_budget=float(np.mean(np.asarray(chunk_gap_ms) > 20.0)) if chunk_gap_ms else 0.0)

        sweep = []
        for period_ms in (0.0, 1.0, 2.0, 4.0, 8.0, 16.0):
            k = 6
            gaps, firsts, t0 = [], [], None
            for i in range(k):
                if t0 is None:
                    t0 = time.perf_counter()
                target = t0 + i * period_ms / 1e3
                while time.perf_counter() < target:
                    time.sleep(0)
                got = drive([xs[i % len(xs)]], adapter)[0]
                firsts.append((got['stamps'][0] - got['published_ns']) / 1e6)
                gaps.extend(np.diff(got['stamps']) / 1e6)
            wall = time.perf_counter() - t0
            offered = 1.0 / (period_ms / 1e3) if period_ms > 0 else None
            achieved = k / wall
            sweep.append(dict(
                period_ms=period_ms, offered_req_s=offered, achieved_req_s=achieved,
                achieved_chunk_s=achieved * result['n_chunks'],
                t_first_median_ms=pct(firsts, 50),
                gap_median_ms=pct(gaps, 50), gap_p95_ms=pct(gaps, 95),
                gap_over_budget=float(np.mean(np.asarray(gaps) > 20.0)) if gaps else 0.0))
        result['offered_load_sweep'] = sweep
        sustained = [r for r in sweep
                     if r['offered_req_s'] is None or r['achieved_req_s'] >= 0.9 * r['offered_req_s']]
        result['best_sustainable'] = max(sustained, key=lambda r: r['achieved_req_s'])
        result['ok'] = True
    finally:
        try:
            if adapter is not None:
                adapter.terminate()
                adapter.close()
        except Exception as exc:
            print('terminate warning:', exc)
        backend.close()
    print('BENCH', json.dumps(result))
    print('backend stdout:', backend.lines)
    if json_out:
        out = Path(json_out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result.get('ok', False), result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--mode', choices=['correctness', 'bench'], default='correctness')
    ap.add_argument('--entry', default='flashrt/apps/causal_features/backend/worker.py')
    ap.add_argument('--module', action='store_true',
                    help='entry is a module name (used for the reference backend)')
    ap.add_argument('--case', choices=sorted(CASES), default='dev')
    ap.add_argument('--variant', default='batch_first')
    ap.add_argument('--gpu', default='0')
    ap.add_argument('--json-out', default=None)
    args = ap.parse_args()
    entry = args.entry
    if not args.module:
        entry = str(Path(entry).resolve())
    if args.mode == 'correctness':
        ok, _ = run_correctness(entry, args.case, args.variant, module=args.module)
    else:
        ok, _ = run_bench(entry, args.case, args.variant, module=args.module,
                          json_out=args.json_out, gpu=args.gpu)
    print('HARNESS_RESULT', 'PASS' if ok else 'FAIL')
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
