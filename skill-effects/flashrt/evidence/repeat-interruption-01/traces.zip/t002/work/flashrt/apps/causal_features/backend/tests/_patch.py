from pathlib import Path
p = Path('flashrt/apps/causal_features/backend/tests/harness.py')
s = p.read_text(encoding='utf-8')
reps = [
    ("def make_config(case, variant, prefix):",
     "def make_config(case, variant, prefix, device='cuda'):"),
    ("cfg.update(prefix=prefix, device='cuda', weight_seed=703, variant=variant,",
     "cfg.update(prefix=prefix, device=device, weight_seed=703, variant=variant,"),
    ("def run_correctness(entry, case, variant, module=False):",
     "def run_correctness(entry, case, variant, module=False, device='cuda'):"),
    ("config = make_config(case, variant, 'cf_corr_' + uuid.uuid4().hex[:8])",
     "config = make_config(case, variant, 'cf_corr_' + uuid.uuid4().hex[:8], device=device)"),
    ("def run_bench(entry, case, variant, module=False, json_out=None, gpu='0'):",
     "def run_bench(entry, case, variant, module=False, json_out=None, gpu='0', device='cuda'):"),
    ("config = make_config(case, variant, 'cf_bench_' + uuid.uuid4().hex[:8])",
     "config = make_config(case, variant, 'cf_bench_' + uuid.uuid4().hex[:8], device=device)"),
    ("ok = compared == 18 and max_rel_excess <= 0.0 and repro <= 1e-6",
     "nchunks = (CASES[case]['length'] + CASES[case]['chunk'] - 1) // CASES[case]['chunk']\n        ok = compared == 6 * nchunks and max_rel_excess <= 0.0 and repro <= 1e-6"),
]
for a, b in reps:
    assert a in s, a
    s = s.replace(a, b)
p.write_text(s, encoding='utf-8')
print('patched')
