"""Standalone backend for causal_features.

Accepts exactly the reference launch surface:
    python worker.py --repository <repo-root> --config <json>

The fixed computation is the three-layer causal convolution stack specified by
flashrt/apps/causal_features/model.py.  The reference steps one chunk at a time
and materialises ``torch.cat([history, chunk])`` on every layer, every chunk.
Because every layer is causal, chunked evaluation and one-shot evaluation of the
whole request are algebraically identical: each layer only needs the previous
``kernel_size - 1`` samples as state.  This worker keeps that minimal state and
offers several deployment strategies selected by ``config["variant"]``:

    batch_first (default) : first chunk alone (fast first output), then the
                            remainder of the request in one batched pass.
    batch                 : whole request in one batched pass, then publish.
    chunk                 : per-chunk GPU passes with preallocated history.
    chunk_cat             : reference-shaped per-chunk evaluation (diagnostic).
    cpu_batch             : whole request on CPU (device placement experiment).
    auto                  : cpu_batch for tiny workloads, batch_first otherwise.

Only the adapter IPC contract is fixed; the compute schedule is ours.
"""
import argparse
import ast
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Fixed computation: build layers exactly like causal_features.model.build_layers
# (same AST extraction and same seed-before-construction order, so weights are
# bit-identical to the research reference).
# ---------------------------------------------------------------------------
def load_causal_conv(repository):
    source_path = Path(repository) / 'flashrt/layers/audio.py'
    node = next(node for node in ast.parse(source_path.read_text(encoding='utf-8')).body
                if isinstance(node, ast.ClassDef) and node.name == 'CausalConv1d')
    namespace = {'nn': nn, 'F': F, 'torch': torch}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source_path), 'exec'), namespace)
    return namespace['CausalConv1d']


def build_layers(repository, config, device):
    conv = load_causal_conv(repository)
    torch.manual_seed(int(config['weight_seed']))
    channels, hidden = int(config['channels']), int(config['hidden'])
    return nn.ModuleList([conv(channels, hidden, 5), conv(hidden, hidden, 5),
                          conv(hidden, channels, 3)]).to(device).eval()


class StreamingEngine:
    """Exact causal-conv streaming engine with minimal history state.

    State per layer: the last ``kernel_size - 1`` pre-convolution samples.
    At session start there is no history; the reference replicate-pads the
    first chunk, which we reproduce with F.pad(mode='replicate').  After that,
    a chunk (or the whole remainder) is convolved against history directly,
    which is identical to the reference's cat+pad+trim sequence.
    """

    def __init__(self, repository, config, device):
        self.device = device
        self.layers = build_layers(repository, config, device)
        self.params = [(layer.conv.weight.detach(), layer.conv.bias.detach(),
                        int(layer._time_causal_padding[0])) for layer in self.layers]
        self.hists = [None] * len(self.params)

    def reset(self):
        self.hists = [None] * len(self.params)

    def _layer(self, index, x):
        weight, bias, pad = self.params[index]
        hist = self.hists[index]
        if hist is None:
            padded = F.pad(x, (pad, 0), mode='replicate') if pad else x
            out = F.conv1d(padded, weight, bias)
            new_hist = x[..., -pad:].clone() if pad else x[..., :0].clone()
        else:
            if hist.shape[-1] < pad:
                hist = F.pad(hist, (pad - hist.shape[-1], 0), mode='replicate')
            joined = torch.cat((hist, x), dim=-1)
            out = F.conv1d(joined, weight, bias)
            new_hist = joined[..., -pad:].clone() if pad else joined[..., :0].clone()
        self.hists[index] = new_hist
        return F.silu(out)

    def step(self, x):
        value = x
        for index in range(len(self.params)):
            value = self._layer(index, value)
        return value


def select_device(config):
    requested = str(config.get('device', 'cuda'))
    if requested.startswith('cuda') and not torch.cuda.is_available():
        return 'cpu'
    return requested


def effective_variant(config):
    variant = str(config.get('variant', 'batch_first'))
    if variant == 'auto':
        channels, hidden = int(config['channels']), int(config['hidden'])
        length = int(config['length'])
        # dev case C=16,H=32,T=1043 is ~10 MFLOP: launch overhead dominates.
        flops = (channels * hidden * 5 + hidden * hidden * 5 + hidden * channels * 3) * length
        return 'cpu_batch' if flops < 1.0e8 else 'batch_first'
    return variant


class Publisher:
    def __init__(self, buffers, config):
        self.buffers = buffers
        self.channels = int(config['channels'])
        self.chunk = int(config['chunk'])
        self.length = int(config['length'])
        self.padded = np.zeros((self.channels, self.chunk), dtype=np.float32)
        self.meta = np.zeros((3,), dtype=np.int64)

    def emit(self, out, request_id, first_chunk, base_pos):
        total = out.shape[-1]
        count = (total + self.chunk - 1) // self.chunk
        for j in range(count):
            pos = j * self.chunk
            valid = min(self.chunk, total - pos)
            self.padded[:, :valid] = out[:, pos:pos + valid]
            if valid < self.chunk:
                self.padded[:, valid:] = 0.0
            # Data is published before metadata, exactly as the adapter checks.
            self.buffers['output'].write(self.padded)
            self.meta[0] = request_id
            self.meta[1] = first_chunk + j
            self.meta[2] = valid
            self.buffers['metadata'].write(self.meta)


def run_request(engine, features, config, publisher, request_id):
    variant = effective_variant(config)
    device = engine.device
    chunk = int(config['chunk'])
    length = int(config['length'])
    x = torch.from_numpy(features[0]).to(device)
    use_gpu = device.startswith('cuda')

    with torch.inference_mode():
        if variant in ('batch', 'cpu_batch', 'auto'):
            # One batched pass over the whole request; publish afterwards.
            out = engine.step(x)
            host = out.detach().to('cpu').numpy() if use_gpu else out.detach().numpy()
            publisher.emit(host, request_id, 0, 0)
        elif variant == 'batch_first':
            # Shortest critical path to the first output, then one batched pass.
            first = engine.step(x[:, :min(chunk, length)])
            host = first.detach().to('cpu').numpy() if use_gpu else first.detach().numpy()
            publisher.emit(host, request_id, 0, 0)
            if length > chunk:
                rest = engine.step(x[:, chunk:])
                host = rest.detach().to('cpu').numpy() if use_gpu else rest.detach().numpy()
                publisher.emit(host, request_id, 1, chunk)
        elif variant == 'chunk':
            # Per-chunk critical path with minimal history state.
            for index, pos in enumerate(range(0, length, chunk)):
                out = engine.step(x[:, pos:pos + chunk])
                host = out.detach().to('cpu').numpy() if use_gpu else out.detach().numpy()
                publisher.padded[:, :host.shape[-1]] = host
                if host.shape[-1] < chunk:
                    publisher.padded[:, host.shape[-1]:] = 0.0
                publisher.buffers['output'].write(publisher.padded)
                publisher.meta[0] = request_id
                publisher.meta[1] = index
                publisher.meta[2] = host.shape[-1]
                publisher.buffers['metadata'].write(publisher.meta)
        elif variant == 'chunk_cat':
            # Diagnostic: literally reference-shaped cat + replicate pad per chunk.
            for index, pos in enumerate(range(0, length, chunk)):
                value = x[:, pos:pos + chunk]
                for layer_index, layer in enumerate(engine.layers):
                    hist = engine.hists[layer_index]
                    joined = value if hist is None else torch.cat((hist, value), dim=-1)
                    result = layer(joined)
                    if hist is not None:
                        result = result[:, :, hist.shape[-1]:]
                    engine.hists[layer_index] = joined[..., -layer._time_causal_padding[0]:].clone()
                    value = F.silu(result)
                host = value.detach().to('cpu').numpy() if use_gpu else value.detach().numpy()
                publisher.padded[:, :host.shape[-1]] = host
                if host.shape[-1] < chunk:
                    publisher.padded[:, host.shape[-1]:] = 0.0
                publisher.buffers['output'].write(publisher.padded)
                publisher.meta[0] = request_id
                publisher.meta[1] = index
                publisher.meta[2] = host.shape[-1]
                publisher.buffers['metadata'].write(publisher.meta)
        else:
            raise ValueError(f'unknown variant: {variant}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    repository = args.repository.resolve()
    sys.path.insert(0, str(repository))

    from causal_features.adapter import open_buffers, close_buffers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(int(config.get('num_threads', 2)))
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    variant = effective_variant(config)
    device = select_device(config)
    engine = StreamingEngine(repository, config, device)

    # Warm the exact code paths once so the first real request is not paying
    # cuDNN handle / allocator initialisation.  State is reset afterwards.
    if bool(config.get('warmup', True)):
        try:
            with torch.inference_mode():
                if variant in ('batch_first', 'chunk', 'chunk_cat'):
                    engine.step(torch.zeros(1, int(config['channels']), int(config['chunk']),
                                            device=device))
                else:
                    engine.step(torch.zeros(1, int(config['channels']), int(config['length']),
                                            device=device))
        except Exception:
            pass
        if device.startswith('cuda'):
            torch.cuda.synchronize()
        engine.reset()

    buffers = open_buffers(config, create=True)
    publisher = Publisher(buffers, config)
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({'ready': True, 'device': device, 'variant': variant}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            run_request(engine, features, config, publisher, request_id)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
