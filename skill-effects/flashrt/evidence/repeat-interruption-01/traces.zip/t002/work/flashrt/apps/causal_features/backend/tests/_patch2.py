from pathlib import Path

CLEAN = '''

def _cleanup_orphans():
    import os
    try:
        import psutil
    except Exception:
        return
    target = os.path.join(os.getcwd(), 'flashrt', 'apps', 'causal_features')
    me = os.getpid()
    for proc in psutil.process_iter(['pid', 'cmdline']):
        try:
            cmd = ' '.join(proc.info['cmdline'] or [])
        except Exception:
            continue
        if proc.info['pid'] != me and 'pilot_trial.py' not in cmd and target in cmd:
            try:
                proc.kill()
            except Exception:
                pass


_cleanup_orphans()
'''
for name in ('run_correctness_matrix.py', 'run_bench_matrix.py'):
    p = Path('flashrt/apps/causal_features/backend/tests') / name
    s = p.read_text(encoding='utf-8')
    if '_cleanup_orphans' not in s:
        p.write_text(s + CLEAN, encoding='utf-8')
        print('appended cleanup to', name)
print('done')
