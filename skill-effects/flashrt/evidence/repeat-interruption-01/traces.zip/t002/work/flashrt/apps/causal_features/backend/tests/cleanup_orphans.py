import os, sys, time
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import psutil
me = os.getpid()
root = os.getcwd()
target = os.path.join(root, 'flashrt', 'apps', 'causal_features')
killed = []
for p in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
    try:
        cmd = ' '.join(p.info['cmdline'] or [])
        cwd = p.cwd()
    except Exception as exc:
        continue
    if p.info['pid'] == me:
        continue
    if 'pilot_trial.py' in cmd:
        continue
    relevant = target in cmd or (cwd and target in cwd)
    print('scan', p.info['pid'], 'relevant', relevant, 'cwd', cwd, 'cmd', cmd[:500])
    if relevant:
        try:
            p.kill()
            killed.append(p.info['pid'])
        except Exception as exc:
            print('kill failed', exc)
for pid in killed:
    try:
        psutil.Process(pid).wait(timeout=5)
    except Exception:
        pass
time.sleep(1)
left = []
for p in psutil.process_iter(['pid', 'cmdline']):
    try:
        cmd = ' '.join(p.info['cmdline'] or [])
        cwd = p.cwd()
    except Exception:
        continue
    if p.info['pid'] != me and 'pilot_trial.py' not in cmd and (target in cmd or (cwd and target in cwd)):
        left.append((p.info['pid'], cmd[:300], cwd))
print('killed', killed)
print('left', left)
