import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import os, re
roots = ['flashrt', 'docs', 'examples', 'README.md', 'pyproject.toml']
pat = re.compile(r'causal_features|verify_local_ir|run_local_reference|offered.load|chunk.gap', re.I)
hits = []
for root in roots:
    paths = [root] if os.path.isfile(root) else [os.path.join(dp, f) for dp, dn, fn in os.walk(root) for f in fn]
    for p in paths:
        if any(s in p for s in ('__pycache__', '.git')):
            continue
        try:
            txt = open(p, 'rb').read().decode('utf-8', errors='replace')
        except Exception:
            continue
        for i, line in enumerate(txt.splitlines(), 1):
            if pat.search(line):
                hits.append(p + ':' + str(i) + ': ' + line.strip()[:180])
for h in hits[:200]:
    print(h.encode('ascii', 'replace').decode('ascii'))
print('total', len(hits))
