import os, sys, json, glob, torch, numpy as np
print('python', sys.version)
print('torch', torch.__version__, 'cuda', torch.cuda.is_available())
if torch.cuda.is_available():
    print('gpu', torch.cuda.get_device_name(0), torch.cuda.get_device_capability(0))
print('cwd', os.getcwd())
print('root', sorted(os.listdir('.')))
import flashrt, inspect
print('flashrt', flashrt.__file__)
print('layers audio', inspect.getsourcefile(__import__('flashrt.layers.audio', fromlist=['x'])))
print('--- CausalConv1d ---')
src = open('flashrt/layers/audio.py').read()
i = src.index('class CausalConv1d')
print(src[i:i+2200])
print('--- evidence ---')
for p in sorted(glob.glob('evidence/**/*', recursive=True))[:80]:
    print(p)
print('--- template backend ---')
for p in sorted(glob.glob('flashrt/apps/_template/backend/**/*', recursive=True))[:80]:
    print(p)
