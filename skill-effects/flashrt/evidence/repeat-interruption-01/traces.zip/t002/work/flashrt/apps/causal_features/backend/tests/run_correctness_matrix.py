import json
import sys
from pathlib import Path

TESTS = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS))
import harness

W = str((TESTS.parent / 'worker.py').resolve())
REF = 'causal_features.reference'
cases = [
    ('reference_dev', REF, 'dev', 'reference', True, 'cuda'),
    ('batch_first_dev', W, 'dev', 'batch_first', False, 'cuda'),
    ('batch_dev', W, 'dev', 'batch', False, 'cuda'),
    ('chunk_dev', W, 'dev', 'chunk', False, 'cuda'),
    ('chunk_cat_dev', W, 'dev', 'chunk_cat', False, 'cuda'),
    ('cpu_batch_dev', W, 'dev', 'cpu_batch', False, 'cpu'),
    ('reference_large', REF, 'large', 'reference', True, 'cuda'),
    ('batch_first_large', W, 'large', 'batch_first', False, 'cuda'),
    ('cpu_batch_large', W, 'large', 'cpu_batch', False, 'cpu'),
]
summary = []
for label, entry, case, variant, module, device in cases:
    print('=== correctness', label, flush=True)
    ok, info = harness.run_correctness(entry, case, variant, module=module, device=device)
    summary.append(dict(label=label, case=case, variant=variant, device=device,
                        pass_=bool(ok), **info))
    print('--- result', label, 'PASS' if ok else 'FAIL', flush=True)
out = Path('flashrt/apps/causal_features/backend/benchmarks/results/correctness_summary.json')
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(summary, indent=2), encoding='utf-8')
print('SUMMARY', json.dumps(summary))


def _cleanup_orphans():
    import os
    try:
        import psutil
    except Exception:
        return
    target = os.path.join(os.getcwd(), 'flashrt', 'apps', 'causal_features')
    me = os.getpid()
    for proc in psutil.process_iter(['pid', 'cmdline']):
        try:
            cmd = ' '.join(proc.info['cmdline'] or [])
        except Exception:
            continue
        if proc.info['pid'] != me and 'pilot_trial.py' not in cmd and target in cmd:
            try:
                proc.kill()
            except Exception:
                pass


_cleanup_orphans()
