import inspect, json, os, sys, importlib

print('CWD', os.getcwd())
print('PY', sys.executable, sys.version.split()[0])
try:
    import torch
    print('TORCH', torch.__version__, 'cuda', torch.cuda.is_available(),
          torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)
except Exception as e:
    print('TORCH ERR', e)

for mod in ('flashrt', 'causal_features', 'causal_features.adapter', 'causal_features.model'):
    try:
        m = importlib.import_module(mod)
        print('IMPORT OK', mod, getattr(m, '__file__', None))
    except Exception as e:
        print('IMPORT FAIL', mod, type(e).__name__, e)

# look for any existing config json fixtures in repo
hits = []
for root, dirs, files in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in ('.git', '__pycache__')]
    for f in files:
        if f.endswith('.json') and ('config' in f or 'causal' in f):
            hits.append(os.path.join(root, f))
    if len(hits) > 40:
        break
print('JSON CANDIDATES', hits[:40])

import flashrt.ir as ir
print('IR EXPORTS', [n for n in dir(ir) if not n.startswith('_')])
from flashrt.ir.graph import IRGraph, IROperator, StateObject, TensorPort
from flashrt.ir.executor import SequentialExecutor
print('IRGraph.__init__', inspect.signature(IRGraph.__init__))
print('IRGraph methods', [n for n in dir(IRGraph) if not n.startswith('_')])
print('IROperator.__init__', inspect.signature(IROperator.__init__))
print('SequentialExecutor', inspect.signature(SequentialExecutor.__init__),
      [n for n in dir(SequentialExecutor) if not n.startswith('_')])
import flashrt.ir.analysis as an
print('ANALYSIS', [n for n in dir(an) if not n.startswith('_')])
for f in ('analyze_cross_chunk_dependencies', 'find_pipeline_stages', 'find_streaming_overlaps',
          'compute_critical_path', 'summarize_graph'):
    print(f, inspect.signature(getattr(an, f)))
print('add_operator', inspect.signature(IRGraph.add_operator))
print('add_edge', inspect.signature(IRGraph.add_edge))
