import subprocess, sys
from pathlib import Path

B = Path('flashrt/apps/causal_features/backend')
f = B / 'cfcommon.py'
t = f.read_text(encoding='utf-8')
t = t.replace("x = torch.from_numpy(np.concatenate([r['out'] * 0 + r['inp'] for r in seg], axis=1).copy())",
              "x = torch.from_numpy(np.concatenate([r['inp'] for r in seg], axis=1).copy())")
f.write_text(t, encoding='utf-8')
print('patched oracle' if "r['inp'] for r in seg" in t else 'PATCH FAILED')

g = B / 'benchmarks' / 'bench.py'
s = g.read_text(encoding='utf-8')
s = s.replace("        if cold and i == 0 and rate == RATES[0]:\n            cold_rec = dict(first_ms=(t_first - t_in) / 1e6, total_ms=(t_done - t_in) / 1e6)\n        else:\n            first.append((t_first - t_in) / 1e6)\n            comp.append((t_done - t_in) / 1e6)",
              "        first.append((t_first - t_in) / 1e6)\n        comp.append((t_done - t_in) / 1e6)")
s = s.replace("    return out, (cold_rec if ('cold_rec' in dir()) else None)", "    return out, None")
g.write_text(s, encoding='utf-8')

def run(cmd, tail=60):
    print('=== ', ' '.join(cmd), flush=True)
    r = subprocess.run(cmd, capture_output=True, text=True)
    print(r.stdout[-6000:], flush=True)
    if r.returncode != 0:
        print('STDERR', r.stderr[-3000:], flush=True)
    print('rc=', r.returncode, flush=True)
    return r

py = sys.executable
run([py, str(B / 'tests' / 'harness.py'), '--worker', 'reference', '--preset', 'dev', '--tag', 'reference'])
run([py, str(B / 'benchmarks' / 'bench.py'), '--worker', 'reference', '--preset', 'dev', '--tag', 'reference'])
run([py, str(B / 'benchmarks' / 'bench.py'), '--worker', 'reference', '--preset', 'large', '--tag', 'reference'])
