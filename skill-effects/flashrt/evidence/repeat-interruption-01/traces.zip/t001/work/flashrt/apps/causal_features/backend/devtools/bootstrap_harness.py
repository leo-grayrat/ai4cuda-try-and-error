import sys, time
from pathlib import Path

B = Path('flashrt/apps/causal_features/backend')


def w(rel, text):
    p = B / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')
    print('wrote', p, len(text))


w('cfcommon.py', r'''"""Shared harness utilities for the causal_features backend workspace.

Config presets, backend subprocess driver (adapter-driven), and the CPU
full-sequence oracle used as the numerical reference.
"""
import importlib
import json
import math
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import numpy as np

PRESETS = {
    # development case from CONTRACT.zh.md (tail chunk: 1043 = 8*127 + 27)
    'dev': dict(channels=16, hidden=32, length=1043, chunk=127),
    # larger case from CONTRACT.zh.md
    'large': dict(channels=128, hidden=256, length=16384, chunk=512),
}

WEIGHT_SEED = 703


def repo_root():
    try:
        from flashrt.paths import repo_root as rr
        return Path(rr()).resolve()
    except Exception:
        return Path.cwd().resolve()


ROOT = repo_root()


def make_config(preset, device='cuda', prefix=None):
    cfg = dict(PRESETS[preset])
    cfg.update(weight_seed=WEIGHT_SEED, device=device,
               prefix=prefix or ('cf' + uuid.uuid4().hex[:10]))
    return cfg


def reference_entry():
    """Path to the research reference module (launched as a script)."""
    m = importlib.import_module('causal_features.reference')
    return Path(m.__file__)


def num_chunks(config):
    return int(math.ceil(config['length'] / config['chunk']))


def spawn(worker, config, logdir, tag):
    logdir = Path(logdir)
    logdir.mkdir(parents=True, exist_ok=True)
    cfgpath = logdir / ('config_%s.json' % tag)
    cfgpath.write_text(json.dumps(config, indent=1), encoding='utf-8')
    err = open(logdir / ('stderr_%s.log' % tag), 'w', encoding='utf-8')
    cmd = [sys.executable, str(worker), '--repository', str(ROOT), '--config', str(cfgpath)]
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = '0'
    env['PYTHONUNBUFFERED'] = '1'
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=err, cwd=str(ROOT),
                            env=env, text=True, bufsize=1)
    return proc, err, cfgpath


def wait_ready(proc, timeout_s=600.0):
    t0 = time.time()
    while True:
        line = proc.stdout.readline()
        if line == '':
            raise RuntimeError('backend exited before signalling ready')
        line = line.strip()
        if line.startswith('{'):
            try:
                info = json.loads(line)
            except Exception:
                continue
            if info.get('ready'):
                return info
        if time.time() - t0 > timeout_s:
            raise TimeoutError('backend did not become ready in %.0fs' % timeout_s)


def shutdown(proc, adapter, err):
    try:
        if adapter is not None:
            adapter.terminate()
    except Exception as exc:
        print('terminate warning:', exc)
    try:
        proc.wait(timeout=60)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=30)
    try:
        proc.stdout.close()
    except Exception:
        pass
    err.close()


def drive(adapter, scenario, request_timeout=300.0):
    """scenario: list of ('reset', tag) or ('req', features, tag)."""
    recs = []
    for step in scenario:
        if step[0] == 'reset':
            adapter.reset()
            recs.append(dict(kind='reset', tag=step[1]))
            continue
        _, features, tag = step
        rid, t_in = adapter.submit(features)
        chunks, times = [], []
        while adapter.pending is not None:
            data, t_obs = adapter.receive(timeout_s=request_timeout)
            chunks.append(np.array(data, dtype=np.float32))
            times.append(t_obs)
        recs.append(dict(kind='req', tag=tag, id=int(rid), t_in=int(t_in), chunk_t=times,
                         out=np.concatenate(chunks, axis=-1),
                         chunk_len=[int(c.shape[-1]) for c in chunks]))
    return recs


def segments_of(recs):
    """Split request records into session segments (a reset starts a new one)."""
    segs, cur = [], []
    for r in recs:
        if r['kind'] == 'reset':
            if cur:
                segs.append(cur)
                cur = []
        else:
            cur.append(r)
    if cur:
        segs.append(cur)
    return segs


def oracle_segments(config, segs):
    """CPU full-sequence oracle: session = concatenation of its requests."""
    import torch
    import torch.nn.functional as F
    from causal_features.model import build_layers
    layers = build_layers(str(ROOT), config, 'cpu')
    outs = []
    with torch.inference_mode():
        for seg in segs:
            x = torch.from_numpy(np.concatenate([r['out'] * 0 + r['inp'] for r in seg], axis=1).copy())
            x = x.unsqueeze(0)
            for layer in layers:
                x = F.silu(layer(x))
            full = x.squeeze(0).numpy()
            pos = 0
            for r in seg:
                width = r['inp'].shape[-1]
                outs.append(full[:, pos:pos + width])
                pos += width
    return outs


ATOL = 3e-5
RTOL = 3e-4
# Justification: the contract fixes atol=3e-5/rtol=3e-4 to allow CPU/GPU float32
# accumulation-order differences in the same convolution mathematics. Nothing
# here changes the meaning of the computation (no TF32, no lower precision)
# unless a variant explicitly experiments with that and is judged by this bound.


def make_inputs(preset, seed=1234):
    cfg = PRESETS[preset]
    rng = np.random.default_rng(seed)
    c, t = cfg['channels'], cfg['length']
    return [rng.standard_normal((c, t), dtype=np.float32) for _ in range(3)]


def make_scenario(preset, seed=1234):
    """Six complete requests: continuation, repeat-without-reset, reset reproduction."""
    a, b, c = make_inputs(preset, seed)
    return [('req', a, 'A1'), ('req', b, 'B1'), ('req', a, 'A2-repeat'),
            ('reset', 'R1'), ('req', a, 'A1-after-reset'),
            ('req', b, 'B1-after-reset'), ('reset', 'R2'), ('req', c, 'C1')]


def attach_inputs(recs, scenario):
    feats = {s[2]: s[1] for s in scenario if s[0] == 'req'}
    for r in recs:
        if r['kind'] == 'req':
            r['inp'] = feats[r['tag']]
    return recs


def compare(recs, config):
    segs = segments_of(recs)
    exp = oracle_segments(config, segs)
    flat = [r for s in segs for r in s]
    rows, ok = [], True
    for r, e in zip(flat, exp):
        d = np.abs(r['out'].astype(np.float64) - e.astype(np.float64))
        tol = ATOL + RTOL * np.abs(e.astype(np.float64))
        bad = int((d > tol).sum())
        good = bad == 0 and r['out'].shape == e.shape
        ok = ok and good
        rows.append(dict(tag=r['tag'], id=r['id'], shape=list(r['out'].shape),
                         max_abs=float(d.max()), mean_abs=float(d.mean()),
                         bad=bad, chunks=len(r['chunk_len']),
                         chunk_len=r['chunk_len'][:3] + ['...'] + r['chunk_len'][-1:],
                         pass_=bool(good)))
    return ok, rows


def orphan_check(pattern):
    try:
        out = subprocess.run(['wmic', 'process', 'where', "name='python.exe'", 'get', 'ProcessId,CommandLine'],
                             capture_output=True, text=True).stdout
    except Exception:
        out = ''
    hits = [l for l in out.splitlines() if pattern in l]
    return hits


def cleanup_run(config):
    """Best-effort removal of stale shm segments for a prefix (Windows: file mappings)."""
    prefix = config['prefix']
    names = [prefix + '__ctrl', prefix + '_input__meta', prefix + '_input__tensor',
             prefix + '_output__meta', prefix + '_output__tensor',
             prefix + '_metadata__meta', prefix + '_metadata__tensor']
    try:
        from multiprocessing import shared_memory
        for n in names:
            try:
                shm = shared_memory.SharedMemory(name=n, create=False)
                shm.close()
                shm.unlink()
            except Exception:
                pass
    except Exception:
        pass
''')

w('tests/harness.py', r'''"""Phase-4 deployment correctness harness.

Launches a candidate backend (or the research reference) as a subprocess, drives
it through the shared adapter with a six-request scenario (continuation, repeat
without reset, reset reproduction, tail chunk), and compares every request
against the CPU full-sequence oracle.

usage: python .../tests/harness.py --worker <path|reference> --preset dev
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parent.parent))

import cfcommon as C  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--worker', required=True)
    ap.add_argument('--preset', default='dev')
    ap.add_argument('--tag', default='cand')
    ap.add_argument('--logdir', default=None)
    args = ap.parse_args()

    worker = C.reference_entry() if args.worker == 'reference' else Path(args.worker).resolve()
    logdir = Path(args.logdir) if args.logdir else (HERE / 'logs')
    tag = args.tag
    config = C.make_config(args.preset)
    scenario = C.make_scenario(args.preset)
    from causal_features.adapter import FeatureAdapter

    print('worker:', worker, 'preset:', args.preset, 'prefix:', config['prefix'], flush=True)
    proc, err, _ = C.spawn(worker, config, logdir, tag)
    adapter = None
    t0 = time.perf_counter()
    try:
        info = C.wait_ready(proc)
        print('ready:', info, 'startup_s=%.2f' % (time.perf_counter() - t0), flush=True)
        adapter = FeatureAdapter(config)
        adapter.start()
        recs = C.drive(adapter, scenario)
    finally:
        C.shutdown(proc, adapter, err)
    recs = C.attach_inputs(recs, scenario)
    ok, rows = C.compare(recs, config)
    # reset reproduction: the post-reset request must repeat the first request
    by_tag = {r['tag']: r for r in recs if r['kind'] == 'req'}
    rep = by_tag['A1-after-reset']['out'] - by_tag['A1']['out']
    print(json.dumps(dict(hardware='RTX 5060 Laptop', preset=args.preset, worker=str(worker),
                          rows=rows, reset_repeat_max_abs=float(np.abs(rep).max()),
                          pass_=bool(ok)), indent=1), flush=True)
    (Path(logdir) / ('verdict_%s_%s.json' % (tag, args.preset))).write_text(
        json.dumps(dict(worker=str(worker), preset=args.preset, rows=rows,
                        reset_repeat_max_abs=float(np.abs(rep).max()), pass_=bool(ok)), indent=1),
        encoding='utf-8')
    print('VERDICT', 'PASS' if ok else 'FAIL', flush=True)
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
''')

w('benchmarks/bench.py', r'''"""Paired finite offered-load benchmark for one backend.

Targets measured (defaults from the repo contract):
  * latency to first output per request  (t_first_out - t_in): median / p95
  * sustainable output rate: highest offered input rate where every submit
    starts on time and every inter-chunk gap stays inside the 20 ms chunk budget
  * smoothness: inter-chunk gap median / p95 / fraction over the 20 ms budget

usage: python .../benchmarks/bench.py --worker <path|reference> --preset dev
"""
import argparse
import json
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parent.parent))

import cfcommon as C  # noqa: E402

CHUNK_BUDGET_MS = 20.0
RATES = [0.0, 400.0, 200.0, 100.0, 50.0, 25.0]  # requests/s, 0 = back-to-back
REQ_PER_RATE = 12


def flat(seq):
    return list(seq) if seq else []


def pct(vals, q):
    if not vals:
        return None
    return float(np.percentile(np.asarray(vals, dtype=np.float64), q))


def run_rate(adapter, config, rate, reqs, rng, cold):
    period = 0.0 if rate <= 0 else 1.0 / rate
    first, comp, gaps, slips = [], [], [], []
    t_start = time.perf_counter()
    n_chunks = C.num_chunks(config)
    for i in range(reqs):
        if period:
            target = t_start + i * period
            now = time.perf_counter()
            if now < target:
                time.sleep(target - now)
            slips.append(max(0.0, time.perf_counter() - target) * 1e3)
        f = rng.standard_normal((config['channels'], config['length']), dtype=np.float32)
        rid, t_in = adapter.submit(f)
        t_first = None
        prev = None
        while adapter.pending is not None:
            data, t_obs = adapter.receive(timeout_s=300)
            if t_first is None:
                t_first = t_obs
            elif prev is not None:
                gaps.append((t_obs - prev) / 1e6)
            prev = t_obs
        t_done = time.perf_counter_ns()
        if cold and i == 0 and rate == RATES[0]:
            cold_rec = dict(first_ms=(t_first - t_in) / 1e6, total_ms=(t_done - t_in) / 1e6)
        else:
            first.append((t_first - t_in) / 1e6)
            comp.append((t_done - t_in) / 1e6)
    wall = time.perf_counter() - t_start
    out = dict(rate=rate, period_ms=period * 1e3, requests=reqs,
               achieved_rate=reqs / wall,
               first_ms_median=pct(first, 50), first_ms_p95=pct(first, 95),
               comp_ms_median=pct(comp, 50), comp_ms_p95=pct(comp, 95),
               gap_ms_median=pct(gaps, 50), gap_ms_p95=pct(gaps, 95),
               gap_over_budget_frac=(sum(1 for g in gaps if g > CHUNK_BUDGET_MS) / len(gaps)) if gaps else 0.0,
               gaps_measured=len(gaps),
               max_slip_ms=(max(slips) if slips else 0.0),
               chunks_per_request=n_chunks)
    return out, (cold_rec if ('cold_rec' in dir()) else None)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--worker', required=True)
    ap.add_argument('--preset', default='dev')
    ap.add_argument('--tag', default='cand')
    ap.add_argument('--outdir', default=None)
    ap.add_argument('--rates', default=None)
    ap.add_argument('--reqs', type=int, default=REQ_PER_RATE)
    args = ap.parse_args()

    worker = C.reference_entry() if args.worker == 'reference' else Path(args.worker).resolve()
    outdir = Path(args.outdir) if args.outdir else (HERE / 'results')
    outdir.mkdir(parents=True, exist_ok=True)
    config = C.make_config(args.preset)
    rates = [float(x) for x in args.rates.split(',')] if args.rates else RATES
    from causal_features.adapter import FeatureAdapter

    print('worker:', worker, 'preset:', args.preset, 'prefix:', config['prefix'], flush=True)
    proc, err, _ = C.spawn(worker, config, outdir, args.tag)
    adapter = None
    cold = None
    rows = []
    t0 = time.perf_counter()
    try:
        info = C.wait_ready(proc)
        startup = time.perf_counter() - t0
        adapter = FeatureAdapter(config)
        adapter.start()
        # warm-up request (timed separately, excluded from steady statistics)
        rng = np.random.default_rng(7)
        f = rng.standard_normal((config['channels'], config['length']), dtype=np.float32)
        t_in = adapter.submit(f)[1]
        t_first = None
        while adapter.pending is not None:
            _, t_obs = adapter.receive(timeout_s=300)
            if t_first is None:
                t_first = t_obs
        cold = dict(first_ms=(t_first - t_in) / 1e6, total_ms=(time.perf_counter_ns() - t_in) / 1e6)
        print('cold-start request: first=%.2fms total=%.2fms' % (cold['first_ms'], cold['total_ms']), flush=True)
        for rate in rates:
            row, _ = run_rate(adapter, config, rate, args.reqs, rng, False)
            rows.append(row)
            print(json.dumps(row), flush=True)
    finally:
        C.shutdown(proc, adapter, err)

    steady = [r for r in rows if r['max_slip_ms'] < 5.0 and r['gap_over_budget_frac'] == 0.0]
    best = max([r['rate'] for r in steady], default=0.0)
    summary = dict(
        worker=str(worker), tag=args.tag, preset=args.preset, config=config,
        hardware=platform.processor() or platform.machine(),
        gpu='RTX 5060 Laptop 8GB', cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        chunk_budget_ms=CHUNK_BUDGET_MS, startup_s=startup, cold=cold,
        offered_rates=rows, sustainable_offered_rate=best,
        max_achieved_rate=max([r['achieved_rate'] for r in rows], default=0.0),
        active_targets=['latency-to-first-output', 'sustainable-output-rate', 'smoothness'],
    )
    path = outdir / ('%s_%s.json' % (args.tag, args.preset))
    path.write_text(json.dumps(summary, indent=1), encoding='utf-8')
    print('SUMMARY sustainable_offered_rate=%.0f req/s max_achieved=%.1f req/s -> %s'
          % (best, summary['max_achieved_rate'], path), flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
''')
print('bootstrap done')
