"""Phase-4 deployment correctness harness.

Launches a candidate backend (or the research reference) as a subprocess, drives
it through the shared adapter with a six-request scenario (continuation, repeat
without reset, reset reproduction, tail chunk), and compares every request
against the CPU full-sequence oracle.

usage: python .../tests/harness.py --worker <path|reference> --preset dev
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parent.parent))

import cfcommon as C  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--worker', required=True)
    ap.add_argument('--preset', default='dev')
    ap.add_argument('--tag', default='cand')
    ap.add_argument('--logdir', default=None)
    args = ap.parse_args()

    worker = C.reference_entry() if args.worker == 'reference' else Path(args.worker).resolve()
    logdir = Path(args.logdir) if args.logdir else (HERE / 'logs')
    tag = args.tag
    config = C.make_config(args.preset)
    scenario = C.make_scenario(args.preset)
    from causal_features.adapter import FeatureAdapter

    print('worker:', worker, 'preset:', args.preset, 'prefix:', config['prefix'], flush=True)
    proc, err, _ = C.spawn(worker, config, logdir, tag)
    adapter = None
    t0 = time.perf_counter()
    try:
        info = C.wait_ready(proc)
        print('ready:', info, 'startup_s=%.2f' % (time.perf_counter() - t0), flush=True)
        adapter = FeatureAdapter(config)
        adapter.start()
        recs = C.drive(adapter, scenario)
    finally:
        C.shutdown(proc, adapter, err)
    recs = C.attach_inputs(recs, scenario)
    ok, rows = C.compare(recs, config)
    # reset reproduction: the post-reset request must repeat the first request
    by_tag = {r['tag']: r for r in recs if r['kind'] == 'req'}
    rep = by_tag['A1-after-reset']['out'] - by_tag['A1']['out']
    print(json.dumps(dict(hardware='RTX 5060 Laptop', preset=args.preset, worker=str(worker),
                          rows=rows, reset_repeat_max_abs=float(np.abs(rep).max()),
                          pass_=bool(ok)), indent=1), flush=True)
    (Path(logdir) / ('verdict_%s_%s.json' % (tag, args.preset))).write_text(
        json.dumps(dict(worker=str(worker), preset=args.preset, rows=rows,
                        reset_repeat_max_abs=float(np.abs(rep).max()), pass_=bool(ok)), indent=1),
        encoding='utf-8')
    print('VERDICT', 'PASS' if ok else 'FAIL', flush=True)
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
