from pathlib import Path

B = Path('flashrt/apps/causal_features/backend')

# 1) add the combination of CUDA-graph replay with the host-side levers
p = B / 'devtools' / 'bootstrap_worker.py'
t = p.read_text(encoding='utf-8')
anchor = "    'final_combo':"
new = ("    'graph_replay_combo': dict(mode='bulk', prefix=True, puball=True, graph=True,\n"
       "                               pinned=True, busy=True, zerocopy=True),\n")
assert anchor in t and 'graph_replay_combo' not in t
t = t.replace(anchor, new + anchor, 1)
p.write_text(t, encoding='utf-8')
print('template patched')

# 2) stress preset first, dev preset only for the correctness verdict
p = B / 'devtools' / 'run_variants.py'
t = p.read_text(encoding='utf-8')
t = t.replace("presets = ['dev', 'large']", "presets = ['large', 'dev']")
t = t.replace("        want_b = not bench.exists()\n",
              "        want_b = not bench.exists() and preset != 'dev'\n")
t = t.replace('STOP_AFTER = 200.0', 'STOP_AFTER = 235.0')
p.write_text(t, encoding='utf-8')
print('runner patched')
