"""Paired finite offered-load benchmark for one backend.

Targets measured (defaults from the repo contract):
  * latency to first output per request  (t_first_out - t_in): median / p95
  * sustainable output rate: highest offered input rate where every submit
    starts on time and every inter-chunk gap stays inside the 20 ms chunk budget
  * smoothness: inter-chunk gap median / p95 / fraction over the 20 ms budget

usage: python .../benchmarks/bench.py --worker <path|reference> --preset dev
"""
import argparse
import json
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parent.parent))

import cfcommon as C  # noqa: E402

CHUNK_BUDGET_MS = 20.0
RATES = [0.0, 400.0, 200.0, 100.0, 50.0, 25.0]  # requests/s, 0 = back-to-back
REQ_PER_RATE = 12


def flat(seq):
    return list(seq) if seq else []


def pct(vals, q):
    if not vals:
        return None
    return float(np.percentile(np.asarray(vals, dtype=np.float64), q))


def run_rate(adapter, config, rate, reqs, rng, cold):
    period = 0.0 if rate <= 0 else 1.0 / rate
    first, comp, gaps, slips = [], [], [], []
    t_start = time.perf_counter()
    n_chunks = C.num_chunks(config)
    for i in range(reqs):
        if period:
            target = t_start + i * period
            now = time.perf_counter()
            if now < target:
                time.sleep(target - now)
            slips.append(max(0.0, time.perf_counter() - target) * 1e3)
        f = rng.standard_normal((config['channels'], config['length']), dtype=np.float32)
        rid, t_in = adapter.submit(f)
        t_first = None
        prev = None
        while adapter.pending is not None:
            data, t_obs = adapter.receive(timeout_s=300)
            if t_first is None:
                t_first = t_obs
            elif prev is not None:
                gaps.append((t_obs - prev) / 1e6)
            prev = t_obs
        t_done = time.perf_counter_ns()
        first.append((t_first - t_in) / 1e6)
        comp.append((t_done - t_in) / 1e6)
    wall = time.perf_counter() - t_start
    out = dict(rate=rate, period_ms=period * 1e3, requests=reqs,
               achieved_rate=reqs / wall,
               first_ms_median=pct(first, 50), first_ms_p95=pct(first, 95),
               comp_ms_median=pct(comp, 50), comp_ms_p95=pct(comp, 95),
               gap_ms_median=pct(gaps, 50), gap_ms_p95=pct(gaps, 95),
               gap_over_budget_frac=(sum(1 for g in gaps if g > CHUNK_BUDGET_MS) / len(gaps)) if gaps else 0.0,
               gaps_measured=len(gaps),
               max_slip_ms=(max(slips) if slips else 0.0),
               chunks_per_request=n_chunks)
    return out, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--worker', required=True)
    ap.add_argument('--preset', default='dev')
    ap.add_argument('--tag', default='cand')
    ap.add_argument('--outdir', default=None)
    ap.add_argument('--rates', default=None)
    ap.add_argument('--reqs', type=int, default=REQ_PER_RATE)
    args = ap.parse_args()

    worker = C.reference_entry() if args.worker == 'reference' else Path(args.worker).resolve()
    outdir = Path(args.outdir) if args.outdir else (HERE / 'results')
    outdir.mkdir(parents=True, exist_ok=True)
    config = C.make_config(args.preset)
    rates = [float(x) for x in args.rates.split(',')] if args.rates else RATES
    from causal_features.adapter import FeatureAdapter

    print('worker:', worker, 'preset:', args.preset, 'prefix:', config['prefix'], flush=True)
    proc, err, _ = C.spawn(worker, config, outdir, args.tag)
    adapter = None
    cold = None
    rows = []
    t0 = time.perf_counter()
    try:
        info = C.wait_ready(proc)
        startup = time.perf_counter() - t0
        adapter = FeatureAdapter(config)
        adapter.start()
        # warm-up request (timed separately, excluded from steady statistics)
        rng = np.random.default_rng(7)
        f = rng.standard_normal((config['channels'], config['length']), dtype=np.float32)
        t_in = adapter.submit(f)[1]
        t_first = None
        while adapter.pending is not None:
            _, t_obs = adapter.receive(timeout_s=300)
            if t_first is None:
                t_first = t_obs
        cold = dict(first_ms=(t_first - t_in) / 1e6, total_ms=(time.perf_counter_ns() - t_in) / 1e6)
        print('cold-start request: first=%.2fms total=%.2fms' % (cold['first_ms'], cold['total_ms']), flush=True)
        for rate in rates:
            row, _ = run_rate(adapter, config, rate, args.reqs, rng, False)
            rows.append(row)
            print(json.dumps(row), flush=True)
    finally:
        C.shutdown(proc, adapter, err)

    steady = [r for r in rows if r['max_slip_ms'] < 5.0 and r['gap_over_budget_frac'] == 0.0]
    best = max([r['rate'] for r in steady], default=0.0)
    summary = dict(
        worker=str(worker), tag=args.tag, preset=args.preset, config=config,
        hardware=platform.processor() or platform.machine(),
        gpu='RTX 5060 Laptop 8GB', cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        chunk_budget_ms=CHUNK_BUDGET_MS, startup_s=startup, cold=cold,
        offered_rates=rows, sustainable_offered_rate=best,
        max_achieved_rate=max([r['achieved_rate'] for r in rows], default=0.0),
        active_targets=['latency-to-first-output', 'sustainable-output-rate', 'smoothness'],
    )
    path = outdir / ('%s_%s.json' % (args.tag, args.preset))
    path.write_text(json.dumps(summary, indent=1), encoding='utf-8')
    print('SUMMARY sustainable_offered_rate=%.0f req/s max_achieved=%.1f req/s -> %s'
          % (best, summary['max_achieved_rate'], path), flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
