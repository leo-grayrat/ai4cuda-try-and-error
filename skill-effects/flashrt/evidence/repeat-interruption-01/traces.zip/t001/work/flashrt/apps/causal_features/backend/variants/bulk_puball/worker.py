"""Standalone causal_features backend (single GPU), strategy: bulk_puball

One (C, T) float32 request enters through the fixed adapter
(causal_features/adapter.py); ceil(T/chunk) ordered chunks leave through it.
The three layers are the pinned upstream CausalConv1d stack; each layer keeps
its own chunk-persistent convolution history and a reset clears the session.

The parametric strategy table below selects where the work is placed:
  mode='bulk'   one full-length pass per layer (minimum kernel/launch overhead)
  mode='tile'   one pass per output chunk (minimum first-output latency)
  mode='wave'   per-chunk tiles on three CUDA streams (layer wavefront overlap)
plus publishing (per chunk vs one batched write), host staging (pinned),
cuDNN autotune, busy-poll control loop, zero-copy input read and CUDA-graph replay.
"""
import argparse
import json
import math
import sys
import time
from pathlib import Path

STRATEGY = 'bulk_puball'

DEFAULT = dict(mode='bulk', prefix=True, puball=True, pinned=False, autotune=False,
               busy=False, zerocopy=False, graph=False, tf32=False)

STRATEGIES = {
    'gpu_chunk_stream':   dict(mode='tile', prefix=False, puball=False),
    'tile_wavefront':     dict(mode='wave', prefix=False, puball=False),
    'bulk_puball':        dict(mode='bulk', prefix=False, puball=True),
    'bulk_pubper':        dict(mode='bulk', prefix=False, puball=False),
    'prefix_bulk_pubper': dict(mode='bulk', prefix=True, puball=False),
    'prefix_bulk_puball': dict(mode='bulk', prefix=True, puball=True),
    'prefix_bulk_pinned': dict(mode='bulk', prefix=True, puball=True, pinned=True),
    'prefix_bulk_autotune': dict(mode='bulk', prefix=True, puball=True, autotune=True),
    'prefix_bulk_busy':   dict(mode='bulk', prefix=True, puball=True, busy=True),
    'prefix_bulk_zerocopy': dict(mode='bulk', prefix=True, puball=True, zerocopy=True),
    'graph_replay':       dict(mode='bulk', prefix=True, puball=True, graph=True),
    'tf32_bulk':          dict(mode='bulk', prefix=True, puball=True, tf32=True),
    'graph_replay_combo': dict(mode='bulk', prefix=True, puball=True, graph=True,
                               pinned=True, busy=True, zerocopy=True),
    'final_combo':        dict(mode='bulk', prefix=True, puball=True, pinned=True,
                               autotune=True, busy=True, zerocopy=True),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repository', type=Path, required=True)
    ap.add_argument('--config', type=Path, required=True)
    args = ap.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    sys.path.insert(0, str(args.repository.resolve()))
    import numpy as np
    import torch
    import torch.nn.functional as F
    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers

    S = dict(DEFAULT)
    S.update(STRATEGIES[STRATEGY])
    torch.backends.cudnn.benchmark = bool(S['autotune'])
    torch.backends.cudnn.allow_tf32 = bool(S['tf32'])
    torch.backends.cuda.matmul.allow_tf32 = bool(S['tf32'])

    dev = config['device']
    CIN, T, CH = int(config['channels']), int(config['length']), int(config['chunk'])
    n = int(math.ceil(T / CH))
    layers = build_layers(str(args.repository), config, dev)
    weights = [(l.conv.weight, l.conv.bias) for l in layers]
    pads = [int(l._time_causal_padding[0]) for l in layers]
    cins = [CIN] + [int(config['hidden']), int(config['hidden'])]

    # chunk-persistent convolution history per layer + full padded conv buffers
    inb = [torch.zeros((1, ci, p + T), device=dev) for ci, p in zip(cins, pads)]
    hist = [torch.zeros((1, ci, p), device=dev) for ci, p in zip(cins, pads)]
    win = [torch.zeros((1, ci, p + CH), device=dev) for ci, p in zip(cins, pads)]
    thist = [torch.zeros((1, ci, p), device=dev) for ci, p in zip(cins, pads)]
    host = torch.zeros((CIN, n * CH), dtype=torch.float32, pin_memory=bool(S['pinned']))
    host_np = host.numpy()
    frames = host_np.reshape(CIN, n, CH).transpose(1, 0, 2)
    vlens = np.array([min(CH, T - t * CH) for t in range(n)], dtype=np.int64)
    state = {'first': True}

    def fill_hist(i, prev):
        P = pads[i]
        if state['first']:
            inb[i][:, :, :P].copy_(prev[:, :, :1].expand(-1, -1, P))
        else:
            inb[i][:, :, :P].copy_(hist[i])

    def bulk_all(x):
        prev = x
        for i in range(3):
            P = pads[i]
            buf = inb[i]
            fill_hist(i, prev)
            buf[:, :, P:].copy_(prev)
            w_, b_ = weights[i]
            prev = F.silu(F.conv1d(buf, w_, b_))
            hist[i].copy_(buf[:, :, T:T + P])
        return prev

    def prefix_only(x):
        prev = x[:, :, :CH]
        for i in range(3):
            P = pads[i]
            buf = inb[i]
            fill_hist(i, prev)
            buf[:, :, P:P + CH].copy_(prev)
            w_, b_ = weights[i]
            prev = F.silu(F.conv1d(buf[:, :, :P + CH], w_, b_))
        return prev

    def suffix_only(x):
        prev = x[:, :, CH:]
        for i in range(3):
            P = pads[i]
            buf = inb[i]
            buf[:, :, P + CH:].copy_(prev)
            w_, b_ = weights[i]
            prev = F.silu(F.conv1d(buf[:, :, CH:P + T], w_, b_))
        for i in range(3):
            hist[i].copy_(inb[i][:, :, T:T + pads[i]])
        return prev

    def tile_chunk(x, t, ln):
        prev = x[:, :, t * CH:t * CH + ln]
        for i in range(3):
            P = pads[i]
            buf = win[i]
            first_cols = state['first'] and t == 0
            if first_cols:
                buf[:, :, :P].copy_(prev[:, :, :1].expand(-1, -1, P))
            else:
                buf[:, :, :P].copy_(thist[i])
            buf[:, :, P:P + ln].copy_(prev)
            w_, b_ = weights[i]
            prev = F.silu(F.conv1d(buf[:, :, :P + ln], w_, b_))
            thist[i].copy_(buf[:, :, ln:ln + P])
        return prev

    def prime(x):
        """First request after a reset: history = replicate of each layer input's
        first column, exactly what F.pad(mode='replicate') does at t=0."""
        prev = x[:, :, :1]
        for i in range(3):
            P = pads[i]
            hist[i].copy_(prev.expand(-1, -1, P))
            w_, b_ = weights[i]
            prev = F.silu(F.conv1d(prev.expand(-1, -1, P + 1), w_, b_))

    def d2h(src, a, b, stream=None):
        st = stream if stream is not None else torch.cuda.current_stream()
        with torch.cuda.stream(st):
            host[:, a:b].copy_(src.squeeze(0), non_blocking=True)
        st.synchronize()

    pub_stream = torch.cuda.Stream()
    wave_streams = [torch.cuda.Stream() for _ in range(3)]

    # optional CUDA-graph capture of the whole prefix+bulk chain (static shapes)
    graph, gpre, gsuf, xstat = None, None, None, None
    if S['graph']:
        xstat = torch.zeros((1, CIN, T), device=dev)
        side = torch.cuda.Stream()
        state['first'] = False
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(2):
                prefix_only(xstat)
                if T > CH:
                    suffix_only(xstat)
        torch.cuda.current_stream().wait_stream(side)
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            gpre = prefix_only(xstat)
            if T > CH:
                gsuf = suffix_only(xstat)
        state['first'] = True

    buffers = open_buffers(config, create=True)
    out_buf, meta_buf, in_buf, ctrl = (buffers['output'], buffers['metadata'],
                                       buffers['input'], buffers['control'])
    consumed, last_command, active = 0, 0, False

    def publish_frame(req, t):
        out_buf.write(host_np[:, t * CH:(t + 1) * CH])
        meta_buf.write(np.array([[req, t, vlens[t]]], dtype=np.int64))

    def publish_rest(req, start):
        for t in range(start, n):
            publish_frame(req, t)

    try:
        print(json.dumps({'ready': True, 'device': dev, 'strategy': STRATEGY}), flush=True)
        while True:
            opcode = ctrl.recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    ctrl.commit()
                    break
                if opcode == 3:
                    state['first'] = True
                    active = False
                    ctrl.commit()
                elif opcode == 1:
                    active = True
                    ctrl.commit()
                elif opcode != 0:
                    raise ValueError('Unknown control opcode: %s' % opcode)
            if not active:
                time.sleep(0) if S['busy'] else time.sleep(0.0002)
                continue
            g = consumed
            have = int(in_buf.num)
            if have <= g:
                time.sleep(0) if S['busy'] else time.sleep(0.0002)
                continue
            if have > g + 1:
                raise RuntimeError('Input overwritten before processing')
            if S['zerocopy']:
                xhost = in_buf.tensor[g % in_buf.max_len]
            else:
                _, fr = in_buf.read(g, 1)
                if fr is None:
                    continue
                xhost = fr[0]
            consumed = g + 1
            with torch.inference_mode():
                x = torch.from_numpy(np.ascontiguousarray(xhost)).unsqueeze(0).to(dev)
                if S['graph']:
                    xstat.copy_(x)
                    if state['first']:
                        prime(xstat)
                    graph.replay()
                    d2h(gpre, 0, CH)
                    publish_frame(g, 0)
                    if T > CH:
                        d2h(gsuf, CH, T)
                        publish_rest(g, 1)
                elif S['mode'] == 'tile':
                    for t in range(n):
                        a = t * CH
                        ln = int(vlens[t])
                        d2h(tile_chunk(x, t, ln), a, a + ln)
                        publish_frame(g, t)
                elif S['mode'] == 'wave':
                    evs = [[torch.cuda.Event() for _ in range(n)] for _ in range(3)]
                    for t in range(n):
                        a = t * CH
                        ln = int(vlens[t])
                        outs = [None, None, None]
                        for i in range(3):
                            st = wave_streams[i]
                            st.wait_event(evs[i][t - 1]) if t > 0 else None
                            if i > 0:
                                st.wait_event(evs[i - 1][t])
                            with torch.cuda.stream(st):
                                P = pads[i]
                                buf = win[i]
                                prev = x[:, :, a:a + ln] if i == 0 else outs[i - 1]
                                if state['first'] and t == 0:
                                    buf[:, :, :P].copy_(prev[:, :, :1].expand(-1, -1, P))
                                else:
                                    buf[:, :, :P].copy_(thist[i])
                                buf[:, :, P:P + ln].copy_(prev)
                                w_, b_ = weights[i]
                                outs[i] = F.silu(F.conv1d(buf[:, :, :P + ln], w_, b_))
                                thist[i].copy_(buf[:, :, ln:ln + P])
                                evs[i][t].record(st)
                        pub_stream.wait_event(evs[2][t])
                        d2h(outs[2], a, a + ln, stream=pub_stream)
                        publish_frame(g, t)
                else:
                    start = 0
                    if S['prefix'] and T > CH:
                        d2h(prefix_only(x), 0, CH)
                        publish_frame(g, 0)
                        start = 1
                        d2h(suffix_only(x), CH, T)
                    else:
                        d2h(bulk_all(x), 0, T)
                    if S['puball']:
                        out_buf.write(frames[start:n])
                        meta_buf.write(np.stack([np.full(n - start, g, dtype=np.int64),
                                                 np.arange(start, n, dtype=np.int64),
                                                 vlens[start:n]], axis=1))
                    else:
                        publish_rest(g, start)
            state['first'] = False
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
