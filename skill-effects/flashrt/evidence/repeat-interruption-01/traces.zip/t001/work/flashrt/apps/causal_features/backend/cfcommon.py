"""Shared harness utilities for the causal_features backend workspace.

Config presets, backend subprocess driver (adapter-driven), and the CPU
full-sequence oracle used as the numerical reference.
"""
import importlib
import json
import math
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import numpy as np

PRESETS = {
    # development case from CONTRACT.zh.md (tail chunk: 1043 = 8*127 + 27)
    'dev': dict(channels=16, hidden=32, length=1043, chunk=127),
    # larger case from CONTRACT.zh.md
    'large': dict(channels=128, hidden=256, length=16384, chunk=512),
}

WEIGHT_SEED = 703


def repo_root():
    try:
        from flashrt.paths import repo_root as rr
        return Path(rr()).resolve()
    except Exception:
        return Path.cwd().resolve()


ROOT = repo_root()


def make_config(preset, device='cuda', prefix=None):
    cfg = dict(PRESETS[preset])
    cfg.update(weight_seed=WEIGHT_SEED, device=device,
               prefix=prefix or ('cf' + uuid.uuid4().hex[:10]))
    return cfg


def reference_entry():
    """Path to the research reference module (launched as a script)."""
    m = importlib.import_module('causal_features.reference')
    return Path(m.__file__)


def num_chunks(config):
    return int(math.ceil(config['length'] / config['chunk']))


def spawn(worker, config, logdir, tag):
    logdir = Path(logdir)
    logdir.mkdir(parents=True, exist_ok=True)
    cfgpath = logdir / ('config_%s.json' % tag)
    cfgpath.write_text(json.dumps(config, indent=1), encoding='utf-8')
    err = open(logdir / ('stderr_%s.log' % tag), 'w', encoding='utf-8')
    cmd = [sys.executable, str(worker), '--repository', str(ROOT), '--config', str(cfgpath)]
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = '0'
    env['PYTHONUNBUFFERED'] = '1'
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=err, cwd=str(ROOT),
                            env=env, text=True, bufsize=1)
    return proc, err, cfgpath


def wait_ready(proc, timeout_s=600.0):
    t0 = time.time()
    while True:
        line = proc.stdout.readline()
        if line == '':
            raise RuntimeError('backend exited before signalling ready')
        line = line.strip()
        if line.startswith('{'):
            try:
                info = json.loads(line)
            except Exception:
                continue
            if info.get('ready'):
                return info
        if time.time() - t0 > timeout_s:
            raise TimeoutError('backend did not become ready in %.0fs' % timeout_s)


def shutdown(proc, adapter, err):
    try:
        if adapter is not None:
            adapter.terminate()
    except Exception as exc:
        print('terminate warning:', exc)
    try:
        proc.wait(timeout=60)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=30)
    try:
        proc.stdout.close()
    except Exception:
        pass
    err.close()


def drive(adapter, scenario, request_timeout=300.0):
    """scenario: list of ('reset', tag) or ('req', features, tag)."""
    recs = []
    for step in scenario:
        if step[0] == 'reset':
            adapter.reset()
            recs.append(dict(kind='reset', tag=step[1]))
            continue
        _, features, tag = step
        rid, t_in = adapter.submit(features)
        chunks, times = [], []
        while adapter.pending is not None:
            data, t_obs = adapter.receive(timeout_s=request_timeout)
            chunks.append(np.array(data, dtype=np.float32))
            times.append(t_obs)
        recs.append(dict(kind='req', tag=tag, id=int(rid), t_in=int(t_in), chunk_t=times,
                         out=np.concatenate(chunks, axis=-1),
                         chunk_len=[int(c.shape[-1]) for c in chunks]))
    return recs


def segments_of(recs):
    """Split request records into session segments (a reset starts a new one)."""
    segs, cur = [], []
    for r in recs:
        if r['kind'] == 'reset':
            if cur:
                segs.append(cur)
                cur = []
        else:
            cur.append(r)
    if cur:
        segs.append(cur)
    return segs


def oracle_segments(config, segs):
    """CPU full-sequence oracle: session = concatenation of its requests."""
    import torch
    import torch.nn.functional as F
    from causal_features.model import build_layers
    layers = build_layers(str(ROOT), config, 'cpu')
    outs = []
    with torch.inference_mode():
        for seg in segs:
            x = torch.from_numpy(np.concatenate([r['inp'] for r in seg], axis=1).copy())
            x = x.unsqueeze(0)
            for layer in layers:
                x = F.silu(layer(x))
            full = x.squeeze(0).numpy()
            pos = 0
            for r in seg:
                width = r['inp'].shape[-1]
                outs.append(full[:, pos:pos + width])
                pos += width
    return outs


ATOL = 3e-5
RTOL = 3e-4
# Justification: the contract fixes atol=3e-5/rtol=3e-4 to allow CPU/GPU float32
# accumulation-order differences in the same convolution mathematics. Nothing
# here changes the meaning of the computation (no TF32, no lower precision)
# unless a variant explicitly experiments with that and is judged by this bound.


def make_inputs(preset, seed=1234):
    cfg = PRESETS[preset]
    rng = np.random.default_rng(seed)
    c, t = cfg['channels'], cfg['length']
    return [rng.standard_normal((c, t), dtype=np.float32) for _ in range(3)]


def make_scenario(preset, seed=1234):
    """Six complete requests: continuation, repeat-without-reset, reset reproduction."""
    a, b, c = make_inputs(preset, seed)
    return [('req', a, 'A1'), ('req', b, 'B1'), ('req', a, 'A2-repeat'),
            ('reset', 'R1'), ('req', a, 'A1-after-reset'),
            ('req', b, 'B1-after-reset'), ('reset', 'R2'), ('req', c, 'C1')]


def attach_inputs(recs, scenario):
    feats = {s[2]: s[1] for s in scenario if s[0] == 'req'}
    for r in recs:
        if r['kind'] == 'req':
            r['inp'] = feats[r['tag']]
    return recs


def compare(recs, config):
    segs = segments_of(recs)
    exp = oracle_segments(config, segs)
    flat = [r for s in segs for r in s]
    rows, ok = [], True
    for r, e in zip(flat, exp):
        d = np.abs(r['out'].astype(np.float64) - e.astype(np.float64))
        tol = ATOL + RTOL * np.abs(e.astype(np.float64))
        bad = int((d > tol).sum())
        good = bad == 0 and r['out'].shape == e.shape
        ok = ok and good
        rows.append(dict(tag=r['tag'], id=r['id'], shape=list(r['out'].shape),
                         max_abs=float(d.max()), mean_abs=float(d.mean()),
                         bad=bad, chunks=len(r['chunk_len']),
                         chunk_len=r['chunk_len'][:3] + ['...'] + r['chunk_len'][-1:],
                         pass_=bool(good)))
    return ok, rows


def orphan_check(pattern):
    try:
        out = subprocess.run(['wmic', 'process', 'where', "name='python.exe'", 'get', 'ProcessId,CommandLine'],
                             capture_output=True, text=True).stdout
    except Exception:
        out = ''
    hits = [l for l in out.splitlines() if pattern in l]
    return hits


def cleanup_run(config):
    """Best-effort removal of stale shm segments for a prefix (Windows: file mappings)."""
    prefix = config['prefix']
    names = [prefix + '__ctrl', prefix + '_input__meta', prefix + '_input__tensor',
             prefix + '_output__meta', prefix + '_output__tensor',
             prefix + '_metadata__meta', prefix + '_metadata__tensor']
    try:
        from multiprocessing import shared_memory
        for n in names:
            try:
                shm = shared_memory.SharedMemory(name=n, create=False)
                shm.close()
                shm.unlink()
            except Exception:
                pass
    except Exception:
        pass
