"""Regenerate all variant workers from the template, then verify+benchmark the
missing (variant, preset) pairs.  Resumable: a pair is skipped when both its
correctness verdict and its benchmark JSON already exist, so repeated runs
continue where the previous execute call was cut off.

usage: run_variants.py            (all variants, dev then large)
"""
import subprocess
import sys
import time
from pathlib import Path

B = Path('flashrt/apps/causal_features/backend')
PY = sys.executable

exec(compile((B / 'devtools' / 'bootstrap_worker.py').read_text(encoding='utf-8'),
             str(B / 'devtools' / 'bootstrap_worker.py'), 'exec'), {'__name__': '__main__'})

names = [p.parent.name for p in sorted((B / 'variants').glob('*/worker.py'))]
presets = ['large', 'dev']
STOP_AFTER = 235.0
t_start = time.time()


def run(cmd, tail=1500):
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True)
    keep = [l for l in r.stdout.splitlines()
            if ('VERDICT' in l or 'SUMMARY' in l or '"rate": 0.0' in l or '"rate": 25.0' in l
                or 'cold-start' in l or 'Error' in l)]
    print('--- %s (%.1fs rc=%d)\n%s' % (Path(cmd[1]).name, time.time() - t0, r.returncode,
                                        '\n'.join(keep[-8:])), flush=True)
    if r.returncode != 0:
        print('STDERR:', r.stderr[-tail:], flush=True)


for preset in presets:
    for name in names:
        verdict = B / 'tests' / 'logs' / ('verdict_%s_%s.json' % (name, preset))
        bench = B / 'benchmarks' / 'results' / ('%s_%s.json' % (name, preset))
        want_v = not verdict.exists()
        want_b = not bench.exists() and preset != 'dev'
        if not (want_v or want_b):
            continue
        print('====================', name, preset, flush=True)
        wk = str(B / 'variants' / name / 'worker.py')
        if want_v:
            run([PY, str(B / 'tests' / 'harness.py'), '--worker', wk, '--preset', preset, '--tag', name])
        if want_b:
            run([PY, str(B / 'benchmarks' / 'bench.py'), '--worker', wk, '--preset', preset, '--tag', name])
        if time.time() - t_start > STOP_AFTER:
            print('stopping for wall-clock budget after', name, preset, flush=True)
            sys.exit(0)
print('all pairs done', flush=True)
