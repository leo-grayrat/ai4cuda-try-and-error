"""Environment diagnostic: torch/CUDA versions, GPU identity, IR module surface."""
import inspect
import sys

import numpy as np
import torch

print('python', sys.version.split()[0])
print('torch', torch.__version__, 'cuda', torch.version.cuda)
print('cuda available', torch.cuda.is_available())
if torch.cuda.is_available():
    print('device count', torch.cuda.device_count())
    print('device 0', torch.cuda.get_device_name(0), torch.cuda.get_device_capability(0))
    print('mem GB', torch.cuda.get_device_properties(0).total_memory / 1e9)

import flashrt
print('flashrt', flashrt.__file__)
import flashrt.ir as ir
print('ir exports', [n for n in dir(ir) if not n.startswith('_')])
from flashrt.ir import IROperator, IRGraph, SequentialExecutor, StateObject, TensorPort, OpType, StreamMode
print('IROperator init sig', inspect.signature(IROperator.__init__))
print('IRGraph init sig', inspect.signature(IRGraph.__init__))
print('IRGraph add_operator sig', inspect.signature(IRGraph.add_operator))
print('SequentialExecutor sig', inspect.signature(SequentialExecutor.__init__))
print('SequentialExecutor methods', [n for n in dir(SequentialExecutor) if not n.startswith('_')])
print('StateObject sig', inspect.signature(StateObject.__init__))
print('TensorPort sig', inspect.signature(TensorPort.__init__))
print('OpType', list(OpType), 'StreamMode', list(StreamMode))
print('cudnn available', torch.backends.cudnn.is_available())
print('np', np.__version__)
