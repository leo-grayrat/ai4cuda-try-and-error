"""Isolate CPU-oracle vs GPU-backend numerical semantics (no IPC involved).

Compares, for the same six-request session:
  A. CPU full-sequence oracle          (causal_features.model.full_sequence_oracle)
  B. CPU literal chunk loop            (ReferencePipeline.step on CPU)
  C. GPU full-sequence single pass     (span-fused formulation, fresh + history)
  D. GPU literal chunk loop            (ReferencePipeline.step on CUDA)
"""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
sys.path.insert(0, str(REPO / 'flashrt' / 'apps'))
sys.path.insert(0, str(REPO))

from causal_features.model import build_layers, full_sequence_oracle, ReferencePipeline  # noqa: E402

CDEV = dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703)
T, K = CDEV['length'], CDEV['chunk']
gen = np.random.default_rng(20240703)
A0 = gen.standard_normal((CDEV['channels'], T), dtype=np.float32)
A1 = gen.standard_normal((CDEV['channels'], T), dtype=np.float32)
session = [A0, A1, A1, A0]
joined = np.concatenate(session, axis=1)

oracle = full_sequence_oracle(str(REPO), CDEV, joined)

# B: literal chunk loop on CPU
proto = dict(CDEV, device='cpu')
pipe = ReferencePipeline(str(REPO), proto)
cpu_chunks = []
for feats in session:
    per = []
    for base in range(0, T, K):
        per.append(pipe.step(feats[:, base:base + K]))
    cpu_chunks.append(np.concatenate(per, axis=1))
cpu_chunked = np.concatenate(cpu_chunks, axis=1)

# D: literal chunk loop on CUDA (the reference backend path)
gproto = dict(CDEV, device='cuda')
gpipe = ReferencePipeline(str(REPO), gproto)
gpu_chunks = []
for feats in session:
    per = []
    for base in range(0, T, K):
        per.append(gpipe.step(feats[:, base:base + K]))
    gpu_chunks.append(np.concatenate(per, axis=1))
gpu_chunked = np.concatenate(gpu_chunks, axis=1)


# C: span-fused formulation, whole session in one pass with history hand-off
@torch.no_grad()
def span_fused(layers, pads, feats, histories):
    device = histories[0].device
    value = torch.from_numpy(feats.copy()).unsqueeze(0).to(device)
    for i, layer in enumerate(layers):
        p = pads[i]
        joined_t = torch.cat([histories[i], value], dim=-1)
        value = F.silu(F.conv1d(joined_t, layer.conv.weight, layer.conv.bias))
        histories[i] = joined_t[:, :, -p:].clone() if p else joined_t[:, :, :0].clone()
    return value.squeeze(0).cpu().numpy()


glayers = build_layers(str(REPO), CDEV, 'cuda')
pads = [int(layer._time_causal_padding[0]) for layer in glayers]
ghist = [torch.zeros(1, d, p, device='cuda') for d, p in
         zip([CDEV['channels'], CDEV['hidden'], CDEV['hidden']], pads)]
gpu_span = []
for feats in session:
    if ghist[0].shape[-1] == pads[0]:
        pass
    gpu_span.append(np.concatenate([span_fused(glayers, pads, feats[:, b:b + K], ghist)
                                    for b in range(0, T, K)], axis=1))
gpu_span = np.concatenate(gpu_span, axis=1)


def report(name, a, b):
    delta = np.abs(a - b)
    allow = 3e-5 + 3e-4 * np.abs(b)
    bad = np.argwhere(delta > allow)
    print(f'{name}: max_abs={delta.max():.3e} violations={len(bad)}')
    if len(bad):
        times = sorted({int(t) for _, t in bad})
        print('   violating time positions (first 40):', times[:40])
        print('   per-request counts:',
              [int(sum(1 for _, t in bad if i * T <= t < (i + 1) * T)) for i in range(len(session))])
        t0 = times[0]
        print('   value at first violation: cpu=', a[:, t0][:4], 'ref=', b[:, t0][:4])


report('CPU chunk-loop   vs CPU oracle', cpu_chunked, oracle)
report('GPU chunk-loop   vs CPU oracle', gpu_chunked, oracle)
report('GPU span-fused   vs CPU oracle', gpu_span, oracle)
report('GPU span-fused   vs GPU chunk-loop', gpu_span, gpu_chunked)
print('dtypes', cpu_chunked.dtype, gpu_chunked.dtype, gpu_span.dtype)
print('magnitudes: oracle absmax', float(np.abs(oracle).max()),
      'mean', float(np.abs(oracle).mean()))
