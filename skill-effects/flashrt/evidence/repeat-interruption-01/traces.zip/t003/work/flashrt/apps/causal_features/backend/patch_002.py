from pathlib import Path

HERE = Path(__file__).resolve().parent
w = HERE / 'worker.py'
t = w.read_text(encoding='utf-8')
t = t.replace("for span, fresh in list(self.graphs) and keys:", "for span, fresh in keys:")
w.write_text(t, encoding='utf-8')

b = HERE / 'benchmarks' / 'bench_e2e.py'
t = b.read_text(encoding='utf-8')
t = t.replace("""        mode = args_mode = None""", "")
t = t.replace("""        if mode:
            cmd += ['--mode', mode]""", """        cmd += mode_args(mode)""")
t = t.replace("""def launch(name, config, mode=None, tag=None):""", '''def mode_args(mode):
    if not mode:
        return []
    out = []
    if mode.endswith('_eager'):
        out.append('--no-graph')
        mode = mode[:-6]
    if mode == 'whole':
        out += ['--plan', 'whole']
    elif mode == 'chunk':
        out += ['--plan', 'chunk']
    elif mode.startswith('split'):
        out += ['--spans', mode[5:]]
    return out


def launch(name, config, mode=None, tag=None):''')
t = t.replace("""        record['cold_first_out_ms'] = (observed - t_submit) / 1e6
""", """        record['cold_first_out_ms'] = (observed - t_submit) / 1e6
        adapter.reset()
""")
t = t.replace("""        record['reset_reproduces'] = bool(np.allclose(blocks[1], blocks[5], atol=ATOL, rtol=RTOL))""",
              """        record['reset_reproduces'] = bool(np.allclose(blocks[0], blocks[5], atol=ATOL, rtol=RTOL))""")
old_print = t[t.index("            print(json.dumps({"):t.index("    out = RESULTS / f'bench_e2e_")]
new_print = """            corr = record.get('correctness') or {}
            sw = sweeps[0]
            line = (f"{config_name}/{name} ok={record['status'] == 'ok'} "
                    f"corr={corr.get('ok')}/{corr.get('violations')} "
                    f"first_out={lat.get('median', float('nan')):.3f}/{lat.get('p95', float('nan')):.3f}ms "
                    f"rps={sw.get('achieved_requests_per_s', float('nan')):.1f} "
                    f"cps={sw.get('achieved_chunks_per_s', float('nan')):.1f} "
                    f"gapp95={[round(s.get('gap_ms_p95', 0), 1) for s in sweeps]} "
                    f"over={[round(s.get('gap_over_budget_fraction', 0), 2) for s in sweeps]} "
                    f"behind={[s.get('fell_behind') for s in sweeps]} "
                    f"reset={record.get('reset_reproduces')} cold={record.get('cold_first_out_ms', 0):.2f}")
            if record['status'] != 'ok':
                line += f" ERR={record['status'][:200]}"
            print(line, flush=True)
"""
t = t.replace(old_print, new_print)
b.write_text(t, encoding='utf-8')
print('patched')
