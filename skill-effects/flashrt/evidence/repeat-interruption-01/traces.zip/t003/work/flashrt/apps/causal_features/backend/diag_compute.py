"""Print the pinned CausalConv1d source and micro-benchmark the exposed compute."""
import ast
import json
import time
from pathlib import Path

import numpy as np
import torch

repo = Path(__file__).resolve().parents[4]
src = repo / 'flashrt/layers/audio.py'
node = next(n for n in ast.parse(src.read_text(encoding='utf-8')).body
            if isinstance(n, ast.ClassDef) and n.name == 'CausalConv1d')
print('=== CausalConv1d source ===')
print(ast.get_source_segment(src.read_text(encoding='utf-8'), node))

import sys
sys.path.insert(0, str(repo))
from causal_features.model import build_layers

torch.backends.cudnn.benchmark = False
torch.backends.cudnn.allow_tf32 = False
torch.backends.cuda.matmul.allow_tf32 = False


def bench(fn, n=200, warm=20):
    for _ in range(warm):
        fn()
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(n):
        fn()
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / n * 1e3


for cfg in ({'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127, 'weight_seed': 703},
            {'channels': 128, 'hidden': 256, 'length': 16384, 'chunk': 512, 'weight_seed': 703}):
    C, H, T, K = cfg['channels'], cfg['hidden'], cfg['length'], cfg['chunk']
    layers = build_layers(repo, cfg, 'cuda')
    pads = [layers[0]._time_causal_padding[0], layers[1]._time_causal_padding[0],
            layers[2]._time_causal_padding[0]]
    print(f"\n=== cfg C={C} H={H} T={T} chunk={K} pads={pads} latent={layers[0]._time_causal_padding} ===")
    x = torch.randn(1, C, T, device='cuda')
    b1 = layers[0]
    # full request one shot (history zeros)
    def full():
        v = x
        for i, layer in enumerate(layers):
            p = pads[i]
            v = torch.nn.functional.silu(layer(torch.cat([torch.zeros(1, v.shape[1], p, device='cuda'), v], -1))[:, :, p:])
        return v
    with torch.inference_mode():
        out_full = full()
        print('full forward ms', round(bench(full), 4))
        # chunkwise with persistent buffers
        buf = [torch.zeros(1, C, T + pads[0], device='cuda'),
               torch.zeros(1, H, T + pads[1], device='cuda'),
               torch.zeros(1, H, T + pads[2], device='cuda')]
        def chunkwise():
            for ci in range(0, T, K):
                k = min(K, T - ci)
                v = x[:, :, ci:ci + k]
                v = torch.nn.functional.silu(layers[0](torch.cat([buf[0][:, :, :pads[0]], v], -1))[:, :, pads[0]:])
                v = torch.nn.functional.silu(layers[1](torch.cat([buf[1][:, :, :pads[1]], v], -1))[:, :, pads[1]:])
                v = torch.nn.functional.silu(layers[2](torch.cat([buf[2][:, :, :pads[2]], v], -1))[:, :, pads[2]:])
            return v
        print('chunkwise ms', round(bench(chunkwise, n=50), 4))
        h = torch.empty(1, C, T, device='cuda', pin_memory=True)
        hx = torch.empty(1, C, T, pin_memory=True)
        def copy_roundtrip():
            g = torch.empty(1, C, T, device='cuda')
            g.copy_(hx, non_blocking=True)
            return g
        print('h2d pinned ms', round(bench(copy_roundtrip), 4))
        def d2h():
            h.copy_(out_full, non_blocking=True)
            torch.cuda.synchronize()
        print('d2h+sync ms', round(bench(d2h), 4))
        # cuda graph of full
        try:
            gs = torch.cuda.Stream()
            gs.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(gs):
                for _ in range(3):
                    full()
            torch.cuda.current_stream().wait_stream(gs)
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                out_g = full()
            def replay():
                graph.replay()
            print('graph replay ms', round(bench(replay), 4))
            torch.cuda.synchronize()
            print('graph matches eager', bool(torch.allclose(out_g, out_full, atol=1e-6, rtol=1e-5)))
        except Exception as exc:  # noqa
            print('graph capture failed', type(exc).__name__, exc)
        # numpy publish cost
        out_np = out_full.cpu().numpy()[0]
        nch = (T + K - 1) // K
        scratch = np.zeros((C, K), np.float32)
        meta = np.zeros(3, np.int64)
        def publish():
            for i in range(nch):
                base = i * K
                valid = min(K, T - base)
                if valid == K:
                    scratch[:, :] = out_np[:, base:base + K]
                else:
                    scratch[:, :valid] = out_np[:, base:base + valid]
                    scratch[:, valid:] = 0
                meta[0], meta[1], meta[2] = 0, i, valid
        print('numpy publish (no shm) ms', round(bench(publish), 4), 'chunks', nch)
