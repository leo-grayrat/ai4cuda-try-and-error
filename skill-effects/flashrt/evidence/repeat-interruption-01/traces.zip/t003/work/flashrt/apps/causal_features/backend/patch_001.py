"""Apply small, surgical fixes to worker.py / bench_e2e.py."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
worker = HERE / 'worker.py'
bench = HERE / 'benchmarks' / 'bench_e2e.py'

text = worker.read_text(encoding='utf-8')
old = "        self.device = torch.device(device_arg)\n        torch.cuda.set_device(self.device)\n"
new = ("        self.device = torch.device(device_arg)\n"
       "        if self.device.index is not None:\n"
       "            torch.cuda.set_device(self.device.index)\n")
assert old in text
worker.write_text(text.replace(old, new), encoding='utf-8')

text = bench.read_text(encoding='utf-8')
pairs = [
    ("        blocks.append(np.stack(got, axis=0))",
     "        blocks.append(np.concatenate(got, axis=1))"),
    ("        t_submit = time.perf_counter()", "        t_submit = time.perf_counter_ns()"),
    ("        'fell_behind': bool(elapsed > count * max(period_s, 1e-6) * 1.15),",
     "        'fell_behind': bool(period_s > 0 and elapsed > count * period_s * 1.15),"),
]
for old, new in pairs:
    assert old in text, old
    text = text.replace(old, new)
bench.write_text(text, encoding='utf-8')
print('patched')
