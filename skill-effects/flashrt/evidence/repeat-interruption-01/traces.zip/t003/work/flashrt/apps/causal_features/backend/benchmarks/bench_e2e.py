"""End-to-end correctness + benchmark harness for the causal_features backend.

Launches a backend (the protected reference, or this workspace's worker.py in a
chosen mode) as a subprocess, drives it through the fixed adapter with a
six-request scenario (continuation, repeated input without reset, reset
reproduction, short tail chunk), then runs a finite offered-load sweep with
varied inputs and a 20 ms chunk-gap budget.  Every number comes from a real run
on the real IPC contract.

    python flashrt/apps/causal_features/backend/benchmarks/bench_e2e.py \
        [configs=dev,big] [reference] [whole] [first_rest] [chunk] [whole_eager]
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent            # .../backend/benchmarks
BACKEND = HERE.parent                             # .../backend
REPO = BACKEND.parents[3]                         # repo root
APPS = REPO / 'flashrt' / 'apps'
for path in (str(APPS), str(REPO)):
    if path not in sys.path:
        sys.path.insert(0, path)

from causal_features.adapter import FeatureAdapter           # noqa: E402
from causal_features.model import full_sequence_oracle       # noqa: E402

RESULTS = HERE / 'results'
RESULTS.mkdir(parents=True, exist_ok=True)

ATOL = 3e-5   # contract tolerance: allowed CPU/GPU float32 reduction-order drift
RTOL = 3e-4

CONFIGS = {
    'dev': dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703, device='cuda'),
    'big': dict(channels=128, hidden=256, length=16384, chunk=512, weight_seed=703, device='cuda'),
}
SWEEP = [(0.000, 6), (0.001, 6), (0.002, 6), (0.005, 6), (0.010, 6), (0.020, 6)]
GAP_BUDGET_MS = 20.0


def scenario_inputs(config, seed=20240703):
    generator = np.random.default_rng(seed)
    shape = (config['channels'], config['length'])
    a0 = generator.standard_normal(shape, dtype=np.float32)
    a1 = generator.standard_normal(shape, dtype=np.float32)
    a2 = generator.standard_normal(shape, dtype=np.float32)
    reset = object()
    plan = [(a0, 's1-r0'), (a1, 's1-r1'), (a1, 's1-r2-repeat'),
            (a0, 's1-r3'), reset, (a0, 's2-r0-reset'), (a2, 's2-r1')]
    return plan


def _is_reset(item):
    return item.__class__ is object


def oracle_sessions(config, plan):
    sessions = [[]]
    for item in plan:
        if _is_reset(item):
            sessions.append([])
            continue
        sessions[-1].append(item[0])
    out = []
    for inputs in sessions:
        if not inputs:
            out.append(None)
            continue
        out.append(full_sequence_oracle(str(REPO), config, np.concatenate(inputs, axis=1)))
    return out


def _pct(values, q):
    if not values:
        return float('nan')
    return float(np.percentile(np.asarray(values, dtype=np.float64), q))


def mode_args(mode):
    if not mode:
        return []
    out = []
    if mode.endswith('_eager'):
        out.append('--no-graph')
        mode = mode[:-6]
    if mode == 'whole':
        out += ['--plan', 'whole']
    elif mode == 'chunk':
        out += ['--plan', 'chunk']
    elif mode.startswith('split'):
        out += ['--spans', mode[5:]]
    return out


def launch(name, config, mode=None, tag=None):
    tag = tag or f'{name}_{int(time.time() * 1000) % 1000000}'
    full = dict(config)
    full['prefix'] = f'cfbench_{tag}'
    config_path = RESULTS / f'{tag}_config.json'
    config_path.write_text(json.dumps(full), encoding='utf-8')
    log_path = RESULTS / f'{tag}.log'
    if name == 'reference':
        cmd = [sys.executable, '-m', 'causal_features.reference',
               '--repository', str(REPO), '--config', str(config_path)]
    else:
        cmd = [sys.executable, str(BACKEND / 'worker.py'),
               '--repository', str(REPO), '--config', str(config_path)]
        cmd += mode_args(mode)
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = '0'
    env['PYTHONPATH'] = os.pathsep.join(
        [str(APPS), str(REPO)] + ([env['PYTHONPATH']] if env.get('PYTHONPATH') else []))
    log = open(log_path, 'w', encoding='utf-8')
    proc = subprocess.Popen(cmd, cwd=str(REPO), stdout=log, stderr=subprocess.STDOUT,
                            env=env,
                            creationflags=getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0))
    return proc, log, full, log_path


def wait_ready(proc, prefix, log_path, timeout_s=120.0):
    """Wait for the creator's control segment, failing fast if the child died."""
    from multiprocessing import shared_memory
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            tail = ''
            try:
                tail = Path(log_path).read_text(encoding='utf-8', errors='replace')[-2000:]
            except Exception:
                pass
            raise RuntimeError(f'backend exited rc={proc.returncode}: {tail}')
        try:
            probe = shared_memory.SharedMemory(name=f'{prefix}__ctrl', create=False)
            probe.close()
            return
        except FileNotFoundError:
            time.sleep(0.02)
    raise RuntimeError('backend never created its control segment')


def stop(proc, log, adapter=None):
    try:
        if adapter is not None:
            try:
                adapter.terminate()
            except Exception:
                pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=10)
    finally:
        try:
            log.close()
        except Exception:
            pass


def collect(config, plan, adapter):
    blocks = []
    meta = []
    for item in plan:
        if _is_reset(item):
            adapter.reset()
            blocks.append(None)
            continue
        features, label = item
        request_id, published = adapter.submit(features)
        got = []
        stamps = []
        while True:
            data, observed = adapter.receive(timeout_s=120)
            got.append(data.copy())
            stamps.append(observed)
            if adapter.pending is None:
                break
        blocks.append(np.concatenate(got, axis=1))
        meta.append({'label': label, 'request_id': request_id, 'chunks': len(got),
                     't_first_ms': (stamps[0] - published) / 1e6,
                     't_total_ms': (stamps[-1] - published) / 1e6,
                     'gaps_ms': [(stamps[i + 1] - stamps[i]) / 1e6 for i in range(len(stamps) - 1)]})
    return blocks, meta


def compare(candidate, oracle):
    sessions = [[]]
    for block in candidate:
        sessions.append([]) if block is None else sessions[-1].append(block)
    worst, violations, shape = 0.0, 0, None
    for session_chunks, reference in zip(sessions, oracle):
        if not session_chunks or reference is None:
            continue
        stacked = np.concatenate(list(session_chunks), axis=1)
        shape = list(stacked.shape)
        if stacked.shape != reference.shape:
            return {'ok': False, 'reason': f'shape {stacked.shape} vs {reference.shape}'}
        delta = np.abs(stacked - reference)
        violations += int((delta > ATOL + RTOL * np.abs(reference)).sum())
        worst = max(worst, float(delta.max()))
    return {'ok': violations == 0, 'max_abs': worst, 'shape': shape, 'violations': violations}


def digest(blocks):
    hasher = hashlib.sha256()
    for block in blocks:
        hasher.update(b'<reset>' if block is None
                      else np.ascontiguousarray(block, dtype=np.float32).tobytes())
    return hasher.hexdigest()


def sweep(adapter, pool, count, period_s):
    latencies, gaps, chunks, previous = [], [], 0, None
    start = time.perf_counter()
    for index in range(count):
        if period_s > 0:
            target = start + index * period_s
            now = time.perf_counter()
            if now < target:
                time.sleep(target - now)
        _request_id, published = adapter.submit(pool[index % len(pool)])
        first = None
        while True:
            _data, observed = adapter.receive(timeout_s=120)
            chunks += 1
            if first is None:
                first = observed
                latencies.append((observed - published) / 1e6)
            if previous is not None:
                gaps.append((observed - previous) / 1e6)
            previous = observed
            if adapter.pending is None:
                break
    elapsed = time.perf_counter() - start
    over = [g for g in gaps if g > GAP_BUDGET_MS]
    return {
        'offered_period_ms': period_s * 1e3,
        'requests': count, 'chunks': chunks, 'elapsed_s': elapsed,
        'achieved_requests_per_s': count / elapsed,
        'achieved_chunks_per_s': chunks / elapsed,
        'fell_behind': bool(period_s > 0 and elapsed > count * period_s * 1.15),
        't_first_ms_median': _pct(latencies, 50),
        't_first_ms_p95': _pct(latencies, 95),
        'gap_ms_median': _pct(gaps, 50),
        'gap_ms_p95': _pct(gaps, 95),
        'gap_max_ms': max(gaps) if gaps else float('nan'),
        'gap_over_budget_fraction': (len(over) / len(gaps)) if gaps else 0.0,
    }


def profile(name, config, mode, plan, oracle, tag):
    proc, log, full, log_path = launch(name, config, mode=mode, tag=tag)
    adapter = None
    record = {'backend': name, 'mode': mode, 'config': dict(config), 'log': str(log_path)}
    try:
        started = time.perf_counter()
        wait_ready(proc, full['prefix'], log_path)
        adapter = FeatureAdapter(full)
        adapter.start()
        record['startup_s'] = time.perf_counter() - started
        # cold request: recorded separately, never mixed into the distributions
        t_submit = time.perf_counter_ns()
        adapter.submit(plan[0][0])
        while True:
            _data, observed = adapter.receive(timeout_s=120)
            if adapter.pending is None:
                break
        record['cold_first_out_ms'] = (observed - t_submit) / 1e6
        adapter.reset()

        blocks, meta = collect(config, plan, adapter)
        record['requests'] = meta
        record['correctness'] = compare(blocks, oracle)
        record['output_digest'] = digest(blocks)
        finite = [m['t_first_ms'] for m in meta if math.isfinite(m['t_first_ms'])]
        record['latency_ms'] = {'median': _pct(finite, 50), 'p95': _pct(finite, 95), 'all': finite}
        record['total_ms'] = [m['t_total_ms'] for m in meta]
        record['reset_reproduces'] = bool(np.allclose(blocks[0], blocks[5], atol=ATOL, rtol=RTOL))
        record['repeat_without_reset_differs'] = bool(
            not np.allclose(blocks[2], blocks[3], atol=ATOL, rtol=RTOL))
        pool = [plan[0][0], plan[1][0], plan[3][0], plan[5][0]]
        record['sweep'] = [sweep(adapter, pool, count, period) for period, count in SWEEP]
        record['status'] = 'ok'
    except Exception as exc:  # noqa: BLE001
        import traceback
        record['status'] = f'error: {type(exc).__name__}: {exc}'
        record['traceback'] = traceback.format_exc()
    finally:
        stop(proc, log, adapter)
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
    return record


def main(argv):
    args = list(argv[1:])
    config_names = list(CONFIGS)
    for arg in list(args):
        if arg.startswith('configs='):
            config_names = [a for a in arg.split('=', 1)[1].split(',') if a]
            args.remove(arg)
    names = args or ['reference', 'whole', 'first_rest', 'chunk', 'whole_eager']
    summary = {}
    for config_name in config_names:
        config = CONFIGS[config_name]
        plan = scenario_inputs(config)
        oracle = oracle_sessions(config, plan)
        for name in names:
            mode = None if name == 'reference' else name
            record = profile('reference' if name == 'reference' else 'worker', config,
                             mode, plan, oracle, f'{config_name}_{name}')
            summary[f'{config_name}/{name}'] = record
            lat = record.get('latency_ms', {})
            sweeps = record.get('sweep') or [{}]
            corr = record.get('correctness') or {}
            sw = sweeps[0]
            line = (f"{config_name}/{name} ok={record['status'] == 'ok'} "
                    f"corr={corr.get('ok')}/{corr.get('violations')} "
                    f"first_out={lat.get('median', float('nan')):.3f}/{lat.get('p95', float('nan')):.3f}ms "
                    f"rps={sw.get('achieved_requests_per_s', float('nan')):.1f} "
                    f"cps={sw.get('achieved_chunks_per_s', float('nan')):.1f} "
                    f"gapp95={[round(s.get('gap_ms_p95', 0), 1) for s in sweeps]} "
                    f"over={[round(s.get('gap_over_budget_fraction', 0), 2) for s in sweeps]} "
                    f"behind={[s.get('fell_behind') for s in sweeps]} "
                    f"reset={record.get('reset_reproduces')} cold={record.get('cold_first_out_ms', 0):.2f}")
            if record['status'] != 'ok':
                line += f" ERR={record['status'][:200]}"
            print(line, flush=True)
    out = RESULTS / f'bench_e2e_{int(time.time())}.json'
    out.write_text(json.dumps(summary, indent=2, default=str), encoding='utf-8')
    print(json.dumps({'written': str(out)}), flush=True)


if __name__ == '__main__':
    main(sys.argv)
