"""Optimized standalone backend for the causal_features task.

Entry point (same two arguments as the reference):

    python worker.py --repository <repo-root> --config <config.json>
                     [--spans K] [--no-graph] [--plan auto|whole|chunk]

Contract (unchanged): `causal_features/adapter.py` + `causal_features/reference.py`.
One float32 (C, T) request frame arrives on the input shared-memory ring; the
backend publishes ceil(T/chunk) output frames of shape (C, chunk) plus
(request, chunk, valid) int64 metadata frames, data before metadata, one
request in flight, session state cleared on opcode 3.

Levers (see notes/experiment_log.md; the IR in ir/ shows the state deps that
make them legal):

1.  Span fusion.  The reference builds `cat(history, chunk)` and runs the causal
    convolution for every (chunk, layer) pair.  A causal convolution's output
    sample t consumes input samples <= t only, and the IR shows a layer's only
    cross-chunk state is its own convolution history, so concatenating the whole
    request behind the history and keeping the T produced samples yields exactly
    the same values.  3 conv + 3 SiLU kernels per request instead of
    3 * n_chunks * 2, independent of the chunk count.
2.  Static state layout.  Histories live in pre-allocated `[history | span]`
    window buffers on the device: no per-chunk `torch.cat`, no per-chunk
    allocation, no per-chunk host sync.  Histories roll by a device-to-device
    copy of at most k-1 samples at span end.
3.  Startup self-tune.  The engine measures its own full-pass time on the device
    it was given, then (a) enables CUDA-graph replay only if the measured replay
    is faster than eager launch, and (b) sizes the span split so the first
    output chunk is published after roughly a millisecond-class amount of work.
    Nothing is predicted from model-size arithmetic; both decisions are
    measurements taken in this process on this GPU.
4.  Busy-wait IPC polling: `time.sleep(0.0002)` really sleeps ~1 ms on Windows,
    which dwarfs the whole computation, so the poll loops spin (and only yield
    after a long idle stretch).
5.  Pinned staging and batched publication: the request frame is copied straight
    out of the input ring into a pinned host buffer, and each finished span is
    published with one ring write for the data plus one for the metadata.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

CTRL_START = 1
CTRL_RESET = 3
CTRL_STOP = 2

TARGET_FIRST_SPAN_MS = 1.5   # desired amount of work before the first publish


def ensure_import_path(repository):
    """Make `causal_features.*` importable given the supplied --repository."""
    for candidate in reversed([repository, repository / 'flashrt' / 'apps']):
        text = str(candidate)
        if text not in sys.path:
            sys.path.insert(0, text)
    import causal_features.adapter  # noqa: F401


class CausalEngine:
    """Span-fused execution of the fixed three-layer causal network."""

    def __init__(self, repository, config, plan_mode='auto', spans=0, graphs=True):
        self.config = config
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        self.length = int(config['length'])
        self.chunk = int(config['chunk'])
        device_arg = config.get('device', 'cuda')
        if isinstance(device_arg, int):
            device_arg = f'cuda:{device_arg}'
        self.device = torch.device(device_arg)
        if self.device.index is not None:
            torch.cuda.set_device(self.device.index)

        from causal_features.model import build_layers

        self.layers = build_layers(repository, config, device_arg)
        # Keep the exact reference parameters; only detach them from the module
        # so the hot loop touches tensors directly.
        self.weights = [layer.conv.weight.detach().contiguous() for layer in self.layers]
        self.biases = [layer.conv.bias.detach().contiguous() for layer in self.layers]
        self.pads = [int(layer._time_causal_padding[0]) for layer in self.layers]
        self.dims = [self.channels, self.hidden, self.hidden]

        T = self.length
        self.win = [torch.zeros(1, dim, T + pad, device=self.device)
                    for dim, pad in zip(self.dims, self.pads)]
        self.n_chunks = math.ceil(T / self.chunk)

        self.pinned_in = torch.empty(1, self.channels, T, dtype=torch.float32, pin_memory=True)
        self.pinned_out = torch.empty(1, self.channels, T, dtype=torch.float32, pin_memory=True)
        self.pinned_in_np = self.pinned_in[0].numpy()
        self.pinned_out_np = self.pinned_out[0].numpy()
        self.scratch = np.zeros((self.channels, self.chunk), dtype=np.float32)
        self.meta = np.zeros(3, dtype=np.int64)
        self.batch = np.zeros((self.n_chunks, self.channels, self.chunk), dtype=np.float32)
        self.batch_meta = np.zeros((self.n_chunks, 3), dtype=np.int64)

        self.pairs = {}
        self.graphs = {}
        self.fresh = True
        self.graphs_ready = False
        self.want_graphs = bool(graphs)
        self.full_ms, self.graph_ms = self._measure()
        self.use_graphs = bool(self.want_graphs and self.graph_ms < self.eager_ms)
        self.plan_mode = plan_mode
        self.span_count = self._choose_spans(plan_mode, spans)
        self.plan = self._build_plan(self.span_count)
        self._capture()
        self.reset()
        self.mode = f'{plan_mode}/spans={self.span_count}/graph={self.use_graphs}'

    # ------------------------------------------------------------------ setup
    def _measure(self):
        """Time the whole-request pass eagerly and from a captured graph."""
        with torch.no_grad():
            pair = self._pair(self.length)
            for _ in range(3):
                self._compute(self.length, True)
            torch.cuda.synchronize()
            start = time.perf_counter()
            for _ in range(6):
                self._compute(self.length, True)
            torch.cuda.synchronize()
            self.eager_ms = (time.perf_counter() - start) / 6 * 1e3
            self._compute(self.length, True)
            torch.cuda.synchronize()
            graph_ms = float('inf')
            try:
                side = torch.cuda.Stream()
                side.wait_stream(torch.cuda.current_stream())
                with torch.cuda.stream(side):
                    for _ in range(2):
                        self._compute(self.length, True)
                torch.cuda.current_stream().wait_stream(side)
                torch.cuda.synchronize()
                graph = torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):
                    self._compute(self.length, True)
                torch.cuda.synchronize()
                start = time.perf_counter()
                for _ in range(6):
                    graph.replay()
                torch.cuda.synchronize()
                graph_ms = (time.perf_counter() - start) / 6 * 1e3
                self.graphs[(self.length, True)] = graph
            except Exception as exc:  # capture is best effort
                print(json.dumps({'graph_capture_failed': f'{type(exc).__name__}: {exc}'}),
                      file=sys.stderr, flush=True)
                self.graphs.clear()
            self.reset()
            del pair
            return self.eager_ms, graph_ms

    def _choose_spans(self, plan_mode, spans):
        if plan_mode == 'whole':
            return 1
        if plan_mode == 'chunk':
            return self.n_chunks
        if spans:
            return max(1, min(int(spans), self.n_chunks))
        best = min(self.eager_ms, self.graph_ms)
        wanted = int(math.ceil(best / TARGET_FIRST_SPAN_MS))
        return max(1, min(wanted, self.n_chunks))

    def _build_plan(self, spans):
        T, chunk, n = self.length, self.chunk, self.n_chunks
        if spans <= 1:
            return [(0, T, 0, n)]
        counts = [1]                      # first span is exactly chunk 0
        remaining, parts = n - 1, spans - 1
        share, extra = divmod(remaining, parts)
        for index in range(parts):
            counts.append(share + (1 if index < extra else 0))
        plan = []
        start = 0
        for count in counts:
            if count <= 0:
                continue
            base = start * chunk
            plan.append((base, min(T - base, count * chunk), start, count))
            start += count
        return plan

    def _pair(self, span):
        if span not in self.pairs:
            self.pairs[span] = (torch.empty(1, self.channels, span, device=self.device),
                                torch.empty(1, self.channels, span, device=self.device))
        return self.pairs[span]

    def _graph_keys(self):
        keys = {(span, False) for _base, span, _f, _c in self.plan}
        keys.add((self.plan[0][1], True))
        return sorted(keys)

    def _capture(self):
        if not self.use_graphs:
            return
        keys = self._graph_keys()
        try:
            with torch.no_grad():
                for span, fresh in keys:
                    self._pair(span)
                    for _ in range(2):
                        self._compute(span, fresh)
                torch.cuda.synchronize()
                for span, fresh in keys:
                    if (span, fresh) in self.graphs:
                        continue
                    graph = torch.cuda.CUDAGraph()
                    with torch.cuda.graph(graph):
                        self._compute(span, fresh)
                    self.graphs[(span, fresh)] = graph
                torch.cuda.synchronize()
            self.graphs_ready = True
        except Exception as exc:  # capture is best effort
            print(json.dumps({'graph_capture_failed': f'{type(exc).__name__}: {exc}'}),
                  file=sys.stderr, flush=True)
            self.graphs.clear()
            self.graphs_ready = False
            self.use_graphs = False

    # --------------------------------------------------------------- compute
    def _compute(self, span, fresh):
        """One span: three (copy, conv, SiLU) pairs plus history rolls.

        Only pre-allocated buffers are touched, so the identical sequence of
        device operations is replayable from a captured CUDA graph.
        """
        src, dst = self._pair(span)
        pad = self.pads[0]
        if fresh:
            # Reference semantics for the first chunk of a session: the pinned
            # `CausalConv1d` pads with mode='replicate', i.e. it repeats the
            # first sample; materialise that repetition as the initial history.
            self.win[0][:, :, :pad].copy_(src[:, :, :1].expand(-1, -1, pad))
        self.win[0][:, :, pad:pad + span].copy_(src)
        value = F.silu(F.conv1d(self.win[0][:, :, :pad + span], self.weights[0], self.biases[0]))
        for index in (1, 2):
            pad = self.pads[index]
            if fresh:
                self.win[index][:, :, :pad].copy_(value[:, :, :1].expand(-1, -1, pad))
            self.win[index][:, :, pad:pad + span].copy_(value)
            value = F.silu(F.conv1d(self.win[index][:, :, :pad + span],
                                    self.weights[index], self.biases[index]))
        dst.copy_(value)
        for index, pad in enumerate(self.pads):
            if span >= pad:
                self.win[index][:, :, :pad].copy_(self.win[index][:, :, span:span + pad])
            else:
                joined = torch.cat([self.win[index][:, :, :pad],
                                    self.win[index][:, :, pad:pad + span]], dim=-1)
                self.win[index][:, :, :pad].copy_(joined[:, :, -pad:])

    def reset(self):
        for index, pad in enumerate(self.pads):
            self.win[index][:, :, :pad].zero_()
        self.fresh = True

    # ------------------------------------------------------------ per request
    def _run_span(self, base, span, fresh):
        src, dst = self.pairs[span]
        if base == 0 and span == self.length:
            src.copy_(self.pinned_in, non_blocking=True)
        else:
            src.copy_(self.pinned_in[:, :, base:base + span], non_blocking=True)
        graph = self.graphs.get((span, fresh)) if self.graphs_ready else None
        if graph is not None:
            graph.replay()
        else:
            self._compute(span, fresh)
        if base == 0 and span == self.length:
            self.pinned_out.copy_(dst, non_blocking=True)
        else:
            self.pinned_out[:, :, base:base + span].copy_(dst, non_blocking=True)
        torch.cuda.synchronize()

    def _publish_chunk(self, buffers, request_id, index):
        base = index * self.chunk
        valid = min(self.chunk, self.length - base)
        if valid == self.chunk:
            buffers['output'].write(self.pinned_out_np[:, base:base + valid])
        else:
            self.scratch[:, :valid] = self.pinned_out_np[:, base:base + valid]
            self.scratch[:, valid:] = 0.0
            buffers['output'].write(self.scratch)
        self.meta[0] = request_id
        self.meta[1] = index
        self.meta[2] = valid
        buffers['metadata'].write(self.meta)

    def _publish_span(self, buffers, request_id, first, count):
        if count == 1:
            self._publish_chunk(buffers, request_id, first)
            return
        out = self.pinned_out_np
        frames, meta = self.batch[:count], self.batch_meta[:count]
        for slot in range(count):
            index = first + slot
            base = index * self.chunk
            valid = min(self.chunk, self.length - base)
            frames[slot, :, :valid] = out[:, base:base + valid]
            if valid != self.chunk:
                frames[slot, :, valid:] = 0.0
            meta[slot, 0] = request_id
            meta[slot, 1] = index
            meta[slot, 2] = valid
        buffers['output'].write(frames)
        buffers['metadata'].write(meta)

    def run_request(self, buffers, request_id):
        fresh = self.fresh
        self.fresh = False
        for index, (base, span, first, count) in enumerate(self.plan):
            self._run_span(base, span, fresh if index == 0 else False)
            self._publish_span(buffers, request_id, first, count)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--plan', type=str, default='auto', choices=('auto', 'whole', 'chunk'))
    parser.add_argument('--spans', type=int, default=0)
    parser.add_argument('--no-graph', action='store_true')
    args = parser.parse_args(argv)

    repository = args.repository.resolve()
    ensure_import_path(repository)
    from causal_features.adapter import open_buffers, close_buffers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    engine = CausalEngine(repository, config, plan_mode=args.plan, spans=args.spans,
                          graphs=not args.no_graph)
    buffers = open_buffers(config, create=True)
    consumed, last_command, active, spin = 0, 0, False, 0
    input_buffer = buffers['input']
    control = buffers['control']
    try:
        print(json.dumps({'ready': True, 'device': str(engine.device), 'mode': engine.mode,
                          'eager_ms': engine.eager_ms, 'graph_ms': engine.graph_ms,
                          'spans': len(engine.plan)}), flush=True)
        while True:
            opcode = control.recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == CTRL_STOP:
                    control.commit()
                    break
                if opcode == CTRL_RESET:
                    engine.reset()
                    active = False
                    control.commit()
                elif opcode == CTRL_START:
                    active = True
                    control.commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                spin += 1
                if spin > 20000:
                    time.sleep(0)
                continue
            count = int(input_buffer.num)
            if count <= consumed:
                spin += 1
                if spin > 20000:
                    time.sleep(0)
                continue
            spin = 0
            if count != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = count
            np.copyto(engine.pinned_in_np, input_buffer.tensor[0])
            engine.run_request(buffers, request_id)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
