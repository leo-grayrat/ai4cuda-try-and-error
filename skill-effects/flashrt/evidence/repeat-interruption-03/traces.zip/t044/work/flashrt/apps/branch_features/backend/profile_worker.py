"""Component-level profiler for the whole-request branch pipeline."""
import argparse
import importlib.util
import statistics
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent


def load_worker():
    spec = importlib.util.spec_from_file_location('bf_worker', HERE / 'worker.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def med(fn, reps=200):
    for _ in range(10):
        fn()
    torch.cuda.synchronize()
    samples = []
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        torch.cuda.synchronize()
        samples.append((time.perf_counter() - t0) * 1e3)
    samples.sort()
    return statistics.median(samples), samples[int(0.95 * (len(samples) - 1))]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=Path('.'))
    args = parser.parse_args()
    repo = str(args.repository.resolve())
    sys.path.insert(0, repo)
    from branch_features.model import build_layers, gate_and_merge

    config = {'device': 'cuda', 'channels': 16, 'hidden': 32, 'length': 1043,
              'chunk': 127, 'weight_seed': 1234, 'prefix': 'profile'}
    device = 'cuda'
    C, H, T = 16, 32, 1043
    layers = build_layers(repo, config, device)
    data = np.random.default_rng(3).standard_normal((C, T), dtype=np.float32)
    x = torch.from_numpy(data).unsqueeze(0).to(device)

    print('H2D copy          : %.3f ms (p95 %.3f)' % med(
        lambda: torch.from_numpy(data).unsqueeze(0).to(device)))
    print('H2D pinned+async  : %.3f ms (p95 %.3f)' % med(
        lambda: torch.from_numpy(data).unsqueeze(0).to(device, non_blocking=True)))
    pin = torch.empty((1, C, T), dtype=torch.float32, pin_memory=True)
    def pinned_h2d():
        pin.copy_(torch.from_numpy(data))
        g = pin.to(device, non_blocking=True)
        return g
    print('H2D pin staging   : %.3f ms (p95 %.3f)' % med(pinned_h2d))

    # separate four convs with whole-sequence histories
    def convs():
        a0 = layers['a0'](x)
        a1 = layers['a1'](F.silu(a0))
        b0 = layers['b0'](x)
        b1 = layers['b1'](F.silu(b0))
        return a1, b1
    print('4 whole-seq convs : %.3f ms (p95 %.3f)' % med(convs))
    a1, b1 = convs()

    def conv_only():
        return layers['a1'](x)
    print('1 conv (H->C k3)  : %.3f ms (p95 %.3f)' % med(conv_only))

    def merge():
        return gate_and_merge(x, a1, b1)
    print('gate+merge        : %.3f ms (p95 %.3f)' % med(merge))
    out = merge()

    def merge_lerp():
        g = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return torch.add(torch.lerp(b1, a1, g), x, alpha=0.1)
    print('gate+merge lerp   : %.3f ms (p95 %.3f)' % med(merge_lerp))

    print('D2H copy          : %.3f ms (p95 %.3f)' % med(
        lambda: out.squeeze(0).cpu().numpy()))
    outcpu = out.squeeze(0).to('cpu', non_blocking=False)
    print('D2H nonblocking   : %.3f ms (p95 %.3f)' % med(
        lambda: out.squeeze(0).to('cpu', non_blocking=True)))

    # full step of each variant
    worker = load_worker()
    for variant in ('separate', 'fused'):
        p = worker.BranchPipeline(repo, config, variant=variant)
        p.warmup(T, repeats=2)
        print(f'{variant:>9s} step     : %.3f ms (p95 %.3f)' % med(
            lambda p=p: p.step(data), reps=100))

    # split: convs vs copies in the separate pipeline
    p = worker.BranchPipeline(repo, config, variant='separate')
    p.warmup(T, repeats=2)

    def body_only():
        xx = x
        with torch.inference_mode():
            aa = p._separate('a1', F.silu(p._separate('a0', xx)))
            bb = p._separate('b1', F.silu(p._separate('b0', xx)))
            return gate_and_merge(xx, aa, bb)
    print('separate body only: %.3f ms (p95 %.3f)' % med(body_only))


if __name__ == '__main__':
    main()
