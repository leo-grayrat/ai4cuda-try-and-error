"""Local correctness + timing harness for the branch_features backend.

Compares the whole-request evaluator in ``worker.py`` against

  * ``branch_features.model.ReferencePipeline`` (the exact sequential
    per-chunk reference, run on the same device), over a ten-step session
    that exercises continuations, repeated input without reset, resets, and
    the short tail chunk (1043 = 8*127 + 27), and
  * ``branch_features.model.full_sequence_oracle`` (CPU full-sequence oracle)
    for requests that start from a reset state.

Run from the repository root:
    python flashrt/apps/branch_features/backend/check_correctness.py --repository .
"""
import argparse
import importlib.util
import statistics
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent


def load_worker():
    spec = importlib.util.spec_from_file_location('bf_worker', HERE / 'worker.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def make_config(seed=1234):
    return {
        'device': 'cuda',
        'channels': 16,
        'hidden': 32,
        'length': 1043,
        'chunk': 127,
        'weight_seed': seed,
        'prefix': f'bf_check_{seed}',
    }


def chunk_starts(length, chunk):
    return list(range(0, length, chunk))


def run_reference(pipeline, features, chunk):
    pieces = [pipeline.step(features[:, start:start + chunk])
              for start in chunk_starts(features.shape[-1], chunk)]
    return np.concatenate(pieces, axis=-1)


def maxdiff(a, b):
    return float(np.max(np.abs(a.astype(np.float64) - b.astype(np.float64))))


def rms(a, b):
    d = a.astype(np.float64) - b.astype(np.float64)
    return float(np.sqrt(np.mean(d * d)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=Path('.'))
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))

    from branch_features.model import (ReferencePipeline, build_layers,
                                       full_sequence_oracle)

    worker = load_worker()
    config = make_config()
    repo = str(args.repository.resolve())
    rng = np.random.default_rng(7)
    C, T, chunk = config['channels'], config['length'], config['chunk']
    A = rng.standard_normal((C, T), dtype=np.float32)
    B = (rng.standard_normal((C, T)) * 3.0).astype(np.float32)
    Cc = np.linspace(-4.0, 4.0, C * T, dtype=np.float32).reshape(C, T)
    D = (rng.standard_normal((C, T)) * 0.1).astype(np.float32)

    ref = ReferencePipeline(repo, config)
    cands = {v: worker.BranchPipeline(repo, config, variant=v)
             for v in ('separate', 'fused')}
    for cand in cands.values():
        cand.warmup(T, repeats=1)

    n_chunks = len(chunk_starts(T, chunk))
    print(f'chunk={chunk} length={T} chunks={n_chunks} '
          f'tail={T - (n_chunks - 1) * chunk}')

    # Fresh -> continuation (repeat) -> continuation (different input) ->
    # reset -> fresh -> reset -> fresh -> continuation -> reset -> fresh.
    script = [('A', A), ('A_again_no_reset', A), ('B_no_reset', B),
              ('RESET', None), ('B_after_reset', B),
              ('RESET', None), ('C', Cc), ('C_again_no_reset', Cc),
              ('RESET', None), ('D', D)]

    worst = {v: 0.0 for v in cands}
    worst_rms = {v: 0.0 for v in cands}
    fresh_vs_oracle = {v: [] for v in cands}
    ref_vs_oracle = []
    fresh_labels = {'A', 'B_after_reset', 'C', 'D'}
    for label, data in script:
        if label == 'RESET':
            ref.reset()
            for cand in cands.values():
                cand.reset()
            print(f'{label:>17s}: all four caches cleared')
            continue
        expected = run_reference(ref, data, chunk)
        cells = []
        for v, cand in cands.items():
            got = cand.step(data)
            assert got.shape == expected.shape, (v, got.shape, expected.shape)
            d, r = maxdiff(got, expected), rms(got, expected)
            worst[v] = max(worst[v], d)
            worst_rms[v] = max(worst_rms[v], r)
            cells.append(f'{v}={d:.3e}')
            if label in fresh_labels:
                oracle = full_sequence_oracle(repo, config, data)
                fresh_vs_oracle[v].append((label, maxdiff(got, oracle)))
        if label in fresh_labels:
            oracle = full_sequence_oracle(repo, config, data)
            ref_vs_oracle.append((label, maxdiff(expected, oracle)))
        print(f'{label:>17s}: max|d| vs sequential reference: ' + '  '.join(cells))

    print('\nworst over session: ' + ', '.join(
        f'{v}: max|d|={worst[v]:.3e} rms={worst_rms[v]:.3e}' for v in worst))
    for v in cands:
        print(f'  {v} vs CPU full-sequence oracle on fresh requests: ' + ', '.join(
            f'{label}={d:.2e}' for label, d in fresh_vs_oracle[v]))
    print('  sequential reference vs CPU oracle on fresh requests: ' + ', '.join(
        f'{label}={d:.2e}' for label, d in ref_vs_oracle))
    print('  (stateful no-reset outputs intentionally differ from the fresh '
          'oracle and are compared against the sequential reference.)')

    # ---------------- timing: complete request, steady state ---------------
    print('\nper-request latency over 40 varied requests (after warmup):')
    timing = {}

    def time_backend(invoke, reset):
        for _ in range(3):
            invoke(A)
        reset()
        samples = []
        for i in range(40):
            data = (rng.standard_normal((C, T)) * (1 + i % 3)).astype(np.float32)
            t0 = time.perf_counter()
            invoke(data)
            samples.append((time.perf_counter() - t0) * 1e3)
        samples.sort()
        return (statistics.median(samples),
                samples[int(0.95 * (len(samples) - 1))],
                samples[0])

    timing['reference'] = time_backend(
        lambda data: run_reference(ref, data, chunk), ref.reset)
    for v, cand in cands.items():
        timing[v] = time_backend(cand.step, cand.reset)
    for name in ('reference', 'separate', 'fused'):
        med, p95, low = timing[name]
        print(f'  {name:>9s}: median={med:.3f} ms  p95={p95:.3f} ms  min={low:.3f} ms')
    for v in ('separate', 'fused'):
        print(f'  speedup {v} vs reference: '
              f'{timing["reference"][0] / timing[v][0]:.2f}x (median)')


if __name__ == '__main__':
    main()
