"""IR model of the branch_features dependency graph, validated against the
sequential reference.  Diagnostic only -- the worker does not import this.

The graph makes the four independent convolution input caches explicit:

    x -> conv_a0 --(cache_a0)--> silu_a -> conv_a1 --(cache_a1)--> \
    x -> conv_b0 --(cache_b0)--> silu_b -> conv_b1 --(cache_b1)-->  merge -> out
    x -> gate(mean+sigmoid) ---------------------------------------/

Every convolution reads *and* writes only its own ``chunk_persistent`` cache,
so the two branches have no shared persistent state and can be reordered /
fused across chunks.  The caches are keyed to different streams (``a1`` sees
``silu(a0)``, ``b1`` sees ``silu(b0)``), which is why they cannot substitute
for one another; the counterfactual graph ``wrong`` demonstrates the extra
cross-chunk dependency and the wrong numbers that substitution introduces.

Run from the repository root:
    python flashrt/apps/branch_features/backend/ir_branch.py --repository .
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from flashrt.ir import (IRGraph, IREdge, IROperator, OpType, StateObject,
                        StreamMode, TensorPort, SequentialExecutor,
                        analyze_cross_chunk_dependencies, find_pipeline_stages,
                        ir_operator, summarize_graph)


class ConvOp(IROperator):
    """One causal convolution with its own input-history cache."""

    def __init__(self, name, layer_key, cache):
        self.layer_key = layer_key
        self.cache = cache
        super().__init__(
            name=name, op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')], outputs=[TensorPort('y')],
            state_reads=[cache], state_writes=[cache],
            stream_mode=StreamMode.STREAMING,
            config={'layer': layer_key, 'cache': cache},
        )

    def execute(self, inputs, context, state):
        layer = context['layers'][self.layer_key]
        hist = state.get(self.cache)
        x = inputs['x']
        joined = x if hist is None else torch.cat([hist, x], dim=-1)
        y = layer(joined)
        if hist is not None:
            y = y[:, :, hist.shape[-1]:]
        state.set(self.cache, joined[:, :, -layer._time_causal_padding[0]:].clone())
        return {'y': y}


@ir_operator(name='silu_a', op_type=OpType.EXPOSED,
             inputs=[TensorPort('x')], outputs=[TensorPort('y')])
def silu_a(inputs, context, state):
    return {'y': F.silu(inputs['x'])}


@ir_operator(name='silu_b', op_type=OpType.EXPOSED,
             inputs=[TensorPort('x')], outputs=[TensorPort('y')])
def silu_b(inputs, context, state):
    return {'y': F.silu(inputs['x'])}


@ir_operator(name='gate', op_type=OpType.EXPOSED,
             inputs=[TensorPort('x')], outputs=[TensorPort('y')])
def gate(inputs, context, state):
    return {'y': torch.sigmoid(inputs['x'].mean(dim=1, keepdim=True))}


@ir_operator(name='merge', op_type=OpType.EXPOSED,
             inputs=[TensorPort('x'), TensorPort('a'), TensorPort('b'),
                     TensorPort('g')],
             outputs=[TensorPort('out')])
def merge(inputs, context, state):
    x, a, b, g = inputs['x'], inputs['a'], inputs['b'], inputs['g']
    return {'out': g * a + (1 - g) * b + 0.1 * x}


def _link(graph, src, src_port, dst, dst_port):
    graph.add_edge(IREdge(src_op=src, src_port=src_port,
                          dst_op=dst, dst_port=dst_port))


def build_graph(name='branch_features', wrong_a1_cache=False):
    graph = IRGraph(name=name)
    for key in ('a0', 'a1', 'b0', 'b1'):
        graph.add_state(StateObject(
            name=f'cache_{key}', scope='chunk_persistent',
            description=(f'trailing kernel_size-1 samples of the input stream '
                         f'of conv_{key}')))
    a1_cache = 'cache_b1' if wrong_a1_cache else 'cache_a1'
    graph.add_operator(ConvOp('conv_a0', 'a0', 'cache_a0'))
    graph.add_operator(silu_a)
    graph.add_operator(ConvOp('conv_a1', 'a1', a1_cache))
    graph.add_operator(ConvOp('conv_b0', 'b0', 'cache_b0'))
    graph.add_operator(silu_b)
    graph.add_operator(ConvOp('conv_b1', 'b1', 'cache_b1'))
    graph.add_operator(gate)
    graph.add_operator(merge)
    _link(graph, 'conv_a0', 'y', 'silu_a', 'x')
    _link(graph, 'silu_a', 'y', 'conv_a1', 'x')
    _link(graph, 'conv_b0', 'y', 'silu_b', 'x')
    _link(graph, 'silu_b', 'y', 'conv_b1', 'x')
    _link(graph, 'conv_a1', 'y', 'merge', 'a')
    _link(graph, 'conv_b1', 'y', 'merge', 'b')
    _link(graph, 'gate', 'y', 'merge', 'g')
    graph.external_inputs = [TensorPort('x')]
    graph.external_outputs = [TensorPort('out')]
    graph.preamble_ops = []
    graph.chunk_ops = ['conv_a0', 'silu_a', 'conv_a1', 'conv_b0', 'silu_b',
                       'conv_b1', 'gate', 'merge']
    return graph


def run_session(repo, config, graph, features_list, reset_each=False):
    """Execute the IR chunk period over complete requests, like the worker."""
    from branch_features.model import build_layers
    C, T, chunk = config['channels'], config['length'], config['chunk']
    layers = build_layers(repo, config, 'cpu')
    context = {'layers': layers}
    executor = SequentialExecutor(graph)
    outputs = []
    for index, features in enumerate(features_list):
        if reset_each or index == 0:
            executor = SequentialExecutor(graph)
            executor.init_state({name: None for name in graph.state_objects})
        pieces = []
        for start in range(0, T, chunk):
            chunk_out = executor.run_chunk(
                {'x': torch.from_numpy(features[:, start:start + chunk])
                 .unsqueeze(0)}, context)['out']
            pieces.append(chunk_out.squeeze(0).numpy())
        outputs.append(np.concatenate(pieces, axis=-1))
    return outputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=Path('.'))
    args = parser.parse_args()
    repo = str(args.repository.resolve())
    sys.path.insert(0, repo)

    from branch_features.model import ReferencePipeline

    config = {'device': 'cpu', 'channels': 16, 'hidden': 32, 'length': 1043,
              'chunk': 127, 'weight_seed': 1234, 'prefix': 'ir_check'}
    rng = np.random.default_rng(11)
    C, T = config['channels'], config['length']
    requests = [rng.standard_normal((C, T), dtype=np.float32)
                for _ in range(3)]

    graph = build_graph()
    print(summarize_graph(graph))

    # ---- state-dependency facts -------------------------------------------
    dep = analyze_cross_chunk_dependencies(graph)
    print('state groups (each cache is touched by exactly one operator):')
    for state, ops in dep.state_groups.items():
        print(f'  {state}: {sorted(ops)}')
    print(f'cross-chunk dependencies between distinct operators: '
          f'{[d for d in dep.dependencies if d.op_a != d.op_b] or "none"}')
    stages = find_pipeline_stages(graph)
    print(f'pipeline stages derived from shared persistent state: '
          f'{len(stages)} (one per operator; nothing must be co-located, '
          f'so one GPU runs the whole graph)')

    # ---- execution validation ---------------------------------------------
    ref = ReferencePipeline(repo, config)
    expected = []
    for features in requests:
        pieces = [ref.step(features[:, s:s + config['chunk']])
                  for s in range(0, T, config['chunk'])]
        expected.append(np.concatenate(pieces, axis=-1))
    got = run_session(repo, config, graph, requests, reset_each=True)
    diffs = [float(np.max(np.abs(a - b))) for a, b in zip(got, expected)]
    print(f'IR executor vs sequential reference (3 fresh requests): '
          f'max|d| = {diffs} -> {"PASS" if max(diffs) < 1e-6 else "FAIL"}')

    # ---- counterfactual: a1 reuses b1's cache -----------------------------
    wrong = build_graph(name='branch_features_wrong_cache', wrong_a1_cache=True)
    wrong_errors = wrong.validate()
    print(f'counterfactual shared-cache graph validation: '
          f'{"PASS (structurally)" if not wrong_errors else wrong_errors}')
    wdep = analyze_cross_chunk_dependencies(wrong)
    shared = [d for d in wdep.dependencies if d.op_a != d.op_b]
    print(f'counterfactual new cross-chunk dependencies: '
          f'{[(d.op_a, d.op_b, d.state_name) for d in shared]}')
    wgot = run_session(repo, config, wrong, requests[:1], reset_each=True)
    wdiff = float(np.max(np.abs(wgot[0] - expected[0])))
    print(f'counterfactual output vs reference: max|d| = {wdiff:.3e} '
          f'-> {"FAIL as expected" if wdiff > 1e-2 else "unexpectedly close"}')


if __name__ == '__main__':
    main()
