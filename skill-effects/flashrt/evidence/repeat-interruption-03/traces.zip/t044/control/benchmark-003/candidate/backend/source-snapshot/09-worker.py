"""Optimized streaming backend for the two-branch causal feature task.

The reference pipeline processes one 127-sample chunk at a time through four
causal convolutions, keeping one input-history cache per convolution and
moving every chunk to / from the GPU separately.  The dependency analysis in
``ir_branch.py`` shows that the four caches are independent, and that each
cache only ever stores the trailing ``kernel_size - 1`` samples of that
convolution's own input stream.  Therefore an entire request (the adapter
publishes a complete ``(C, T)`` feature sequence per request) can be evaluated
at once: the same causal histories are prepended, the same four convolutions
run over the whole sequence, and the per-chunk outputs are slices of the
result.  This is exactly what ``ReferencePipeline.step`` computes chunk by
chunk, but with one H2D copy, one D2H copy and a handful of kernel launches
per request instead of nine.

Two kernels are used in the ``fused`` variant (the default).  Both pairs of
convolutions are executed as single ``conv1d`` calls with block-structured,
zero-padded weights:

  * stage 1: ``a0`` (kernel 5) and ``b0`` (kernel 3).  A kernel-3 causal
    convolution is a kernel-5 causal convolution whose first two taps are
    zero (replicate padding makes the boundary samples identical).
  * stage 2: ``a1`` (kernel 3 on a0 activations) and ``b1`` (kernel 5 on b0
    activations).  These have different inputs, so the two activation blocks
    are stacked along the channel axis and a block-diagonal kernel-5 weight is
    used, with the kernel-3 block shifted by two taps.

The four logical history caches are still kept separately, with exactly the
same sizes and update rule as the reference (``a1``'s cache is *not* derived
from ``a0``'s; the two branches cannot substitute for one another).

The worker honours the unchanged adapter protocol: level-valued control
opcodes, whole-sequence input frames, and ordered output/metadata ring writes.
Output chunks are all written to the ring before their metadata frames, which
keeps the adapter's "payload before metadata" ordering intact.

Usage:
    python backend/worker.py --repository <repo> --config <config.json>
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path


class BranchPipeline:
    """Whole-request evaluator equivalent to the sequential reference.

    ``variant``:
        ``fused``    -- two fused conv1d launches (default, fastest)
        ``separate`` -- four conv1d launches, reference topology
    """

    def __init__(self, repository, config, variant='fused', device=None):
        import torch
        import torch.nn.functional as F
        from branch_features.model import build_layers, gate_and_merge

        self.torch = torch
        self.F = F
        self.gate_and_merge = gate_and_merge
        self.config = config
        self.device = device or config['device']
        self.channels = config['channels']
        self.hidden = config['hidden']
        self.variant = variant
        # Same fixed-seed weights as the reference (build_layers reseeds).
        self.layers = build_layers(repository, config, self.device)
        if variant == 'fused':
            self._build_fused_weights()
        elif variant != 'separate':
            raise ValueError(f'unknown variant: {variant}')
        self.reset()

    # ------------------------------------------------------------------ setup
    def _build_fused_weights(self):
        torch = self.torch
        C, H = self.channels, self.hidden
        a0, a1 = self.layers['a0'], self.layers['a1']
        b0, b1 = self.layers['b0'], self.layers['b1']
        device, dtype = self.device, torch.float32

        # Stage 1: x (C) -> [a0(x) (H), b0(x) (H)] with kernel 5.
        w1 = torch.zeros(2 * H, C, 5, device=device, dtype=dtype)
        w1[:H] = a0.conv.weight
        w1[H:, :, 2:] = b0.conv.weight  # left-pad b0's kernel-3 taps by two
        self.w1 = w1
        self.b1 = torch.cat([a0.conv.bias, b0.conv.bias]).contiguous()

        # Stage 2: [a_act (H), b_act (H)] -> [a1(a_act) (C), b1(b_act) (C)]
        #           with a block-diagonal kernel 5.
        w2 = torch.zeros(2 * C, 2 * H, 5, device=device, dtype=dtype)
        w2[:C, :H, 2:] = a1.conv.weight  # kernel-3 taps sit at offsets 2..4
        w2[C:, H:, :] = b1.conv.weight
        self.w2 = w2
        self.b2 = torch.cat([a1.conv.bias, b1.conv.bias]).contiguous()

    def reset(self):
        # One cache per convolution, exactly like the reference: each stores
        # the trailing kernel_size - 1 samples of *that convolution's input*.
        self.h_a0 = None
        self.h_a1 = None
        self.h_b0 = None
        self.h_b1 = None

    # -------------------------------------------------------------- helpers
    @staticmethod
    def _prepad(prev, x, n, torch):
        """History of length n, replicate-padded at the left if too short.

        Replicate filling matches ``CausalConv1d``'s left padding for the
        first chunk of a session or any cache shorter than n.
        """
        if prev is None:
            return x[..., :1].expand(-1, -1, n)
        if prev.shape[-1] >= n:
            return prev[..., -n:]
        fill = prev[..., :1].expand(-1, -1, n - prev.shape[-1])
        return torch.cat([fill, prev], dim=-1)

    @staticmethod
    def _newtail(prev, x, n, torch):
        joined = x if prev is None else torch.cat([prev, x], dim=-1)
        return joined[..., -n:].clone()

    # --------------------------------------------------------------- compute
    def _separate(self, name, x):
        layer = self.layers[name]
        hist = getattr(self, 'h_' + name)
        joined = x if hist is None else self.torch.cat([hist, x], dim=-1)
        out = layer(joined)
        if hist is not None:
            out = out[:, :, hist.shape[-1]:]
        setattr(self, 'h_' + name,
                joined[:, :, -layer._time_causal_padding[0]:].clone())
        return out

    def step(self, features):
        """Process one complete request; returns ``(C, T)`` float32 numpy."""
        torch, F = self.torch, self.F
        with torch.inference_mode():
            x = torch.from_numpy(features).unsqueeze(0).to(self.device)
            if self.variant == 'separate':
                a1 = self._separate('a1', F.silu(self._separate('a0', x)))
                b1 = self._separate('b1', F.silu(self._separate('b0', x)))
            else:
                C, H = self.channels, self.hidden
                # ---- stage 1: a0 and b0 in one kernel-5 convolution ----
                z1 = torch.cat(
                    [self._prepad(self.h_a0, x, 4, torch), x], dim=-1)
                y1 = F.conv1d(z1, self.w1, self.b1)
                # keep both logical caches of the shared input stream
                self.h_a0 = z1[..., -4:].clone()
                self.h_b0 = self.h_a0[..., -2:].clone()
                a_act = F.silu(y1[:, :H])
                b_act = F.silu(y1[:, H:])
                # ---- stage 2: a1 and b1 in one block-diagonal conv ----
                za = torch.cat(
                    [self._prepad(self.h_a1, a_act, 4, torch), a_act], dim=-1)
                zb = torch.cat(
                    [self._prepad(self.h_b1, b_act, 4, torch), b_act], dim=-1)
                y2 = F.conv1d(torch.cat([za, zb], dim=1), self.w2, self.b2)
                self.h_a1 = a_act[..., -2:].clone()
                self.h_b1 = b_act[..., -4:].clone()
                a1 = y2[:, :C]
                b1 = y2[:, C:]
            out = self.gate_and_merge(x, a1, b1)
            return out.squeeze(0).cpu().numpy()

    def warmup(self, length, repeats=2):
        """Run the exact steady-state code path before the worker announces
        readiness, so CUDA/cuDNN lazy initialisation is not charged to the
        first offered request."""
        import numpy as np
        dummy = np.zeros((self.channels, length), dtype=np.float32)
        for _ in range(repeats):
            self.step(dummy)
        self.reset()


def _chunk_plan(length, chunk):
    plan = []
    for index, start in enumerate(range(0, length, chunk)):
        plan.append((index, start, min(chunk, length - start)))
    return plan


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--variant', default=os.environ.get('BRANCH_VARIANT', 'fused'),
                        choices=['fused', 'separate'])
    args = parser.parse_args()

    sys.path.insert(0, str(args.repository.resolve()))
    import numpy as np
    import torch
    from branch_features.adapter import close_buffers, open_buffers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    # Match the reference numerics: no TF32, deterministic cudnn choice.
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    pipeline = BranchPipeline(args.repository, config, variant=args.variant)
    pipeline.warmup(config['length'])
    buffers = open_buffers(config, create=True)

    length, chunk = config['length'], config['chunk']
    channels = config['channels']
    plan = _chunk_plan(length, chunk)
    n_chunks = len(plan)
    # One bulk output payload and one bulk metadata frame set per request;
    # every payload frame is published before any metadata frame.
    payload = np.zeros((n_chunks, channels, chunk), dtype=np.float32)
    metadata = np.zeros((n_chunks, 3), dtype=np.int64)

    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({'ready': True, 'device': config['device'],
                          'task': 'branch_features'}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    pipeline.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id, consumed = consumed, next_cursor
            output = pipeline.step(features[0])
            for index, start, valid in plan:
                if valid == chunk:
                    payload[index] = output[:, start:start + valid]
                else:
                    payload[index].fill(0.0)
                    payload[index, :, :valid] = output[:, start:start + valid]
                metadata[index] = (request_id, index, valid)
            del output
            buffers['output'].write(payload)
            buffers['metadata'].write(metadata)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
