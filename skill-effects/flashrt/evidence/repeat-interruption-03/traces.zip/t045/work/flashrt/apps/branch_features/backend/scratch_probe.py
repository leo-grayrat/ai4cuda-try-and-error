import json, sys, time
from pathlib import Path
import numpy as np
import torch

repo = str(Path('.').resolve())
sys.path.insert(0, repo)
print('torch', torch.__version__, 'cuda avail', torch.cuda.is_available())
if torch.cuda.is_available():
    print('device', torch.cuda.get_device_name(0), 'cc', torch.cuda.get_device_capability(0))
    print('mem GB', round(torch.cuda.get_device_properties(0).total_memory / 1e9, 2))

from branch_features.model import ReferencePipeline, build_layers, gate_and_merge, full_sequence_oracle
import torch.nn.functional as F

config = dict(device='cuda', weight_seed=1234, channels=16, hidden=32, length=1043, chunk=127)
rng = np.random.default_rng(0)
feat = rng.standard_normal((config['channels'], config['length'])).astype(np.float32)

pipe = ReferencePipeline(repo, config)
# warmup
for _ in range(3):
    for pos in range(0, config['length'], config['chunk']):
        pipe.step(feat[:, pos:pos+config['chunk']])
torch.cuda.synchronize()
t0 = time.perf_counter()
for _ in range(20):
    for pos in range(0, config['length'], config['chunk']):
        pipe.step(feat[:, pos:pos+config['chunk']])
torch.cuda.synchronize()
t1 = time.perf_counter()
print('reference full request (9 chunks) ms', (t1-t0)/20*1e3)
pipe.reset()

# time just one chunk step
torch.cuda.synchronize(); t0=time.perf_counter()
for _ in range(200):
    pipe.step(feat[:, :127])
torch.cuda.synchronize(); t1=time.perf_counter()
print('reference single chunk ms', (t1-t0)/200*1e3)
pipe.reset()

# full sequence GPU
layers = build_layers(repo, config, 'cuda')
vals = torch.from_numpy(feat).unsqueeze(0).cuda()
with torch.inference_mode():
    for _ in range(5):
        a = layers['a1'](F.silu(layers['a0'](vals)))
        b = layers['b1'](F.silu(layers['b0'](vals)))
        o = gate_and_merge(vals, a, b)
    torch.cuda.synchronize(); t0=time.perf_counter()
    for _ in range(50):
        a = layers['a1'](F.silu(layers['a0'](vals)))
        b = layers['b1'](F.silu(layers['b0'](vals)))
        o = gate_and_merge(vals, a, b)
    torch.cuda.synchronize(); t1=time.perf_counter()
print('full-seq gpu ms', (t1-t0)/50*1e3)

# compare full-seq GPU vs oracle
ref = full_sequence_oracle(repo, config, feat)
print('fullseq max abs diff vs oracle', float(np.abs(ref - o.squeeze(0).cpu().numpy()).max()))

# chunked reference vs oracle
outs = []
pipe.reset()
for pos in range(0, config['length'], config['chunk']):
    outs.append(pipe.step(feat[:, pos:pos+config['chunk']]))
chunked = np.concatenate(outs, axis=-1)
print('chunked max abs diff vs oracle', float(np.abs(ref - chunked).max()))

# continuation check: second request continues history
feat2 = rng.standard_normal((config['channels'], config['length'])).astype(np.float32)
outs2 = []
for pos in range(0, config['length'], config['chunk']):
    outs2.append(pipe.step(feat2[:, pos:pos+config['chunk']]))
cont = np.concatenate(outs2, axis=-1)
whole = np.concatenate([feat, feat2], axis=-1)
ref2 = full_sequence_oracle(repo, config, whole)[:, config['length']:]
print('continuation chunked max abs diff vs oracle-on-concat', float(np.abs(ref2 - cont).max()))
