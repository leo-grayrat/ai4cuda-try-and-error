"""Express the two-branch task as an explicit IR and validate it.

Builds a chunk-periodic IRGraph with four exposed causal-convolution
operators, each owning its own chunk-persistent input history, plus the
SiLU and gate/merge operators.  Runs the original SequentialExecutor and
compares against the CPU full-sequence oracle from the research reference,
including a continuation session and a reset-replay session.
"""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from flashrt.ir import (
    IRGraph, IROperator, OpType, TensorPort, StateObject, IREdge,
    SequentialExecutor, analyze_cross_chunk_dependencies, find_pipeline_stages,
    summarize_graph, ir_operator,
)
from branch_features.model import build_layers, full_sequence_oracle

REPO = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
CONFIG = {'channels': 16, 'hidden': 32, 'length': 37, 'chunk': 9,
          'weight_seed': 703, 'device': 'cpu'}
HIST_NAMES = ('hist_a0', 'hist_a1', 'hist_b0', 'hist_b1')


class ConvOp(IROperator):
    def __init__(self, name, layer, in_port='x'):
        super().__init__(name=name, op_type=OpType.EXPOSED,
                         inputs=[TensorPort(in_port)], outputs=[TensorPort('y')],
                         state_reads=[f'hist_{name}'], state_writes=[f'hist_{name}'])
        self.layer = layer

    def execute(self, inputs, context, state):
        key = self.state_reads[0]
        history = state.get(key)
        x = inputs[self.inputs[0].name]
        pad = self.layer._time_causal_padding[0]
        if history is None:
            out = self.layer(x)
            new_history = x[:, :, -pad:].clone()
        else:
            joined = torch.cat([history, x], dim=-1)
            out = self.layer(joined)[:, :, history.shape[-1]:]
            new_history = joined[:, :, -pad:].clone()
        state.set(key, new_history)
        return {'y': out}


def silu_op(name):
    def fn(inputs, context, state):
        return {'y': F.silu(inputs['x'])}
    return ir_operator(name=name, op_type=OpType.EXPOSED,
                       inputs=[TensorPort('x')], outputs=[TensorPort('y')])(fn)


def merge_fn(inputs, context, state):
    features = inputs['features']
    gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
    return {'out': gate * inputs['a'] + (1 - gate) * inputs['b'] + 0.1 * features}


def build_graph(layers):
    g = IRGraph(name='branch_features')
    g.add_operator(ConvOp('a0', layers['a0'], 'features'))
    g.add_operator(silu_op('silu_a0'))
    g.add_operator(ConvOp('a1', layers['a1']))
    g.add_operator(ConvOp('b0', layers['b0'], 'features'))
    g.add_operator(silu_op('silu_b0'))
    g.add_operator(ConvOp('b1', layers['b1']))
    g.add_operator(ir_operator(name='gate_merge', op_type=OpType.EXPOSED,
                               inputs=[TensorPort('features'), TensorPort('a'), TensorPort('b')],
                               outputs=[TensorPort('out')])(merge_fn))
    for h in HIST_NAMES:
        g.add_state(StateObject(h, 'per-layer causal input history', 'chunk_persistent'))
    g.add_edge(IREdge('a0', 'y', 'silu_a0', 'x'))
    g.add_edge(IREdge('silu_a0', 'y', 'a1', 'x'))
    g.add_edge(IREdge('b0', 'y', 'silu_b0', 'x'))
    g.add_edge(IREdge('silu_b0', 'y', 'b1', 'x'))
    g.add_edge(IREdge('a1', 'y', 'gate_merge', 'a'))
    g.add_edge(IREdge('b1', 'y', 'gate_merge', 'b'))
    g.chunk_ops = [op.name for op in g.operators.values()]
    g.external_inputs = [TensorPort('features')]
    g.external_outputs = [TensorPort('out')]
    return g


def run_session(graph, chunks):
    ex = SequentialExecutor(graph)
    ex.init_state({h: None for h in HIST_NAMES})
    outs = []
    with torch.inference_mode():
        for chunk in chunks:
            outs.append(ex.run_chunk({'features': chunk})['out'])
    return torch.cat(outs, dim=-1)


def main():
    torch.manual_seed(0)
    total = CONFIG['length']
    sequence = torch.randn(1, CONFIG['channels'], total)
    chunks = [sequence[:, :, i:i + CONFIG['chunk']] for i in range(0, total, CONFIG['chunk'])]

    layers = build_layers(REPO, CONFIG, 'cpu')
    graph = build_graph(layers)
    errors = graph.validate()
    print('validate_errors:', errors)
    dep = analyze_cross_chunk_dependencies(graph)
    stages = find_pipeline_stages(graph)
    print('cross_chunk_deps:', [(d.op_a, d.op_b, d.state_name) for d in dep.dependencies])
    print('independent_pairs:', len(dep.independent_pairs))
    print('pipeline_stages:', [[s.operators, sorted(s.state_objects)] for s in stages])

    expected = full_sequence_oracle(REPO, CONFIG, sequence[0].numpy())
    got = run_session(graph, chunks).squeeze(0).numpy()
    diff1 = float(np.max(np.abs(got - expected)))
    print('session_replay_max_abs_diff:', diff1)

    # Continuation: second request must extend the same causal network.
    seq2 = torch.randn(1, CONFIG['channels'], 23)
    joint = torch.cat([sequence, seq2], dim=-1)
    chunks2 = [joint[:, :, i:i + CONFIG['chunk']] for i in range(0, joint.shape[-1], CONFIG['chunk'])]
    expected2 = full_sequence_oracle(REPO, CONFIG, joint[0].numpy())
    got2 = run_session(graph, chunks2).squeeze(0).numpy()
    diff2 = float(np.max(np.abs(got2 - expected2)))
    print('continuation_max_abs_diff:', diff2)

    # Reset replay: a fresh executor must reproduce the first session exactly.
    got3 = run_session(graph, chunks).squeeze(0).numpy()
    diff3 = float(np.max(np.abs(got3 - got)))
    print('reset_replay_max_abs_diff:', diff3)

    ok = not errors and diff1 < 3e-5 and diff2 < 3e-5 and diff3 == 0.0
    print('IR_VALIDATION', 'PASS' if ok else 'FAIL')
    print('--- summary excerpt ---')
    summary = summarize_graph(graph)
    for line in summary.splitlines():
        if line.startswith(('## State', '## Cross', '## Pipeline', '## Validation')) or 'Stage ' in line:
            print(line)


if __name__ == '__main__':
    main()
