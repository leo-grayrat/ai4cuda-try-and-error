# branch_features backend — experiment record

Task: two-branch causal feature processing (C=16, H=32, T=1043, chunk=127,
weight_seed=703).  Fixed adapter: `branch_features.adapter` (re-export of
`causal_features.adapter`).  Research reference: `branch_features.reference`,
CPU full-sequence oracle: `branch_features.model.full_sequence_oracle`.
Correctness tolerance: atol 3e-5, rtol 3e-4, verified by the independent
controller.

## IR conversion (execute-002)

- Worker graph: 7 chunk operators, 4 chunk-persistent state objects.
  - Exposed ops: `a0` (C->H k5), `a1` (H->C k3), `b0` (C->H k3),
    `b1` (H->C k5), `silu_a0`, `silu_b0`, `gate_merge`.
  - State: `hist_a0`, `hist_a1`, `hist_b0`, `hist_b1` (one private input
    history per convolution, chunk_persistent).
- IR validation: PASS (`backend/ir/validate_ir.py`, `flashrt.ir.SequentialExecutor`)
  - single-session replay vs CPU full-sequence oracle: max abs diff 1.34e-7
  - two-request continuation (concatenated session) vs oracle: 1.34e-7
  - reset replay (fresh executor, same input): 0.0
  - residual validation errors: none
- Analysis:
  - Cross-chunk dependencies are self-only: each conv reads/writes its own
    history, so 21 operator pairs are cross-chunk independent.
  - Naive stage partitioning reports 7 stages (4 histories are disjoint);
    on the assigned single GPU everything is co-located, so this means the
    two branches can be scheduled/merged freely within a chunk while the
    four caches may not alias each other.  We still keep four distinct
    histories (path-B states were never reused as path-A states).

## Iteration 1 — whole-request GPU pass (verify-003, benchmark-004)

- Hypothesis: the reference relaunches four tiny convolutions per configured
  chunk (36 conv launches + 9 H2D/D2H round trips for T=1043); launch and
  transfer overhead, not FLOPs, dominates.  One causal pass over each
  request's full sequence, with four persistent histories, is numerically
  the oracle and removes most launches.
- Correctness: PASS, 6/6 requests, max abs diff 2.1e-7, cleanup verified.
- Benchmark (paired finite sweep, 20 ms gap budget):
  - reference highest passing rate 50/s (rate gate failed at 100 and 200)
  - candidate highest passing rate 200/s
  - candidate 50/s: first output 2.114 ms median, gap p95 19.93 ms,
    over-budget fraction 4.68% -> smoothness gate FAILED
  - candidate 100/s: pass; 200/s: pass
- Failure diagnosis: the controller is closed-loop with scheduled arrivals.
  Bursting all chunks then idling makes the single inter-request gap equal
  to the offered period (~20 ms at 50/s); scheduling jitter pushes ~5% of
  gaps over 20 ms (gate: <=1%).

## Iteration 2 — combined first stage, fused epilogue, adaptive pacing (verify-008, benchmark-009)

- Changes:
  - a0 (C->H k5) and b0 (C->H k3) both consume the raw request.  Path B's
    kernel is zero-prepended to length 5, so one (2H,C,5) convolution on a
    single 4-frame raw-input history produces both branches exactly
    (replicate boundaries included).  Removes one pad+conv+history-cat.
  - Epilogue `gate*A+(1-gate)*B+0.1*x` as `add(lerp(B,A,gate), x, alpha=0.1)`.
  - Output pacing: estimate the offered arrival period from successive
    request start times and spread chunks over `period - 10 ms` (never
    delay chunk 0), so the idle window before the next request is
    ~10-12 ms instead of ~period, and first-chunk latency is unchanged.
  - Idle poll interval 0.2 ms -> 0.1 ms.
- Correctness: PASS, 6/6 requests, max abs diff 2.4e-7, cleanup verified.
- Benchmark:
  - reference highest passing rate 100/s (rate gate failed at 200)
  - candidate highest passing rate 200/s (all gates passed at 50/100/200)
  - candidate 50/s: first output 2.014 ms, gap p95 10.51 ms,
    over-budget 0.22% (PASS)
  - candidate 100/s: first output 1.591 ms, gap p95 9.97 ms, over-budget 0
  - candidate 200/s: first output 1.589 ms, gap p95 4.93 ms, over-budget 0,
    peak external queue 0
- Comparison vs iteration 1: first-output median improved 2.114->2.014 ms
  at 50/s and 1.634->1.591 ms at 100/s; smoothness fixed at the low rate.

## Trade-offs and remaining risks

- Whole-request evaluation minimizes launches and maximizes throughput but
  makes first output wait for the whole request's causal pass.  At the dev
  size this is ~1.6-2.0 ms; for a much larger T or a stricter per-chunk
  first-output deadline, a hybrid super-chunk scheme would be needed.
  The large case (C=128,H=256,T=16384,chunk512) was NOT verified or
  benchmarked in this session.
- Pacing assumes the closure/scheduled-arrival controller used here; the
  first request after each reset is unpaced (one inter-request gap may be
  near the budget), and at offered periods near/above ~170 ms the internal
  paced gaps themselves would approach 20 ms.  Sweep rates exercised were
  50/100/200 per second.
- Candidate saturates the controller's highest tested rate (200/s) with an
  empty external queue, so true headroom above 200/s is unmeasured.
- Paired runs share a GPU lock and show reference variance (highest passing
  50/s in one run, 100/s in another); finite windows are not an aggregate
  effect claim.
