# branch_features optimized backend

`worker.py` is the standalone entry point:

```
python worker.py --repository <fixed-source-root> --config <task-config.json>
```

It honors the fixed `branch_features.adapter` shared-memory protocol
(control opcodes 1/3/2, one in-flight request, chunk-ordered output,
data-before-metadata publication, unlink on exit).

Implementation summary:

- each request's full causal sequence is evaluated in one GPU pass with four
  persistent per-layer histories (a0, a1, b0, b1);
- the two first-stage convolutions are combined into one (2H,C,5) conv by
  zero-prepending path B's kernel-3 weights (exact including replicate
  boundaries); path A/B second-stage histories stay separate;
- the gate/merge epilogue is evaluated as `add(lerp(B,A,gate), x, alpha=0.1)`;
- output chunks are adaptively paced from the measured arrival period to keep
  inter-chunk gaps under the 20 ms budget without delaying the first chunk.

`ir/validate_ir.py` builds the explicit chunk-periodic IR with the four
chunk-persistent histories and validates `SequentialExecutor` output against
the CPU full-sequence oracle (session, continuation and reset replay).

See `notes/experiment_log.md` for hypotheses, measurements and failures.
