"""Optimized streaming backend for the two-branch causal feature task.

Faithful to ``branch_features.reference`` numerically, but instead of
re-launching four tiny convolutions for every configured chunk, each
incoming request's complete causal sequence is evaluated in one GPU pass
using four persistent per-layer input-history caches.  The resulting
(C, T) array is then published through the unchanged shared-memory
contract in configured chunks (including the zero-padded tail chunk).

CLI: --repository <fixed source root> --config <task JSON>
"""
import argparse
import json
import sys
import time
from pathlib import Path

POLL_SLEEP = 0.0002


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))

    import numpy as np
    import torch
    import torch.nn.functional as F
    from branch_features.adapter import open_buffers, close_buffers
    from branch_features.model import build_layers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = torch.device(config['device'])
    channels, hidden = config['channels'], config['hidden']
    length, chunk = config['length'], config['chunk']
    layers = build_layers(args.repository, config, device)
    names = ('a0', 'a1', 'b0', 'b1')
    hists = {name: None for name in names}

    def reset():
        for name in names:
            hists[name] = None

    def run_layer(name, x):
        layer = layers[name]
        pad = layer._time_causal_padding[0]
        history = hists[name]
        if history is None:
            out = layer(x)
            new_history = x[:, :, -pad:].clone() if pad else x
        else:
            joined = torch.cat([history, x], dim=-1)
            out = layer(joined)[:, :, history.shape[-1]:]
            new_history = joined[:, :, -pad:].clone() if pad else joined
        hists[name] = new_history
        return out

    @torch.inference_mode()
    def process(features):
        values = torch.from_numpy(features).unsqueeze(0).to(device)
        branch_a = F.silu(run_layer('a0', values))
        branch_b = F.silu(run_layer('b0', values))
        branch_a = run_layer('a1', branch_a)
        branch_b = run_layer('b1', branch_b)
        gate = torch.sigmoid(values.mean(dim=1, keepdim=True))
        merged = gate * branch_a + (1 - gate) * branch_b + 0.1 * values
        return merged.squeeze(0).cpu().numpy()

    buffers = open_buffers(config, create=True)
    frame = np.zeros((channels, chunk), dtype=np.float32)
    consumed, last_command, active = 0, 0, False
    num_chunks = (length + chunk - 1) // chunk
    try:
        print(json.dumps({'ready': True, 'device': config['device'], 'task': 'branch_features'}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(POLL_SLEEP)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(POLL_SLEEP)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id, consumed = consumed, next_cursor
            output = process(features[0])
            for index in range(num_chunks):
                position = index * chunk
                valid = min(chunk, length - position)
                if valid == chunk:
                    payload = output[:, position:position + valid]
                else:
                    frame.fill(0.0)
                    frame[:, :valid] = output[:, position:position + valid]
                    payload = frame
                buffers['output'].write(payload)
                buffers['metadata'].write(np.array([request_id, index, valid], dtype=np.int64))
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
