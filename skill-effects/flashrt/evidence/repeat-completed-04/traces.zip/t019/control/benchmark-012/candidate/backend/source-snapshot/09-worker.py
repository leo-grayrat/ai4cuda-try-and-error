"""Standalone optimized worker for the branch_features two-branch causal task.

Protocol (identical to branch_features.reference): one complete (C, length)
feature matrix per request, ``length / chunk`` ordered output chunks, session
state (four convolution histories in the reference) kept across requests and
cleared by reset.  Nothing but the fixed adapter is used.

Per time position t (C=16, H=32, all causal):

    A = a1(silu(a0(x))),  B = b1(silu(b0(x)))        # kernels 5/3 and 3/5
    y[t] = g[t]*A[t] + (1-g[t])*B[t] + 0.1*x[t],  g = sigmoid(mean_c x)

Optimizations (each exact: it reproduces the reference arithmetic up to float
rounding, verified against the CPU full-sequence oracle):

1. Branch fusion.  A branch-0 conv with kernel 3 and replicate left pad 2 is
   algebraically the same as a kernel-5 conv whose first two taps are zero,
   because replicate padding repeats x[:, 0] and those taps are multiplied by
   zero.  Both branch-0 convolutions therefore read the same raw input and are
   evaluated by one 16->64 kernel-5 convolution (weight rows concatenated, the
   k=3 rows zero padded on the left).  Both branch-1 convolutions are evaluated
   by one 64->32 kernel-5 convolution whose weight is block-diagonal over the
   concatenated [silu(A0), silu(B0)] activation.  Two kernels instead of four.
2. State.  Two 4-column histories (last 4 raw inputs, last 4 layer-1 inputs)
   replace the reference's four 2/4/2/4-column caches.  A k=3 window is a
   sub-window of the k=5 window of the same tensor, so no information is lost;
   the branches still have distinct history tensors (the k=3 branch reads the
   last two columns of the same layer-1 buffer, never the other branch's cache).
3. Chunking is a transport convention.  A request is evaluated in two
   position windows (first chunk, then the rest), which is exactly the state
   progression of the chunked reference but with only two device passes.
4. Each window is replayed as two CUDA graphs (layer 0, layer 1), so launches
   collapse to four per request and synchronization drops from one per chunk to
   two per request.  Splitting by layer also lets a fresh session prime the
   layer-1 replicate boundary of position 0 with a 4-column copy.
5. Staged draining.  Chunk 0 is published as soon as its own window finishes,
   well before the remaining chunks, so time-to-first-chunk is ~0.25 ms and the
   last-chunk-to-next-first-chunk gap stays below the 20 ms budget even when the
   offered interval is exactly 20 ms.  Each stage publishes its payload rows
   before the metadata rows that reference them.
6. The receive loop polls with a short bounded spin instead of a 0.2 ms sleep,
   so request pickup latency is microseconds while idle CPU use stays bounded.
"""
import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HIST = 4  # k - 1 of the widest kernel (5)
K = 5


def build_fused_weights(repository, config):
    """Rebuild the four reference convs with the reference seed, then fuse."""
    from branch_features.model import build_layers

    layers = build_layers(repository, config, 'cpu')
    a0, a1 = layers['a0'].conv, layers['a1'].conv
    b0, b1 = layers['b0'].conv, layers['b1'].conv
    channels, hidden = config['channels'], config['hidden']
    with torch.no_grad():
        # (2H, C, 5): rows [0:H] = a0 (k=5), rows [H:2H] = b0 (k=3 -> taps 2..4)
        w0 = torch.cat([a0.weight, F.pad(b0.weight, (2, 0))], dim=0).contiguous()
        beta0 = torch.cat([a0.bias, b0.bias], dim=0).contiguous()
        # (2C, 2H, 5): rows [0:C] = a1 over silu(A0) (taps 2..4),
        #              rows [C:2C] = b1 over silu(B0) (taps 0..4)
        w1 = torch.zeros(2 * channels, 2 * hidden, K,
                         dtype=a0.weight.dtype, device=a0.weight.device)
        w1[:channels, :hidden, 2:] = a1.weight
        w1[channels:, hidden:, :] = b1.weight
        beta1 = torch.cat([a1.bias, b1.bias], dim=0).contiguous()
    return w0, beta0, w1.contiguous(), beta1


class Window:
    """One position window of the fused graph plus its captured CUDA graphs."""

    def __init__(self, owner, width):
        self.owner = owner
        c, h = owner.channels, owner.hidden
        dev = owner.device
        self.width = width
        self.x_buf = torch.zeros(1, c, width, device=dev)
        self.y_buf = torch.zeros(1, 2 * h, width, device=dev)
        self.out_buf = torch.zeros(1, c, width, device=dev)
        self.pin = torch.empty(1, c, width, dtype=torch.float32, pin_memory=True)
        self.graphs = None

    # -- graph bodies ----------------------------------------------------
    def body_a(self):
        o = self.owner
        xin = torch.cat((o.h0, self.x_buf), dim=2)
        y = F.silu(F.conv1d(xin, o.w0, o.b0))
        self.y_buf.copy_(y)
        o.h0.copy_(xin[:, :, -HIST:])      # layer-0 state: last 4 raw inputs

    def body_b(self):
        o = self.owner
        mid = torch.cat((o.h1, self.y_buf), dim=2)
        z = F.conv1d(mid, o.w1, o.b1)
        c = o.channels
        gate = torch.sigmoid(self.x_buf.mean(dim=1, keepdim=True))
        merged = torch.lerp(z[:, :c], z[:, c:], 1.0 - gate)
        self.out_buf.copy_(torch.add(merged, self.x_buf, alpha=0.1))
        o.h1.copy_(mid[:, :, -HIST:])      # layer-1 state: last 4 layer-1 inputs

    def capture(self):
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side), torch.inference_mode():
            for _ in range(3):
                self.body_a()
                self.body_b()
        torch.cuda.current_stream().wait_stream(side)
        torch.cuda.synchronize()
        graph_a = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph_a):
            self.body_a()
        graph_b = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph_b):
            self.body_b()
        self.graphs = (graph_a, graph_b)


class FusedPipeline:
    """Two-window, two-kernel-per-window executor of the two-branch graph."""

    def __init__(self, repository, config, mode='graph'):
        self.config = dict(config)
        self.device = torch.device(self.config.get('device') or 'cuda')
        self.channels = int(self.config['channels'])
        self.hidden = int(self.config['hidden'])
        self.length = int(self.config['length'])
        self.chunk = int(self.config['chunk'])
        self.w0, self.b0, self.w1, self.b1 = build_fused_weights(repository, self.config)
        self.gpu = self.device.type == 'cuda' and torch.cuda.is_available()
        self.mode = mode if self.gpu else 'eager'
        self.h0 = None
        self.h1 = None
        if self.gpu:
            self.w0 = self.w0.to(self.device)
            self.b0 = self.b0.to(self.device)
            self.w1 = self.w1.to(self.device)
            self.b1 = self.b1.to(self.device)
            self.h0 = torch.zeros(1, self.channels, HIST, device=self.device)
            self.h1 = torch.zeros(1, 2 * self.hidden, HIST, device=self.device)
            first = min(self.chunk, self.length)
            widths = [first] + ([self.length - first] if self.length > first else [])
            self.windows = [Window(self, w) for w in widths]
            self.offsets = [0] + [first]
            if self.mode == 'graph':
                self._capture()
        else:
            self.windows = None
            self.offsets = None
        self.reset()

    def _capture(self):
        try:
            for window in self.windows:
                window.capture()
            self.h0.zero_()
            self.h1.zero_()
        except Exception as exc:  # keep a correct eager path if capture fails
            for window in self.windows:
                window.graphs = None
            self.mode = 'eager'
            self.capture_error = repr(exc)

    # ---- public API -----------------------------------------------------
    def reset(self):
        self.fresh = True
        if not self.gpu:
            self.h0 = None
            self.h1 = None

    @torch.inference_mode()
    def run(self, values, index):
        """Evaluate window ``index`` over ``values`` (C, width) and return (C, width).

        On the GPU path the result aliases a pinned staging buffer; it must be
        consumed before the same window is used again.
        """
        src = torch.from_numpy(np.ascontiguousarray(values, dtype=np.float32))
        if not self.gpu:
            return self._forward_cpu(src.unsqueeze(0))[0].numpy()
        window = self.windows[index]
        window.x_buf.copy_(src.unsqueeze(0), non_blocking=True)
        if window.graphs is not None:
            if self.fresh:
                self.h0.copy_(window.x_buf[:, :, :1].expand(1, self.channels, HIST))
            window.graphs[0].replay()
            if self.fresh:
                self.h1.copy_(window.y_buf[:, :, :1].expand(1, 2 * self.hidden, HIST))
                self.fresh = False
            window.graphs[1].replay()
        else:
            if self.fresh:
                self.h0.copy_(window.x_buf[:, :, :1].expand(1, self.channels, HIST))
            window.body_a()
            if self.fresh:
                self.h1.copy_(window.y_buf[:, :, :1].expand(1, 2 * self.hidden, HIST))
                self.fresh = False
            window.body_b()
        window.pin.copy_(window.out_buf, non_blocking=True)
        torch.cuda.synchronize()
        return window.pin[0].numpy()

    @torch.inference_mode()
    def _forward_cpu(self, x):
        if self.h0 is None:
            xin = F.pad(x, (HIST, 0), mode='replicate')
        else:
            xin = torch.cat((self.h0, x), dim=2)
        y = F.silu(F.conv1d(xin, self.w0, self.b0))
        if self.h1 is None:
            mid = F.pad(y, (HIST, 0), mode='replicate')
        else:
            mid = torch.cat((self.h1, y), dim=2)
        z = F.conv1d(mid, self.w1, self.b1)
        self.h0 = xin[:, :, -HIST:].clone()
        self.h1 = mid[:, :, -HIST:].clone()
        c = self.channels
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        merged = torch.lerp(z[:, :c], z[:, c:], 1.0 - gate)
        return torch.add(merged, x, alpha=0.1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    repository = str(args.repository.resolve())
    sys.path.insert(0, repository)
    from branch_features.adapter import open_buffers, close_buffers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    for module, attr in ((torch.backends.cudnn, 'conv'), (torch.backends.cuda, 'matmul')):
        try:
            getattr(module, attr).fp32_precision = 'ieee'
        except Exception:
            pass

    pipeline = FusedPipeline(repository, config, os.environ.get('FLASHRT_BF_MODE', 'graph'))
    channels, length, chunk = config['channels'], config['length'], config['chunk']
    n_chunks = math.ceil(length / chunk)
    bases = [i * chunk for i in range(n_chunks)]
    valid = [min(chunk, length - b) for b in bases]
    out_batch = np.zeros((n_chunks, channels, chunk), dtype=np.float32)
    meta_batch = np.zeros((n_chunks, 3), dtype=np.int64)
    for i, v in enumerate(valid):
        meta_batch[i] = (0, i, v)

    buffers = open_buffers(config, create=True)
    control = buffers['control']
    inbuf = buffers['input']
    outbuf = buffers['output']
    metabuf = buffers['metadata']
    in_view = inbuf.tensor[0]
    consumed, last_command, active = 0, 0, False
    spin_until = 0.0
    try:
        print(json.dumps({'ready': True, 'device': config['device'],
                          'task': 'branch_features', 'mode': pipeline.mode}), flush=True)
        while True:
            opcode = control.recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    control.commit()
                    break
                if opcode == 3:
                    pipeline.reset()
                    active = False
                    control.commit()
                    continue
                if opcode == 1:
                    active = True
                    control.commit()
                    continue
                if opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if active and inbuf.num == consumed + 1:
                request_id = consumed
                for w, offset in enumerate(pipeline.offsets):
                    width = pipeline.windows[w].width
                    out = pipeline.run(in_view[:, offset:offset + width], w)
                    first = bases.index(offset) if offset in bases else 0
                    stop = first
                    while stop + 1 < n_chunks and bases[stop + 1] < offset + width:
                        stop += 1
                    for i in range(first, stop + 1):
                        lo = bases[i] - offset
                        hi = min(lo + chunk, width)
                        out_batch[i, :, :hi - lo] = out[:, lo:hi]
                        meta_batch[i, 0] = request_id
                    rows = slice(first, stop + 1)
                    outbuf.write(out_batch[rows])     # payload first ...
                    metabuf.write(meta_batch[rows])   # ... then metadata rows
                consumed += 1
                continue
            if active and inbuf.num > consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            if time.perf_counter() < spin_until:
                continue
            time.sleep(0.0002)
            spin_until = time.perf_counter() + 0.002
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
