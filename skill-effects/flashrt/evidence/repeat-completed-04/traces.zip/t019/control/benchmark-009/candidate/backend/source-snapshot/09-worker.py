"""Standalone optimized worker for the branch_features two-branch causal task.

Protocol (identical to branch_features.reference): one complete (C, length)
feature matrix per request, ``length / chunk`` ordered output chunks, session
state (four convolution histories in the reference) kept across requests and
cleared by reset.

What the pipeline does per time position t (C=16, H=32, all causal):

    A = a1(silu(a0(x))),  B = b1(silu(b0(x)))        # kernels 5/3 and 3/5
    y[t] = g[t]*A[t] + (1-g[t])*B[t] + 0.1*x[t],  g = sigmoid(mean_c x)

Optimizations (each is exact, i.e. reproduces the reference arithmetic up to
float rounding):

1. Branches are fused.  A branch-0 conv with kernel 3 and replicate left pad 2
   is algebraically the same as a kernel-5 conv whose first two taps are zero,
   because replicate padding repeats x[:, 0] and those taps are multiplied by
   zero.  Hence both branch-0 convolutions read the same raw input and are
   evaluated by a single 16->64 kernel-5 convolution (weight rows concatenated,
   the k=3 rows zero padded on the left).  Likewise both branch-1 convolutions
   are evaluated by one 64->32 kernel-5 convolution whose weight is
   block-diagonal over the concatenated [silu(A0), silu(B0)] activation.
   Two kernel launches instead of four per step.
2. State is two 4-column histories (last 4 raw inputs, last 4 layer-1 inputs)
   instead of the reference's four 2/4/2/4-column caches.  A k=3 window is a
   sub-window of the k=5 window of the same tensor, so no information is lost,
   and the two branches keep distinct history tensors (the k=3 branch reads the
   last two columns of the same layer-1 buffer, not the other branch's cache).
3. Chunking is a transport convention only.  A whole request is evaluated in
   one pass over the full length (a fixed, config-given shape), which produces
   exactly the state the chunked reference holds at the end of the request and
   makes the pass capturable as a CUDA graph.
4. The pass is replayed with two CUDA graphs (layer 0, layer 1) plus one
   device-to-host copy, i.e. one synchronization per request instead of one per
   chunk.  Graph B is separate so that a fresh session can prime the layer-1
   replicate boundary of position 0 with a 4-column copy.
5. The request is drained in a burst: all output chunks and all metadata rows
   are published with two shared-memory writes after a single GPU completion,
   so the client's 0.2 ms metadata poll almost never has to sleep.
6. The receive loop polls with a short bounded spin instead of a 0.2 ms sleep,
   so request pickup latency is microseconds while idle CPU use stays bounded.
"""
import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HIST = 4  # k - 1 of the widest kernel (5)
K = 5


def build_fused_weights(repository, config):
    """Rebuild the four reference convs with the reference seed, then fuse."""
    from branch_features.model import build_layers

    layers = build_layers(repository, config, 'cpu')
    a0, a1 = layers['a0'].conv, layers['a1'].conv
    b0, b1 = layers['b0'].conv, layers['b1'].conv
    channels, hidden = config['channels'], config['hidden']
    with torch.no_grad():
        # (2H, C, 5): rows [0:H] = a0 (k=5), rows [H:2H] = b0 (k=3 -> taps 2..4)
        w0 = torch.cat([a0.weight, F.pad(b0.weight, (2, 0))], dim=0).contiguous()
        beta0 = torch.cat([a0.bias, b0.bias], dim=0).contiguous()
        # (2C, 2H, 5): rows [0:C] = a1 over silu(A0) (taps 2..4),
        #              rows [C:2C] = b1 over silu(B0) (taps 0..4)
        w1 = torch.zeros(2 * channels, 2 * hidden, K,
                         dtype=a0.weight.dtype, device=a0.weight.device)
        w1[:channels, :hidden, 2:] = a1.weight
        w1[channels:, hidden:, :] = b1.weight
        beta1 = torch.cat([a1.bias, b1.bias], dim=0).contiguous()
    return w0, beta0, w1.contiguous(), beta1


class FusedPipeline:
    """Whole-request two-kernel executor with optional CUDA graph replay."""

    def __init__(self, repository, config, mode='graph'):
        self.config = dict(config)
        self.device = torch.device(self.config.get('device') or 'cuda')
        self.channels = int(self.config['channels'])
        self.hidden = int(self.config['hidden'])
        self.length = int(self.config['length'])
        self.w0, self.b0, self.w1, self.b1 = build_fused_weights(repository, self.config)
        self.gpu = self.device.type == 'cuda' and torch.cuda.is_available()
        self.mode = mode if self.gpu else 'eager'
        self.graphs = None
        self.h0 = None
        self.h1 = None
        if self.gpu:
            self.w0 = self.w0.to(self.device)
            self.b0 = self.b0.to(self.device)
            self.w1 = self.w1.to(self.device)
            self.b1 = self.b1.to(self.device)
            c, h, t = self.channels, self.hidden, self.length
            self.x_buf = torch.zeros(1, c, t, device=self.device)
            self.y_buf = torch.zeros(1, 2 * h, t, device=self.device)
            self.out_buf = torch.zeros(1, c, t, device=self.device)
            self.h0 = torch.zeros(1, c, HIST, device=self.device)
            self.h1 = torch.zeros(1, 2 * h, HIST, device=self.device)
            self.pin_out = torch.empty(1, c, t, dtype=torch.float32, pin_memory=True)
        self.reset()
        if self.gpu and self.mode == 'graph':
            self._capture()

    # ---- graph bodies ---------------------------------------------------
    def _body_a(self):
        xin = torch.cat((self.h0, self.x_buf), dim=2)
        y = F.silu(F.conv1d(xin, self.w0, self.b0))
        self.y_buf.copy_(y)
        self.h0.copy_(xin[:, :, -HIST:])   # layer-0 state: last 4 raw inputs

    def _body_b(self):
        mid = torch.cat((self.h1, self.y_buf), dim=2)
        z = F.conv1d(mid, self.w1, self.b1)
        c = self.channels
        gate = torch.sigmoid(self.x_buf.mean(dim=1, keepdim=True))
        merged = torch.lerp(z[:, :c], z[:, c:], 1.0 - gate)
        self.out_buf.copy_(torch.add(merged, self.x_buf, alpha=0.1))
        self.h1.copy_(mid[:, :, -HIST:])   # layer-1 state: last 4 layer-1 inputs

    def _capture(self):
        try:
            side = torch.cuda.Stream()
            side.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(side), torch.inference_mode():
                for _ in range(3):
                    self._body_a()
                    self._body_b()
            torch.cuda.current_stream().wait_stream(side)
            torch.cuda.synchronize()
            graph_a = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph_a):
                self._body_a()
            graph_b = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph_b):
                self._body_b()
            self.h0.zero_()
            self.h1.zero_()
            self.graphs = (graph_a, graph_b)
        except Exception as exc:  # keep a correct eager path if capture fails
            self.graphs = None
            self.mode = 'eager'
            self.capture_error = repr(exc)

    # ---- public API -----------------------------------------------------
    def reset(self):
        self.fresh = True
        if not self.gpu:
            self.h0 = None
            self.h1 = None

    def _prime_history(self):
        """Session-start boundary: replicate x[:, 0] into both histories."""
        self.h0.copy_(self.x_buf[:, :, :1].expand(1, self.channels, HIST))

    @torch.inference_mode()
    def run(self, values):
        """values: (C, length) float32 array -> (C, length) array.

        On the GPU path the result aliases a pinned staging buffer and must be
        consumed before the next call (the worker copies it into the burst).
        """
        src = torch.from_numpy(np.ascontiguousarray(values, dtype=np.float32))
        if not self.gpu:
            return self._forward_cpu(src.unsqueeze(0))[0].numpy()
        self.x_buf.copy_(src.unsqueeze(0), non_blocking=True)
        if self.graphs is not None:
            if self.fresh:
                self._prime_history()          # layer-0 replicate boundary
            self.graphs[0].replay()
            if self.fresh:
                self.h1.copy_(self.y_buf[:, :, :1].expand(1, 2 * self.hidden, HIST))
                self.fresh = False
            self.graphs[1].replay()
        else:
            if self.fresh:
                self._prime_history()
            self._body_a()
            if self.fresh:
                self.h1.copy_(self.y_buf[:, :, :1].expand(1, 2 * self.hidden, HIST))
                self.fresh = False
            self._body_b()
        self.pin_out.copy_(self.out_buf, non_blocking=True)
        torch.cuda.synchronize()
        return self.pin_out[0].numpy()

    @torch.inference_mode()
    def _forward_cpu(self, x):
        if self.h0 is None:
            xin = F.pad(x, (HIST, 0), mode='replicate')
        else:
            xin = torch.cat((self.h0, x), dim=2)
        y = F.silu(F.conv1d(xin, self.w0, self.b0))
        if self.h1 is None:
            mid = F.pad(y, (HIST, 0), mode='replicate')
        else:
            mid = torch.cat((self.h1, y), dim=2)
        z = F.conv1d(mid, self.w1, self.b1)
        self.h0 = xin[:, :, -HIST:].clone()
        self.h1 = mid[:, :, -HIST:].clone()
        c = self.channels
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        merged = torch.lerp(z[:, :c], z[:, c:], 1.0 - gate)
        return torch.add(merged, x, alpha=0.1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    repository = str(args.repository.resolve())
    sys.path.insert(0, repository)
    from branch_features.adapter import open_buffers, close_buffers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    for module, attr in ((torch.backends.cudnn, 'conv'), (torch.backends.cuda, 'matmul')):
        try:
            getattr(module, attr).fp32_precision = 'ieee'
        except Exception:
            pass

    import os
    mode = os.environ.get('FLASHRT_BF_MODE', 'graph')
    pipeline = FusedPipeline(repository, config, mode)
    channels, length, chunk = config['channels'], config['length'], config['chunk']
    n_chunks = math.ceil(length / chunk)
    valid = [min(chunk, length - i * chunk) for i in range(n_chunks)]
    bases = list(range(0, length, chunk))
    out_batch = np.zeros((n_chunks, channels, chunk), dtype=np.float32)
    meta_batch = np.zeros((n_chunks, 3), dtype=np.int64)
    for i, v in enumerate(valid):
        meta_batch[i] = (0, i, v)

    buffers = open_buffers(config, create=True)
    control = buffers['control']
    inbuf = buffers['input']
    outbuf = buffers['output']
    metabuf = buffers['metadata']
    in_view = inbuf.tensor[0]
    consumed, last_command, active = 0, 0, False
    spin_until = 0.0
    try:
        print(json.dumps({'ready': True, 'device': config['device'],
                          'task': 'branch_features', 'mode': pipeline.mode}), flush=True)
        while True:
            opcode = control.recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    control.commit()
                    break
                if opcode == 3:
                    pipeline.reset()
                    active = False
                    control.commit()
                    continue
                if opcode == 1:
                    active = True
                    control.commit()
                    continue
                if opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if active and inbuf.num == consumed + 1:
                request_id = consumed
                # Whole request in one device pass; session state updated.
                out = pipeline.run(in_view)
                for i, v in enumerate(valid):
                    base = bases[i]
                    out_batch[i, :, :v] = out[:, base:base + v]
                    meta_batch[i, 0] = request_id
                outbuf.write(out_batch)        # payload first ...
                metabuf.write(meta_batch)      # ... then the metadata rows
                consumed += 1
                continue
            if active and inbuf.num > consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            if time.perf_counter() < spin_until:
                continue
            time.sleep(0.0002)
            spin_until = time.perf_counter() + 0.002
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
