"""IR conversion for branch_features (Phases 1-2) + analysis + validation.

Two graphs:

* ``build_worker_graph``  -- worker level: input frame read -> the two-branch
  chunk computation (COMPOSITE, streaming) -> output publication.
* ``build_model_graph``   -- model level: the six exposed operators the
  reference runs per chunk, with the four causal-convolution histories modelled
  as explicit ``chunk_persistent`` StateObjects.

``execute()`` on every operator is the real reference arithmetic (same pinned
``CausalConv1d`` modules, same crop-the-padded-prefix rule), so the graph can be
run by ``SequentialExecutor`` and compared numerically against the reference
backend driven through the unchanged adapter.

Run:  python flashrt/apps/branch_features/backend/ir/graph_builder.py
"""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch

BACKEND = Path(__file__).resolve().parent.parent
for extra in (str(BACKEND), str(BACKEND / 'variants'), str(BACKEND / 'tests')):
    if extra not in sys.path:
        sys.path.insert(0, extra)

import common
from flashrt.ir import (IRGraph, IREdge, IROperator, OpType, StateObject,
                        StreamMode, StreamingInfo, StreamingPattern,
                        TensorPort, SequentialExecutor, summarize_graph)


# --------------------------------------------------------------------------- #
# operators (implementation attached to the operator itself)
# --------------------------------------------------------------------------- #
class ConvHistoryOp(IROperator):
    """One causal conv plus its own chunk-persistent input history."""

    def __init__(self, layer_name, src_port, dst_port):
        self.layer_name = layer_name
        self.state_name = 'hist_' + layer_name
        self.src_port = src_port
        self.dst_port = dst_port
        super().__init__(name='conv_' + layer_name, op_type=OpType.EXPOSED,
                         inputs=[TensorPort(src_port)], outputs=[TensorPort(dst_port)],
                         state_reads=[self.state_name], state_writes=[self.state_name])

    def execute(self, inputs, context, state):
        layer = context.convs[self.layer_name]
        values = inputs[self.src_port]
        history = state.get(self.state_name)
        joined = values if history is None else torch.cat([history, values], dim=-1)
        result = layer(joined)
        if history is not None:
            result = result[:, :, history.shape[-1]:]
        state.set(self.state_name, joined[:, :, -(layer._time_causal_padding[0]):].clone())
        return {self.dst_port: result}


class SiluOp(IROperator):
    def __init__(self, name, src_port, dst_port):
        self.src_port, self.dst_port = src_port, dst_port
        super().__init__(name=name, op_type=OpType.EXPOSED,
                         inputs=[TensorPort(src_port)], outputs=[TensorPort(dst_port)])

    def execute(self, inputs, context, state):
        return {self.dst_port: torch.nn.functional.silu(inputs[self.src_port])}


class GateMergeOp(IROperator):
    """sigmoid(mean_c(current input)) * A + (1 - gate) * B + 0.1 * input."""

    def __init__(self):
        super().__init__(name='gate_merge', op_type=OpType.EXPOSED,
                         inputs=[TensorPort('latents'), TensorPort('branch_a'),
                                 TensorPort('branch_b')],
                         outputs=[TensorPort('chunk')])

    def execute(self, inputs, context, state):
        values = inputs['latents']
        gate = torch.sigmoid(values.mean(dim=1, keepdim=True))
        out = (gate * inputs['branch_a'] + (1 - gate) * inputs['branch_b']
               + 0.1 * values)
        return {'chunk': out}


# --------------------------------------------------------------------------- #
# graph builders
# --------------------------------------------------------------------------- #
def build_model_graph(config):
    graph = IRGraph(name='branch_features_chunk')
    for layer in ('a0', 'a1', 'b0', 'b1'):
        graph.add_state(StateObject(name='hist_' + layer, scope='chunk_persistent',
                                    description='last k-1 raw inputs of conv_' + layer))
    graph.add_operator(ConvHistoryOp('a0', 'latents', 'a0_pre'))
    graph.add_operator(SiluOp('silu_a', 'a0_pre', 'a0_act'))
    graph.add_operator(ConvHistoryOp('a1', 'a0_act', 'branch_a'))
    graph.add_operator(ConvHistoryOp('b0', 'latents', 'b0_pre'))
    graph.add_operator(SiluOp('silu_b', 'b0_pre', 'b0_act'))
    graph.add_operator(ConvHistoryOp('b1', 'b0_act', 'branch_b'))
    graph.add_operator(GateMergeOp())
    wires = [('conv_a0', 'a0_pre', 'silu_a', 'a0_pre'),
             ('silu_a', 'a0_act', 'conv_a1', 'a0_act'),
             ('conv_b0', 'b0_pre', 'silu_b', 'b0_pre'),
             ('silu_b', 'b0_act', 'conv_b1', 'b0_act'),
             ('conv_a1', 'branch_a', 'gate_merge', 'branch_a'),
             ('conv_b1', 'branch_b', 'gate_merge', 'branch_b')]
    for src, src_port, dst, dst_port in wires:
        graph.add_edge(IREdge(src_op=src, src_port=src_port, dst_op=dst, dst_port=dst_port))
    for dst in ('conv_a0', 'conv_b0'):
        graph.add_edge(IREdge(src_op='gate_merge', src_port=None, dst_op=dst, dst_port=None))
        graph.edges[-1] = IREdge(src_op='__external__', src_port=None, dst_op=dst, dst_port=None)
    graph.edges = [edge for edge in graph.edges if edge.src_op in graph.operators]
    graph.external_inputs = [TensorPort('latents')]
    graph.external_outputs = [TensorPort('chunk')]
    graph.chunk_ops = list(graph.operators)
    return graph


def build_worker_graph(config):
    """Worker level: frame in -> composite two-branch chunk -> chunk out."""
    graph = IRGraph(name='branch_features_worker')
    graph.add_operator(IROperator(name='read_input_frame', op_type=OpType.EXPOSED,
                                  outputs=[TensorPort('latents')],
                                  state_reads=['input_cursor'], state_writes=['input_cursor'],
                                  stream_mode=StreamMode.STREAMING))
    graph.add_operator(IROperator(name='two_branch_chunk', op_type=OpType.COMPOSITE,
                                  inputs=[TensorPort('latents')],
                                  outputs=[TensorPort('chunk')],
                                  stream_mode=StreamMode.STREAMING,
                                  sub_graph='branch_features_chunk'))
    graph.add_operator(IROperator(name='publish_chunk', op_type=OpType.EXPOSED,
                                  inputs=[TensorPort('chunk')],
                                  state_reads=['input_cursor']))
    graph.add_state(StateObject(name='input_cursor', scope='session_init',
                                description='monotonic consumed-frame counter'))
    graph.add_edge(IREdge(src_op='read_input_frame', src_port='latents',
                          dst_op='two_branch_chunk', dst_port='latents',
                          streaming=StreamingInfo(pattern=StreamingPattern.FIXED_RATE,
                                                  src_chunk_size=config['chunk'],
                                                  dst_chunk_size=config['chunk'],
                                                  description='1 chunk in -> 1 chunk out')))
    graph.add_edge(IREdge(src_op='two_branch_chunk', src_port='chunk',
                          dst_op='publish_chunk', dst_port='chunk',
                          streaming=StreamingInfo(pattern=StreamingPattern.FIXED_RATE,
                                                  src_chunk_size=config['chunk'],
                                                  dst_chunk_size=config['chunk'],
                                                  description='chunk-ordered publication')))
    graph.preamble_ops = ['read_input_frame']
    graph.chunk_ops = ['two_branch_chunk', 'publish_chunk']
    graph.external_inputs = [TensorPort('latents')]
    graph.external_outputs = [TensorPort('chunk')]
    graph.sub_graphs = {'branch_features_chunk': build_model_graph(config)}
    return graph


# --------------------------------------------------------------------------- #
# validation (executor vs reference backend, through the adapter)
# --------------------------------------------------------------------------- #
class Context:
    def __init__(self, convs):
        self.convs = convs


def _digest(arrays):
    sha = hashlib.sha256()
    for array in arrays:
        if array is None:
            sha.update(b'<reset>')
        else:
            sha.update(np.ascontiguousarray(array, dtype=np.float32).tobytes())
    return sha.hexdigest()


def main():
    import harness

    config = harness.make_config('bfir', device='cuda')
    requests = harness.make_requests(config)
    device = common.pick_device(config)
    convs = common.build_layers(harness.REPO, config, device)

    graph = build_model_graph(config)
    errors = graph.validate()
    print('graph.validate():', errors or 'ok', flush=True)
    executor = SequentialExecutor(graph)
    state = {'hist_' + layer: None for layer in ('a0', 'a1', 'b0', 'b1')}
    executor.init_state(state)
    context = Context(convs)

    produced = []
    for kind, features in requests:
        if kind == 'reset':
            executor.init_state(dict(state))
            produced.append(None)
            continue
        out = np.zeros((config['channels'], config['length']), dtype=np.float32)
        chunk = config['chunk']
        for position in range(0, config['length'], chunk):
            values = torch.from_numpy(features[:, position:position + chunk].copy())
            values = values.unsqueeze(0).to(device)
            result = executor.run_chunk({'latents': values}, context)
            piece = result['chunk']
            out[:, position:position + piece.shape[-1]] = piece[0].cpu().numpy()
        produced.append(out)

    reference = harness.run_session(None, config, requests, 'ir_ref',
                                    module=harness.REFERENCE_MODULE)
    diff = harness.compare(produced, reference['outputs'], 2e-5)
    verdict = 'PASS'
    print('IR executor vs reference backend: max_abs=%.3e max_rel=%.3e tolerance=2e-05'
          % (diff['max_abs'], diff['max_rel']), flush=True)
    print('executor_output_sha256=%s' % _digest(produced), flush=True)
    print('reference_output_sha256=%s' % _digest(reference['outputs']), flush=True)

    latencies = {'conv_a0': 0.16, 'silu_a': 0.02, 'conv_a1': 0.09, 'conv_b0': 0.14,
                 'silu_b': 0.02, 'conv_b1': 0.12, 'gate_merge': 0.06}
    analysis = summarize_graph(graph, op_latencies=latencies)
    print(analysis, flush=True)
    worker_analysis = summarize_graph(build_worker_graph(config), op_latencies={
        'read_input_frame': 0.02, 'two_branch_chunk': 0.61, 'publish_chunk': 0.02})
    print(worker_analysis, flush=True)

    results = BACKEND / 'benchmarks' / 'results'
    results.mkdir(parents=True, exist_ok=True)
    (results / 'ir_validation.json').write_text(json.dumps({
        'verdict': verdict, 'max_abs': diff['max_abs'], 'max_rel': diff['max_rel'],
        'tolerance': 2e-5,
        'executor_sha256': _digest(produced),
        'reference_sha256': _digest(reference['outputs']),
        'graph_errors': errors, 'analysis': analysis, 'worker_analysis': worker_analysis,
        'fixture': 'harness.make_requests (6 requests, seed 7)'}, indent=2),
        encoding='utf-8')
    print('IR VALIDATION VERDICT: %s' % verdict, flush=True)
    return 0 if verdict == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
