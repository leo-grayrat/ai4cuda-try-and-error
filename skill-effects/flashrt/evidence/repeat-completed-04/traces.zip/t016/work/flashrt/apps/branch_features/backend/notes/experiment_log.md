# branch_features — experiment log

All measurements: one RTX 5060 8GB, PyTorch 2.11.0+cu128, C=16, H=32, T=1043,
chunk=127 (9 chunks, last one 27 valid samples), weight_seed=20240613, driven
head-lessly through `branch_features.adapter` (never through the frontend).

## IR Conversion (Phase 1-2)

- Worker graph `branch_features_worker`: 3 operators, 2 edges.
  - `read_input_frame` (EXPOSED, STREAMING, preamble, session_init `input_cursor`)
  - `two_branch_chunk` (COMPOSITE, STREAMING, sub-graph `branch_features_chunk`)
  - `publish_chunk` (EXPOSED, BATCH)
  - Streaming edges: 2, both FIXED_RATE with src=dst=127 (ratio 1.00) -> one
    output chunk per input chunk, no accumulation buffer needed, so
    whole-request evaluation is legal (it changes when values exist, not what
    they are).
- Model graph `branch_features_chunk`: 7 operators, 6 data edges, 4 state objects
  `hist_a0/hist_a1/hist_b0/hist_b1` (all `chunk_persistent`: the last k-1 raw
  inputs of that conv). Ops: `conv_a0`, `silu_a`, `conv_a1`, `conv_b0`,
  `silu_b`, `conv_b1`, `gate_merge`.
- IR validation: **PASS**
  - fixture: `tests/harness.py::make_requests` (6 requests: fresh, continuation,
    repeated input without reset, reset, two more requests)
  - reference run: reference backend (`branch_features.reference`) driven through
    the adapter by `tests/test_ir.py`
  - executor_output_sha256 = reference_output_sha256 =
    `f4831339abea351d03f7c5430df841711921127e754104e30465535dbc0c2a4a`
    (max_abs 0.0)
  - tolerance 2e-5: the reference backend itself differs from the in-process CPU
    oracle by max_abs 4.172e-07 on the same fixture (float32 GPU-vs-CPU
    reduction order); 2e-5 is ~50x that gap and ~4 orders below output scale.
  - artifact: `benchmarks/results/ir_validation.json`
- Analysis highlights (`summarize_graph`, latencies per chunk estimated from the
  measured reference total 9.04 ms / 9 chunks, not measured per op):
  - Cross-chunk dependencies are four self-loops only; every other op pair is
    cross-chunk independent, i.e. branch A (`conv_a0,silu_a,conv_a1`) and branch
    B (`conv_b0,silu_b,conv_b1`) share no state and may run concurrently, on
    different chunks or (as used here) fused into one kernel each.
  - Critical path 0.34 ms/chunk: `conv_b0` 0.14 -> `silu_b` 0.02 -> `conv_b1`
    0.12 -> `gate_merge` 0.06. `gate_merge` is the only join.
  - Pipeline stages: 7 (one per op by state partitioning); with one GPU the
    usable part is intra-request overlap, not cross-device pipelining.
  - Streaming overlaps: 1:1 on both worker edges (see above).

## Variant queue

| # | name | hypothesis | IR basis | predicted impact | status |
|---|------|-----------|----------|------------------|--------|
| 0 | `reference` | anchor | - | - | measured |
| 1 | `chunk_seq_gpu` | keep the reference chunk schedule but keep histories on the device and upload each request once | 4 self-loop histories, 1:1 streaming edges | FO latency neutral/good, rate small win | measured |
| 2 | `chunk_fused` | fuse the two branches into one block-diagonal 5-tap conv per stage, keep streaming emission | branch A and B are cross-chunk independent | fewer launches per chunk, rate up | measured |
| 3 | `wholerequest` | evaluate the whole request in one fused two-conv pass, publish chunks from host | ratio 1.00 streaming + causality | FO latency and rate both up strongly | measured |
| 4 | `wholerequest_graph` | same as 3 replayed from a CUDA graph with pinned staging | op count per chunk (7 ops incl. elementwise) | remove launch/host overhead | measured |
| 5 | `wholerequest_cpu` | do the whole-request pass on the CPU, no device traffic | data movement vs arithmetic | tests whether the GPU is needed | measured |
| 6 | `hybrid_firstchunk` | stream chunk 0 first, bulk-compute the remaining 8 chunks | 1:1 edges + critical path per chunk | FO latency oriented | measured |

Ordering rationale: the IR shows the per-chunk critical path is tiny (0.34 ms)
while the reference pays 9 device round trips and 36 kernel launches per
request; data-movement/scheduling levers therefore rank above any arithmetic
lever. Nothing was ordered by implementation cost.

Changelog:
- initial queue committed from the IR analysis (rows 0-6).
- row 1 measured: bulk emission regresses FO latency (all 9 chunks computed
  before the first publish) and gives no rate win -> kept as the isolation
  datum for "GPU-resident state" and superseded by row 2.
- rows 2-6 measured; `wholerequest_graph` best on both active targets; promoted
  as `worker.py`.
- queue floor not reached: see "Unmet requirements" at the end.

## Deployment iteration records

### reference (2026-01-01)
- Correctness: PASS vs CPU oracle (max_abs 2.38e-07 in the benchmark run).
- FO latency: median 1.549 ms, p95 161.618 ms (first request pays CUDA/cuDNN
  module load); total to last chunk median 9.041 ms.
- Chunk gaps: median 1.049 ms, p95 2.009 ms, 0.0% over the 20 ms budget.
- Sustained: 112.46 req/s, 1012.1 chunks/s.
- Artifact: `benchmarks/results/reference_rtx5060.json`.

### chunk_seq_gpu (2026-01-01)
- Hypothesis: the reference's per-chunk H2D/D2H and CPU-side `cat` of histories
  dominate; keep state on device and upload once.
- Correctness: PASS, max_abs 0.000e+00 vs reference (bit-identical).
- FO latency median 8.546 ms (regression: emission deferred until all chunks are
  computed), p95 194.917 ms; total 8.629 ms; gaps 0.009/0.017 ms, 0% over
  budget; 104.63 req/s, 941.7 chunks/s.
- Verdict: needs-followup -> the deferral defect is fixed by streaming emission
  in row 2. Artifact `benchmarks/results/chunk_seq_gpu_rtx5060.json`.

### chunk_fused (2026-01-01)
- Hypothesis: fusing both branches into one block-diagonal conv per stage halves
  the kernel count per chunk while keeping streaming emission.
- Correctness: PASS, max_abs 0.000e+00 vs reference.
- FO latency median 1.117 ms, p95 326.500 ms (first request); total 5.645 ms;
  gaps 0.553/1.079 ms, 0% over budget; 205.66 req/s, 1851.0 chunks/s.
- Verdict: promote (rate 1.83x, total 1.60x) but still pays 9 device round trips.

### wholerequest (2026-01-01)
- Hypothesis: one fused pass over the whole request removes the 9 round trips.
- Correctness: PASS, max_abs 0.000e+00 vs reference (after disabling TF32, which
  otherwise costs 1.642e-04).
- FO latency median 1.069 ms, total 1.146 ms; gaps 0.008/0.015 ms; 1130.60
  req/s, 10175.4 chunks/s (rate 10.05x, total 7.89x).
- Verdict: promote.

### wholerequest_graph (2026-01-01)
- Hypothesis: with only ~7 ops per chunk and one chunk-shaped pass, a captured
  CUDA graph plus pinned staging removes the remaining launch overhead.
- Correctness: PASS, max_abs 2.38e-07 vs CPU oracle (state buffers must be
  written in place: a captured graph holds raw pointers, rebinding the history
  tensors silently froze them - observed as 4.134e-01 error before the fix).
- FO latency median 0.555 ms, p95 2.632 ms; total 0.592 ms; gaps 0.005/0.011 ms,
  0% over budget; 1595.73 req/s, 14361.6 chunks/s (FO 2.79x, p95 61x, rate
  14.19x, total 15.26x).
- Verdict: promote -> `backend/worker.py` (`entry_worker` measures the same
  code: 0.524 ms median FO, 1574.14 req/s).

### wholerequest_cpu (2026-01-01)
- Hypothesis: at 16->32 channels and 1043 samples the arithmetic may be cheaper
  than any device traffic.
- Correctness: PASS, max_abs 4.77e-07.
- FO latency median 1.538 ms, p95 18.313 ms; total 1.598 ms; 857.38 req/s,
  7716.4 chunks/s (rate 7.62x).
- Verdict: keep as evidence that batching, not the GPU, produced most of the
  win; the GPU graph variant still wins 2.8x on FO latency.

### hybrid_firstchunk (2026-01-01)
- Hypothesis: publishing chunk 0 before the bulk pass should beat bulk FO
  latency.
- Correctness: PASS, max_abs 0.000e+00.
- FO latency median 1.877 ms (worse than `wholerequest` 1.069 ms), total
  1.999 ms; 568.95 req/s. The extra pass costs more than the first chunk's
  publication saves at this size.
- Verdict: discard as a lever - the split point is wrong; the whole pass is
  already shorter than one chunk's worth of round-trip overhead.

## Unmet requirements (stated explicitly)

- The definition of done asks for >= 10 distinct measured variants; this
  session measured 6 distinct variants plus the reference anchor and the entry
  point. Ideas that were surfaced but not implemented/measured: concurrent
  branch execution across two CUDA streams, asynchronous double-buffered chunk
  emission on top of the fused chunk schedule, publishing straight into the
  shared output ring from a pinned staging buffer per chunk, `torch.compile` of
  the whole-request pass, and fp16/int8 variants (rejected on tolerance grounds
  without measurement).
- No cross-device work: the assignment is a single GPU, so the 7 IR pipeline
  stages cannot be mapped to separate devices and the multi-GPU levers do not
  apply.
- Only one hardware configuration was measured; the 20 ms chunk-gap budget was
  never exceeded by any variant, so the smoothness side condition did not
  discriminate between variants.
