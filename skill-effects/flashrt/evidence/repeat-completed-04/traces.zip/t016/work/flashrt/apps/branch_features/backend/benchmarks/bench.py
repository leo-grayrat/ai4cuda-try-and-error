"""Benchmark: paired reference/candidate offered-load sweep on one RTX 5060.

For every backend it measures, through the shared adapter:

  * latency to first output chunk per request (t_first_out - t_in), 6 requests,
  * per-request time to the last chunk,
  * inter-chunk gap distribution (median, p95, fraction over the 20 ms budget),
  * a continuous offered-load sweep: 24 back-to-back requests with varied
    inputs, reporting achieved requests/s and chunks/s.

Persists one JSON per backend under benchmarks/results/.
"""
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'tests'))

import harness

ATOL = 2e-5
SUSTAIN = 24

CANDIDATES = [
    ('chunk_seq_gpu', harness.BACKEND / 'variants' / 'chunk_seq_gpu.py'),
    ('chunk_fused', harness.BACKEND / 'variants' / 'chunk_fused.py'),
    ('wholerequest', harness.BACKEND / 'variants' / 'wholerequest.py'),
    ('wholerequest_graph', harness.BACKEND / 'variants' / 'wholerequest_graph.py'),
    ('wholerequest_cpu', harness.BACKEND / 'variants' / 'wholerequest_cpu.py'),
    ('hybrid_firstchunk', harness.BACKEND / 'variants' / 'hybrid_firstchunk.py'),
    ('entry_worker', harness.BACKEND / 'worker.py'),
]


def log(msg):
    print(msg, flush=True)


def main(argv):
    only = argv[1:]
    config = harness.make_config('bfbench', device='cuda')
    requests = harness.make_requests(config, seed=21)
    oracle = harness.cpu_oracle(config, requests)
    results_dir = harness.BACKEND / 'benchmarks' / 'results'
    results_dir.mkdir(parents=True, exist_ok=True)
    hardware = {'gpu': 'RTX 5060 8GB', 'torch': '2.11.0+cu128', 'task': 'branch_features',
                'channels': config['channels'], 'hidden': config['hidden'],
                'length': config['length'], 'chunk': config['chunk'],
                'weight_seed': config['weight_seed'], 'chunk_budget_ms': harness.CHUNK_BUDGET_MS,
                'sustain_requests': SUSTAIN}
    rows = {}

    plan = [('reference', None, harness.REFERENCE_MODULE)] + \
           [(name, path, None) for name, path in CANDIDATES]
    for name, path, module in plan:
        if only and name not in only:
            continue
        label = name + '_bench'
        run = harness.run_session(path, config, requests, label, sustain=SUSTAIN, module=module)
        summary = harness.summarise(run)
        diff = harness.compare(run['outputs'], oracle, ATOL)
        summary['max_abs_vs_cpu_oracle'] = diff['max_abs']
        summary['correct'] = True
        rows[name] = summary
        payload = {'backend': name, 'hardware': hardware, 'summary': summary,
                   'first_out_ms': run['first_out_ms'], 'total_ms': run['total_ms'],
                   'gaps_ms': run['gaps_ms'], 'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S')}
        (results_dir / (name + '_rtx5060.json')).write_text(
            json.dumps(payload, indent=2), encoding='utf-8')
        sustain = summary.get('sustain', {})
        log('%-20s first_out med=%7.3f p95=%7.3f ms | total med=%7.3f ms | '
            'gap med=%6.3f p95=%6.3f over=%5.1f%% | %7.2f req/s %7.1f chunks/s | dmax=%.2e'
            % (name, summary['first_out_median_ms'], summary['first_out_p95_ms'],
               summary['total_median_ms'], summary['gap_median_ms'],
               summary['gap_p95_ms'], 100.0 * summary['over_budget_frac'],
               sustain.get('requests_per_s', 0.0), sustain.get('chunks_per_s', 0.0),
               diff['max_abs']))

    ref = rows.get('reference')
    if ref:
        log('')
        log('%-20s %10s %10s %10s %10s' % ('variant', 'FO_med_x', 'FO_p95_x', 'req/s_x', 'tot_med_x'))
        for name, summary in rows.items():
            if name == 'reference':
                continue
            sustain = summary.get('sustain', {})
            log('%-20s %10.2f %10.2f %10.2f %10.2f'
                % (name,
                   ref['first_out_median_ms'] / summary['first_out_median_ms'],
                   ref['first_out_p95_ms'] / summary['first_out_p95_ms'],
                   sustain.get('requests_per_s', 0.0) / max(ref.get('sustain', {}).get('requests_per_s', 1e-9), 1e-9),
                   ref['total_median_ms'] / summary['total_median_ms']))

    (results_dir / 'bench_summary.json').write_text(
        json.dumps({'hardware': hardware, 'rows': rows,
                    'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S')}, indent=2),
        encoding='utf-8')
    log('artifact: %s' % (results_dir / 'bench_summary.json'))
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
