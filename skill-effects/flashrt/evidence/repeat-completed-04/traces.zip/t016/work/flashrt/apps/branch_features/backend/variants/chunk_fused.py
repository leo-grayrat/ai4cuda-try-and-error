"""Variant: chunked (streaming) schedule with the two branches fused per stage.

Lever (isolated from chunk_seq_gpu): kernel count.  Stage 1 runs one 5-tap conv
with 2H output channels covering a0 and b0; stage 2 runs one 5-tap conv whose
weight matrix is block diagonal over the concatenated branch activations.  The
chunk is still computed and emitted one chunk at a time, so first-output
latency is not paid for the whole request.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import common  # noqa: E402


class ChunkFused:
    name = 'chunk_fused'

    def __init__(self, repository, config):
        self.config = config
        self.device = common.pick_device(config)
        layers = common.build_layers(repository, config, self.device)
        self.head_w, self.head_b, self.tail_w, self.tail_b = common.fused_weights(layers)
        self.reset()

    def reset(self):
        self.hist_head = None
        self.hist_tail = None

    @torch.inference_mode()
    def step(self, values_np):
        values = torch.from_numpy(values_np.copy()).unsqueeze(0).to(self.device)
        if self.hist_head is None:
            self.hist_head, self.hist_tail = common.first_sample_history(
                values, None, self.head_w, self.head_b)
        out, self.hist_head, self.hist_tail = common.fused_pass(
            values, self.hist_head, self.hist_tail,
            self.head_w, self.head_b, self.tail_w, self.tail_b)
        return out[0].cpu().numpy()

    def process(self, values):
        chunk = self.config['chunk']
        length = self.config['length']
        out = np.zeros((self.config['channels'], length), dtype=np.float32)
        for position in range(0, length, chunk):
            piece = self.step(values[:, position:position + chunk])
            out[:, position:position + piece.shape[-1]] = piece
        return out


def main():
    common.run_main(ChunkFused, streaming=True)


if __name__ == '__main__':
    main()
