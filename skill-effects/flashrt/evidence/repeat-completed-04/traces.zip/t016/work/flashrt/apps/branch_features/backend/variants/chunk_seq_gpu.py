"""Variant: reference chunk schedule, but GPU-resident state and one upload.

Lever (isolated): data movement.  The reference uploads one 127-sample chunk and
re-downloads every chunk, and keeps the four histories as freshly ``cat``-ed
device tensors per chunk.  Here the whole request is uploaded once, the four
histories live on the device for the whole session, and each chunk still runs
the reference's four convolutions in the reference's order.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import common  # noqa: E402


class ChunkSeqGpu:
    name = 'chunk_seq_gpu'

    def __init__(self, repository, config):
        self.config = config
        self.device = common.pick_device(config)
        self.layers = common.build_layers(repository, config, self.device)
        self.reset()

    def reset(self):
        self.history = {name: None for name in self.layers}

    @torch.inference_mode()
    def process(self, values):
        device = self.device
        full = torch.from_numpy(values.copy()).unsqueeze(0).to(device)
        chunk = self.config['chunk']
        length = self.config['length']
        channels = self.config['channels']
        out = np.zeros((channels, length), dtype=np.float32)
        for position in range(0, length, chunk):
            piece = full[:, :, position:position + chunk]
            result = common.reference_pass(piece, self.history, self.layers)
            out[:, position:position + piece.shape[-1]] = result[0].cpu().numpy()
        return out


def main():
    common.run_main(ChunkSeqGpu, streaming=False)


if __name__ == '__main__':
    main()
