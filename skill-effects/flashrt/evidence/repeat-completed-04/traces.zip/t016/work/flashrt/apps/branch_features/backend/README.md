# branch_features agent backend (CUDA, single RTX 5060)

Optimised backend for the two-branch causal feature task. The adapter, the task
model and the reference are untouched; this tree only adds a worker, variants,
an IR conversion, harnesses and measurements.

## Recommended entry

`backend/worker.py` — standalone worker, same CLI and IPC contract as the
reference:

```
python flashrt/apps/branch_features/backend/worker.py \
    --repository <repo root that contains flashrt/layers/audio.py> \
    --config <config.json>
```

The config is the JSON the reference worker consumes
(`prefix, channels, hidden, length, chunk, weight_seed, device`). The worker
creates the four shared-memory buffers the adapter expects, serves opcodes
1/2/3, publishes `(channels, chunk)` frames plus `[request_id, chunk, valid]`
metadata in chunk order, and unlinks the buffers on terminate. The unchanged
frontend can drive it exactly like the reference backend.

Numerics: whole-request fused two-conv pass (`common.fused_pass`) replayed from
a CUDA graph, pinned staging for upload/download, session histories kept on the
device across requests, `reset` invalidating them.

## Layout

```
backend/
├── worker.py                 recommended entry (delegates to wholerequest_graph)
├── common.py                 weights, fused formulation, adapter-faithful control loop
├── variants/common.py        shim so variants can `import common`
├── variants/chunk_seq_gpu.py       reference chunk schedule, GPU-resident state
├── variants/chunk_fused.py         chunked, branches fused per stage, streaming emit
├── variants/wholerequest.py        whole-request fused pass
├── variants/wholerequest_graph.py  whole-request fused pass in a CUDA graph (recommended)
├── variants/wholerequest_cpu.py    whole-request pass on the CPU
├── variants/hybrid_firstchunk.py   stream chunk 0, bulk-compute the tail
├── ir/graph_builder.py       worker- and model-level IR + Phase-2 validation + analysis
├── tests/harness.py          subprocess/adapter harness (launch, drive, compare)
├── tests/test_worker.py      correctness: 6-request scenario vs reference + CPU oracle
├── tests/test_ir.py          Phase-2 IR validation (executor vs reference, SHA-256)
├── benchmarks/bench.py       paired reference/candidate latency + offered-load sweep
└── notes/experiment_log.md   IR record, variant queue, per-variant results
```

## Running the evidence

```
python flashrt/apps/branch_features/backend/tests/test_worker.py     # PASS/FAIL
python flashrt/apps/branch_features/backend/tests/test_ir.py         # IR validation + analysis
python flashrt/apps/branch_features/backend/benchmarks/bench.py      # timings + JSON
```

Artifacts land in `backend/benchmarks/results/` (`correctness.json`,
`ir_validation.json`, `<variant>_rtx5060.json`, `bench_summary.json`) and worker
logs in `backend/tests/logs/`.
