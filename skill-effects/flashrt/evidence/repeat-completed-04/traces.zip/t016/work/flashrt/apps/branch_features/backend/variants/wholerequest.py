"""Variant: whole-request bulk pass (one upload, one fused two-conv sequence).

Lever: remove per-chunk GPU round trips and per-chunk kernel launches.  The
whole 1043-sample request is one upload, one 5-tap fused branch conv, one SiLU,
one block-diagonal fused second-stage conv, one gate/merge, one download; the
nine output chunks are then published from the host staging buffer in order.
Causality makes this legal: computing ahead changes no value, only the moment at
which the values exist.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import common  # noqa: E402


class WholeRequest:
    name = 'wholerequest'

    def __init__(self, repository, config):
        self.config = config
        self.device = common.pick_device(config)
        layers = common.build_layers(repository, config, self.device)
        self.head_w, self.head_b, self.tail_w, self.tail_b = common.fused_weights(layers)
        self.reset()

    def reset(self):
        self.hist_head = None
        self.hist_tail = None

    @torch.inference_mode()
    def process(self, values_np):
        values = torch.from_numpy(values_np.copy()).unsqueeze(0).to(self.device)
        if self.hist_head is None:
            self.hist_head, self.hist_tail = common.first_sample_history(
                values, None, self.head_w, self.head_b)
        out, self.hist_head, self.hist_tail = common.fused_pass(
            values, self.hist_head, self.hist_tail,
            self.head_w, self.head_b, self.tail_w, self.tail_b)
        return out[0].cpu().numpy()


def main():
    common.run_main(WholeRequest, streaming=False)


if __name__ == '__main__':
    main()
