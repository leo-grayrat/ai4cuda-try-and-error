"""Shim: lets variant entry scripts (which live in variants/) `import common`.

The real helpers are ``flashrt/apps/branch_features/backend/common.py``; the
variant scripts only need the backend directory on sys.path, so this shim puts
it there and executes the shared module in this namespace.

Session-wide numeric policy, mirrored from the reference worker's start-up so
that every variant computes in fp32 exactly like the reference does:
``cudnn.allow_tf32 = False`` and ``matmul.allow_tf32 = False`` (without these,
cuDNN selects a TF32 tensor-core convolution for the long whole-request shapes
and the output drifts to ~1.6e-4 from the reference).
"""
import sys
from pathlib import Path

import torch

BACKEND = Path(__file__).resolve().parent.parent
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

torch.backends.cudnn.benchmark = False
torch.backends.cudnn.allow_tf32 = False
torch.backends.cuda.matmul.allow_tf32 = False

_TARGET = BACKEND / 'common.py'
exec(compile(_TARGET.read_text(encoding='utf-8'), str(_TARGET), 'exec'))
