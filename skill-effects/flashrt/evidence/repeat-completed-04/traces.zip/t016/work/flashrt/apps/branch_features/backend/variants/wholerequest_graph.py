"""Variant: whole-request fused pass captured in a CUDA graph, pinned staging.

Stacks the bulk formulation with two host-overhead levers: (a) the entire
per-request GPU graph (fused branch conv -> SiLU -> fused merge conv ->
gate/merge -> history roll) is replayed with one launch instead of ~8 kernel
launches plus ~10 python-level tensor ops, and (b) upload/download go through
pinned host buffers with non-blocking copies.

Every tensor the graph touches is a static buffer allocated before capture
(``values``, ``hist_head``, ``hist_tail``, ``out``).  A captured graph keeps
raw pointers, so the history buffers are never rebound: ``reset()`` only marks
the carried state invalid and the first sample's replicate-padded history is
copied *into* the same buffers.
"""
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import common


class WholeRequestGraph:
    name = 'wholerequest_graph'

    def __init__(self, repository, config):
        self.config = config
        self.device = common.pick_device(config)
        self.cuda = self.device.type == 'cuda'
        layers = common.build_layers(repository, config, self.device)
        self.head_w, self.head_b, self.tail_w, self.tail_b = common.fused_weights(layers)
        channels, length, hidden = config['channels'], config['length'], config['hidden']
        self.channels = channels
        self.values = torch.zeros(1, channels, length, device=self.device)
        self.hist_head = torch.zeros(1, channels, common.HIST, device=self.device)
        self.hist_tail = torch.zeros(1, 2 * hidden, common.HIST, device=self.device)
        self.out = torch.zeros(1, channels, length, device=self.device)
        self.hist_valid = False
        self.graph = None
        if self.cuda:
            self.host_in = torch.empty(1, channels, length, pin_memory=True)
            self.host_out = torch.empty(channels, length, pin_memory=True)
            self.graph = self._capture()

    def reset(self):
        self.hist_valid = False

    @torch.inference_mode()
    def _forward(self):
        out, head_hist, tail_hist = common.fused_pass(
            self.values, self.hist_head, self.hist_tail,
            self.head_w, self.head_b, self.tail_w, self.tail_b)
        self.out.copy_(out)
        self.hist_head.copy_(head_hist)
        self.hist_tail.copy_(tail_hist)

    @torch.inference_mode()
    def _capture(self):
        stream = torch.cuda.Stream()
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for _ in range(3):
                self._forward()
        torch.cuda.current_stream().wait_stream(stream)
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            self._forward()
        return graph

    @torch.inference_mode()
    def _seed_history(self, values):
        head, tail = common.first_sample_history(values, None, self.head_w, self.head_b)
        self.hist_head.copy_(head)
        self.hist_tail.copy_(tail)
        self.hist_valid = True

    @torch.inference_mode()
    def process(self, values_np):
        if not self.cuda:
            self.values[0].copy_(torch.from_numpy(values_np))
            if not self.hist_valid:
                self._seed_history(self.values)
            self._forward()
            return self.out[0].cpu().numpy()
        self.host_in[0].copy_(torch.from_numpy(values_np))
        self.values.copy_(self.host_in, non_blocking=True)
        if not self.hist_valid:
            self._seed_history(self.values)
        self.graph.replay()
        self.host_out.copy_(self.out[0], non_blocking=True)
        torch.cuda.current_stream().synchronize()
        return self.host_out.numpy()


def main():
    common.run_main(WholeRequestGraph, streaming=False)


if __name__ == '__main__':
    main()
