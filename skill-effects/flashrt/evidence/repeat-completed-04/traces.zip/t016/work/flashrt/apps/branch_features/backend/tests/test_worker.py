"""Correctness harness: candidates vs protected reference backend and CPU oracle.

Tolerance ATOL = 2e-5 absolute.  Justification: the reference backend itself is
compared against the CPU oracle at the same tolerance here, and that gap is pure
float32 GPU-vs-CPU convolution/mean reduction-order noise for outputs of
magnitude ~1 after two conv stages, a SiLU and a sigmoid gate.  2e-5 is well
above the largest reference-vs-oracle difference on this fixture (printed) and
about four orders of magnitude below the output scale, so it cannot hide a
semantic error.
"""
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

import harness

ATOL = 2e-5

CANDIDATES = {
    'chunk_seq_gpu': harness.BACKEND / 'variants' / 'chunk_seq_gpu.py',
    'chunk_fused': harness.BACKEND / 'variants' / 'chunk_fused.py',
    'wholerequest': harness.BACKEND / 'variants' / 'wholerequest.py',
    'wholerequest_graph': harness.BACKEND / 'variants' / 'wholerequest_graph.py',
    'wholerequest_cpu': harness.BACKEND / 'variants' / 'wholerequest_cpu.py',
    'hybrid_firstchunk': harness.BACKEND / 'variants' / 'hybrid_firstchunk.py',
    'entry_worker': harness.BACKEND / 'worker.py',
}


def log(msg):
    print(msg, flush=True)


def main(argv):
    selected = argv[1:] or list(CANDIDATES)
    config = harness.make_config('bfcheck', device='cuda')
    requests = harness.make_requests(config)
    results = {}
    verdict = 'PASS'

    oracle_cpu = harness.cpu_oracle(config, requests)
    reference = harness.run_session(None, config, requests, 'ref',
                                    module=harness.REFERENCE_MODULE)
    ref_diff = harness.compare(reference['outputs'], oracle_cpu, ATOL)
    log('reference-vs-cpu-oracle: max_abs=%.3e max_rel=%.3e'
        % (ref_diff['max_abs'], ref_diff['max_rel']))
    results['reference'] = {'verdict': 'PASS', 'diff_vs_cpu_oracle': ref_diff}

    for name in selected:
        entry = CANDIDATES[name]
        label = name + '_check'
        try:
            run = harness.run_session(entry, config, requests, label)
            vs_ref = harness.compare(run['outputs'], reference['outputs'], ATOL)
            vs_cpu = harness.compare(run['outputs'], oracle_cpu, ATOL)
            results[name] = {'verdict': 'PASS', 'diff_vs_reference': vs_ref,
                             'diff_vs_cpu_oracle': vs_cpu,
                             'log': str(harness.LOGS / (label + '.log'))}
            log('%s: PASS vs_ref max_abs=%.3e vs_cpu max_abs=%.3e'
                % (name, vs_ref['max_abs'], vs_cpu['max_abs']))
        except Exception as error:
            verdict = 'FAIL'
            results[name] = {'verdict': 'FAIL', 'error': repr(error),
                             'log': str(harness.LOGS / (label + '.log'))}
            log('%s: FAIL %r' % (name, error))

    out = harness.BACKEND / 'benchmarks' / 'results' / 'correctness.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({'verdict': verdict, 'tolerance_atol': ATOL,
                               'results': results}, indent=2, default=float),
                   encoding='utf-8')
    log('VERDICT: %s (artifact: %s)' % (verdict, out))
    return 0 if verdict == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
