"""Headless harness: launch a backend subprocess, drive it through the shared
adapter, collect every output chunk with timestamps, compare against the
protected reference backend and the in-process CPU reference pipeline.

Used by tests/test_worker.py (correctness) and benchmarks/bench.py (timing).
Nothing here touches the user's frontend.
"""
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

TESTS_DIR = Path(__file__).resolve().parent
BACKEND = TESTS_DIR.parent
APP = BACKEND.parent
LOGS = TESTS_DIR / 'logs'


def _find_repo():
    """Directory that contains flashrt/layers/audio.py (the --repository root)."""
    for candidate in (APP.parents[2], APP.parents[1], APP.parents[0]):
        if (candidate / 'flashrt' / 'layers' / 'audio.py').exists():
            return candidate
    try:
        from flashrt.paths import repo_root
        return Path(repo_root())
    except Exception:
        raise RuntimeError('cannot locate repository root')


REPO = _find_repo()
REFERENCE_MODULE = 'branch_features.reference'
LOGS.mkdir(parents=True, exist_ok=True)
CONFIG_DIR = LOGS
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

CHUNK_BUDGET_MS = 20.0


def make_config(prefix, device='cuda', **overrides):
    config = {'prefix': prefix, 'channels': 16, 'hidden': 32, 'length': 1043,
              'chunk': 127, 'weight_seed': 20240613, 'device': device}
    config.update(overrides)
    return config


def n_chunks(config):
    return (config['length'] + config['chunk'] - 1) // config['chunk']


def make_requests(config, seed=7):
    """Six complete requests: fresh, continuation, repeated input, reset, tail."""
    rng = np.random.default_rng(seed)
    shape = (config['channels'], config['length'])
    a = rng.standard_normal(shape).astype(np.float32)
    b = (0.5 * rng.standard_normal(shape) + 0.2).astype(np.float32)
    c = np.cumsum(rng.standard_normal(shape).astype(np.float32), axis=1) * 0.1
    return [('request', a), ('request', b), ('request', b.copy()),
            ('reset', None), ('request', c),
            ('request', (a * 0.3).astype(np.float32))]


def varied_inputs(config, count, seed=11):
    rng = np.random.default_rng(seed)
    shape = (config['channels'], config['length'])
    return [(0.2 + 0.3 * (index % 5)) * rng.standard_normal(shape).astype(np.float32)
            for index in range(count)]


def cpu_oracle(config, requests):
    """Same specification evaluated in-process on the CPU (chunked semantics)."""
    from branch_features.model import ReferencePipeline
    pipeline = ReferencePipeline(REPO, dict(config, device='cpu'))
    assembled = []
    chunk = config['chunk']
    for kind, features in requests:
        if kind == 'reset':
            pipeline.reset()
            assembled.append(None)
            continue
        out = np.zeros((config['channels'], config['length']), dtype=np.float32)
        for position in range(0, config['length'], chunk):
            piece = pipeline.step(features[:, position:position + chunk])
            out[:, position:position + piece.shape[-1]] = piece
        assembled.append(out)
    return assembled


def _spawn(kind, worker_path, config, log_file, config_path):
    config_path.write_text(json.dumps(config), encoding='utf-8')
    env = os.environ.copy()
    env.setdefault('CUDA_VISIBLE_DEVICES', '0')
    env['PYTHONUNBUFFERED'] = '1'
    kwargs = {}
    if os.name == 'nt':
        kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs['preexec_fn'] = os.setsid
    if worker_path is None:
        command = [sys.executable, '-u', '-m', kind, '--repository', str(REPO),
                   '--config', str(config_path)]
    else:
        command = [sys.executable, '-u', str(worker_path), '--repository', str(REPO),
                   '--config', str(config_path)]
    handle = open(log_file, 'w', encoding='utf-8')
    proc = subprocess.Popen(command, cwd=str(REPO), env=env, stdout=handle,
                            stderr=subprocess.STDOUT, **kwargs)
    return proc, handle


def _kill(proc):
    if proc is None:
        return
    if proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            if os.name != 'nt':
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                except ProcessLookupError:
                    pass
            proc.kill()
            proc.wait(timeout=20)


def run_session(worker_path, config, requests, label, sustain=None, module=None):
    """Drive one backend process; return outputs, per-request timings and gaps."""
    from branch_features.adapter import FeatureAdapter
    prefix = '%s_%s_%d' % (config['prefix'][:5], label[:7], os.getpid() % 9973)
    run_config = dict(config, prefix=prefix)
    log_file = LOGS / (label + '.log')
    config_path = CONFIG_DIR / (label + '.json')
    adapter = None
    chunks_per_request = n_chunks(config)
    proc, handle = _spawn(module, worker_path, run_config, log_file, config_path)
    started = time.perf_counter()
    try:
        adapter = FeatureAdapter(run_config)
        adapter.start()
        ready_s = time.perf_counter() - started
        outputs, first_ms, total_ms, gaps_ms = [], [], [], []
        for kind, features in requests:
            if kind == 'reset':
                adapter.reset()
                outputs.append(None)
                continue
            _, t_in = adapter.submit(features)
            buffer = np.zeros((config['channels'], config['length']), dtype=np.float32)
            stamps = []
            for index in range(chunks_per_request):
                data, observed = adapter.receive(timeout_s=120)
                position = index * config['chunk']
                buffer[:, position:position + data.shape[-1]] = data
                stamps.append(observed)
            first_ms.append((stamps[0] - t_in) / 1e6)
            total_ms.append((stamps[-1] - t_in) / 1e6)
            gaps_ms.extend((np.diff(np.array(stamps, dtype=np.int64)) / 1e6).tolist())
            outputs.append(buffer)
        report = {'ready_s': ready_s, 'first_out_ms': first_ms, 'total_ms': total_ms,
                  'gaps_ms': gaps_ms, 'outputs': outputs, 'sustain': None}
        if sustain:
            count = int(sustain)
            inputs = varied_inputs(config, count)
            wall0 = time.perf_counter()
            live_gaps = []
            for features in inputs:
                _, t_in = adapter.submit(features)
                stamps = []
                for index in range(chunks_per_request):
                    data, observed = adapter.receive(timeout_s=120)
                    stamps.append(observed)
                live_gaps.extend((np.diff(np.array(stamps, dtype=np.int64)) / 1e6).tolist())
            wall = time.perf_counter() - wall0
            gaps = np.array(live_gaps)
            report['sustain'] = {
                'requests': count, 'wall_s': wall,
                'requests_per_s': count / wall,
                'chunks_per_s': count * chunks_per_request / wall,
                'gap_median_ms': float(np.median(gaps)),
                'gap_p95_ms': float(np.percentile(gaps, 95)),
                'over_budget_frac': float(np.mean(gaps > CHUNK_BUDGET_MS)),
                'budget_ms': CHUNK_BUDGET_MS}
        return report
    finally:
        try:
            if adapter is not None:
                adapter.terminate()
            _kill(proc)
        finally:
            if adapter is not None:
                try:
                    adapter.close()
                except Exception:
                    pass
            handle.close()


def summarise(report):
    first = np.array(report['first_out_ms'])
    total = np.array(report['total_ms'])
    gaps = np.array(report['gaps_ms'])
    summary = {
        'requests': int(first.size),
        'first_out_median_ms': float(np.median(first)),
        'first_out_p95_ms': float(np.percentile(first, 95)),
        'total_median_ms': float(np.median(total)),
        'total_p95_ms': float(np.percentile(total, 95)),
        'gap_median_ms': float(np.median(gaps)),
        'gap_p95_ms': float(np.percentile(gaps, 95)),
        'over_budget_frac': float(np.mean(gaps > CHUNK_BUDGET_MS)),
        'ready_s': report['ready_s'],
    }
    if report.get('sustain'):
        summary['sustain'] = report['sustain']
    return summary


def compare(actual, expected, tol):
    """Max abs diff between two lists of (C, T) arrays; None marks a reset."""
    worst_abs, worst_rel = 0.0, 0.0
    for index, (lhs, rhs) in enumerate(zip(actual, expected)):
        if lhs is None or rhs is None:
            if (lhs is None) != (rhs is None):
                raise AssertionError('request %d: reset/request mismatch' % index)
            continue
        if lhs.shape != rhs.shape:
            raise AssertionError('request %d: shape %s != %s'
                                 % (index, lhs.shape, rhs.shape))
        if not np.all(np.isfinite(lhs)):
            raise AssertionError('request %d: non-finite output' % index)
        diff = np.abs(lhs - rhs)
        worst_abs = max(worst_abs, float(diff.max()))
        denom = np.maximum(np.abs(rhs), 1e-6)
        worst_rel = max(worst_rel, float((diff / denom).max()))
        if worst_abs > tol:
            raise AssertionError('request %d: max abs diff %.3e > tol %.3e'
                                 % (index, worst_abs, tol))
    return {'max_abs': worst_abs, 'max_rel': worst_rel, 'tol': tol}
