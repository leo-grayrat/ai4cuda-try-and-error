"""Variant: whole-request pass on the CPU (no device traffic at all).

Lever: isolate data movement from arithmetic.  The task is tiny (16->32, 32->16
convs over 1043 samples), so a CPU pass removes the upload, the download and all
kernel launches; the four reference convolutions are run once over the whole
sequence with the same carried histories.  It exists to measure how much of the
GPU variants' win comes from batching rather than from the GPU.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import common  # noqa: E402


class WholeRequestCpu:
    name = 'wholerequest_cpu'

    def __init__(self, repository, config):
        self.config = config
        self.device = torch.device('cpu')
        self.layers = common.build_layers(repository, config, self.device)
        self.reset()

    def reset(self):
        self.history = {name: None for name in self.layers}

    @torch.inference_mode()
    def process(self, values_np):
        values = torch.from_numpy(values_np.copy()).unsqueeze(0)
        out = common.reference_pass(values, self.history, self.layers)
        return out[0].numpy()


def main():
    common.run_main(WholeRequestCpu, streaming=False)


if __name__ == '__main__':
    main()
