"""Shared helpers for the branch_features agent backend.

Vendored semantics (divergence note): ``build_layers`` mirrors
``flashrt/apps/branch_features/model.py::build_layers`` byte-for-byte in effect
(same pinned upstream ``CausalConv1d`` extracted from ``flashrt/layers/audio.py``
via ``ast``, same ``torch.manual_seed(config['weight_seed'])`` and same
module-creation order), so every variant starts from weights identical to the
reference.  Everything else here (the fused / whole-request formulations, the
control loop) is our own code, written against the *unchanged* adapter
contract in ``flashrt/apps/branch_features/adapter.py``.

Contracts honoured by ``serve`` (identical to
``flashrt/apps/branch_features/reference.py``):
  * control opcodes 0 (idle) / 1 (start) / 2 (terminate) / 3 (reset), one
    ``commit()`` per observed level change;
  * input frames read with a monotonically increasing ``consumed`` cursor;
  * one output frame of shape ``(channels, chunk)`` plus metadata
    ``[request_id, chunk_index, valid]`` written per chunk, in chunk order.
"""
import argparse
import ast
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

# Longest causal history any layer in the task needs: 5-tap convs need k-1 = 4.
HIST = 4

# Session-wide numeric policy, mirrored from the reference worker's start-up.
# With TF32 enabled cuDNN picks a TF32 tensor-core convolution for the long
# whole-request shapes and the output drifts ~1.6e-4 from the reference; these
# flags make every variant compute in fp32 like the reference does.
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.allow_tf32 = False
torch.backends.cuda.matmul.allow_tf32 = False


# --------------------------------------------------------------------------- #
# config / weights
# --------------------------------------------------------------------------- #
def load_config(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def pick_device(config):
    requested = str(config.get('device', 'cuda'))
    if requested.startswith('cuda') and not torch.cuda.is_available():
        return torch.device('cpu')
    return torch.device(requested)


def causal_conv_class(repository):
    """Extract the pinned upstream ``CausalConv1d`` exactly as the task model does."""
    source_path = Path(repository) / 'flashrt/layers/audio.py'
    node = next(node for node in ast.parse(source_path.read_text(encoding='utf-8')).body
                if isinstance(node, ast.ClassDef) and node.name == 'CausalConv1d')
    namespace = {'nn': nn, 'F': F, 'torch': torch}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source_path), 'exec'), namespace)
    return namespace['CausalConv1d']


def build_layers(repository, config, device):
    conv = causal_conv_class(repository)
    torch.manual_seed(config['weight_seed'])
    channels, hidden = config['channels'], config['hidden']
    return nn.ModuleDict({'a0': conv(channels, hidden, 5), 'a1': conv(hidden, channels, 3),
                          'b0': conv(channels, hidden, 3), 'b1': conv(hidden, channels, 5)}).to(device).eval()


def fused_weights(layers):
    """Stack the two branches into one 5-tap conv per stage (block diagonal).

    Stage 1: ``[a0 (k=5) ; b0 (k=3)]``.  A k=3 causal conv is the last three
    taps of a k=5 causal window, so ``b0`` is placed at taps 2..4 and taps 0..1
    are zero.  Stage 2: input channels are ``[silu(a0) | silu(b0)]`` and output
    channels are ``[branchA | branchB]``; ``a1`` (k=3, taps 2..4) reads only the
    first ``H`` input channels and ``b1`` (k=5) reads only the last ``H``.
    Every kept output element therefore sums exactly the same products as the
    reference conv (plus exact ``+0.0`` terms).
    """
    with torch.no_grad():
        wa0, ba0 = layers['a0'].conv.weight, layers['a0'].conv.bias
        wa1, ba1 = layers['a1'].conv.weight, layers['a1'].conv.bias
        wb0, bb0 = layers['b0'].conv.weight, layers['b0'].conv.bias
        wb1, bb1 = layers['b1'].conv.weight, layers['b1'].conv.bias
        hidden, channels = wa0.shape[0], wa0.shape[1]
        head_w = torch.zeros(2 * hidden, channels, 5, device=wa0.device, dtype=wa0.dtype)
        head_b = torch.zeros(2 * hidden, device=wa0.device, dtype=wa0.dtype)
        head_w[:hidden] = wa0
        head_b[:hidden] = ba0
        head_w[hidden:, :, 2:] = wb0
        head_b[hidden:] = bb0
        tail_w = torch.zeros(2 * channels, 2 * hidden, 5, device=wa0.device, dtype=wa0.dtype)
        tail_b = torch.zeros(2 * channels, device=wa0.device, dtype=wa0.dtype)
        tail_w[:channels, :hidden, 2:] = wa1
        tail_b[:channels] = ba1
        tail_w[channels:, hidden:, :] = wb1
        tail_b[channels:] = bb1
    return head_w.contiguous(), head_b.contiguous(), tail_w.contiguous(), tail_b.contiguous()


# --------------------------------------------------------------------------- #
# numeric cores
# --------------------------------------------------------------------------- #
def first_sample_history(values, hist_head, head_w, head_b):
    """Replicate-padded history for a session whose state was reset.

    With ``history is None`` the reference replicate-pads the first sample
    ``k-1`` times inside the conv.  Pre-filling the history buffer with ``k-1``
    copies of the layer's first input value reproduces that exactly, because the
    kept outputs (index >= k-1) never see the conv's own padding.  For stage 2
    the first input value is ``silu(head_conv(window of 5 copies of x0))[0]``.
    """
    x0 = values[:, :, :1]
    window = x0.repeat(1, 1, 5)
    y = F.conv1d(F.pad(window, (HIST, 0), mode='replicate'), head_w, head_b)
    tail0 = F.silu(y[:, :, :1])
    return x0.repeat(1, 1, HIST), tail0.repeat(1, 1, HIST)


def fused_pass(values, hist_head, hist_tail, head_w, head_b, tail_w, tail_b):
    """Two-conv causal pass over a whole sequence ``values`` of shape (1,C,T).

    Returns ``(out, new_hist_head, new_hist_tail)`` with ``out`` of shape
    (1,C,T); identical values to the reference chunked loop, which keeps the
    last k-1 inputs of every conv and crops the padded prefix.
    """
    joined = torch.cat([hist_head, values], dim=-1)
    head = F.conv1d(F.pad(joined, (HIST, 0), mode='replicate'), head_w, head_b)[:, :, HIST:]
    tail_in = F.silu(head)
    joined_tail = torch.cat([hist_tail, tail_in], dim=-1)
    both = F.conv1d(F.pad(joined_tail, (HIST, 0), mode='replicate'), tail_w, tail_b)[:, :, HIST:]
    channels = values.shape[1]
    branch_a, branch_b = both[:, :channels], both[:, channels:]
    gate = torch.sigmoid(values.mean(dim=1, keepdim=True))
    out = gate * branch_a + (1 - gate) * branch_b + 0.1 * values
    return out, joined[:, :, -HIST:], joined_tail[:, :, -HIST:]


def reference_pass(values, history, convs):
    """One step of the reference schedule on one device, histories reused.

    ``values`` may be a single chunk (reference behaviour) or a whole request:
    the crop of the replicate-padded prefix makes both equivalent.
    """
    out = {}
    for name in ('a0', 'b0'):
        layer, hist = convs[name], history[name]
        joined = values if hist is None else torch.cat([hist, values], dim=-1)
        res = layer(joined)
        if hist is not None:
            res = res[:, :, hist.shape[-1]:]
        history[name] = joined[:, :, -(layer._time_causal_padding[0]):].clone()
        out[name] = F.silu(res)
    for name, src in (('a1', 'a0'), ('b1', 'b0')):
        layer, hist = convs[name], history[name]
        joined = out[src] if hist is None else torch.cat([hist, out[src]], dim=-1)
        res = layer(joined)
        if hist is not None:
            res = res[:, :, hist.shape[-1]:]
        history[name] = joined[:, :, -(layer._time_causal_padding[0]):].clone()
        out[name] = res
    gate = torch.sigmoid(values.mean(dim=1, keepdim=True))
    return gate * out['a1'] + (1 - gate) * out['b1'] + 0.1 * values


# --------------------------------------------------------------------------- #
# worker plumbing (adapter contract)
# --------------------------------------------------------------------------- #
def bootstrap(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args(argv)
    repository = args.repository.resolve()
    if str(repository) not in sys.path:
        sys.path.insert(0, str(repository))
    from branch_features.adapter import open_buffers, close_buffers
    return repository, load_config(args.config), open_buffers, close_buffers


def serve(repository, config, open_buffers, close_buffers, engine, streaming):
    """Reference-equivalent control loop; ``engine`` owns the numerics."""
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    buffers = open_buffers(config, create=True)
    control, inp = buffers['control'], buffers['input']
    out_buf, meta_buf = buffers['output'], buffers['metadata']
    channels, length, chunk = config['channels'], config['length'], config['chunk']
    n_chunks = (length + chunk - 1) // chunk
    staging = np.zeros((channels, n_chunks * chunk), dtype=np.float32)
    meta = np.zeros((3,), dtype=np.int64)
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({'ready': True, 'device': str(config.get('device')),
                          'task': 'branch_features',
                          'variant': getattr(engine, 'name', 'unknown'),
                          'streaming': bool(streaming)}), flush=True)
        while True:
            opcode = control.recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    control.commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    control.commit()
                elif opcode == 1:
                    active = True
                    control.commit()
                elif opcode != 0:
                    raise ValueError('Unknown control opcode: %r' % (opcode,))
            if not active:
                continue
            next_cursor, features = inp.read(consumed, 1)
            if features is None:
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id, consumed = consumed, next_cursor
            values = features[0]
            if streaming:
                for index, position in enumerate(range(0, length, chunk)):
                    piece = engine.step(values[:, position:position + chunk])
                    valid = piece.shape[-1]
                    staging[:, :valid] = piece
                    if valid < chunk:
                        staging[:, valid:chunk] = 0.0
                    out_buf.write(staging[:, :chunk])
                    meta[:] = (request_id, index, valid)
                    meta_buf.write(meta)
            else:
                full_out = engine.process(values)
                staging[:, :length] = full_out
                if staging.shape[1] > length:
                    staging[:, length:] = 0.0
                for index in range(n_chunks):
                    position = index * chunk
                    valid = min(chunk, length - position)
                    out_buf.write(staging[:, position:position + chunk])
                    meta[:] = (request_id, index, valid)
                    meta_buf.write(meta)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


def run_main(engine_factory, streaming, argv=None):
    repository, config, open_buffers, close_buffers = bootstrap(argv)
    engine = engine_factory(repository, config)
    serve(repository, config, open_buffers, close_buffers, engine, streaming)
