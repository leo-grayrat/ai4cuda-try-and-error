"""Phase-2 IR validation harness.

Runs ``backend/ir/graph_builder.py`` (graph construction, ``SequentialExecutor``
execution over the six-request fixture, numerical comparison against the
reference backend driven through the shared adapter, and ``summarize_graph``
analysis) with autograd disabled so the executor's outputs can be read back with
``.numpy()`` exactly like the reference pipeline does.

Artifact: ``backend/benchmarks/results/ir_validation.json``.
"""
import runpy
import sys
from pathlib import Path

import torch

TARGET = Path(__file__).resolve().parent.parent / 'ir' / 'graph_builder.py'

if __name__ == '__main__':
    torch.set_grad_enabled(False)
    sys.argv = [str(TARGET)]
    try:
        runpy.run_path(str(TARGET), run_name='__main__')
    except SystemExit as exit_signal:
        raise SystemExit(exit_signal.code)
