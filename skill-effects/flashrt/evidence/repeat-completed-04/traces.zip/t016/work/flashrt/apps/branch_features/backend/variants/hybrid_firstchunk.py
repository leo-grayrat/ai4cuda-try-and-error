"""Variant: latency-oriented hybrid (stream chunk 0, bulk-compute the tail).

Lever: split the request at the first chunk boundary so the consumer sees a
first output chunk after one 127-sample step, then run the remaining 916 samples
as one fused bulk pass.  Attacks first-output latency while keeping most of the
bulk formulation's throughput.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import common  # noqa: E402


class HybridFirstChunk:
    name = 'hybrid_firstchunk'

    def __init__(self, repository, config):
        self.config = config
        self.device = common.pick_device(config)
        layers = common.build_layers(repository, config, self.device)
        self.head_w, self.head_b, self.tail_w, self.tail_b = common.fused_weights(layers)
        self.reset()

    def reset(self):
        self.hist_head = None
        self.hist_tail = None

    @torch.inference_mode()
    def _fused(self, values):
        if self.hist_head is None:
            self.hist_head, self.hist_tail = common.first_sample_history(
                values, None, self.head_w, self.head_b)
        out, self.hist_head, self.hist_tail = common.fused_pass(
            values, self.hist_head, self.hist_tail,
            self.head_w, self.head_b, self.tail_w, self.tail_b)
        return out

    @torch.inference_mode()
    def step(self, values_np):
        values = torch.from_numpy(values_np.copy()).unsqueeze(0).to(self.device)
        return self._fused(values)[0].cpu().numpy()

    @torch.inference_mode()
    def process(self, values_np):
        chunk, length = self.config['chunk'], self.config['length']
        values = torch.from_numpy(values_np.copy()).unsqueeze(0).to(self.device)
        out = np.zeros((self.config['channels'], length), dtype=np.float32)
        piece = self._fused(values[:, :, :chunk])
        out[:, :piece.shape[-1]] = piece[0].cpu().numpy()
        if length > chunk:
            rest = self._fused(values[:, :, chunk:])
            out[:, chunk:chunk + rest.shape[-1]] = rest[0].cpu().numpy()
        return out


def main():
    common.run_main(HybridFirstChunk, streaming=False)


if __name__ == '__main__':
    main()
