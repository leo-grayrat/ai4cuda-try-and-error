"""Recommended entry point for the branch_features agent backend.

Standalone worker accepting ``--repository`` / ``--config`` and honouring the
unchanged adapter contract.  Numerics are delegated to the
``wholerequest_graph`` variant: whole-request fused two-conv pass replayed from
a CUDA graph, pinned staging, GPU-resident session histories, chunk-ordered
publication of all nine output chunks.
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / 'variants'))

from wholerequest_graph import main


if __name__ == '__main__':
    main()
