## 结论

在单张 RTX 5060 8GB、PyTorch 2.11.0+cu128 上，我给出 `flashrt/apps/branch_features/backend/worker.py` 作为推荐入口（接受 `--repository` / `--config`，完全沿用 `branch_features.adapter` 的共享内存与控制协议）。独立 verify 通过：6 个完整请求全部数值匹配，最大绝对误差 2.4e-07，进程清理已验证（`evidence/verify-008`）。独立 benchmark（`evidence/benchmark-009`）显示参考后端在有限负载扫描中只有 50 req/s 档通过速率门（100/200 档外部队列增长到 2/80），而候选在 200 req/s（最高测试档）仍通过、外部队列始终为 0；首块延迟中位数 0.54 ms 对 1.63 ms。

## 假设与证据

**IR（阶段 1–2）**：`backend/ir/graph_builder.py` 建立 worker 级图（3 算子、2 条定点速率 1:1 流式边）与模型级图（7 算子、4 个 `chunk_persistent` 状态 `hist_a0/a1/b0/b1`）。执行 `SequentialExecutor` 与通过适配器驱动的受保护参考后端对比，6 请求（首请求、续接、不 reset 的重复输入、reset、尾块）输出 SHA-256 完全相同（`f4831339…c2a4a`），即 PASS，工件在 `benchmarks/results/ir_validation.json`。分析结论：跨块依赖只有四个自环，因此 A 分支与 B 分支、乃至 `conv_a1 || conv_b1` 都跨块独立；单块关键路径仅 0.34 ms（`conv_b0→silu_b→conv_b1→gate_merge`），`gate_merge` 是唯一汇合点；两条流式边速率比 1.00，说明“提前整段计算”不改变任何取值、只改变取值产生的时刻。

**据此推出的局部优化**：(1) 把两条分支在每一级融合成一个 5 抽头块对角卷积（k=3 卷积等价于 5 抽头窗口的后三个抽头，故 b0/a1 补零放入 tap 2..4），每块卷积核数 4→2；(2) 把整段 1043 点一次算完，每请求 1 次上传、1 次下载代替 9 次往返；(3) 用 CUDA 图捕获整段融合通路 + pinned 暂存，并把四份历史常驻显存、按块序发布输出。

**实测（`benchmarks/results/*_rtx5060.json`，中位首块延迟 / 持续速率）**：参考 1.549 ms / 112.5 req/s（1012 chunks/s，每块间隔中位 1.05 ms）；`chunk_seq_gpu` 8.55 ms / 104.6 req/s；`chunk_fused` 1.117 ms / 205.7 req/s；`wholerequest` 1.069 ms / 1130.6 req/s；`wholerequest_graph` 0.555 ms / 1595.7 req/s（总时延 9.04→0.59 ms，15.3×）；`wholerequest_cpu` 1.538 ms / 857.4 req/s；`hybrid_firstchunk` 1.877 ms / 569.0 req/s。除参考外全部变体与 CPU 全序列 oracle 的最大误差 ≤ 4.8e-07。

## 失败与权衡

- **TF32**：最初长形状卷积被 cuDNN 选成 TF32 张量核，误差 1.64e-04；在 `common.py` 里像参考一样关闭 `cudnn.allow_tf32` / `matmul.allow_tf32` 后归零（`wholerequest`、`hybrid_firstchunk` 由此变成逐位一致）。
- **CUDA 图捕获陷阱**：捕获的图持有裸指针，第一版在 reset 后重新绑定 `hist_*` 张量，导致图仍写旧缓冲，误差 4.13e-01；改为“只就地 `copy_`、永不重绑定”后通过（`variants/wholerequest_graph.py`）。
- **`chunk_seq_gpu` 首块延迟回退到 8.55 ms**：它把所有块算完才发布，说明“状态常驻”这一孤立杠杆本身无害但也无益，收益来自融合与整段批处理，而非省一次上传。
- **`hybrid_firstchunk` 反而更慢（1.877 ms）**：在本尺寸下额外一次通路成本高于提前发布首块的收益。
- **平滑度侧条件有一处未达标**：独立 benchmark 的 50 req/s 窗口里候选 `over_budget_fraction=5.8%`、间隔 p95=20.01 ms（其余两个窗口 0%）；同一窗口速率门通过。这是我自己的 24 请求连续扫描没暴露的（那里三档全 0%），诚实记录为一次未解释的抖动，未做进一步归因。
- **权衡**：整段批处理牺牲“边算边发”的天然节奏，换来 9 次设备往返的消除；实测首块延迟反而更优，所以在这套尺寸下没有真正取舍。CPU 变体证明大部分收益来自批处理而非 GPU，但 GPU 图变体仍快 2.8×。

## 未完成的要求（明确列出）

1. **未达到 ≥10 个不同实测变体的下限**：实际完成 6 个不同变体 + 参考锚点 + 入口点（`entry_worker` 与推荐变体同码，不算新变体）。已想到但未实现、未测量的方向：两条分支用两个 CUDA 流真正并发、在融合分块调度上做异步双缓冲分块发布、把 pinned 暂存直接写进共享输出环、对整段通路做 `torch.compile`、以及 fp16/int8（后者按容差理由在未测量情况下被排除——这是未测量的判断，不是结论）。这些不是被“成本理由”删除，而是观测预算耗尽后的剩余工作，队列里没有把它们伪装成 `measured`。
2. **没有跨设备工作**：任务指定单 GPU，IR 分出的 7 个流水阶段无法映射到不同设备，多 GPU 相关条款不适用；也因此没有“应用流水调度 + 模型并行组合”的完整矩阵。
3. **单硬件、单配置**：只测了一种 GPU 与一种形状，20 ms 块间隔预算在所有变体的自测中都未被突破，因此平滑度侧条件在自测里不具区分度（独立 benchmark 上才暴露上面那一次）。
4. **`benchmarks/bench.py` 的 p95 首块延迟含冷启动**（首请求要加载 cuDNN 模块），参考与候选都受影响，故 p95 列只作次要证据。

## 交付物

`backend/worker.py`（推荐入口）、`backend/common.py`（权重/融合/忠实控制循环）、`backend/variants/*`（6 个变体 + shim）、`backend/ir/graph_builder.py`、`backend/tests/{harness,test_worker,test_ir}.py`、`backend/benchmarks/bench.py` 与 `benchmarks/results/` 下的 JSON、`backend/notes/experiment_log.md`、`backend/README.md`。未修改任何共享/参考文件。

## 交接门自检

- “Implementation and debugging cost are never valid rationale …”：满足——队列 7 行全部是 `measured`，没有以成本为由跳过任何已入队变体；未入队的方向在“未完成的要求”里如实登记。
- “Read-only areas are not a blocker — vendor the file into your workspace”：满足——需要的语义都写在我自己的 `common.py` / `variants/*` 中，未改动 `flashrt/`、`assets/`、`branch_features/{adapter,model,reference}.py`。
- “Terminal statuses” / “What `blocked` means (strict)”：满足——没有 `blocked` / `discarded` 行，因此无需类别证据；`hybrid_firstchunk` 标为 `discard as a lever` 属实测后的裁决，其测量工件在 `benchmarks/results/hybrid_firstchunk_rtx5060.json`（若严格按规则解读该词应视为 `measured` 且不推广，我按后者理解）。
- “Forbidden session-handoff language”：已检查 `notes/experiment_log.md`、`README.md` 与本报告，未出现 “next session / future session / follow-on / pick this up later / beyond this session's scope / deferred to a later session / out of scope for this session / left for follow-up” 等表述。
- “Adversarial self-framing”：本会话没有 `blocked`/`discarded` 队列行，故无该段落需求；第 1 条未完成项以“预算耗尽、方向未实现”明示，而非伪装成环境阻塞。