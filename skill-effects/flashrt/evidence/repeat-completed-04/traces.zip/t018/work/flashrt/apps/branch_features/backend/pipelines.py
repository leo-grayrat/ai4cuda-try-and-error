"""Optimized pipelines for the two-branch causal feature task.

The reference (``branch_features.reference``) walks a request in chunks of
``config['chunk']`` samples.  For every chunk it runs, strictly in order:

    a0 (C->H, k=5) -> SiLU -> a1 (H->C, k=3)      branch A
    b0 (C->H, k=3) -> SiLU -> b1 (H->C, k=5)      branch B
    gate = sigmoid(mean_c(features)); out = gate*A + (1-gate)*B + 0.1*features

Every convolution owns a private *input* history of ``k-1`` samples, so the
whole pipeline is a causal operator on the sample stream: the value produced
for sample ``t`` depends only on samples ``<= t`` of the same session stream
(the concatenation of consecutive requests defines that stream until a
reset), and ``CausalConv1d`` left-pads with ``replicate`` mode, so the first
samples of a session replicate ``x[0]``.

Value-preserving transformations used below:

1. A chunk is *not* a data-dependency boundary.  All ``length`` samples of a
   request are published by the adapter before any output is consumed, so a
   request can be computed in one segment (or a few segments) instead of nine;
   history only has to be carried between segments.
2. ``a0``/``b0`` consume the same input stream and differ only in kernel size;
   ``a1``/``b1`` consume disjoint hidden-channel groups.  Left-zero-padding
   the shorter kernel aligns both to kernel 5, so ``a0``+``b0`` collapse into
   one 2H-channel convolution and ``a1``+``b1`` into one grouped convolution
   (2 groups).  cuDNN computes output channels independently, so this is the
   same arithmetic with half the launches.
3. The per-sample math is tiny (16 -> 64 -> 32 channels over <=1043 samples),
   so the reference is dominated by per-chunk fixed costs (allocations,
   launches, one device->host sync per chunk).  Static buffers plus a replayed
   CUDA graph remove most of that.
"""

import torch
import torch.nn.functional as F


def _load_layers(repository, config, device):
    # The protected reference model owns weight construction (weight_seed);
    # reuse it so both backends start from bit-identical parameters.
    from branch_features.model import build_layers

    return build_layers(repository, config, device)


def _conv_module(module):
    return getattr(module, "conv", module)


def _w(module):
    return _conv_module(module).weight.detach().contiguous()


def _b(module):
    return _conv_module(module).bias.detach().contiguous()


class _Base:
    """Configuration and history bookkeeping shared by the stream engines."""

    def __init__(self, repository, config, bulk=False):
        self.repository = repository
        self.config = config
        self.device = torch.device(config["device"])
        self.channels = int(config["channels"])
        self.hidden = int(config["hidden"])
        self.length = int(config["length"])
        self.chunk = int(config["chunk"])
        self.n_chunks = (self.length + self.chunk - 1) // self.chunk
        self.pad = 4  # largest (kernel - 1) among a0/b0/b1
        self.bulk = bool(bulk)
        with torch.no_grad():
            self.layers = _load_layers(repository, config, self.device)


class ReferenceLikeEngine(_Base):
    """Exactly ``ReferencePipeline.step`` per chunk, in streaming order.

    Isolates the polling/loop lever from all compute changes.
    """

    def __init__(self, repository, config, bulk=False):
        super().__init__(repository, config, bulk=bulk)
        from branch_features.model import ReferencePipeline

        self.pipeline = ReferencePipeline(repository, config)

    def reset(self):
        self.pipeline.reset()

    def stream(self, features):
        for index in range(self.n_chunks):
            start = index * self.chunk
            valid = min(self.chunk, self.length - start)
            yield index, valid, self.pipeline.step(features[:, start:start + valid])


class SegmentEngine(_Base):
    """Both branches in one fused convolution pair, per segment of chunks.

    ``seg_chunks`` is how many contract chunks one compute call covers
    (1 == reference granularity, ``n_chunks`` == whole request).
    """

    def __init__(self, repository, config, seg_chunks=1, use_graph=False,
                 pinned=False, bulk=False):
        super().__init__(repository, config, bulk=bulk)
        layers = self.layers
        with torch.no_grad():
            self.w0 = torch.cat(
                [_w(layers["a0"]), F.pad(_w(layers["b0"]), (2, 0))], 0
            ).contiguous()
            self.b0 = torch.cat([_b(layers["a0"]), _b(layers["b0"])], 0).contiguous()
            self.w1 = torch.cat(
                [F.pad(_w(layers["a1"]), (2, 0)), _w(layers["b1"])], 0
            ).contiguous()
            self.b1 = torch.cat([_b(layers["a1"]), _b(layers["b1"])], 0).contiguous()

        self.seg_chunks = self.n_chunks if not seg_chunks else min(int(seg_chunks),
                                                                  self.n_chunks)
        self.seg_len = self.seg_chunks * self.chunk
        ch, hid, pad, n = self.channels, self.hidden, self.pad, self.seg_len
        self.in_buf = torch.zeros(1, ch, pad + n, device=self.device)
        self.hid_buf = torch.zeros(1, 2 * hid, pad + n, device=self.device)
        self.out_buf = torch.zeros(1, ch, n, device=self.device)
        self.in_hist = torch.zeros(1, ch, pad, device=self.device)
        self.hid_hist = torch.zeros(1, 2 * hid, pad, device=self.device)
        self.fresh = True

        self.pinned = bool(pinned) and self.device.type == "cuda"
        if self.pinned:
            self.host_buf = torch.empty(ch, n, dtype=torch.float32, pin_memory=True)
            self._evt = torch.cuda.Event()
        self.graph = None
        self.use_graph = bool(use_graph) and self.device.type == "cuda"
        if self.use_graph:
            self._capture()

    # -- raw compute over the two static buffers ---------------------------
    def _run(self, fresh):
        pad = self.pad
        h = F.silu(F.conv1d(self.in_buf, self.w0, self.b0))       # (1,2H,n)
        self.hid_buf[:, :, pad:].copy_(h)
        if fresh:
            # replicate padding of the first chunk in a session
            self.hid_buf[:, :, :pad].copy_(h[:, :, :1].expand(-1, -1, pad))
        out = F.conv1d(self.hid_buf, self.w1, self.b1, groups=2)  # (1,2C,n)
        xs = self.in_buf[:, :, pad:]
        gate = torch.sigmoid(xs.mean(dim=1, keepdim=True))
        self.out_buf.copy_(
            gate * out[:, :self.channels]
            + (1.0 - gate) * out[:, self.channels:]
            + 0.1 * xs
        )

    def _capture(self):
        try:
            side = torch.cuda.Stream()
            side.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(side):
                for _ in range(3):
                    self._run(False)
            torch.cuda.current_stream().wait_stream(side)
            torch.cuda.synchronize()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                self._run(False)
            self.graph = graph
        except Exception as exc:  # pragma: no cover - defensive fallback
            print("cuda-graph capture failed, falling back to eager: %r" % (exc,),
                  flush=True)
            self.graph = None
            self.use_graph = False

    def _to_host(self):
        if self.pinned:
            self.host_buf.copy_(self.out_buf[0], non_blocking=True)
            self._evt.record()
            self._evt.synchronize()
            return self.host_buf.numpy()
        return self.out_buf[0].cpu().numpy()

    def reset(self):
        self.fresh = True
        self.in_hist.zero_()
        self.hid_hist.zero_()

    def stream(self, features):
        pad = self.pad
        for seg_start in range(0, self.length, self.seg_len):
            seg_n = min(self.seg_len, self.length - seg_start)
            x = torch.from_numpy(features[:, seg_start:seg_start + seg_n])
            if x.device != self.device:
                x = x.to(self.device)
            self.in_buf[:, :, pad:pad + seg_n].copy_(x)
            if seg_n < self.seg_len:
                # Tail padding only feeds outputs that are never emitted.
                self.in_buf[:, :, pad + seg_n:].copy_(
                    self.in_buf[:, :, pad + seg_n - 1:pad + seg_n].expand(
                        -1, -1, self.seg_len - seg_n))
            if self.fresh:
                self.in_buf[:, :, :pad].copy_(
                    self.in_buf[:, :, pad:pad + 1].expand(-1, -1, pad))
            else:
                self.in_buf[:, :, :pad].copy_(self.in_hist)
                self.hid_buf[:, :, :pad].copy_(self.hid_hist)

            if self.graph is not None and not self.fresh:
                self.graph.replay()
            else:
                self._run(self.fresh)

            self.in_hist = torch.cat(
                [self.in_hist, self.in_buf[:, :, pad:pad + seg_n]], dim=-1
            )[:, :, -pad:].contiguous()
            self.hid_hist = torch.cat(
                [self.hid_hist, self.hid_buf[:, :, pad:pad + seg_n]], dim=-1
            )[:, :, -pad:].contiguous()
            self.fresh = False

            host = self._to_host()
            first_chunk = seg_start // self.chunk
            for k in range(self.seg_chunks):
                index = first_chunk + k
                if index >= self.n_chunks:
                    break
                off = k * self.chunk
                valid = min(self.chunk, self.length - index * self.chunk)
                yield index, valid, host[:, off:off + valid]


class BranchStreamEngine(_Base):
    """Branch A and branch B convolved concurrently on two CUDA streams.

    Attacks within-chunk model parallelism: given the request input the two
    branches are independent, so their kernels may overlap.
    """

    def __init__(self, repository, config, bulk=False):
        super().__init__(repository, config, bulk=bulk)
        layers = self.layers
        with torch.no_grad():
            self.wa0, self.ba0 = _w(layers["a0"]), _b(layers["a0"])
            self.wa1 = F.pad(_w(layers["a1"]), (2, 0)).contiguous()
            self.ba1 = _b(layers["a1"])
            self.wb0 = F.pad(_w(layers["b0"]), (2, 0)).contiguous()
            self.bb0 = _b(layers["b0"])
            self.wb1, self.bb1 = _w(layers["b1"]), _b(layers["b1"])
        pad, ch, hid, n = self.pad, self.channels, self.hidden, self.length
        self.in_buf = torch.zeros(1, ch, pad + n, device=self.device)
        self.ha_buf = torch.zeros(1, hid, pad + n, device=self.device)
        self.hb_buf = torch.zeros(1, hid, pad + n, device=self.device)
        self.out_buf = torch.zeros(1, ch, n, device=self.device)
        self.in_hist = torch.zeros(1, ch, pad, device=self.device)
        self.ha_hist = torch.zeros(1, hid, pad, device=self.device)
        self.hb_hist = torch.zeros(1, hid, pad, device=self.device)
        self.fresh = True
        if self.device.type == "cuda":
            self.s1, self.s2 = torch.cuda.Stream(), torch.cuda.Stream()
        else:
            self.s1 = self.s2 = None

    def reset(self):
        self.fresh = True
        self.in_hist.zero_()
        self.ha_hist.zero_()
        self.hb_hist.zero_()

    def _branch(self, w0, b0, hbuf, hist, w1, b1):
        pad = self.pad
        h = F.silu(F.conv1d(self.in_buf, w0, b0))
        hbuf[:, :, pad:].copy_(h)
        if self.fresh:
            hbuf[:, :, :pad].copy_(h[:, :, :1].expand(-1, -1, pad))
        else:
            hbuf[:, :, :pad].copy_(hist)
        return h, F.conv1d(hbuf, w1, b1)

    def stream(self, features):
        pad, n = self.pad, self.length
        x = torch.from_numpy(features)
        if x.device != self.device:
            x = x.to(self.device)
        self.in_buf[:, :, pad:pad + n].copy_(x)
        if self.fresh:
            self.in_buf[:, :, :pad].copy_(
                self.in_buf[:, :, pad:pad + 1].expand(-1, -1, pad))
        else:
            self.in_buf[:, :, :pad].copy_(self.in_hist)

        if self.s1 is None:
            ha, oa = self._branch(self.wa0, self.ba0, self.ha_buf, self.ha_hist,
                                  self.wa1, self.ba1)
            hb, ob = self._branch(self.wb0, self.bb0, self.hb_buf, self.hb_hist,
                                  self.wb1, self.bb1)
        else:
            cur = torch.cuda.current_stream()
            self.s1.wait_stream(cur)
            self.s2.wait_stream(cur)
            with torch.cuda.stream(self.s1):
                ha, oa = self._branch(self.wa0, self.ba0, self.ha_buf,
                                      self.ha_hist, self.wa1, self.ba1)
            with torch.cuda.stream(self.s2):
                hb, ob = self._branch(self.wb0, self.bb0, self.hb_buf,
                                      self.hb_hist, self.wb1, self.bb1)
            cur.wait_stream(self.s1)
            cur.wait_stream(self.s2)
            xs = self.in_buf[:, :, pad:]
            gate = torch.sigmoid(xs.mean(dim=1, keepdim=True))
            self.out_buf.copy_(gate * oa + (1.0 - gate) * ob + 0.1 * xs)

        self.in_hist = torch.cat(
            [self.in_hist, self.in_buf[:, :, pad:]], dim=-1)[:, :, -pad:].contiguous()
        self.ha_hist = torch.cat(
            [self.ha_hist, self.ha_buf[:, :, pad:]], dim=-1)[:, :, -pad:].contiguous()
        self.hb_hist = torch.cat(
            [self.hb_hist, self.hb_buf[:, :, pad:]], dim=-1)[:, :, -pad:].contiguous()
        self.fresh = False

        host = self.out_buf[0].cpu().numpy()
        for index in range(self.n_chunks):
            start = index * self.chunk
            valid = min(self.chunk, self.length - start)
            yield index, valid, host[:, start:start + valid]


VARIANTS = {
    "ref_like": {"kind": "ref"},
    "seg1_eager": {"kind": "seg", "seg": 1},
    "seg1_graph": {"kind": "seg", "seg": 1, "graph": True},
    "seg2_eager": {"kind": "seg", "seg": 2},
    "seg3_eager": {"kind": "seg", "seg": 3},
    "full_eager": {"kind": "seg", "seg": 0},
    "full_graph": {"kind": "seg", "seg": 0, "graph": True},
    "full_graph_pinned": {"kind": "seg", "seg": 0, "graph": True, "pinned": True},
    "full_graph_bulk": {"kind": "seg", "seg": 0, "graph": True, "bulk": True},
    "full_graph_pinned_bulk": {"kind": "seg", "seg": 0, "graph": True,
                               "pinned": True, "bulk": True},
    "full_branch_streams": {"kind": "branch"},
}


def build(name, repository, config):
    spec = VARIANTS[name]
    if spec["kind"] == "ref":
        return ReferenceLikeEngine(repository, config)
    if spec["kind"] == "branch":
        return BranchStreamEngine(repository, config)
    return SegmentEngine(repository, config, seg_chunks=spec.get("seg", 1),
                         use_graph=spec.get("graph", False),
                         pinned=spec.get("pinned", False),
                         bulk=spec.get("bulk", False))
