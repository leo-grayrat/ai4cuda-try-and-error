"""IR conversion of the two-branch causal feature worker (Phases 1-2).

Two graphs:

``build_model_graph`` - the seven chunk-periodic operators of one chunk of the
reference pipeline, each with its own declared state.  The four causal
convolutions own *private* ``chunk_persistent`` histories (``hist_a0``,
``hist_a1``, ``hist_b0``, ``hist_b1``); ``gate_merge`` owns none.  That makes
the branch split visible to ``analyze_cross_chunk_dependencies`` /
``find_pipeline_stages``: branch A's operators share no state with branch B's,
so they are independent within a chunk and across chunks, while each branch
carries its own cross-chunk chain.

``build_worker_graph`` - the high-level stage scheduling of the reference
worker: ingest one request, branch A, branch B, gate+merge, publish chunks.
Both branches are COMPOSITE stages whose sub-graph is the model graph above,
and the merge->publish edge is a FIXED_RATE streaming edge with one contract
chunk on both sides.

The operators below execute the reference computation verbatim (same modules,
same order, same ``history is None`` first-chunk handling), so the IR executor
can be compared numerically against the reference backend.
"""

import torch
from torch import nn
from torch.nn import functional as F

from flashrt.ir import (IREdge, IRGraph, IROperator, OpType, StateObject,
                        StreamMode, StreamingInfo, StreamingPattern, TensorPort)

HISTORIES = ("hist_a0", "hist_a1", "hist_b0", "hist_b1")
LAYER_OF = {"hist_a0": "a0", "hist_a1": "a1", "hist_b0": "b0", "hist_b1": "b1"}


class CausalConvOp(IROperator):
    """One ``CausalConv1d`` of the reference pipeline (private history)."""

    def __init__(self, layer_name, cache, in_port, out_port):
        super().__init__(
            name=f"conv_{layer_name}",
            op_type=OpType.EXPOSED,
            inputs=[TensorPort(in_port)],
            outputs=[TensorPort(out_port)],
            state_reads=[cache],
            state_writes=[cache],
            stream_mode=StreamMode.STREAMING,
        )
        self.layer_name = layer_name
        self.cache = cache
        self.in_port = in_port
        self.out_port = out_port

    def execute(self, inputs, ctx, state):
        layer = ctx.layers[self.layer_name]
        features = inputs[self.in_port]
        history = state.get(self.cache)
        joined = features if history is None else torch.cat([history, features], dim=-1)
        out = layer(joined)
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        state.set(self.cache,
                  joined[:, :, -layer._time_causal_padding[0]:].clone())
        return {self.out_port: out}


class SiluOp(IROperator):
    def __init__(self, name, in_port, out_port):
        super().__init__(name=name, op_type=OpType.EXPOSED,
                         inputs=[TensorPort(in_port)], outputs=[TensorPort(out_port)])
        self.in_port, self.out_port = in_port, out_port

    def execute(self, inputs, ctx, state):
        return {self.out_port: F.silu(inputs[self.in_port])}


class GateMergeOp(IROperator):
    """``sigmoid(mean_c(x)) * A + (1 - gate) * B + 0.1 * x``."""

    def __init__(self):
        super().__init__(name="gate_merge", op_type=OpType.EXPOSED,
                         inputs=[TensorPort("x"), TensorPort("branch_a"),
                                 TensorPort("branch_b")],
                         outputs=[TensorPort("y")])

    def execute(self, inputs, ctx, state):
        x = inputs["x"]
        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))
        return {"y": gate * inputs["branch_a"] + (1 - gate) * inputs["branch_b"]
                + 0.1 * x}


class BranchStage(IROperator):
    """Structural COMPOSITE stage standing for one branch's two convs."""

    def __init__(self, name, hist_reads, hist_writes):
        super().__init__(name=name, op_type=OpType.COMPOSITE,
                         inputs=[TensorPort("x")], outputs=[TensorPort("branch")],
                         state_reads=hist_reads, state_writes=hist_writes,
                         stream_mode=StreamMode.STREAMING,
                         sub_graph="branch_model")
        self.hist_reads = hist_reads

    def execute(self, inputs, ctx, state):
        # The worker graph is a scheduling model; the executable implementation
        # lives in the model graph (validated separately).
        raise NotImplementedError


class IngestStage(IROperator):
    def __init__(self):
        super().__init__(name="ingest_request", op_type=OpType.EXPOSED,
                         outputs=[TensorPort("x")], state_writes=["request_input"],
                         stream_mode=StreamMode.BATCH)

    def execute(self, inputs, ctx, state):
        raise NotImplementedError


class PublishStage(IROperator):
    def __init__(self):
        super().__init__(name="publish_chunks", op_type=OpType.EXPOSED,
                         inputs=[TensorPort("y")], stream_mode=StreamMode.STREAMING)

    def execute(self, inputs, ctx, state):
        raise NotImplementedError


def build_model_graph(config) -> IRGraph:
    graph = IRGraph(name="branch_features_model")
    for name in HISTORIES:
        graph.add_state(StateObject(name, f"private input history of {LAYER_OF[name]}",
                                    scope="chunk_persistent"))
    graph.add_state(StateObject("request_input", "one request of features",
                                scope="ephemeral"))
    graph.add_state(StateObject("chunk_output", "merged chunk output",
                                scope="ephemeral"))

    ops = [
        CausalConvOp("a0", "hist_a0", "x", "ha_pre"),
        SiluOp("silu_a", "ha_pre", "ha"),
        CausalConvOp("a1", "hist_a1", "ha", "branch_a"),
        CausalConvOp("b0", "hist_b0", "x", "hb_pre"),
        SiluOp("silu_b", "hb_pre", "hb"),
        CausalConvOp("b1", "hist_b1", "hb", "branch_b"),
        GateMergeOp(),
    ]
    for op in ops:
        graph.add_operator(op)
    graph.add_edge(IREdge("conv_a0", "ha_pre", "silu_a", "ha_pre"))
    graph.add_edge(IREdge("silu_a", "ha", "conv_a1", "ha"))
    graph.add_edge(IREdge("conv_b0", "hb_pre", "silu_b", "hb_pre"))
    graph.add_edge(IREdge("silu_b", "hb", "conv_b1", "hb"))
    graph.add_edge(IREdge("conv_a1", "branch_a", "gate_merge", "branch_a"))
    graph.add_edge(IREdge("conv_b1", "branch_b", "gate_merge", "branch_b"))
    graph.external_inputs = [TensorPort("x", (1, config["channels"], config["chunk"]))]
    graph.external_outputs = [TensorPort("y")]
    graph.chunk_ops = [op.name for op in ops]
    return graph


def build_worker_graph(config) -> IRGraph:
    graph = IRGraph(name="branch_features_worker")
    for name in HISTORIES:
        graph.add_state(StateObject(name, f"private history of {LAYER_OF[name]}",
                                    scope="chunk_persistent"))
    graph.add_state(StateObject("request_input", "request features",
                                scope="ephemeral"))
    graph.add_state(StateObject("chunk_output", "published chunk",
                                scope="ephemeral"))
    ops = [IngestStage(),
           BranchStage("branch_a", ["hist_a0", "hist_a1"], ["hist_a0", "hist_a1"]),
           BranchStage("branch_b", ["hist_b0", "hist_b1"], ["hist_b0", "hist_b1"]),
           GateMergeOp(),
           PublishStage()]
    for op in ops:
        graph.add_operator(op)
    graph.add_edge(IREdge("ingest_request", "x", "branch_a", "x"))
    graph.add_edge(IREdge("ingest_request", "x", "branch_b", "x"))
    graph.add_edge(IREdge("ingest_request", "x", "gate_merge", "x"))
    graph.add_edge(IREdge("branch_a", "branch", "gate_merge", "branch_a"))
    graph.add_edge(IREdge("branch_b", "branch", "gate_merge", "branch_b"))
    graph.add_edge(IREdge("gate_merge", "y", "publish_chunks", "y",
                          streaming=StreamingInfo(
                              pattern=StreamingPattern.FIXED_RATE,
                              src_chunk_size=config["chunk"],
                              dst_chunk_size=config["chunk"],
                              description="one merged chunk per published chunk")))
    graph.external_inputs = [TensorPort("x", (1, config["channels"], config["length"]))]
    graph.external_outputs = [TensorPort("y")]
    graph.chunk_ops = [op.name for op in ops]
    graph.sub_graphs["branch_model"] = build_model_graph(config)
    return graph
