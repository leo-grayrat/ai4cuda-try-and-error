"""Subprocess harness: correctness + latency + offered-load sweep.

Drives a backend (the protected reference or one candidate variant) through the
shared adapter, exactly like a frontend would, and records:

  * element-wise correctness against the CPU full-sequence oracle
    (``branch_features.model.full_sequence_oracle``) over six complete
    requests covering session start, continuation, a repeated input without
    reset, an explicit reset, and the tail chunk;
  * latency to first output per request (median / p95);
  * an offered-load sweep (request interval sweep) with the inter-chunk-gap
    distribution and the fraction of gaps above the 20 ms chunk budget.

Every backend subprocess is terminated in a ``finally`` block; a process is
never abandoned.

Usage (from the repo root):
  python flashrt/apps/branch_features/backend/benchmarks/harness.py \
      --variants reference,full_graph_pinned_bulk --mode both
"""

import argparse
import json
import os
import subprocess
import sys
import time
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
APP_REL = os.path.join("flashrt", "apps", "branch_features")
REPO = os.path.abspath(os.path.join(BACKEND, "..", "..", "..", ".."))
RESULTS = os.path.join(BACKEND, "benchmarks", "results")
WORKER = os.path.join(BACKEND, "worker.py")
REFERENCE = os.path.join(REPO, APP_REL, "reference.py")

BUDGET_MS = 20.0
# Six complete requests: start, continuation, repeat-without-reset, reset,
# continuation, continuation.  The final chunk of every request is the tail
# chunk (length 1043 with chunk 127 -> last chunk valid = 27).
SCENARIO = ["r1", "r2", "r2", "reset", "r4", "r5", "r6"]


def make_config(prefix, device):
    return {
        "channels": 16,
        "hidden": 32,
        "length": 1043,
        "chunk": 127,
        "weight_seed": 1234,
        "device": device,
        "prefix": prefix,
    }


def make_inputs(cfg, seed=7):
    import numpy as np

    rng = np.random.default_rng(seed)
    shape = (cfg["channels"], cfg["length"])
    inputs = {name: rng.standard_normal(shape).astype(np.float32)
              for name in ("r1", "r2", "r4", "r5", "r6")}
    inputs["r2_rep"] = inputs["r2"].copy()
    return inputs


def scenario_requests(cfg, inputs):
    """[(name, features)] plus the reset markers, and (segments, slices)."""
    seq = []
    for tag in SCENARIO:
        if tag == "reset":
            seq.append(("reset", None))
            continue
        key = "r2_rep" if (tag == "r2" and any(t == "r2" for t, _ in seq)) else tag
        seq.append((key, inputs[key]))
    # oracle: per reset-delimited stream, the sequence is causal, so the
    # oracle is the full-sequence oracle over the concatenation.
    segments, current = [], []
    for key, feats in seq:
        if key == "reset":
            if current:
                segments.append(current)
            current = []
        else:
            current.append((key, feats))
    if current:
        segments.append(current)
    return seq, segments


def oracle_segments(cfg, segments):
    import numpy as np

    from branch_features.model import full_sequence_oracle

    out = {}
    for seg in segments:
        joined = np.concatenate([f for _, f in seg], axis=1)
        pred = full_sequence_oracle(REPO, cfg, joined)
        pos = 0
        for key, feats in seg:
            width = feats.shape[1]
            out.setdefault(key, []).append(pred[:, pos:pos + width])
            pos += width
    return out


def stat(values, q):
    import numpy as np

    if not values:
        return float("nan")
    return float(np.percentile(np.asarray(values, dtype=np.float64), q))


class Backend:
    """Launch one backend subprocess and attach the adapter."""

    def __init__(self, variant, cfg, env_extra=None, poll="spin"):
        self.variant = variant
        self.cfg = cfg
        self.poll = poll
        self.env_extra = env_extra or {}
        self.proc = None
        self.adapter = None

    def __enter__(self):
        env = os.environ.copy()
        for var in ("RANK", "LOCAL_RANK", "WORLD_SIZE", "MASTER_ADDR",
                    "MASTER_PORT", "TORCH_NCCL_ASYNC_ERROR_HANDLING"):
            env.pop(var, None)
        env["BF_POLL"] = self.poll
        env.update(self.env_extra)
        if self.variant == "reference":
            cmd = [sys.executable, "-u", REFERENCE,
                   "--repository", REPO, "--config", self.cfg["_path"]]
        else:
            env["BF_VARIANT"] = self.variant
            cmd = [sys.executable, "-u", WORKER,
                   "--repository", REPO, "--config", self.cfg["_path"]]
        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["preexec_fn"] = os.setsid
        self.proc = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True,
                                     **kwargs)
        line = self.proc.stdout.readline()
        if "ready" not in line:
            err = self.proc.stderr.read()
            raise RuntimeError(f"{self.variant}: backend failed to start: "
                               f"{line!r} {err[-2000:]}")
        from branch_features.adapter import FeatureAdapter

        self.adapter = FeatureAdapter(self.cfg)
        self.adapter.start()
        return self

    def __exit__(self, *exc):
        ok = True
        try:
            if self.adapter is not None:
                try:
                    self.adapter.terminate()
                    self.proc.wait(timeout=10)
                except Exception:
                    ok = False
                try:
                    self.adapter.close()
                except Exception:
                    pass
        finally:
            if self.proc.poll() is None:
                self.proc.kill()
                self.proc.wait(timeout=10)
            # never leak processes
            if os.name != "nt" and self.proc.poll() is None:
                os.killpg(os.getpgid(self.proc.pid), 9)
        return False


def drain(adapter, budget=30.0):
    """Receive every remaining chunk of the pending request."""
    chunks = []
    deadline = time.monotonic() + budget
    while adapter.pending is not None:
        if time.monotonic() > deadline:
            raise TimeoutError("drain timed out")
        data, ts = adapter.receive(timeout_s=budget)
        chunks.append((data, ts))
    return chunks


def run_correctness(backend, cfg, inputs):
    import numpy as np

    adapter = backend.adapter
    seq, segments = scenario_requests(cfg, inputs)
    expected = oracle_segments(cfg, segments)
    got = {}
    per_request = []
    for key, feats in seq:
        if key == "reset":
            adapter.reset()
            continue
        rid, pub = adapter.submit(feats)
        chunks = drain(adapter)
        got.setdefault(key, []).append(np.concatenate([c for c, _ in chunks], axis=1))
        per_request.append(((chunks[0][1] - pub) / 1e6,
                            (chunks[-1][1] - pub) / 1e6, len(chunks)))

    max_diff = 0.0
    where = None
    for key, refs in expected.items():
        for i, ref in enumerate(refs):
            cand = got[key][i]
            if cand.shape != ref.shape:
                raise AssertionError(f"{key}[{i}] shape {cand.shape} != {ref.shape}")
            diff = float(np.max(np.abs(cand - ref))) if ref.size else 0.0
            if diff > max_diff:
                max_diff = diff
                where = f"{key}[{i}]"
    n_chunks = int(np.ceil(cfg["length"] / cfg["chunk"]))
    for latency_first, latency_last, count in per_request:
        assert count == n_chunks, f"expected {n_chunks} chunks, saw {count}"
    tol = 2e-5
    verdict = "PASS" if max_diff <= tol else "FAIL"
    return {"verdict": verdict, "max_abs_diff": max_diff, "at": where,
            "tolerance": tol, "n_requests": len(per_request),
            "per_request_first_ms": [p[0] for p in per_request],
            "per_request_last_ms": [p[1] for p in per_request]}


def run_latency(backend, cfg, inputs, n=10):
    adapter = backend.adapter
    order = ["r1", "r2", "r4", "r5", "r6"]
    first_ms, drain_ms = [], []
    for i in range(n):
        feats = inputs[order[i % len(order)]]
        rid, pub = adapter.submit(feats)
        chunks = drain(adapter)
        first_ms.append((chunks[0][1] - pub) / 1e6)
        drain_ms.append((chunks[-1][1] - pub) / 1e6)
        time.sleep(0.002)
    return {"first_ms_median": stat(first_ms, 50), "first_ms_p95": stat(first_ms, 95),
            "drain_ms_median": stat(drain_ms, 50), "drain_ms_p95": stat(drain_ms, 95),
            "samples": n}


def run_sweep(backend, cfg, inputs, intervals_ms=(0.0, 1.0, 2.0, 5.0, 10.0, 20.0),
              n=12):
    import numpy as np

    adapter = backend.adapter
    names = ["r1", "r2", "r4", "r5", "r6"]
    entries = []
    for interval in intervals_ms:
        t0 = time.perf_counter()
        lat_first, lat_last, gaps, lags = [], [], [], []
        prev_ts = None
        for i in range(n):
            target = t0 + i * interval / 1000.0
            now = time.perf_counter()
            if now < target:
                time.sleep(target - now)
            offered = time.perf_counter()
            submit_t = time.perf_counter()
            rid, pub = adapter.submit(inputs[names[i % len(names)]])
            lags.append((submit_t - offered) * 1000.0)
            chunks = drain(adapter)
            for _, ts in chunks:
                if prev_ts is not None:
                    gaps.append((ts - prev_ts) / 1e6)
                prev_ts = ts
            lat_first.append((chunks[0][1] - pub) / 1e6)
            lat_last.append((chunks[-1][1] - pub) / 1e6)
        wall = time.perf_counter() - t0
        achieved = n / wall
        offered_rate = (1.0 / (interval / 1000.0)) if interval > 0 else float("inf")
        gaps_a = np.asarray(gaps, dtype=np.float64)
        entries.append({
            "interval_ms": interval,
            "offered_req_per_s": offered_rate if interval > 0 else None,
            "achieved_req_per_s": achieved,
            "achieved_chunk_per_s": achieved * int(np.ceil(cfg["length"] / cfg["chunk"])),
            "submit_lag_ms_median": stat(lags, 50),
            "gap_ms_median": stat(gaps, 50),
            "gap_ms_p95": stat(gaps, 95),
            "gap_ms_max": float(gaps_a.max()) if gaps_a.size else float("nan"),
            "gap_over_budget_frac": float((gaps_a > BUDGET_MS).mean()) if gaps_a.size else 0.0,
            "first_ms_median": stat(lat_first, 50),
            "first_ms_p95": stat(lat_first, 95),
            "last_ms_median": stat(lat_last, 50),
            "last_ms_p95": stat(lat_last, 95),
            "n_requests": n,
        })
    sustainable = 0.0
    for e in entries:
        if e["offered_req_per_s"] is None:
            continue
        if e["achieved_req_per_s"] >= 0.95 * e["offered_req_per_s"] \
                and e["gap_over_budget_frac"] == 0.0:
            sustainable = max(sustainable, e["offered_req_per_s"])
    sat = entries[0]
    return {"entries": entries,
            "sustainable_offered_req_per_s": sustainable,
            "saturating_req_per_s": sat["achieved_req_per_s"],
            "saturating_chunk_per_s": sat["achieved_chunk_per_s"],
            "saturating_gap_ms_median": sat["gap_ms_median"],
            "saturating_gap_ms_p95": sat["gap_ms_p95"],
            "saturating_gap_over_budget_frac": sat["gap_over_budget_frac"]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variants", default="reference")
    parser.add_argument("--mode", default="both", choices=["correct", "bench", "both"])
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--sweep-n", type=int, default=12)
    parser.add_argument("--tag", default="")
    args = parser.parse_args()

    os.makedirs(RESULTS, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(RESULTS, f"harness_{stamp}{('_' + args.tag) if args.tag else ''}.log")
    log_lines = []

    def log(msg):
        print(msg, flush=True)
        log_lines.append(msg)

    inputs = make_inputs(None)
    summary = {}
    for spec in args.variants.split(","):
        spec = spec.strip()
        if not spec:
            continue
        name, _, poll = spec.partition("@")
        poll = poll or "spin"
        label = name if poll == "spin" else f"{name}@{poll}"
        prefix = f"bf_{name}_{poll}_{os.getpid()}_{uuid.uuid4().hex[:6]}"
        cfg = make_config(prefix, args.device)
        cfg["_path"] = os.path.join(RESULTS, f"config_{prefix}.json")
        with open(cfg["_path"], "w", encoding="utf-8") as handle:
            json.dump({k: v for k, v in cfg.items() if not k.startswith("_")}, handle)
        record = {"variant": label, "device": args.device, "poll": poll,
                  "config": {k: v for k, v in cfg.items() if not k.startswith("_")},
                  "started": time.strftime("%Y-%m-%dT%H:%M:%S")}
        t0 = time.perf_counter()
        try:
            with Backend(name, cfg, poll=poll) as backend:
                record["startup_s"] = time.perf_counter() - t0
                if args.mode in ("correct", "both"):
                    record["correctness"] = run_correctness(backend, cfg, inputs)
                    log(f"[{label}] correctness {record['correctness']['verdict']} "
                        f"max_abs_diff={record['correctness']['max_abs_diff']:.3e} "
                        f"at={record['correctness']['at']}")
                if args.mode in ("bench", "both"):
                    record["latency"] = run_latency(backend, cfg, inputs)
                    log(f"[{label}] first-out median="
                        f"{record['latency']['first_ms_median']:.3f}ms p95="
                        f"{record['latency']['first_ms_p95']:.3f}ms drain median="
                        f"{record['latency']['drain_ms_median']:.3f}ms")
                    record["sweep"] = run_sweep(backend, cfg, inputs, n=args.sweep_n)
                    sw = record["sweep"]
                    for e in sw["entries"]:
                        off = e["offered_req_per_s"]
                        log(f"[{label}]   offered={('inf' if off is None else f'{off:.1f}')}"
                            f"/s achieved={e['achieved_req_per_s']:.1f}/s "
                            f"gap med={e['gap_ms_median']:.3f} p95={e['gap_ms_p95']:.3f} "
                            f"max={e['gap_ms_max']:.3f} over20={e['gap_over_budget_frac']:.3f} "
                            f"first med={e['first_ms_median']:.3f}")
                    log(f"[{label}] sustainable={sw['sustainable_offered_req_per_s']:.1f}"
                        f" req/s saturating={sw['saturating_req_per_s']:.1f} req/s "
                        f"({sw['saturating_chunk_per_s']:.1f} chunks/s) "
                        f"gap p95={sw['saturating_gap_ms_p95']:.3f}ms over20="
                        f"{sw['saturating_gap_over_budget_frac']:.3f}")
        except Exception as exc:
            record["error"] = f"{type(exc).__name__}: {exc}"
            log(f"[{label}] ERROR {record['error']}")
        finally:
            try:
                os.remove(cfg["_path"])
            except OSError:
                pass
        out = os.path.join(RESULTS, f"{name}{('_' + poll) if poll != 'spin' else ''}"
                                     f"_{stamp}.json")
        record["log"] = os.path.basename(log_path)
        with open(out, "w", encoding="utf-8") as handle:
            json.dump(record, handle, indent=1)
        record["json"] = out
        summary[label] = record

    with open(log_path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(log_lines) + "\n")
    print("RESULTS " + json.dumps({k: {"json": v.get("json"),
                                       "verdict": v.get("correctness", {}).get("verdict"),
                                       "error": v.get("error"),
                                       "first_ms_median": v.get("latency", {}).get("first_ms_median"),
                                       "saturating_req_per_s": v.get("sweep", {}).get("saturating_req_per_s")}
                                  for k, v in summary.items()}), flush=True)


if __name__ == "__main__":
    main()
