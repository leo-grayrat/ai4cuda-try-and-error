"""Driver for the branch_features measurement harness (correctness + sweep).

``harness.py`` holds the measurement primitives; this is the entry point used
for every recorded run.  ``workspace.execute`` takes no arguments, so the
variant list is read from ``benchmarks/plan.txt`` when present (one variant per
line, ``#`` comments allowed) and otherwise defaults to every registered
variant plus the protected reference.  Results are flushed to disk after every
variant, so a partial run still leaves valid per-variant JSON evidence.
"""

import json
import os
import sys
import time
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import harness as H  # noqa: E402

PLAN = os.path.join(HERE, "plan.txt")
ALL = ["reference", "ref_like", "ref_like@sleep", "seg1_eager", "seg1_graph",
       "seg2_eager", "seg3_eager", "full_eager", "full_graph",
       "full_graph_pinned", "full_graph_bulk", "full_graph_pinned_bulk",
       "full_branch_streams"]
MODE = "both"
SWEEP_N = 6
TAG = ""


def read_plan():
    if os.path.exists(PLAN):
        names = []
        with open(PLAN, "r", encoding="utf-8") as handle:
            for line in handle:
                line = line.split("#", 1)[0].strip()
                if line:
                    names.append(line)
        if names:
            return names
    return ALL


def main():
    variants, mode, sweep_n, tag = read_plan(), MODE, SWEEP_N, TAG
    os.makedirs(H.RESULTS, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    suffix = ("_" + tag) if tag else ""
    log_path = os.path.join(H.RESULTS, f"harness_{stamp}{suffix}.log")
    log_lines = []

    def log(msg):
        print(msg, flush=True)
        log_lines.append(msg)

    inputs = H.make_inputs(H.make_config("tmp", "cuda"))
    summary = {}
    for spec in variants:
        name, _, poll = spec.partition("@")
        poll = poll or "spin"
        label = name if poll == "spin" else f"{name}@{poll}"
        prefix = f"bf_{name}_{poll}_{os.getpid()}_{uuid.uuid4().hex[:6]}"
        cfg = H.make_config(prefix, "cuda")
        cfg_path = os.path.join(H.RESULTS, f"config_{prefix}.json")
        with open(cfg_path, "w", encoding="utf-8") as handle:
            json.dump(dict(cfg), handle)
        cfg["_path"] = cfg_path
        record = {"variant": label, "name": name, "device": "cuda",
                  "poll": poll, "config": {k: v for k, v in cfg.items()
                                           if not k.startswith("_")},
                  "started": time.strftime("%Y-%m-%dT%H:%M:%S")}
        t0 = time.perf_counter()
        try:
            with H.Backend(name, cfg, poll=poll) as backend:
                record["startup_s"] = round(time.perf_counter() - t0, 3)
                if mode in ("correct", "both"):
                    c = H.run_correctness(backend, cfg, inputs)
                    record["correctness"] = c
                    log(f"[{label}] correctness {c['verdict']} "
                        f"max_abs_diff={c['max_abs_diff']:.3e} at={c['at']} "
                        f"tol={c['tolerance']}")
                if mode in ("bench", "both"):
                    lat = H.run_latency(backend, cfg, inputs)
                    record["latency"] = lat
                    log(f"[{label}] first-out median={lat['first_ms_median']:.3f}ms "
                        f"p95={lat['first_ms_p95']:.3f}ms drain median="
                        f"{lat['drain_ms_median']:.3f}ms")
                    sw = H.run_sweep(backend, cfg, inputs, n=sweep_n)
                    record["sweep"] = sw
                    for e in sw["entries"]:
                        off = e["offered_req_per_s"]
                        off_s = "inf" if off is None else f"{off:.1f}"
                        log(f"[{label}]   offered={off_s}/s "
                            f"achieved={e['achieved_req_per_s']:.1f}/s "
                            f"gap med={e['gap_ms_median']:.3f} "
                            f"p95={e['gap_ms_p95']:.3f} max={e['gap_ms_max']:.3f} "
                            f"over20={e['gap_over_budget_frac']:.3f} "
                            f"first med={e['first_ms_median']:.3f}")
                    log(f"[{label}] sustainable={sw['sustainable_offered_req_per_s']:.1f} "
                        f"req/s saturating={sw['saturating_req_per_s']:.1f} req/s "
                        f"({sw['saturating_chunk_per_s']:.1f} chunks/s) gap p95="
                        f"{sw['saturating_gap_ms_p95']:.3f}ms over20="
                        f"{sw['saturating_gap_over_budget_frac']:.3f}")
        except Exception as exc:
            record["error"] = f"{type(exc).__name__}: {exc}"
            log(f"[{label}] ERROR {record['error']}")
        finally:
            try:
                os.remove(cfg_path)
            except OSError:
                pass
        out = os.path.join(H.RESULTS,
                           f"{name}{('_' + poll) if poll != 'spin' else ''}"
                           f"_{stamp}{suffix}.json")
        record["log"] = os.path.basename(log_path)
        with open(out, "w", encoding="utf-8") as handle:
            json.dump(record, handle, indent=1)
        record["json"] = out
        summary[label] = record
        log(f"[{label}] json={os.path.basename(out)}")
        with open(log_path, "w", encoding="utf-8") as handle:
            handle.write("\n".join(log_lines) + "\n")

    with open(log_path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(log_lines) + "\n")
    print("RESULTS " + json.dumps({
        k: {"json": os.path.basename(v.get("json", "")),
            "verdict": v.get("correctness", {}).get("verdict"),
            "error": v.get("error"),
            "first_ms_median": v.get("latency", {}).get("first_ms_median"),
            "drain_ms_median": v.get("latency", {}).get("drain_ms_median"),
            "saturating_req_per_s": v.get("sweep", {}).get("saturating_req_per_s"),
            "sustainable_req_per_s": v.get("sweep", {}).get("sustainable_offered_req_per_s")}
        for k, v in summary.items()}), flush=True)


if __name__ == "__main__":
    main()
