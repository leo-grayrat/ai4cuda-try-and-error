# branch_features backend (cuda, single RTX 5060)

Optimized streaming backend for the two-branch causal feature task.  It honors
the unchanged adapter contract (`branch_features.adapter`, which re-exports
`causal_features.adapter`): the same shared-memory buffers, control opcodes
(1 start, 2 terminate, 3 reset), input frame `(channels, length)` and output
frames `(channels, chunk)` with metadata `[request_id, chunk_index, valid]`.

## Launch

```
python flashrt/apps/branch_features/backend/worker.py \
    --repository <repo-root> --config <config.json>
```

`config.json` is the same object the reference worker takes: `channels`,
`hidden`, `length`, `chunk`, `weight_seed`, `device`, `prefix`.  The frontend
(or any adapter client) then attaches to `prefix` exactly as with the
reference backend.  Weights are built by the protected
`branch_features.model.build_layers` with the configured seed; nothing is
downloaded.

Variant selection (default `full_graph_pinned_bulk`, the recommended one):

```
BF_VARIANT=full_graph|full_graph_bulk|full_graph_pinned|seg1_graph|... \
BF_POLL=sleep   # optional: emulate the reference's 0.2 ms polling
```

Registered variants are listed in `pipelines.py::VARIANTS`.

## What it does

1. **Branch fusion** — `a0`/`b0` consume the same input stream and
   `a1`/`b1` consume disjoint hidden groups, so the shorter kernels are
   left-zero-padded to kernel 5 and the pairs become one 2H-channel
   convolution plus one grouped convolution.  Same arithmetic, half the
   launches.
2. **Request-level scheduling** — a chunk boundary is not a dependency
   boundary: the adapter publishes all `length` samples before any output is
   consumed, so a request is computed in one segment and only the four
   convolution histories are carried between requests (and cleared on reset).
   `CausalConv1d` left-pads with `replicate`, which the engine reproduces for
   the first request of a session.
3. **CUDA graph** — the segment compute over static buffers is captured once
   and replayed; only the input copy and the history update run per request.
4. **Bulk publish** — all `ceil(length/chunk)` frames and all metadata records
   of a request are pushed with two shared-memory writes.
5. **Spin polling** — the reference's 0.2 ms `time.sleep` in the control loop
   costs ~0.5 ms per poll on Windows; the default spin loop removes it.

Expected numbers on this GPU (see `notes/experiment_log.md`): first output
0.535 ms median / 0.985 ms p95 (reference 1.572 / 1.872 ms), 1471 req/s
saturating (reference 122 req/s), inter-chunk gap p95 0.54 ms, no gap above
the 20 ms chunk budget.

## Correctness / measurement

```
python flashrt/apps/branch_features/backend/tests/test_ir_cpu.py     # IR vs reference, PASS
python flashrt/apps/branch_features/backend/benchmarks/run.py        # all variants, needs benchmarks/plan.txt
```

`benchmarks/run.py` reads `benchmarks/plan.txt` (one variant per line) and
writes one JSON plus a console log per variant under `benchmarks/results/`.
Every candidate run compares against the CPU full-sequence oracle over six
complete requests (start, continuation, repeated input without reset, reset,
two continuations, tail chunk) and reports latency-to-first-output and an
offered-load sweep with the inter-chunk-gap distribution.

## Layout

- `worker.py` — standalone entry point and adapter control loop.
- `pipelines.py` — engines: `ReferenceLikeEngine`, `SegmentEngine` (fusion,
  segment size, CUDA graph, pinned staging, bulk publish), `BranchStreamEngine`
  (two CUDA streams for the two independent branches) + variant registry.
- `ir/branch_ir.py` — worker-level and model-level IR graphs (validated).
- `tests/test_ir.py`, `tests/test_ir_cpu.py` — Phase-2 IR validation.
- `benchmarks/harness.py`, `benchmarks/run.py`, `benchmarks/results/`.
- `notes/experiment_log.md`, `notes/ir_analysis.md`.
