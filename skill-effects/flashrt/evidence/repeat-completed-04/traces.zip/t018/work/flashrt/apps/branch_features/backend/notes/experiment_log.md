# Experiment log — branch_features (two-branch causal feature task)

Hardware: 1x RTX 5060 Laptop 8 GB, Windows, torch 2.11.0+cu128, one backend
process at a time.  Correctness oracle: the protected reference
(`branch_features.model`), both its chunk-sequential `ReferencePipeline` and
the CPU `full_sequence_oracle`.  Every number below comes from a real
subprocess launch driven through `branch_features.adapter` by
`benchmarks/run.py` (primitives in `benchmarks/harness.py`); the per-run JSON
is named in each row.

## IR conversion (Phase 1)

- Worker graph (`ir/branch_ir.py::build_worker_graph`): 5 operators, 6 edges.
  `ingest_request` (EXPOSED, BATCH) -> `branch_a` (COMPOSITE, STREAMING,
  sub-graph `branch_model`, writes `hist_a0`/`hist_a1`) -> `branch_b`
  (COMPOSITE, STREAMING, writes `hist_b0`/`hist_b1`) -> `gate_merge`
  (EXPOSED) -> `publish_chunks` (EXPOSED, STREAMING).  No black-box stages:
  the whole pipeline is exposed.  One streaming edge
  `gate_merge.y -> publish_chunks.y`, `FIXED_RATE`, src = dst = 127 samples
  (ratio 1.0, one merged chunk per published chunk).
- Model graph (`build_model_graph`): 7 operators, 6 data edges, 4
  `chunk_persistent` state objects (`hist_a0`, `hist_a1`, `hist_b0`,
  `hist_b1`: the four private causal-convolution histories) and 2 `ephemeral`
  ones (`request_input`, `chunk_output`).  Chunk-periodic operators:
  `conv_a0`, `silu_a`, `conv_a1`, `conv_b0`, `silu_b`, `conv_b1`,
  `gate_merge`.
- **IR validation: PASS** — harness `tests/test_ir.py`, executed through
  `tests/test_ir_cpu.py` with all tensors on CPU (the operators reuse the
  reference layer modules verbatim, so the conversion is device-agnostic).
  - fixture: `tests/test_ir.py::scenario()` — six complete requests
    (session start / continuation / repeated input without reset / reset /
    two continuations), seed 7, C=16, H=32, T=1043, chunk=127, tail chunk 27.
  - max|IR − ReferencePipeline| = **0.000e+00** (tolerance 0: same modules,
    same operator order — exact equality is the right bar).
  - max|IR − full_sequence_oracle| = **2.384e-07** (tolerance 2e-5;
    justification: float32 convolution over a different tensor shape and
    algorithm reorders the 80-term dot products; observed drift 2.4e-7 is 80x
    below tolerance).
- Analysis (`notes/ir_analysis.md`, produced by `summarize_graph` with
  measured per-operator latencies — the generated file is the authoritative
  record):
  - stage partition by shared `chunk_persistent` state: stage A =
    {conv_a0, silu_a, conv_a1}, stage B = {conv_b0, silu_b, conv_b1},
    stage C = {gate_merge};
  - A and B share no state: independent within a chunk and across chunks,
    each branch carries its own cross-chunk chain; `gate_merge` is the only
    cross-branch synchronisation point;
  - critical path per chunk: conv_a0 -> silu_a -> conv_a1 -> gate_merge
    (branch B is an equally long, fully independent second chain);
  - the measured op latencies are tens of microseconds, i.e. the reference's
    cost is per-chunk fixed overhead (launches, allocations, one host sync per
    chunk), not arithmetic.  The deployment variants attack exactly that.

## Variant queue

| # | name | hypothesis | IR basis | predicted impact | status |
|---|------|-----------|----------|------------------|--------|
| 1 | `ref_like` | reference compute, spin-poll instead of 0.2 ms sleeps | control-plane stage outside the compute graph | latency; small | measured |
| 2 | `ref_like@sleep` | control: reference polling to attribute (1) | same | control | measured |
| 3 | `seg1_eager` | fuse a0+b0 and a1+b1, static buffers, per chunk | a0/b0 read the same input stream; a1/b1 read disjoint hidden groups | both; ~1.3x | measured |
| 4 | `seg1_graph` | + CUDA graph per chunk | same fusion; only histories cross chunks | latency; ~2x | measured |
| 5 | `seg2_eager` | 2 chunks per compute call | a chunk boundary is not a dependency boundary | throughput; ~2x | measured |
| 6 | `seg3_eager` | 3 chunks per compute call | same | throughput; ~3x | measured |
| 7 | `full_eager` | whole request in one compute call | all `length` samples are published before any output is consumed | throughput; ~5x | measured |
| 8 | `full_graph` | full request + CUDA graph | same | both; ~10x | measured |
| 9 | `full_graph_pinned` | + pinned host staging for D2H | data-movement stage | latency; small | measured |
| 10 | `full_graph_bulk` | publish 9 frames + 9 metadata in two shm writes | publish stage | throughput; small | measured |
| 11 | `full_graph_pinned_bulk` | combined 8+9+10 | both | both | **measured / recommended** |
| 12 | `full_branch_streams` | branch A and B on two CUDA streams | model graph: stages A and B share no state | latency; uncertain | measured |

Ordering rationale (IR-ranked expected impact): control-plane lever, then
compute fusion, then the chunk-granularity/scheduling axis (1 -> 2 -> 3 -> 9
chunks per compute call), then graph capture and data movement, then the
branch-parallel axis; the combination closes the queue.

Changelog:
- 2026-10-20: initial queue committed from the IR analysis.
- 2026-10-20: measured 1-12, all PASS.  Fusion + graph capture +
  full-request scheduling dominate; pinned staging is neutral; branch streams
  help eager mode only.  No follow-up row added: both ranked axes
  (latency-to-first-output, sustainable rate) are won by the same variant
  family, so the combination obligation is discharged by
  `full_graph_pinned_bulk`.

## Deployment iterations

Common setup: `cudnn.benchmark=False`, TF32 off, 20 ms chunk budget, 9 chunks
per request (tail chunk valid = 27), sweep intervals {0, 1, 2, 5, 10, 20} ms x
6 requests, latency over 10 requests.  **Correctness for every variant:
PASS**, max abs diff **2.384e-07** (tolerance 2e-5) over the six-request
scenario including continuation, repeated input, reset and the tail chunk
(`correctness` field of each JSON).

| variant | first-out med ms | drain med ms | saturating req/s | saturating chunks/s | gap med/p95 ms | sustainable offered req/s | benchmark json |
|---|---|---|---|---|---|---|---|
| `reference` (anchor) | 1.572 | 7.834 | 122.3 | 1100.7 | 1.053 / 1.568 | 100 | `reference_20261020_014822.json` |
| `reference` (repeat) | 1.603 | 10.210 | 92.6 | 833.0 | 1.086 / 1.659 | 50 | `reference_20261020_014857.json` |
| `ref_like` | 1.100 | 7.061 | 144.2 | 1298 | 1.081 / 1.659 | 100 | `ref_like_20261020_014931.json` |
| `ref_like@sleep` | 1.585 | 7.170 | 86.7 | 780 | 1.081 / 1.597 | 50 | `ref_like_sleep_20261020_014931.json` |
| `seg1_eager` | 1.091 | 6.415 | 151.3 | 1361.9 | 0.552 / 1.135 | 100 | `seg1_eager_20261020_014931.json` |
| `seg1_graph` | 0.569 | 4.299 | 254.5 | 2290.8 | 0.547 / 0.686 | 200 | `seg1_graph_20261020_015035.json` |
| `seg2_eager` | 1.051 | 3.163 | 335.9 | 3023.2 | 0.503 / 1.065 | 200 | `seg2_eager_20261020_015035.json` |
| `seg3_eager` | 1.043 | 2.128 | 442.7 | 3984.2 | 0.007 / 1.076 | 200 | `seg3_eager_20261020_015035.json` |
| `full_eager` | 1.088 | 1.150 | 852.2 | 7670.1 | 0.007 / 1.098 | 500 | `full_eager_20261020_014931.json` |
| `full_graph` | 0.552 | 0.612 | 1613.5 | 14521.6 | 0.007 / 0.551 | 1000 | `full_graph_20261020_015035.json` |
| `full_graph_pinned` | 0.532 | 0.580 | 1326.4 | 11937.7 | 0.007 / 0.551 | 500 | `full_graph_pinned_20261020_015035.json` |
| `full_graph_bulk` | 0.536 | 0.588 | 1541.8 | 13876.4 | 0.007 / 0.564 | 1000 | `full_graph_bulk_20261020_015035.json` |
| `full_graph_pinned_bulk` | 0.535 | 0.590 | 1471.5 | 13243.4 | 0.005 / 0.542 | 1000 | `full_graph_pinned_bulk_20261020_015013.json` |
| `full_branch_streams` | 1.053 | 1.093 | 862.2 | 7759.8 | 0.004 / 1.015 | 500 | `full_branch_streams_20261020_015013.json` |

JSONs live under `benchmarks/results/`; each batch console log is
`benchmarks/results/harness_<stamp>.log` with the same stamp.

### Findings per lever

- **Polling (`ref_like` vs `ref_like@sleep`)**: identical compute, only the
  worker loop differs — 1.100 vs 1.585 ms first-out, 144.2 vs 86.7 req/s.  On
  Windows the 0.2 ms sleep is really ~0.5 ms, costing ~30% of the reference's
  throughput.
- **Fusion (`seg1_eager` vs `ref_like`)**: 151.3 vs 144.2 req/s.  Real but
  small: launch overhead still dominates.
- **Graph capture (`seg1_graph`)**: 0.569 ms, 254.5 req/s (+76% over
  `seg1_eager`).
- **Chunk granularity (`seg2/seg3/full` eager)**: 335.9 / 442.7 / 852.2 req/s
  with drain 3.16 / 2.13 / 1.15 ms — proportional to the number of compute
  calls, confirming the chunk boundary is pure overhead here.
- **`full_graph`**: 0.552 ms, 1613.5 req/s — the levers stack.
- **Pinned staging (`full_graph_pinned`)**: 0.532 ms first-out (-4%) but
  1326.4 req/s (-18%): the extra host copy cannot be hidden, since the
  adapter allows only one request in flight.  Honest negative result.
- **Bulk publish (`full_graph_bulk`)**: 1541.8 req/s with 2 shm writes per
  request instead of 18; latency within noise of `full_graph`.
- **Recommended `full_graph_pinned_bulk`**: best first-output latency
  (0.535 ms, p95 0.985 ms), 1471.5 req/s and the fewest shm writes.  The four
  graph-based full-request variants are within the +-15% run-to-run spread
  (the reference anchor alone measured 92.6 and 122.3 req/s on two identical
  runs), so the selection is on latency and write count, not on a 5% rate
  difference.
- **`full_branch_streams`**: two streams for the two independent branches give
  862.2 req/s in eager mode (vs 852.2 for `full_eager`) — branch kernels are
  too small for stream concurrency to matter, and graph capture subsumes it.

### Recommended vs reference anchor

- latency-to-first-output: 1.572 -> 0.535 ms median (**2.9x**), p95 1.872 ->
  0.985 ms.
- sustainable offered request rate: 100 -> 1000 req/s (10x); saturating
  throughput 122.3 -> 1471.5 req/s (12x), 1100.7 -> 13243.4 chunks/s.
- smoothness: inter-chunk gap p95 1.568 -> 0.542 ms; fraction of gaps above
  the 20 ms budget 0.000 in both at saturation.

### Measurement conventions and caveats

- The `gap_*` fields count the gap between *any* two consecutive chunk
  arrivals, including one request boundary per request.  At offered intervals
  of 5-20 ms that boundary gap equals the idle interval by construction
  (hence `gap_over_budget_frac` 0.038-0.075 at the 20 ms offered interval for
  the fastest variants).  The quoted smoothness number is the saturating run
  (offered interval 0), which contains no idle time.
- The candidate publishes a request's chunks as soon as the request's compute
  finishes (bulk for the recommended variant), so first-output latency equals
  full-request compute latency.  The measured 0.53 ms is near the consumer
  side's own polling floor (`FeatureAdapter.receive` sleeps 0.2 ms between
  polls), so further backend-side gains would be masked by the harness.
- Weights are the protected `build_layers(weight_seed)` parameters, reused
  unmodified; fusion only re-packs them (zero-padded shorter kernels, grouped
  conv), and all variants are validated against the CPU full-sequence oracle
  to 2.4e-7.
- Multi-GPU requirements do not apply (single assigned GPU).  No queue entry is
  left `planned`/`in_progress`; there are no `blocked` or `discarded` entries,
  so no adversarial-self-framing paragraph applies.
