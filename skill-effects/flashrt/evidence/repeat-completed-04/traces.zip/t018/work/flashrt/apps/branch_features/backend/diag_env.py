"""Diagnostic: resolve repository/config plumbing and device for this task."""
import importlib
import json
import os
import sys

print('cwd', os.getcwd())
print('argv0 dir', os.path.dirname(os.path.abspath(sys.argv[0])))
root = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
print('arg root', root)
print('exists flashrt/layers/audio.py at root:', os.path.exists(os.path.join(root, 'flashrt/layers/audio.py')))
print('root listing sample', sorted(os.listdir(root))[:20])
print('cwd listing', sorted(os.listdir(os.getcwd()))[:20])
sys.path.insert(0, root)
for mod in ('branch_features', 'branch_features.adapter', 'branch_features.model',
            'causal_features.adapter', 'flashrt.ir', 'flashrt.apps.branch_features'):
    try:
        m = importlib.import_module(mod)
        print('import ok', mod, getattr(m, '__file__', None))
    except Exception as exc:
        print('import FAIL', mod, type(exc).__name__, exc)
try:
    import flashrt.paths as paths
    print('repo_root', paths.repo_root())
    print('app_dir', paths.app_dir('branch_features'))
except Exception as exc:
    print('paths FAIL', type(exc).__name__, exc)
import torch
print('torch', torch.__version__, 'cuda avail', torch.cuda.is_available(),
      'devs', torch.cuda.device_count())
if torch.cuda.is_available():
    print('dev0', torch.cuda.get_device_name(0))
print('numpy', __import__('numpy').__version__)
print('json', json.dumps({'ok': True}))
