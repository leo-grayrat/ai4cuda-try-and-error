"""Run the Phase-2 IR validation with every tensor on CPU and without autograd.

The IR operators reuse the reference layer modules verbatim, so the conversion
is device-agnostic; running both the IR executor and the reference pipeline on
CPU lets the same fixture be compared bit-for-bit without device transfers.
``no_grad`` keeps the executors from building autograd graphs (the reference
backend also runs under ``torch.inference_mode``).
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
for path in (HERE, os.path.dirname(HERE)):
    if path not in sys.path:
        sys.path.insert(0, path)

import torch  # noqa: E402

import test_ir  # noqa: E402

test_ir.CONFIG = dict(test_ir.CONFIG, device="cpu")
with torch.no_grad():
    code = test_ir.main()
sys.exit(code)
