# Reading `notes/ir_analysis.md`

`notes/ir_analysis.md` is the verbatim `summarize_graph` output.  Its literal
results:

- Model graph: 7 operators, 6 data edges, 4 `chunk_persistent` histories.
  Cross-chunk chains: `conv_a0<->hist_a0`, `conv_a1<->hist_a1`,
  `conv_b0<->hist_b0`, `conv_b1<->hist_b1`; 21 cross-chunk independent pairs
  (every pair that shares no history, e.g. `conv_a1 || conv_b1`);
  `find_pipeline_stages` returns 7 single-operator stages (it splits at every
  state boundary); streaming overlaps: 0 (each branch is a 1:1 chunk edge, no
  rate conversion).
- Worker graph: 5 operators, 5 stages (`ingest_request`, `branch_b`,
  `branch_a`, `gate_merge`, `publish_chunks`), 1 streaming overlap
  (`gate_merge -> publish_chunks`, fixed rate 127 -> 127, ratio 1.0).
- The per-operator latencies printed there are the measured per-chunk executor
  time divided equally over the 7 operators (0.0482 ms each); they are a
  serial lower bound per operator, not isolated measurements.

The experiment log's sentence "stage A = {conv_a0, silu_a, conv_a1}, stage B =
{conv_b0, silu_b, conv_b1}, stage C = {gate_merge}" is the *interpretation*
used for deployment, not a literal quote: `silu_a`, `silu_b` and `gate_merge`
hold no state, so they are pinned into the state-owning branch chains, and
those three groups are exactly what `pipelines.SegmentEngine` computes as its
fused pair of convolutions plus the merge.
