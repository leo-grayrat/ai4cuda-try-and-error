"""Phase-2 IR validation: SequentialExecutor vs the protected reference.

Runs the IR model graph chunk-by-chunk over a six-request scenario (session
start, continuation, repeated input without reset, explicit reset, two further
continuations, tail chunk included) and compares the output to

  (a) ``branch_features.model.ReferencePipeline`` - the exact chunk-sequential
      reference computation on the same fixture.  The IR uses the same layer
      modules in the same order, so exact equality is required, and
  (b) the CPU full-sequence oracle ``full_sequence_oracle`` over each
      reset-delimited concatenation of requests (different conv shape and
      algorithm, hence a documented float32 tolerance).

Then runs ``summarize_graph`` on the model graph (with measured per-operator
latencies) and on the worker graph, writing notes/ir_analysis.md.
"""

import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
REPO = os.path.abspath(os.path.join(BACKEND, "..", "..", "..", ".."))
for path in (BACKEND, os.path.join(BACKEND, "ir"), REPO):
    if path not in sys.path:
        sys.path.insert(0, path)

import numpy as np
import torch

from flashrt.ir import SequentialExecutor, summarize_graph
from branch_ir import build_model_graph, build_worker_graph

CONFIG = {"channels": 16, "hidden": 32, "length": 1043, "chunk": 127,
          "weight_seed": 1234, "device": "cuda"}
HISTS = ("hist_a0", "hist_a1", "hist_b0", "hist_b1")


class Ctx:
    def __init__(self, layers):
        self.layers = layers


def scenario():
    rng = np.random.default_rng(7)
    shape = (CONFIG["channels"], CONFIG["length"])
    r = {name: rng.standard_normal(shape).astype(np.float32)
         for name in ("r1", "r2", "r4", "r5", "r6")}
    return [r["r1"], r["r2"], r["r2"].copy(), "reset", r["r4"], r["r5"], r["r6"]]


def main():
    from branch_features.model import ReferencePipeline, full_sequence_oracle

    pipeline = ReferencePipeline(REPO, CONFIG)
    graph = build_model_graph(CONFIG)
    executor = SequentialExecutor(graph)
    executor.init_state({name: None for name in HISTS})
    ctx = Ctx(pipeline.layers)

    reference_out, ir_out, op_time = {}, {}, {}
    reset_index = 0
    reference_out[0], ir_out[0] = [], []
    for feats in scenario():
        if isinstance(feats, str):
            pipeline.reset()
            executor.init_state({name: None for name in HISTS})
            reset_index += 1
            reference_out[reset_index], ir_out[reset_index] = [], []
            continue
        reference_out[reset_index].append([])
        ir_out[reset_index].append([])
        tensor = torch.from_numpy(feats).unsqueeze(0)
        for start in range(0, CONFIG["length"], CONFIG["chunk"]):
            chunk = tensor[:, :, start:start + CONFIG["chunk"]]
            reference_out[reset_index][-1].append(
                pipeline.step(chunk[0].numpy()).copy())
            t0 = time.perf_counter()
            values = executor.run_chunk({"x": chunk}, ctx)
            dt = (time.perf_counter() - t0) * 1e3
            for name in executor.chunk_execution_order:
                op_time.setdefault(name, []).append(
                    dt / len(executor.chunk_execution_order))
            ir_out[reset_index][-1].append(values["y"][0].numpy().copy())

    diff_ir = 0.0
    for seg in reference_out:
        for req in range(len(reference_out[seg])):
            for chunk in range(len(reference_out[seg][req])):
                a = reference_out[seg][req][chunk]
                b = ir_out[seg][req][chunk]
                diff_ir = max(diff_ir, float(np.max(np.abs(a - b))))

    seq = scenario()
    seg_requests, current, index = {}, [], 0
    for feats in seq:
        if isinstance(feats, str):
            seg_requests[index] = current
            current = []
            index += 1
        else:
            current.append(feats)
    seg_requests[index] = current
    diff_oracle = 0.0
    for seg, requests in seg_requests.items():
        if not requests:
            continue
        pred = full_sequence_oracle(REPO, CONFIG, np.concatenate(requests, axis=1))
        got = np.concatenate([np.concatenate(chunks, axis=1)
                              for chunks in ir_out[seg]], axis=1)
        diff_oracle = max(diff_oracle, float(np.max(np.abs(got - pred))))

    tol_ir = 0.0       # identical modules and op order -> exact
    tol_oracle = 2e-5  # float32 conv over a different shape/algorithm
    verdict = "PASS" if (diff_ir <= tol_ir and diff_oracle <= tol_oracle) else "FAIL"
    print(f"IR validation {verdict}: max|IR-reference|={diff_ir:.3e} "
          f"(tol {tol_ir:.1e}), max|IR-oracle|={diff_oracle:.3e} "
          f"(tol {tol_oracle:.1e})")

    worker_graph = build_worker_graph(CONFIG)
    assert not graph.validate(), graph.validate()
    assert not worker_graph.validate(), worker_graph.validate()
    latencies = {name: float(np.median(v)) / 1e3 for name, v in op_time.items()}
    os.makedirs(os.path.join(BACKEND, "notes"), exist_ok=True)
    path = os.path.join(BACKEND, "notes", "ir_analysis.md")
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("# IR analysis (generated by tests/test_ir.py)\n\n")
        handle.write(f"validation: {verdict}  max|IR-reference|={diff_ir:.3e}  "
                     f"max|IR-oracle|={diff_oracle:.3e}\n\n")
        handle.write("## Model graph (chunk-periodic, executable)\n\n```\n")
        try:
            handle.write(summarize_graph(graph, op_latencies=latencies))
        except Exception as exc:
            handle.write(f"summarize_graph(latencies) failed: {exc!r}\n")
            handle.write(summarize_graph(graph))
        handle.write("\n```\n\n## Worker graph (stage scheduling)\n\n```\n")
        try:
            handle.write(summarize_graph(worker_graph))
        except Exception as exc:
            handle.write(f"summarize_graph failed: {exc!r}\n")
        handle.write("\n```\n\n## measured per-op latency (ms, median, serial)\n\n")
        for name, value in sorted(latencies.items()):
            handle.write(f"- {name}: {value * 1e3:.4f}\n")
    print("IR analysis written to notes/ir_analysis.md")
    print("OPS " + json.dumps(sorted(latencies)))
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
