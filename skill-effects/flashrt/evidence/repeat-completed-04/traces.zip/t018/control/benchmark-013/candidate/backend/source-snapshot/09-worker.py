"""Standalone optimized backend for the two-branch causal feature task.

Adapter contract (identical to ``branch_features.reference``):
  * create the shared-memory buffers named by ``config['prefix']``,
  * write ``{'ready': True, ...}`` to stdout once,
  * answer control opcodes 1 (start / keep running), 2 (terminate),
    3 (reset all four convolution histories),
  * for each published input frame ``(channels, length)`` emit
    ``ceil(length / chunk)`` output frames ``(channels, chunk)`` with
    metadata ``[request_id, chunk_index, valid]``, in order.

Implementation choice per request is selected by ``BF_VARIANT`` (see
``pipelines.VARIANTS``); the default is the recommended variant.  Polling
mode is ``BF_POLL=spin|sleep`` (default spin: the reference's 0.2 ms sleeps
dominate its per-chunk latency on Windows).

Usage:
  python flashrt/apps/branch_features/backend/worker.py \
      --repository <repo-root> --config <config.json>
"""

import argparse
import json
import math
import os
import sys
import time

DEFAULT_VARIANT = "full_graph_pinned_bulk"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", required=True)
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.abspath(args.repository)
    for path in (repo, here):
        if path not in sys.path:
            sys.path.insert(0, path)

    import numpy as np
    import torch

    from branch_features.adapter import close_buffers, open_buffers

    import pipelines

    with open(args.config, "r", encoding="utf-8") as handle:
        config = json.loads(handle.read())

    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    variant = os.environ.get("BF_VARIANT", DEFAULT_VARIANT)
    poll_spin = os.environ.get("BF_POLL", "spin") != "sleep"
    pipeline = pipelines.build(variant, repo, config)

    channels = int(config["channels"])
    chunk = int(config["chunk"])
    length = int(config["length"])
    n_chunks = int(math.ceil(length / chunk))
    bulk = bool(getattr(pipeline, "bulk", False))

    # One request's worth of output frames, reused across requests.
    frames = np.zeros((n_chunks, channels, chunk), dtype=np.float32)
    meta = np.zeros((n_chunks, 3), dtype=np.int64)

    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({"ready": True, "device": str(config.get("device")),
                          "task": "branch_features", "variant": variant,
                          "poll": "spin" if poll_spin else "sleep"}), flush=True)
        while True:
            opcode = buffers["control"].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers["control"].commit()
                    break
                if opcode == 3:
                    pipeline.reset()
                    active = False
                    buffers["control"].commit()
                elif opcode == 1:
                    active = True
                    buffers["control"].commit()
                elif opcode != 0:
                    raise ValueError(f"Unknown control opcode: {opcode}")
            if not active:
                if not poll_spin:
                    time.sleep(0.0002)
                continue
            next_cursor, features = buffers["input"].read(consumed, 1)
            if features is None:
                if not poll_spin:
                    time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError("Input overwritten before processing")
            request_id, consumed = consumed, next_cursor
            request_frames = features[0]
            for index, valid, data in pipeline.stream(request_frames):
                frames[index, :, :valid] = data
                if valid < chunk:
                    frames[index, :, valid:] = 0.0
                meta[index, 0] = request_id
                meta[index, 1] = index
                meta[index, 2] = valid
                if not bulk:
                    buffers["output"].write(frames[index])
                    buffers["metadata"].write(meta[index])
            if bulk:
                buffers["output"].write(frames[:n_chunks])
                buffers["metadata"].write(meta[:n_chunks])
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({"closed": True, "variant": variant}), flush=True)


if __name__ == "__main__":
    main()
