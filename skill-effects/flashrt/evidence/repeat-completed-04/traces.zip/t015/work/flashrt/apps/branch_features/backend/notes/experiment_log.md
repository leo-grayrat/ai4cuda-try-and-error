# branch_features experiment log

## IR conversion and validation
- Worker/model graph: 5 chunk ops, 4 chunk-persistent histories (one per
  causal convolution), 4 data edges plus one ordering edge.  The A and B
  branches are independent after the shared input; gate_merge joins them.
- Validation: PASS, six complete requests through `SequentialExecutor` vs the
  reference backend through the unchanged adapter.  Max abs IR-vs-reference
  error is recorded in stdout of `tests/run_ir_validation.py`; the reference
  itself differs from the CPU oracle by 2.68e-7.  Tolerance 2e-5 is used for
  float32 convolution non-associativity.
- Analysis persisted in `notes/ir_analysis.txt`.

## Deployment variants measured on one RTX 5060 8GB GPU
1. `reference` — supplied sequential backend.  Median time-to-first-output
   1.44 ms, median whole-request service 7.55 ms at the zero-interval sweep,
   inter-chunk-gap median 0.58 ms / p95 1.54 ms.
2. `fused_hybrid` — two equivalent conv calls instead of four, first chunk
   published before the remainder.  Service median 2.00 ms; first output
   1.40 ms.  Correctness PASS (exact vs reference).
3. `fused_chunked` — same fused math with one publication per chunk; in-process
   GPU timing 4.13 ms for nine segments versus 0.42 ms for one full pass.  This
   isolates batching of the remainder.
4. `fused_full_bulk` — current default: one fused full-sequence pass, one
   output and one metadata bulk write; adaptive busy-poll covers a 20 ms
   offered interval.  Correctness PASS vs reference and CPU oracle; median
   first output 1.08 ms, median service 1.15 ms, gap median 0.007 ms / p95
   0.013 ms at zero offered interval.  At 20 ms offered interval all requests
   complete and no chunk gap exceeds the 20 ms budget.

Exact raw measurements live under `benchmarks/results/`.  This session did not
reach the upstream ten-variant floor; the four measured variants above plus the
IR-level fusion/batching experiment are the actual evidence obtained.
