"""End-to-end correctness check for backend/worker.py.

Drives both the reference and candidate through the unchanged adapter, and
also compares candidate output against the CPU full-sequence oracle.  Every
subprocess is killed in a finally block.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import traceback
import uuid

import numpy as np

HERE = Path(__file__).resolve().parent


def launch(script, repository, config_path):
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = os.environ.get('CUDA_VISIBLE_DEVICES', '0')
    return subprocess.Popen(
        [sys.executable, '-u', str(script), '--repository', str(repository),
         '--config', str(config_path)],
        cwd=str(repository), env=env, start_new_session=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding='utf-8', errors='replace')


def collect(script, repository, config, inputs, tag):
    from branch_features.adapter import FeatureAdapter
    tmp = Path(tempfile.mkdtemp(prefix=f'bf_{tag}_'))
    config_path = tmp / 'config.json'
    config_path.write_text(json.dumps(config), encoding='utf-8')
    proc = launch(script, repository, config_path)
    adapter = None
    outputs = []
    try:
        adapter = FeatureAdapter(config)
        adapter.start()
        for values in inputs:
            adapter.submit(values)
            chunks = []
            valid_total = 0
            while valid_total < config['length']:
                chunk, _ = adapter.receive(timeout_s=30)
                chunks.append(chunk)
                valid_total += chunk.shape[-1]
            outputs.append(np.concatenate(chunks, axis=-1))
        adapter.terminate()
        proc.wait(timeout=10)
        return outputs
    finally:
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                proc.wait()
        err = proc.stderr.read()
        if err and 'Traceback' in err:
            print(f'[{tag}] stderr:\n{err}', flush=True)


def cpu_session_oracle(repository, config, inputs):
    from branch_features.model import full_sequence_oracle
    out = []
    accumulated = None
    for values in inputs:
        accumulated = values if accumulated is None else np.concatenate(
            [accumulated, values], axis=-1)
        full = full_sequence_oracle(str(repository), config, accumulated)
        out.append(full[:, -values.shape[-1]:])
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=Path.cwd())
    args = parser.parse_args()
    repo = args.repository.resolve()
    cfg = {
        'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
        'weight_seed': 1234, 'device': 'cuda',
        'prefix': 'bf_check_' + uuid.uuid4().hex[:10],
    }
    rng = np.random.default_rng(7)
    a = rng.standard_normal((cfg['channels'], cfg['length']), dtype=np.float32)
    b = rng.standard_normal((cfg['channels'], cfg['length']), dtype=np.float32)
    c = rng.standard_normal((cfg['channels'], cfg['length']), dtype=np.float32)
    # continuation, repeated input without reset, reset, and tail chunks.
    inputs = [a, b, b, c, a, b]  # a reset is inserted between b and c below

    ref_script = repo / 'flashrt/apps/branch_features/reference.py'
    cand_script = repo / 'flashrt/apps/branch_features/backend/worker.py'
    print(f'fixture: 6 requests shape={(cfg["channels"], cfg["length"])} chunk={cfg["chunk"]}', flush=True)

    # Scenario 1 (no reset): continuation and repeated input.
    ref1 = collect(ref_script, repo, cfg, [a, b, b], 'ref_noreset')
    cand1 = collect(cand_script, repo, cfg, [a, b, b], 'cand_noreset')
    oracle1 = cpu_session_oracle(repo, cfg, [a, b, b])

    # Scenario 2: reset, then three requests including a repeated first input
    # and a final request whose last emitted chunk is the tail (27 samples).
    def with_reset(script, tag):
        from branch_features.adapter import FeatureAdapter
        tmp = Path(tempfile.mkdtemp(prefix=f'bf_{tag}_'))
        config_path = tmp / 'config.json'
        config_path.write_text(json.dumps(cfg), encoding='utf-8')
        proc = launch(script, repo, config_path)
        adapter = None
        outputs = []
        try:
            adapter = FeatureAdapter(cfg)
            adapter.start()
            for values in [a]:
                adapter.submit(values)
                got = 0
                chunks = []
                while got < cfg['length']:
                    ch, _ = adapter.receive(timeout_s=30)
                    chunks.append(ch)
                    got += ch.shape[-1]
                outputs.append(np.concatenate(chunks, axis=-1))
            adapter.reset()
            for values in [a, b, c]:
                adapter.submit(values)
                got = 0
                chunks = []
                while got < cfg['length']:
                    ch, _ = adapter.receive(timeout_s=30)
                    chunks.append(ch)
                    got += ch.shape[-1]
                outputs.append(np.concatenate(chunks, axis=-1))
            adapter.terminate()
            proc.wait(timeout=10)
            return outputs
        finally:
            if adapter is not None:
                adapter.close()
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    proc.wait()
            err = proc.stderr.read()
            if err and 'Traceback' in err:
                print(f'[{tag}] stderr:\n{err}', flush=True)

    ref2 = with_reset(ref_script, 'ref_reset')
    cand2 = with_reset(cand_script, 'cand_reset')
    oracle2 = cpu_session_oracle(repo, cfg, [a]) + cpu_session_oracle(repo, cfg, [a, b, c])

    def check(name, got, want):
        if len(got) != len(want) or not got:
            print(f'FAIL {name}: count got={len(got)} want={len(want)}', flush=True)
            return False
        worst = 0.0
        for i, (x, y) in enumerate(zip(got, want)):
            d = float(np.max(np.abs(x - y)))
            worst = max(worst, d)
            if not np.allclose(x, y, atol=2e-5, rtol=2e-5):
                print(f'FAIL {name} req{i} max_abs={d:.3e}', flush=True)
                return False
        print(f'{name}: n={len(got)} max_abs={worst:.3e}', flush=True)
        return True

    ok = True
    ok &= check('reference_vs_oracle_noreset', ref1, oracle1)
    ok &= check('candidate_vs_oracle_noreset', cand1, oracle1)
    ok &= check('candidate_vs_reference_noreset', cand1, ref1)
    ok &= check('reference_vs_oracle_reset', ref2, oracle2)
    ok &= check('candidate_vs_oracle_reset', cand2, oracle2)
    ok &= check('candidate_vs_reference_reset', cand2, ref2)
    print('PASS' if ok else 'FAIL', flush=True)
    return 0 if ok else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except BaseException:
        (HERE / 'check_error.txt').write_text(
            traceback.format_exc(), encoding='ascii', errors='replace')
        print('CHECK_FAILED_ASCII_SAFE', flush=True)
