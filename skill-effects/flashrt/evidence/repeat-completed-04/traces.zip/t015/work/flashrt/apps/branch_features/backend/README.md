# branch_features optimized backend

Entry point: `flashrt/apps/branch_features/backend/worker.py --repository <repo> --config <json>`.
It uses the unchanged `branch_features.adapter` (the shared `causal_features`
contract).  The default mode is `full`: one fused GPU pass per complete request
and one bulk ring-buffer publication.  `BF_MODE=hybrid` publishes the first
127-sample chunk early; `BF_MODE=chunked` is the fused fallback with one
publication per chunk.

Verified: six complete requests (continuation, repeated input without reset,
tail chunks), plus the reset scenario in `tests/check_worker.py`, match the
reference exactly and the CPU full-sequence oracle within 2.68e-7.
Benchmark evidence: see `benchmarks/results/paired_worker_*.json` and
`notes/experiment_log.md`.
