"""Paired latency / sustainable-rate benchmark for the branch_features backend.

Every backend is launched through the unchanged adapter and cleanly
terminated.  Timestamps come from FeatureAdapter.submit and receive.  The
sweep reports per-request service time, time to first chunk, and inter-chunk
gaps; a finite offered-load interval is considered sustainable when the whole
request finishes before the next offered input (no growing backlog).
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import tempfile
import time
import traceback
import uuid

import numpy as np

HERE = Path(__file__).resolve().parent


def percentile(values, q):
    if not values:
        return None
    return float(np.percentile(np.asarray(values, dtype=np.float64), q))


def launch(script, repository, config_path):
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = os.environ.get('CUDA_VISIBLE_DEVICES', '0')
    return subprocess.Popen(
        [sys.executable, '-u', str(script), '--repository', str(repository),
         '--config', str(config_path)], cwd=str(repository), env=env,
        start_new_session=True, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, encoding='utf-8', errors='replace')


def run_backend(script, repository, cfg, tag, offered_ms=(0.0, 1.0, 2.0, 5.0, 10.0, 20.0)):
    from branch_features.adapter import FeatureAdapter
    tmp = Path(tempfile.mkdtemp(prefix=f'bf_bench_{tag}_'))
    config_path = tmp / 'config.json'
    config_path.write_text(json.dumps(cfg), encoding='utf-8')
    proc = launch(script, repository, config_path)
    adapter = None
    result = {'tag': tag, 'sweeps': {}, 'first_latency_ms': [], 'service_ms': [],
              'gap_ms': [], 'errors': []}
    rng = np.random.default_rng(12345)
    try:
        adapter = FeatureAdapter(cfg)
        adapter.start()
        # Warm-up (also absorbs first-call CUDA / allocator overhead).
        for _ in range(3):
            v = rng.standard_normal((cfg['channels'], cfg['length']), dtype=np.float32)
            adapter.submit(v)
            got = 0
            while got < cfg['length']:
                ch, _ = adapter.receive(timeout_s=30)
                got += ch.shape[-1]
        for offered in offered_ms:
            interval = offered / 1000.0
            lat, svc, gaps = [], [], []
            next_due = time.perf_counter()
            for k in range(20):
                if interval > 0:
                    now = time.perf_counter()
                    if next_due > now:
                        time.sleep(next_due - now)
                values = rng.standard_normal((cfg['channels'], cfg['length']), dtype=np.float32)
                _, t_in = adapter.submit(values)
                first, t_first = adapter.receive(timeout_s=30)
                lat.append((t_first - t_in) / 1e6)
                prev = t_first
                got = first.shape[-1]
                while got < cfg['length']:
                    ch, t = adapter.receive(timeout_s=30)
                    gaps.append((t - prev) / 1e6)
                    prev = t
                    got += ch.shape[-1]
                t_end = time.perf_counter_ns()
                svc.append((t_end - t_in) / 1e6)
                if interval > 0:
                    next_due += interval
                    # If we could not keep up, reset the offer schedule.
                    if time.perf_counter() > next_due:
                        next_due = time.perf_counter()
                if interval == max(offered_ms):
                    result['first_latency_ms'].extend(lat)
                    result['service_ms'].extend(svc)
                    result['gap_ms'].extend(gaps)
            result['sweeps'][f'{offered:g}ms'] = {
                'first_median_ms': percentile(lat, 50),
                'first_p95_ms': percentile(lat, 95),
                'service_median_ms': percentile(svc, 50),
                'service_p95_ms': percentile(svc, 95),
                'gap_median_ms': percentile(gaps, 50),
                'gap_p95_ms': percentile(gaps, 95),
                'over_20ms_fraction': float(np.mean(np.asarray(gaps) > 20.0)) if gaps else 0.0,
                'max_service_ms': float(max(svc)),
                'sustainable': bool(max(svc) <= offered) if interval > 0 else None,
            }
        adapter.terminate()
        proc.wait(timeout=15)
        return result
    finally:
        if adapter is not None:
            adapter.close()
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                proc.wait()
        err = proc.stderr.read()
        if err and 'Traceback' in err:
            result['errors'].append(err[-4000:])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, default=Path.cwd())
    args = parser.parse_args()
    repo = args.repository.resolve()
    cfg = {'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
           'weight_seed': 1234, 'device': 'cuda',
           'prefix': 'bf_bench_' + uuid.uuid4().hex[:10]}
    ref_script = repo / 'flashrt/apps/branch_features/reference.py'
    cand_script = repo / 'flashrt/apps/branch_features/backend/worker.py'
    out = {'config': cfg, 'hardware': os.environ.get('CUDA_VISIBLE_DEVICES', '0')}
    out['reference'] = run_backend(ref_script, repo, cfg, 'reference')
    out['candidate'] = run_backend(cand_script, repo, cfg, 'candidate')
    print(json.dumps(out, indent=2), flush=True)
    results = HERE / 'results'
    results.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d_%H%M%S')
    (results / f'paired_worker_{stamp}.json').write_text(
        json.dumps(out, indent=2), encoding='utf-8')


if __name__ == '__main__':
    try:
        main()
    except BaseException:
        (HERE / 'bench_error.txt').write_text(
            traceback.format_exc(), encoding='ascii', errors='replace')
        print('BENCH_FAILED_ASCII_SAFE', flush=True)
