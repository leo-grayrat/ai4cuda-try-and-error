"""Minimal staged diagnostic for the check harness."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import traceback
import uuid

HERE = Path(__file__).resolve().parent


def main():
    repo = Path.cwd()
    cfg = {'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
           'weight_seed': 1234, 'device': 'cuda',
           'prefix': 'bf_diag_' + uuid.uuid4().hex[:10]}
    tmp = Path(tempfile.mkdtemp(prefix='bf_diag_'))
    cfg_path = tmp / 'config.json'
    cfg_path.write_text(json.dumps(cfg), encoding='utf-8')
    print('stage import adapter', flush=True)
    from branch_features.adapter import FeatureAdapter
    print('stage launch reference', flush=True)
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = os.environ.get('CUDA_VISIBLE_DEVICES', '0')
    script = repo / 'flashrt/apps/branch_features/reference.py'
    proc = subprocess.Popen(
        [sys.executable, '-u', str(script), '--repository', str(repo),
         '--config', str(cfg_path)], cwd=str(repo), env=env,
        start_new_session=True, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, encoding='utf-8', errors='replace')
    print('stage attach', flush=True)
    adapter = None
    try:
        adapter = FeatureAdapter(cfg)
        print('stage start', flush=True)
        adapter.start()
        print('stage submit', flush=True)
        import numpy as np
        rng = np.random.default_rng(7)
        values = rng.standard_normal((cfg['channels'], cfg['length']), dtype=np.float32)
        adapter.submit(values)
        print('stage receive', flush=True)
        total = 0
        while total < cfg['length']:
            chunk, _ = adapter.receive(timeout_s=30)
            total += chunk.shape[-1]
            print('chunk', total, flush=True)
        print('stage terminate', flush=True)
        adapter.terminate()
        proc.wait(timeout=10)
        print('stage done', flush=True)
    finally:
        if adapter is not None:
            adapter.close()
        if proc.poll() is None:
            proc.terminate()
            proc.wait(timeout=10)
        out = proc.stdout.read()
        err = proc.stderr.read()
        print('child stdout:', out[-2000:], flush=True)
        print('child stderr:', err[-4000:], flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException:
        text = traceback.format_exc()
        (HERE / 'diag_error.txt').write_text(text, encoding='ascii', errors='replace')
        print('DIAG_FAILED_ASCII_SAFE', flush=True)
