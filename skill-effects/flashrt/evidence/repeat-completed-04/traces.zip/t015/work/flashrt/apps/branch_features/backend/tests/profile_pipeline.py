"""In-process timing of the fused math (no IPC)."""
import importlib.util
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
from branch_features.model import ReferencePipeline

spec = importlib.util.spec_from_file_location(
    'bf_worker', ROOT / 'flashrt/apps/branch_features/backend/worker.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
FusedPipeline = mod.FusedPipeline

cfg = {'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
       'weight_seed': 1234, 'device': 'cuda', 'prefix': 'bf_prof'}
rng = np.random.default_rng(1)
x = rng.standard_normal((1, cfg['channels'], cfg['length']), dtype=np.float32)
import torch
values = torch.from_numpy(x).to('cuda')


def bench(fn, n=100):
    for _ in range(5):
        fn()
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(n):
        fn()
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / n * 1000.0


p = FusedPipeline(str(ROOT), cfg)


def full():
    p.reset()
    return p.process(values)


def first():
    p.reset()
    return p.process(values[:, :, :127])


def rounds():
    p.reset()
    out = []
    for pos in range(0, 1043, 127):
        out.append(p.process(values[:, :, pos:pos + 127]))
    return out


def steady_full():
    return p.process(values)


print('fused full ms', bench(full))
print('fused first ms', bench(first))
print('fused 9 rounds ms', bench(rounds))
p.reset()
p.process(values)
print('fused steady full ms', bench(steady_full))

cpu_cfg = dict(cfg, device='cpu')
cp = ReferencePipeline(str(ROOT), cpu_cfg)
cx = torch.from_numpy(x)


def cpu_full():
    cp.reset()
    return cp.step(x[0])


def cpu_first():
    cp.reset()
    return cp.step(x[0, :, :127])


print('cpu reference full ms', bench(cpu_full, 50))
print('cpu reference first ms', bench(cpu_first, 50))
