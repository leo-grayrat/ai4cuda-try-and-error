"""IR representation of the branch_features chunk-periodic graph.

Four exposed causal convolutions each carry their own ``chunk_persistent``
history.  The two branches are independent after the shared input, and the
gate/merge consumes both branch outputs plus the current input.  This is the
reference dependency structure; the optimized worker fuses the two first-layer
convolutions and the two second-layer convolutions without changing it.
"""
from __future__ import annotations

import torch

from flashrt.ir import (IRGraph, IREdge, IROperator, OpType, StateObject,
                        StreamMode, TensorPort)


class ConvHistoryOp(IROperator):
    def __init__(self, name: str, layer_name: str, in_port: str,
                 out_port: str, kernel: int):
        super().__init__(
            name=name, op_type=OpType.EXPOSED,
            inputs=[TensorPort(in_port)], outputs=[TensorPort(out_port)],
            state_reads=[f'{name}_history'], state_writes=[f'{name}_history'],
            stream_mode=StreamMode.STREAMING,
            config={'kernel': kernel, 'layer': layer_name})
        self.layer_name = layer_name
        self.in_port = in_port
        self.out_port = out_port
        self.kernel = kernel

    def execute(self, inputs, ctx, state):
        values = inputs[self.in_port]
        history = state.get(f'{self.name}_history')
        joined = values if history is None else torch.cat([history, values], dim=-1)
        layer = ctx.layers[self.layer_name]
        out = layer(joined)
        if history is not None:
            out = out[:, :, history.shape[-1]:]
        state.set(f'{self.name}_history',
                  joined[:, :, -(self.kernel - 1):].clone())
        return {self.out_port: out}


class GateMergeOp(IROperator):
    def __init__(self):
        super().__init__(
            name='gate_merge', op_type=OpType.EXPOSED,
            inputs=[TensorPort('features'), TensorPort('branch_a'),
                    TensorPort('branch_b')],
            outputs=[TensorPort('out')], stream_mode=StreamMode.STREAMING)

    def execute(self, inputs, ctx, state):
        features = inputs['features']
        gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
        out = gate * inputs['branch_a'] + (1 - gate) * inputs['branch_b'] + 0.1 * features
        return {'out': out}


def build_chunk_graph() -> IRGraph:
    g = IRGraph(name='branch_features_chunk')
    for name, layer, in_port, out_port, kernel in (
            ('conv_a0', 'a0', 'features', 'ha', 5),
            ('conv_a1', 'a1', 'ha', 'branch_a', 3),
            ('conv_b0', 'b0', 'features', 'hb', 3),
            ('conv_b1', 'b1', 'hb', 'branch_b', 5)):
        g.add_state(StateObject(f'{name}_history',
                                f'{name} causal history', 'chunk_persistent'))
        g.add_operator(ConvHistoryOp(name, layer, in_port, out_port, kernel))
    g.add_operator(GateMergeOp())
    for edge in (
            ('conv_a0', 'ha', 'conv_a1', 'ha'),
            ('conv_b0', 'hb', 'conv_b1', 'hb'),
            ('conv_a1', 'branch_a', 'gate_merge', 'branch_a'),
            ('conv_b1', 'branch_b', 'gate_merge', 'branch_b')):
        g.add_edge(IREdge(*edge))
    # Current features feed both first-layer convolutions and the merge.
    g.add_edge(IREdge('conv_a0', None, 'conv_b0', None))
    g.external_inputs = [TensorPort('features')]
    g.external_outputs = [TensorPort('out')]
    g.chunk_ops = ['conv_a0', 'conv_a1', 'conv_b0', 'conv_b1', 'gate_merge']
    return g
