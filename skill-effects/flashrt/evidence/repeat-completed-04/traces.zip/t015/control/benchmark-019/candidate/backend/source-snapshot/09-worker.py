"""Optimized streaming worker for the two-branch causal-feature task.

The adapter contract is exactly the one in ``causal_features.adapter``.
The four reference convolutions are rewritten as two equivalent causal
convolutions: the two first-layer convolutions share their input, and the
two second-layer convolutions operate on disjoint hidden-channel groups.
This keeps the dependency graph unchanged while removing two kernel
launches per processed segment.

Modes (selected by ``BF_MODE``, default ``full``):
  full     evaluate the complete request in one fused GPU pass and publish
           all output chunks in one bulk shared-memory write;
  hybrid   publish the first chunk immediately, then batch the remainder;
  chunked  fused math but one publication per configured chunk.

All modes carry the same histories across requests and clear them on reset.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import time


def _build_fused(repository: str, config: dict, device):
    """Build reference layers then fold them into two conv calls."""
    import torch
    from branch_features.model import build_layers

    layers = build_layers(repository, config, device)
    a0, a1 = layers['a0'], layers['a1']
    b0, b1 = layers['b0'], layers['b1']
    channels, hidden = config['channels'], config['hidden']

    # First stage: both branches see the same input.  The b0 kernel (3) is
    # right-aligned in a 5-tap window (its two oldest taps are zero), exactly
    # matching the reference's 2-sample left replicate pad.
    w0 = torch.zeros((2 * hidden, channels, 5),
                     device=device, dtype=a0.conv.weight.dtype)
    w0[:hidden, :, :] = a0.conv.weight.detach()
    w0[hidden:, :, 2:] = b0.conv.weight.detach()
    b0f = torch.cat([a0.conv.bias.detach(), b0.conv.bias.detach()], dim=0)

    # Second stage: a1 owns hidden channels 0:H, b1 owns H:2H.  Grouped
    # convolution runs both disjoint branches in one launch.
    w1 = torch.zeros((2 * channels, hidden, 5),
                     device=device, dtype=a1.conv.weight.dtype)
    w1[:channels, :, 2:] = a1.conv.weight.detach()
    w1[channels:, :, :] = b1.conv.weight.detach()
    b1f = torch.cat([a1.conv.bias.detach(), b1.conv.bias.detach()], dim=0)
    return w0, b0f, w1, b1f


class FusedPipeline:
    """Stateful, history-carrying implementation of the reference graph."""

    def __init__(self, repository: str, config: dict):
        import torch
        self.torch = torch
        self.config = config
        self.device = torch.device(config['device'])
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        self.w0, self.b0, self.w1, self.b1 = _build_fused(
            repository, config, self.device)
        self.reset()

    def reset(self):
        self.feat_hist = None
        self.ha_hist = None
        self.hb_hist = None

    def _first_stage(self, values):
        torch = self.torch
        F = torch.nn.functional
        joined = values if self.feat_hist is None else torch.cat(
            [self.feat_hist, values], dim=-1)
        hist_len = joined.shape[-1] - values.shape[-1]
        padded = F.pad(joined, (4, 0), mode='replicate')
        out = F.conv1d(padded, self.w0, self.b0)
        out = out[:, :, hist_len:hist_len + values.shape[-1]]
        self.feat_hist = joined[:, :, -4:].clone()
        return F.silu(out[:, :self.hidden, :]), F.silu(out[:, self.hidden:, :])

    def _second_stage(self, ha, hb):
        torch = self.torch
        F = torch.nn.functional
        cur_len = ha.shape[-1]
        if self.ha_hist is None:
            ya, yb, hist_len = ha, hb, 0
        else:
            pad_len = self.hb_hist.shape[-1] - self.ha_hist.shape[-1]
            ya = torch.cat([torch.zeros((1, self.hidden, pad_len),
                                        device=ha.device, dtype=ha.dtype),
                            self.ha_hist, ha], dim=-1)
            yb = torch.cat([self.hb_hist, hb], dim=-1)
            hist_len = self.hb_hist.shape[-1]
        y = torch.cat([ya, yb], dim=1)
        padded = F.pad(y, (4, 0), mode='replicate')
        out = F.conv1d(padded, self.w1, self.b1, groups=2)
        out = out[:, :, hist_len:hist_len + cur_len]
        self.ha_hist = ya[:, :, -2:].clone()
        self.hb_hist = yb[:, :, -4:].clone()
        return out[:, :self.channels, :], out[:, self.channels:, :]

    def process(self, values):
        torch = self.torch
        ha, hb = self._first_stage(values)
        a, b = self._second_stage(ha, hb)
        gate = torch.sigmoid(values.mean(dim=1, keepdim=True))
        return gate * a + (1.0 - gate) * b + 0.1 * values

    process_chunk = process


def _pack(np, tensor, channels, chunk, n_chunks, length):
    """Copy a (1,C,L) device result into the adapter's padded chunk layout."""
    raw = tensor[0].detach().cpu().numpy()
    packed = np.zeros((n_chunks, channels, chunk), dtype=np.float32)
    for i in range(n_chunks):
        lo = i * chunk
        hi = min(lo + chunk, length)
        packed[i, :, :hi - lo] = raw[:, lo:hi]
    meta = np.empty((n_chunks, 3), dtype=np.int64)
    for i in range(n_chunks):
        lo = i * chunk
        meta[i] = (0, i, min(chunk, length - lo))
    return packed, meta, raw


def _run(repository: Path, config_path: Path) -> None:
    sys.path.insert(0, str(repository.resolve()))
    import numpy as np
    import torch
    from branch_features.adapter import open_buffers, close_buffers

    config = json.loads(config_path.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    mode = os.environ.get('BF_MODE', 'full').strip().lower()
    if mode not in ('full', 'hybrid', 'chunked'):
        mode = 'full'
    pipeline = FusedPipeline(str(repository), config)
    chunk = int(config['chunk'])
    length = int(config['length'])
    channels = int(config['channels'])
    n_chunks = (length + chunk - 1) // chunk

    buffers = open_buffers(config, create=True)
    consumed = 0
    last_command = 0
    active = False
    spin_deadline = time.perf_counter() + 0.01
    try:
        print(json.dumps({'ready': True, 'device': config['device'],
                          'task': 'branch_features', 'backend': 'fused_' + mode}),
              flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    pipeline.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    spin_deadline = time.perf_counter() + 0.01
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                # Short busy poll after activity removes Windows scheduler
                # sleep quanta from the first-output critical path; long idle
                # periods back off to a normal sleep.
                if time.perf_counter() > spin_deadline:
                    time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            spin_deadline = time.perf_counter() + 0.030

            values = torch.from_numpy(features[0]).unsqueeze(0).to(
                pipeline.device, non_blocking=False)

            if mode == 'full':
                out = pipeline.process(values)
                packed, meta, _ = _pack(np, out, channels, chunk, n_chunks, length)
                meta[:, 0] = request_id
                buffers['output'].write(packed)
                buffers['metadata'].write(meta)
            elif mode == 'hybrid':
                first_valid = min(chunk, length)
                first = pipeline.process_chunk(values[:, :, :first_valid])
                first_pad = np.zeros((channels, chunk), dtype=np.float32)
                first_pad[:, :first_valid] = first[0].detach().cpu().numpy()
                buffers['output'].write(first_pad)
                buffers['metadata'].write(
                    np.array([request_id, 0, first_valid], dtype=np.int64))
                remaining = length - first_valid
                if remaining > 0:
                    rest = pipeline.process(values[:, :, first_valid:])
                    rest_chunks = n_chunks - 1
                    packed = np.zeros((rest_chunks, channels, chunk), dtype=np.float32)
                    raw = rest[0].detach().cpu().numpy()
                    for i in range(rest_chunks):
                        lo = i * chunk
                        hi = min(lo + chunk, remaining)
                        packed[i, :, :hi - lo] = raw[:, lo:hi]
                    meta = np.empty((rest_chunks, 3), dtype=np.int64)
                    for i in range(rest_chunks):
                        lo = i * chunk
                        meta[i] = (request_id, i + 1,
                                   min(chunk, remaining - lo))
                    buffers['output'].write(packed)
                    buffers['metadata'].write(meta)
            else:
                for index, position in enumerate(range(0, length, chunk)):
                    out = pipeline.process_chunk(
                        values[:, :, position:position + chunk])
                    valid = min(chunk, length - position)
                    padded = np.zeros((channels, chunk), dtype=np.float32)
                    padded[:, :valid] = out[0].detach().cpu().numpy()
                    buffers['output'].write(padded)
                    buffers['metadata'].write(
                        np.array([request_id, index, valid], dtype=np.int64))
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    _run(args.repository, args.config)


if __name__ == '__main__':
    main()
