"""Direct (no IPC) correctness + timing probe for every engine variant."""
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))
from common import LENGTH, REPO, make_config  # noqa: E402

import engine as engine_mod  # noqa: E402

TOL = 2e-5


def fixture():
    import torch
    gen = torch.Generator().manual_seed(21)
    return [torch.randn(16, LENGTH, generator=gen).numpy().astype(np.float32)
            for _ in range(3)]


def oracle(requests):
    from branch_features.model import full_sequence_oracle
    cfg = make_config()
    whole = full_sequence_oracle(str(REPO), cfg, np.concatenate(requests, axis=1))
    n = len(requests)
    return [whole[:, i * LENGTH:(i + 1) * LENGTH] for i in range(n)]


def collect(engine, requests):
    outs = []
    for feats in requests:
        if engine.bulk:
            frames, valids = engine.process(feats)
            full = np.zeros((16, LENGTH), dtype=np.float32)
            for i, v in enumerate(valids):
                full[:, i * engine.chunk:i * engine.chunk + v] = frames[i, :, :v]
            outs.append(full)
        else:
            full = np.zeros((16, LENGTH), dtype=np.float32)
            for idx, valid, arr in engine.process(feats):
                full[:, idx * engine.chunk:idx * engine.chunk + valid] = arr
            outs.append(full)
    return outs


def main():
    names = sys.argv[1:] or list(engine_mod.ENGINES)
    requests = fixture()
    want = oracle(requests)
    for name in names:
        try:
            eng = engine_mod.make_engine(name, str(REPO), make_config())
        except Exception as exc:  # noqa: BLE001
            print(f'{name}: CONSTRUCT-FAIL {exc!r}', flush=True)
            continue
        for trial in range(2):
            eng.reset()
            got = collect(eng, requests)
            diffs = [float(np.max(np.abs(g - w))) for g, w in zip(got, want)]
            if trial == 0:
                print(f'{name}: diffs={["%.2e" % d for d in diffs]}', flush=True)
        # timing (steady state, requests back to back, histories carried)
        eng.reset()
        collect(eng, requests[:1])
        t0 = time.perf_counter()
        n = 20
        for _ in range(n):
            collect(eng, requests[:1])
        t1 = time.perf_counter()
        verdict = 'PASS' if max(diffs) <= TOL else 'FAIL'
        print(f'{name}: {verdict} per-request={1e3 * (t1 - t0) / n:.3f} ms '
              f'({n / (t1 - t0):.1f} req/s)', flush=True)


if __name__ == '__main__':
    main()
