"""Optimized branch_features backend workspace (IR, engines, harnesses, notes)."""
