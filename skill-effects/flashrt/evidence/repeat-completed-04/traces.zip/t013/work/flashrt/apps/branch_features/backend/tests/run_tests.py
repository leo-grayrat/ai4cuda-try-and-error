"""Runner that keeps harness output ASCII-decodable on a localized Windows console."""
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding='utf-8', errors='backslashreplace')
    except Exception:
        pass

import test_worker  # noqa: E402

if __name__ == '__main__':
    try:
        sys.exit(test_worker.main())
    except SystemExit:
        raise
    except BaseException:
        traceback.print_exc()
        sys.exit(2)
