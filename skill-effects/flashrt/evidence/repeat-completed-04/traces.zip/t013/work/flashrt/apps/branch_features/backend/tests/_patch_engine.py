"""One-off source patch (kept out of the way of the engine module)."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / 'engine.py'
src = path.read_text(encoding='utf-8')

subs = [
    (
        "        self.in_host_np = self.in_host.numpy()\n",
        "        self.in_host_np = self.in_host.numpy()\n"
        "        # Separate pinned staging for history-carrying requests: a column slice of\n"
        "        # a pinned tensor is non-contiguous and torch refuses to capture such a\n"
        "        # host->device copy into a graph.\n"
        "        self.in_cur = torch.empty((self.channels, self.length),\n"
        "                                  dtype=torch.float32, pin_memory=True)\n"
        "        self.in_cur_np = self.in_cur.numpy()\n",
    ),
    (
        "            self.in_dev[:, HIST:].copy_(self.in_host[:, HIST:], non_blocking=True)\n",
        "            self.in_dev[:, HIST:].copy_(self.in_cur, non_blocking=True)\n",
    ),
    (
        "        np.copyto(self.in_host_np[:, HIST:], feats)\n"
        "        graph = self.graph_fresh if self.fresh else self.graph_carry\n",
        "        if self.fresh:\n"
        "            np.copyto(self.in_host_np[:, HIST:], feats)\n"
        "        else:\n"
        "            np.copyto(self.in_cur_np, feats)\n"
        "        graph = self.graph_fresh if self.fresh else self.graph_carry\n",
    ),
]

for old, new in subs:
    assert src.count(old) == 1, old
    src = src.replace(old, new)
path.write_text(src, encoding='utf-8')
print('patched', path)
