"""Pinpoint where a variant's output diverges from the CPU full-sequence oracle."""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))
from common import LENGTH, REPO, make_config  # noqa: E402

import engine as engine_mod  # noqa: E402

cfg = make_config()
gen = torch.Generator().manual_seed(21)
feats = torch.randn(16, LENGTH, generator=gen).numpy().astype(np.float32)

from branch_features.model import full_sequence_oracle, build_layers  # noqa: E402

want = full_sequence_oracle(str(REPO), cfg, feats)

eng = engine_mod.make_engine(sys.argv[1] if len(sys.argv) > 1 else 'whole_fused',
                             str(REPO), cfg)
frames, valids = eng.process(feats)
got = np.zeros_like(want)
for i, v in enumerate(valids):
    got[:, i * eng.chunk:i * eng.chunk + v] = frames[i, :, :v]
diff = np.abs(got - want)
profile = diff.max(axis=0)
bad = np.nonzero(profile > 1e-3)[0]
print('n_bad_positions', bad.size, 'first', bad[:12].tolist(), 'last', bad[-6:].tolist())
print('profile[0:8]', np.round(profile[:8], 5).tolist())
print('profile[120:135]', np.round(profile[120:135], 5).tolist())
print('got', np.round(got[0, :6], 5).tolist())
print('want', np.round(want[0, :6], 5).tolist())

# Layer-by-layer comparison of the first branch using the same window trick.
layers = build_layers(str(REPO), cfg, 'cpu')
vals = torch.from_numpy(feats).unsqueeze(0)
a0_ref = layers['a0'](vals)
win = torch.cat([torch.from_numpy(feats)[:, :1].repeat(1, 4),
                 torch.from_numpy(feats)], dim=1).unsqueeze(0)
a0_win = F.conv1d(win, layers['a0'].conv.weight, layers['a0'].conv.bias)
print('a0 window vs causal-conv max diff', float((a0_ref - a0_win).abs().max()))
h = F.silu(a0_ref)
a1_ref = layers['a1'](h)
hwin = torch.cat([h[:, :, :1].repeat(1, 1, 4), h], dim=2)
a1_win = F.conv1d(hwin, F.pad(layers['a1'].conv.weight, (2, 0)),
                  layers['a1'].conv.bias)
print('a1 window vs causal-conv max diff', float((a1_ref - a1_win).abs().max()))
