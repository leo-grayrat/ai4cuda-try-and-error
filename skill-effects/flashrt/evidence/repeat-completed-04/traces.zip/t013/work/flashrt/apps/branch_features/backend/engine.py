"""Feature-processing engines for branch_features.

The reference (``branch_features.model.ReferencePipeline``) walks a request chunk by
chunk and runs four causal convolutions per chunk, re-copying the whole input to the
GPU for every chunk.  Every time position only depends on the current and past input,
and the adapter hands the backend one *complete* request (``length`` samples) at a
time, so the per-request work can be reorganised along two independent levers:

1.  **branch fusion** - the A and B branches consume the same input stream at stage 1
    and produce two streams of identical shape at stage 2, so each stage can be one
    grouped ``conv1d`` (kernel size 5, the k=3 filters zero-extended on the causal
    side, which is exactly the reference's causal alignment).
2.  **request batching / launch elimination** - compute the whole request's 1047-sample
    window in one pass instead of nine 131-sample windows, and (best variant) bake the
    whole pass into a CUDA graph so a request costs one graph launch plus one sync.

Causal histories of the four convolutions are kept across requests, exactly as the
reference does; ``reset()`` clears them.  A fresh session replicates the first sample
(kernel-1) times, which is what ``CausalConv1d``'s replicate padding does.
"""
import math

import numpy as np
import torch
import torch.nn.functional as F

HIST = 4          # longest causal history (kernel 5 -> 4 samples)
PAD_KERNEL = 5    # common kernel width used by the fused / zero-extended filters


def _left_zero_pad(weight, n):
    """Zero-extend a causal conv kernel on the *oldest* taps (k=3 -> k=5)."""
    return F.pad(weight, (n, 0))


class _Weights:
    """Loads the fixed weights through the shared model builder (identical seeds)."""

    def __init__(self, repository, config, force_device=None):
        import branch_features.model as model

        self.config = dict(config)
        self.channels = int(config['channels'])
        self.hidden = int(config['hidden'])
        self.length = int(config['length'])
        self.chunk = int(config['chunk'])
        self.n_chunks = math.ceil(self.length / self.chunk)
        self.valids = [min(self.chunk, self.length - i * self.chunk)
                       for i in range(self.n_chunks)]
        self.device = torch.device(force_device or config.get('device', 'cuda'))
        self.layers = model.build_layers(repository, config, self.device)
        lay = self.layers
        with torch.inference_mode():
            self.w_a0 = lay['a0'].conv.weight.detach().clone()
            self.b_a0 = lay['a0'].conv.bias.detach().clone()
            self.w_a1 = lay['a1'].conv.weight.detach().clone()
            self.b_a1 = lay['a1'].conv.bias.detach().clone()
            self.w_b0 = lay['b0'].conv.weight.detach().clone()
            self.b_b0 = lay['b0'].conv.bias.detach().clone()
            self.w_b1 = lay['b1'].conv.weight.detach().clone()
            self.b_b1 = lay['b1'].conv.bias.detach().clone()
            # k=3 filters zero-extended to the shared k=5 causal window.
            self.w_b0p = _left_zero_pad(self.w_b0, 2).contiguous()
            self.w_a1p = _left_zero_pad(self.w_a1, 2).contiguous()
            H, C = self.hidden, self.channels
            self.w1 = torch.cat([self.w_a0, self.w_b0p], dim=0).contiguous()   # (2H, C, 5)
            self.b1 = torch.cat([self.b_a0, self.b_b0], dim=0).contiguous()
            self.w2 = torch.cat([self.w_a1p, self.w_b1], dim=0).contiguous()   # (2C, H, 5)
            self.b2 = torch.cat([self.b_a1, self.b_b1], dim=0).contiguous()
        # The shared layers are no longer needed; keep them referenced so nothing is
        # freed while a CUDA graph may still hold pointers into their storage.
        self._keep = lay

    # -- static parameters -------------------------------------------------------
    def stage1(self, joined, fused):
        if fused:
            dup = torch.cat([joined, joined], dim=0)          # (2C, 4+T)
            hidden = F.conv1d(dup, self.w1, self.b1, groups=2)
        else:
            hidden = torch.cat([F.conv1d(joined, self.w_a0, self.b_a0),
                                F.conv1d(joined, self.w_b0p, self.b_b0)], dim=0)
        return F.silu(hidden)

    def stage2(self, win_a, win_b, fused):
        if fused:
            stacked = torch.cat([win_a, win_b], dim=0)       # (2H, 4+T)
            merged = F.conv1d(stacked, self.w2, self.b2, groups=2)
        else:
            merged = torch.cat([F.conv1d(win_a, self.w_a1p, self.b_a1),
                                F.conv1d(win_b, self.w_b1, self.b_b1)], dim=0)
        return merged

    def merge(self, x, branch_a, branch_b):
        # x is (channels, time): the gate is the per-position channel mean, exactly
        # the reference's ``features.mean(dim=1)`` on its (1, channels, time) input.
        gate = torch.sigmoid(x.mean(dim=0, keepdim=True))
        return gate * branch_a + (1 - gate) * branch_b + 0.1 * x


class ChunkStreamEngine(_Weights):
    """Per-chunk streaming (reference cadence), fused branches, one host copy/request."""

    bulk = False

    def __init__(self, repository, config, fused=True):
        super().__init__(repository, config)
        self.fused = fused
        self.reset()

    def reset(self):
        self.hist_in = None
        self.hist_a = None
        self.hist_b = None

    def _history(self, x, stored):
        if stored is None:
            return x[:, :1].repeat(1, HIST)
        return stored

    def process(self, feats):
        with torch.inference_mode():
            x_all = torch.from_numpy(np.ascontiguousarray(feats, dtype=np.float32)).to(self.device)
            for i in range(self.n_chunks):
                lo = i * self.chunk
                hi = min(lo + self.chunk, self.length)
                x = x_all[:, lo:hi]
                joined = torch.cat([self._history(x, self.hist_in), x], dim=1)
                hidden = self.stage1(joined, self.fused)
                h_a, h_b = hidden[:self.hidden], hidden[self.hidden:]
                win_a = torch.cat([self._history(h_a, self.hist_a), h_a], dim=1)
                win_b = torch.cat([self._history(h_b, self.hist_b), h_b], dim=1)
                merged = self.stage2(win_a, win_b, self.fused)
                out = self.merge(x, merged[:self.channels], merged[self.channels:])
                # Same history update the reference performs: last (k-1) of the
                # concatenated window, so a short request keeps older samples.
                self.hist_in = joined[:, -HIST:].clone()
                self.hist_a = win_a[:, -HIST:].clone()
                self.hist_b = win_b[:, -HIST:].clone()
                yield i, self.valids[i], out.cpu().numpy()


class WholeEngine(_Weights):
    """One pass over the complete request; chunks are published after it finishes."""

    bulk = True

    def __init__(self, repository, config, fused=True, force_cpu=False):
        super().__init__(repository, config,
                         force_device='cpu' if force_cpu else None)
        self.fused = fused
        self.fresh = True
        self._pad = torch.zeros((self.channels, self.n_chunks * self.chunk),
                                dtype=torch.float32, device=self.device)
        self.reset()

    def reset(self):
        self.hist_in = None
        self.hist_a = None
        self.hist_b = None
        self.fresh = True

    def _windows(self, x):
        if self.fresh:
            win_in = x[:, :1].repeat(1, HIST)
        else:
            win_in = self.hist_in
        joined = torch.cat([win_in, x], dim=1)
        hidden = self.stage1(joined, self.fused)
        h_a, h_b = hidden[:self.hidden], hidden[self.hidden:]
        if self.fresh:
            win_a = torch.cat([h_a[:, :1].repeat(1, HIST), h_a], dim=1)
            win_b = torch.cat([h_b[:, :1].repeat(1, HIST), h_b], dim=1)
        else:
            win_a = torch.cat([self.hist_a, h_a], dim=1)
            win_b = torch.cat([self.hist_b, h_b], dim=1)
        return joined, win_a, win_b

    def _forward(self, x):
        """x: (C, length) on device -> padded chunk-major frames (n_chunks, C, chunk)."""
        joined, win_a, win_b = self._windows(x)
        merged = self.stage2(win_a, win_b, self.fused)
        out = self.merge(x, merged[:self.channels], merged[self.channels:])
        self.hist_in = joined[:, -HIST:].clone()
        self.hist_a = win_a[:, -HIST:].clone()
        self.hist_b = win_b[:, -HIST:].clone()
        self._pad.zero_()
        self._pad[:, :self.length] = out
        return (self._pad.view(self.channels, self.n_chunks, self.chunk)
                .permute(1, 0, 2).contiguous())

    def process(self, feats):
        with torch.inference_mode():
            x = torch.from_numpy(np.ascontiguousarray(feats, dtype=np.float32)).to(self.device)
            frames = self._forward(x)
            arr = frames.cpu().numpy()
        self.fresh = False
        return arr, self.valids


class GraphEngine(WholeEngine):
    """Whole-request pass captured into two CUDA graphs (fresh / history-carrying).

    Both graphs share the static device buffers.  The carry graph also holds the
    host->device copy of the current request and the device->host copy of the padded
    chunk-major output, so a request costs one replay plus one stream sync.
    """

    def __init__(self, repository, config, fused=True):
        super().__init__(repository, config, fused=fused)
        self.hist_a_dev = torch.zeros((self.hidden, HIST), dtype=torch.float32,
                                      device=self.device)
        self.hist_b_dev = torch.zeros((self.hidden, HIST), dtype=torch.float32,
                                      device=self.device)
        self.in_dev = torch.zeros((self.channels, HIST + self.length),
                                  dtype=torch.float32, device=self.device)
        self.in_host = torch.empty((self.channels, HIST + self.length),
                                   dtype=torch.float32, pin_memory=True)
        self.in_host_np = self.in_host.numpy()
        # Separate pinned staging for history-carrying requests: a column slice of
        # a pinned tensor is non-contiguous and torch refuses to capture such a
        # host->device copy into a graph.
        self.in_cur = torch.empty((self.channels, self.length),
                                  dtype=torch.float32, pin_memory=True)
        self.in_cur_np = self.in_cur.numpy()
        self.out_host = torch.empty((self.n_chunks, self.channels, self.chunk),
                                    dtype=torch.float32, pin_memory=True)
        self.frames_dev = torch.zeros((self.n_chunks, self.channels, self.chunk),
                                      dtype=torch.float32, device=self.device)
        self.fresh = True
        self.graph_fresh = self._capture(True)
        self.graph_carry = self._capture(False)
        self.fresh = True

    def reset(self):
        super().reset()

    # NOTE: uses the static buffers only (graph-capture safe).
    def _graph_forward(self, fresh):
        if fresh:
            self.in_dev.copy_(self.in_host, non_blocking=True)
        else:
            self.in_dev[:, HIST:].copy_(self.in_cur, non_blocking=True)
        x = self.in_dev[:, HIST:]
        joined = self.in_dev
        hidden = self.stage1(joined, self.fused)
        h_a, h_b = hidden[:self.hidden], hidden[self.hidden:]
        if fresh:
            win_a = torch.cat([h_a[:, :1].repeat(1, HIST), h_a], dim=1)
            win_b = torch.cat([h_b[:, :1].repeat(1, HIST), h_b], dim=1)
        else:
            win_a = torch.cat([self.hist_a_dev, h_a], dim=1)
            win_b = torch.cat([self.hist_b_dev, h_b], dim=1)
        merged = self.stage2(win_a, win_b, self.fused)
        out = self.merge(x, merged[:self.channels], merged[self.channels:])
        self._pad.zero_()
        self._pad[:, :self.length] = out
        self.frames_dev.copy_(self._pad.view(self.channels, self.n_chunks, self.chunk)
                              .permute(1, 0, 2))
        self.out_host.copy_(self.frames_dev, non_blocking=True)
        self.in_dev[:, :HIST].copy_(self.in_dev[:, self.length:])
        self.hist_a_dev.copy_(win_a[:, -HIST:])
        self.hist_b_dev.copy_(win_b[:, -HIST:])

    def _capture(self, fresh):
        with torch.inference_mode():
            stream = torch.cuda.Stream()
            stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(stream):
                for _ in range(3):
                    self._graph_forward(fresh)
            torch.cuda.current_stream().wait_stream(stream)
            torch.cuda.synchronize()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                self._graph_forward(fresh)
            torch.cuda.synchronize()
        return graph

    def process(self, feats):
        if self.fresh:
            np.copyto(self.in_host_np[:, :HIST], feats[:, :1])
        if self.fresh:
            np.copyto(self.in_host_np[:, HIST:], feats)
        else:
            np.copyto(self.in_cur_np, feats)
        graph = self.graph_fresh if self.fresh else self.graph_carry
        graph.replay()
        torch.cuda.current_stream().synchronize()
        self.fresh = False
        return self.out_host.numpy(), self.valids


ENGINES = {
    'chunk_stream': lambda r, c: ChunkStreamEngine(r, c, fused=False),
    'chunk_fused': lambda r, c: ChunkStreamEngine(r, c, fused=True),
    'whole': lambda r, c: WholeEngine(r, c, fused=False),
    'whole_fused': lambda r, c: WholeEngine(r, c, fused=True),
    'whole_cpu': lambda r, c: WholeEngine(r, c, fused=True, force_cpu=True),
    'graph_unfused': lambda r, c: GraphEngine(r, c, fused=False),
    'graph_fused': lambda r, c: GraphEngine(r, c, fused=True),
}

DEFAULT_ENGINE = 'graph_fused'


def make_engine(name, repository, config):
    if name not in ENGINES:
        raise ValueError(f'unknown engine variant {name!r}; known: {sorted(ENGINES)}')
    return ENGINES[name](repository, config)
