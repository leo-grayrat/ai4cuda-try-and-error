"""One-off source patch: gate averages over channels, not time (engine works batch-free)."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / 'engine.py'
src = path.read_text(encoding='utf-8')
old = "        gate = torch.sigmoid(x.mean(dim=1, keepdim=True))\n"
new = ("        # x is (channels, time): the gate is the per-position channel mean, exactly\n"
       "        # the reference's ``features.mean(dim=1)`` on its (1, channels, time) input.\n"
       "        gate = torch.sigmoid(x.mean(dim=0, keepdim=True))\n")
assert src.count(old) == 1
path.write_text(src.replace(old, new), encoding='utf-8')
print('patched', path)
