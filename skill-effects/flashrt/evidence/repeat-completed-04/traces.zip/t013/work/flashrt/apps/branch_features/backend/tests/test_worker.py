"""Phase-4 correctness harness: candidate worker vs reference backend vs CPU oracle.

Six complete requests are driven through the supplied adapter, in three sessions so
that cross-request continuation, a repeated input without reset, a reset, and the tail
chunk (length 1043 = 8*127 + 27) are all exercised.  The oracle is
``branch_features.model.full_sequence_oracle`` on the concatenation of each session,
which is exactly the dependency structure of the reference (causal filters with
(kernel-1) replicate padding at a session start and infinite carry across requests).

Tolerance: 2e-5 absolute on fp32 activations.  GPU cuDNN convolutions and the CPU
reference differ only through reduction/algorithm ordering (non-associative fp32
sums); the measured reference-vs-oracle difference is ~2e-7, so 2e-5 leaves two orders
of magnitude of margin while still catching any real dependency error (a wrong
history, swapped branch, or chunk-boundary bug shifts values by O(1)).
"""
import argparse
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (CHANNELS, LENGTH, REPO, REFERENCE, WORKER, drive, make_config,
                    repo_root)

TOL = 2e-5
LOG_DIR = Path(__file__).resolve().parent / 'logs'


def build_fixture():
    import torch
    gen = torch.Generator().manual_seed(11)
    requests = [torch.randn(CHANNELS, LENGTH, generator=gen).numpy().astype(np.float32)
                for _ in range(4)]
    sessions = [[0, 1, 2, 0], [0], [3]]
    return requests, sessions


def build_oracle(requests, sessions):
    from branch_features.model import full_sequence_oracle
    cfg = make_config()
    outputs = []
    for session in sessions:
        joined = np.concatenate([requests[i] for i in session], axis=1)
        whole = full_sequence_oracle(str(REPO), cfg, joined)
        for k in range(len(session)):
            outputs.append(whole[:, k * LENGTH:(k + 1) * LENGTH])
    return outputs


def compare(name, outputs, oracle):
    worst_abs, worst_idx = 0.0, -1
    for i, (got, want) in enumerate(zip(outputs, oracle)):
        if got.shape != want.shape:
            print(f'  [{name}] request {i}: shape {got.shape} != {want.shape}')
            return False, float('inf')
        diff = float(np.max(np.abs(got - want)))
        scale = float(np.max(np.abs(want))) or 1.0
        print(f'  [{name}] request {i}: max_abs_diff={diff:.3e} '
              f'rel={diff / scale:.3e} (tail chunk diff='
              f'{float(np.max(np.abs(got[:, -LENGTH % 127 or 127:] - want[:, -LENGTH % 127 or 127:]))):.3e})')
        if diff > worst_abs:
            worst_abs, worst_idx = diff, i
    ok = worst_abs <= TOL
    print(f'  [{name}] worst max_abs_diff={worst_abs:.3e} at request {worst_idx} '
          f'(tolerance {TOL:.0e})')
    return ok, worst_abs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variants', default='graph_fused')
    parser.add_argument('--skip-reference', action='store_true')
    args = parser.parse_args()
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    requests, sessions = build_fixture()
    t0 = time.perf_counter()
    oracle = build_oracle(requests, sessions)
    print(f'oracle built for {len(oracle)} requests in {time.perf_counter() - t0:.2f}s',
          flush=True)

    verdicts = {}
    if not args.skip_reference:
        cfg = make_config()
        log = LOG_DIR / 'reference.log'
        outs = drive(cfg, requests, sessions, script=REFERENCE, log_path=str(log))
        ok, worst = compare('reference', outs, oracle)
        print(f'reference backend: {"PASS" if ok else "FAIL"}  log={log}', flush=True)
        verdicts['reference'] = ok

    for variant in [v.strip() for v in args.variants.split(',') if v.strip()]:
        cfg = make_config()
        log = LOG_DIR / f'{variant}.log'
        outs = drive(cfg, requests, sessions, variant=variant, log_path=str(log))
        ok, worst = compare(variant, outs, oracle)
        print(f'{variant}: {"PASS" if ok else "FAIL"}  log={log}', flush=True)
        verdicts[variant] = ok

    print('VERDICT: ' + ('PASS' if all(verdicts.values()) else 'FAIL') + ' ' +
          str({k: ('PASS' if v else 'FAIL') for k, v in verdicts.items()}), flush=True)
    return 0 if all(verdicts.values()) else 1


if __name__ == '__main__':
    sys.exit(main())
