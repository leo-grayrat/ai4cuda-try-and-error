"""Shared harness utilities: launch a backend, drive it through the shared adapter."""
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid

import numpy as np

try:  # keep harness output decodable regardless of the Windows console code page
    sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
    sys.stderr.reconfigure(encoding='utf-8', errors='backslashreplace')
except Exception:
    pass


def repo_root():
    try:
        from flashrt.paths import repo_root as _rr
        return Path(_rr())
    except Exception:
        return Path(__file__).resolve().parents[5]


REPO = repo_root()
APP = REPO / 'flashrt' / 'apps' / 'branch_features'
WORKER = APP / 'backend' / 'worker.py'
REFERENCE = APP / 'reference.py'

CHANNELS, HIDDEN, LENGTH, CHUNK, SEED = 16, 32, 1043, 127, 1234


def make_config(prefix=None, device='cuda'):
    return {
        'prefix': prefix or f'bf_{uuid.uuid4().hex[:10]}',
        'channels': CHANNELS,
        'hidden': HIDDEN,
        'length': LENGTH,
        'chunk': CHUNK,
        'device': device,
        'weight_seed': SEED,
    }


def write_config(config, path):
    path = Path(path)
    path.write_text(json.dumps(config), encoding='utf-8')
    return path


def _names(prefix):
    out = [f'{prefix}__ctrl']
    for buf in ('_input', '_output', '_metadata'):
        out.append(f'{prefix}{buf}__meta')
        out.append(f'{prefix}{buf}__tensor')
    return out


def cleanup_shm(prefix):
    """Best-effort removal of this run's shared-memory segments."""
    from multiprocessing import shared_memory
    for name in _names(prefix):
        try:
            shm = shared_memory.SharedMemory(name=name, create=False)
        except (FileNotFoundError, OSError):
            continue
        try:
            shm.close()
            shm.unlink()
        except Exception:
            pass


_CREATE_NEW_PROCESS_GROUP = getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)


def launch(script, config_path, variant=None, log_path=None):
    cmd = [sys.executable, str(script), '--repository', str(REPO),
           '--config', str(config_path)]
    if variant:
        cmd += ['--variant', variant]
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = env.get('CUDA_VISIBLE_DEVICES', '0')
    env['PYTHONIOENCODING'] = 'utf-8'
    log = open(log_path, 'wb') if log_path else None
    proc = subprocess.Popen(cmd, stdout=log or subprocess.DEVNULL,
                            stderr=log or subprocess.DEVNULL,
                            creationflags=_CREATE_NEW_PROCESS_GROUP, env=env)
    return proc, log


def stop(proc, log=None, adapter=None):
    if adapter is not None:
        try:
            adapter.terminate()
        except Exception:
            pass
    try:
        proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass
    if log is not None:
        try:
            log.close()
        except Exception:
            pass


def drive(config, requests, sessions, variant=None, script=None, log_path=None,
          on_chunk=None):
    """Drive one backend through the adapter over several sessions.

    ``requests`` is a list of (channels, length) float32 arrays; ``sessions`` a list of
    lists of request indices (a reset separates sessions).  Returns one full-length
    output array per request, flattened in session order.
    """
    from branch_features.adapter import FeatureAdapter

    script = script or WORKER
    cfg_path = write_config(config, Path(str(log_path) + '.json') if log_path
                            else f'{config["prefix"]}.json')
    outputs = []
    proc, log = launch(script, cfg_path, variant=variant, log_path=log_path)
    adapter = None
    try:
        adapter = FeatureAdapter(config)
        adapter.start()
        for s_idx, session in enumerate(sessions):
            if s_idx:
                adapter.reset()
            for index in session:
                adapter.submit(requests[index])
                full = np.zeros((config['channels'], config['length']), dtype=np.float32)
                while adapter.pending is not None:
                    chunk_index = adapter.pending['chunk']
                    data, observed_ns = adapter.receive(timeout_s=60)
                    pos = chunk_index * config['chunk']
                    full[:, pos:pos + data.shape[1]] = data
                    if on_chunk is not None:
                        on_chunk(s_idx, index, chunk_index, observed_ns, data)
                outputs.append(full)
    finally:
        stop(proc, log, adapter)
        if adapter is not None:
            try:
                adapter.close()
            except Exception:
                pass
        cleanup_shm(config['prefix'])
    return outputs
