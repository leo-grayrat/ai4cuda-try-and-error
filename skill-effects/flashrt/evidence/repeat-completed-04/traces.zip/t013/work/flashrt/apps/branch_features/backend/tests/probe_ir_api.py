import inspect
from flashrt.ir import graph as g
for name in ('IRGraph', 'IROperator', 'StateObject', 'IREdge', 'TensorPort'):
    obj = getattr(g, name)
    print(name, inspect.signature(obj.__init__))
for meth in ('add_operator', 'add_edge', 'add_state_object', 'validate', 'add_external_output'):
    fn = getattr(g.IRGraph, meth, None)
    print('IRGraph.' + meth, inspect.signature(fn) if fn else 'MISSING')
print('IRGraph attrs', [a for a in dir(g.IRGraph) if not a.startswith('_')])
print('StateObject attrs', [a for a in dir(g.StateObject) if not a.startswith('_')])
print('IREdge attrs', [a for a in dir(g.IREdge) if not a.startswith('_')])
