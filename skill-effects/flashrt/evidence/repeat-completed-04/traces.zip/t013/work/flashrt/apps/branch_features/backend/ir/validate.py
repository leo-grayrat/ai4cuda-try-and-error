"""Run the IR conversion/validation with a one-line fix applied to graph_builder.py.

The executor returns tensors that still carry ``requires_grad`` (the reference
modules are not wrapped in ``inference_mode``), so the collected outputs need
``detach()`` before ``numpy()``.  The replacement is applied to the file itself so
``graph_builder.py`` stays directly runnable afterwards.
"""
import sys
from pathlib import Path

target = Path(__file__).with_name('graph_builder.py')
source = target.read_text(encoding='utf-8')
source = source.replace("got = result['merged'].squeeze(0).numpy()",
                        "got = result['merged'].squeeze(0).detach().numpy()")
target.write_text(source, encoding='utf-8')

sys.argv = [str(target)]
code = compile(target.read_text(encoding='utf-8'), str(target), 'exec')
exec(code, {'__name__': '__main__', '__file__': str(target)})  # noqa: S102
