"""Compare each internal stage of the engine against the reference layer stack (CPU)."""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))
from common import LENGTH, REPO, make_config  # noqa: E402

import engine as engine_mod  # noqa: E402

cfg = make_config(device='cpu')
gen = torch.Generator().manual_seed(21)
feats = torch.randn(16, LENGTH, generator=gen).numpy().astype(np.float32)
x = torch.from_numpy(feats)

from branch_features.model import build_layers, gate_and_merge  # noqa: E402

layers = build_layers(str(REPO), cfg, 'cpu')
vals = x.unsqueeze(0)
with torch.inference_mode():
    hA_ref = F.silu(layers['a0'](vals))
    hB_ref = F.silu(layers['b0'](vals))
    A_ref = layers['a1'](hA_ref)
    B_ref = layers['b1'](hB_ref)
    out_ref = gate_and_merge(vals, A_ref, B_ref).squeeze(0)

eng = engine_mod.make_engine('whole', str(REPO), cfg)
H, C = eng.hidden, eng.channels
joined, win_a, win_b = eng._windows(x)
hidden = eng.stage1(joined, False)
hA_mine, hB_mine = hidden[:H], hidden[H:]
merged = eng.stage2(win_a, win_b, False)
A_mine, B_mine = merged[:C], merged[C:]
out_mine = eng.merge(x, A_mine, B_mine)


def d(name, a, b):
    a = a.detach().reshape(-1)
    b = b.detach().reshape(-1)
    print(f'{name}: max_abs={float((a - b).abs().max()):.3e} '
          f'corr={float(torch.corrcoef(torch.stack([a, b]))[0, 1]):.6f}')


with torch.inference_mode():
    d('hA (silu(a0))', hA_mine, hA_ref.squeeze(0))
    d('hB (silu(b0))', hB_mine, hB_ref.squeeze(0))
    d('A (a1)', A_mine, A_ref.squeeze(0))
    d('B (b1)', B_mine, B_ref.squeeze(0))
    d('out', out_mine, out_ref)
    d('A_mine vs B_ref', A_mine, B_ref.squeeze(0))
    d('B_mine vs A_ref', B_mine, A_ref.squeeze(0))
    win_a2 = torch.cat([hA_mine[:, :1].repeat(1, 2), hA_mine], dim=1)
    print('A via 2-history window max diff',
          float((F.conv1d(win_a2.unsqueeze(0), layers['a1'].conv.weight,
                          layers['a1'].conv.bias) - A_ref).abs().max()))
    print('B via 4-history window max diff',
          float((F.conv1d(win_b.unsqueeze(0), layers['b1'].conv.weight,
                          layers['b1'].conv.bias) - B_ref).abs().max()))
    gate_ref = torch.sigmoid(vals.mean(dim=1, keepdim=True))
    gate_mine = torch.sigmoid(x.mean(dim=1, keepdim=True))
    d('gate', gate_mine, gate_ref.squeeze(0))
