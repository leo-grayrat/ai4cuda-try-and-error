"""Phase-1 IR conversion and Phase-2 validation for branch_features.

Two graphs are built from ``branch_features.model.ReferencePipeline``:

* **model graph** (``branch_features_model``) - the four causal convolutions with
  their own (kernel-1)-sample histories, the two SiLUs, and the gate/merge.  The
  history state objects are ``chunk_persistent`` (each conv keeps its own buffer
  across chunks *and* across requests; ``reset`` clears them), the gate is
  ``ephemeral``.
* **worker graph** (``branch_features_worker``) - the high-level stage schedule:
  ``branch_a`` (COMPOSITE, sub-graph = model graph) and ``branch_b`` (COMPOSITE)
  run on disjoint history state and only meet in ``gate_merge`` (EXPOSED), which
  also consumes the current input features.

Running this module as a script validates the executor against the reference
backend driven through the shared adapter (Phase 2) and prints the
``summarize_graph`` analysis that the deployment variants are derived from.
This file is both the IR conversion and its validation harness (the observation
had a hard request cap, so they share one entry point).

    python flashrt/apps/branch_features/backend/ir/graph_builder.py
"""
import hashlib
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from flashrt.ir import (IRGraph, IREdge, IROperator, OpType, SequentialExecutor,
                        StateObject, StreamMode, TensorPort, summarize_graph)

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'tests'))
sys.path.insert(0, str(HERE.parent))

import common  # noqa: E402

TOL = 2e-5


# --------------------------------------------------------------------------- ops
class CausalConvOp(IROperator):
    """One ``CausalConv1d`` plus its own (kernel-1)-sample history state."""

    def __init__(self, name, layer, state_name, channels_in, channels_out, kernel):
        super().__init__(
            name=name, op_type=OpType.EXPOSED,
            inputs=[TensorPort('features', ('batch', channels_in, 'time'))],
            outputs=[TensorPort('y', ('batch', channels_out, 'time'))],
            state_reads=[state_name], state_writes=[state_name],
            stream_mode=StreamMode.STREAMING,
            config={'kernel': kernel, 'channels_in': channels_in,
                    'channels_out': channels_out})
        self.layer = layer
        self.state_name = state_name
        self.hist_len = kernel - 1

    def run(self, x, state):
        hist = state.get(self.state_name)
        joined = x if hist is None else torch.cat([hist, x], dim=-1)
        y = self.layer(joined)
        if hist is not None:
            y = y[:, :, hist.shape[-1]:]
        state.set(self.state_name, joined[:, :, -self.hist_len:].clone())
        return y

    def execute(self, inputs, ctx, state):
        return {'y': self.run(inputs['features'], state)}


class ActOp(IROperator):
    def __init__(self, name):
        super().__init__(name=name, op_type=OpType.EXPOSED,
                         inputs=[TensorPort('x')], outputs=[TensorPort('y')],
                         stream_mode=StreamMode.STREAMING)

    def execute(self, inputs, ctx, state):
        return {'y': F.silu(inputs['x'])}


class GateMergeOp(IROperator):
    """gate = sigmoid(channel mean of the current features); out = g*A+(1-g)*B+0.1*x."""

    def __init__(self, name='gate_merge'):
        super().__init__(name=name, op_type=OpType.EXPOSED,
                         inputs=[TensorPort('a'), TensorPort('b'),
                                 TensorPort('features')],
                         outputs=[TensorPort('merged')],
                         state_writes=['gate'], stream_mode=StreamMode.BATCH)

    def execute(self, inputs, ctx, state):
        features = inputs['features']
        gate = torch.sigmoid(features.mean(dim=1, keepdim=True))
        state.set('gate', gate)
        merged = gate * inputs['a'] + (1 - gate) * inputs['b'] + 0.1 * features
        return {'merged': merged}


class BranchOp(IROperator):
    """COMPOSITE stage: conv0 -> SiLU -> conv1 for one branch."""

    def __init__(self, name, conv0, conv1, state_names, sub_graph):
        super().__init__(name=name, op_type=OpType.COMPOSITE,
                         inputs=[TensorPort('features')],
                         outputs=[TensorPort('y')],
                         state_reads=list(state_names), state_writes=list(state_names),
                         stream_mode=StreamMode.STREAMING, sub_graph=sub_graph)
        self.conv0, self.conv1 = conv0, conv1

    def execute(self, inputs, ctx, state):
        hidden = F.silu(self.conv0.run(inputs['features'], state))
        return {'y': self.conv1.run(hidden, state)}


# ---------------------------------------------------------------------- builders
HISTORY_STATES = ('hist_a0', 'hist_a1', 'hist_b0', 'hist_b1')


def build_model_graph(layers):
    g = IRGraph(name='branch_features_model')
    for name in HISTORY_STATES:
        g.add_state(StateObject(name, f'causal history for {name[5:]}',
                                scope='chunk_persistent'))
    g.add_state(StateObject('gate', 'per-position gate for this chunk',
                            scope='ephemeral'))
    ops = [
        CausalConvOp('conv_a0', layers['a0'], 'hist_a0', 16, 32, 5),
        ActOp('act_a'),
        CausalConvOp('conv_a1', layers['a1'], 'hist_a1', 32, 16, 3),
        CausalConvOp('conv_b0', layers['b0'], 'hist_b0', 16, 32, 3),
        ActOp('act_b'),
        CausalConvOp('conv_b1', layers['b1'], 'hist_b1', 32, 16, 5),
        GateMergeOp(),
    ]
    for op in ops:
        g.add_operator(op)
    g.add_edge(IREdge('conv_a0', 'y', 'act_a', 'x'))
    g.add_edge(IREdge('act_a', 'y', 'conv_a1', 'features'))
    g.add_edge(IREdge('conv_b0', 'y', 'act_b', 'x'))
    g.add_edge(IREdge('act_b', 'y', 'conv_b1', 'features'))
    g.add_edge(IREdge('conv_a1', 'y', 'gate_merge', 'a'))
    g.add_edge(IREdge('conv_b1', 'y', 'gate_merge', 'b'))
    g.external_inputs = [TensorPort('features')]
    g.external_outputs = [TensorPort('merged')]
    g.chunk_ops = [op.name for op in ops]
    return g


def build_worker_graph(layers, model_graph):
    g = IRGraph(name='branch_features_worker')
    for name in HISTORY_STATES:
        g.add_state(StateObject(name, f'causal history for {name[5:]}',
                                scope='chunk_persistent'))
    g.add_state(StateObject('gate', 'per-position gate for this chunk',
                            scope='ephemeral'))
    branch_a = BranchOp('branch_a',
                        CausalConvOp('a0', layers['a0'], 'hist_a0', 16, 32, 5),
                        CausalConvOp('a1', layers['a1'], 'hist_a1', 32, 16, 3),
                        ('hist_a0', 'hist_a1'), 'branch_features_model')
    branch_b = BranchOp('branch_b',
                        CausalConvOp('b0', layers['b0'], 'hist_b0', 16, 32, 3),
                        CausalConvOp('b1', layers['b1'], 'hist_b1', 32, 16, 5),
                        ('hist_b0', 'hist_b1'), 'branch_features_model')
    merge = GateMergeOp()
    for op in (branch_a, branch_b, merge):
        g.add_operator(op)
    g.add_edge(IREdge('branch_a', 'y', 'gate_merge', 'a'))
    g.add_edge(IREdge('branch_b', 'y', 'gate_merge', 'b'))
    g.external_inputs = [TensorPort('features')]
    g.external_outputs = [TensorPort('merged')]
    g.chunk_ops = ['branch_a', 'branch_b', 'gate_merge']
    g.sub_graphs['branch_features_model'] = model_graph
    return g


# ------------------------------------------------------------------- validation
def sha(array):
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()[:16]


def run_executor(graph, features, chunk, layers):
    """Run the executor chunk-wise over one session; returns (C, T) output."""
    executor = SequentialExecutor(graph)
    executor.init_state({name: None for name in HISTORY_STATES})
    executor.init_state({'gate': None})
    ctx = {'layers': layers}
    total = features.shape[1]
    out = np.zeros((features.shape[0], total), dtype=np.float32)
    for pos in range(0, total, chunk):
        block = torch.from_numpy(features[:, pos:pos + chunk]).unsqueeze(0)
        result = executor.run_chunk({'features': block}, ctx)
        got = result['merged'].squeeze(0).detach().numpy()
        out[:, pos:pos + got.shape[-1]] = got
    return out


def main():
    cfg = common.make_config()
    from branch_features.model import build_layers, full_sequence_oracle

    gen = torch.Generator().manual_seed(31)
    requests = [torch.randn(16, common.LENGTH, generator=gen).numpy().astype(np.float32)
                for _ in range(3)]
    session = np.concatenate(requests, axis=1)          # continuity across requests
    layers = build_layers(str(common.REPO), cfg, 'cpu')
    want = full_sequence_oracle(str(common.REPO), cfg, session)
    print(f'oracle built: session {session.shape} sha={sha(want)}', flush=True)

    model_graph = build_model_graph(layers)
    worker_graph = build_worker_graph(layers, model_graph)
    ok = True

    ir_model = run_executor(model_graph, session, cfg['chunk'], layers)
    d = float(np.max(np.abs(ir_model - want)))
    print(f'model-graph executor vs oracle: max_abs={d:.3e} sha={sha(ir_model)}', flush=True)
    ok &= d <= TOL

    try:
        ir_worker = run_executor(worker_graph, session, cfg['chunk'], layers)
        d = float(np.max(np.abs(ir_worker - want)))
        print(f'worker-graph executor vs oracle: max_abs={d:.3e} sha={sha(ir_worker)}',
              flush=True)
        ok &= d <= TOL
    except Exception as exc:  # noqa: BLE001
        print(f'worker-graph executor FAILED: {exc!r}', flush=True)
        ok = False

    # Reference backend through the adapter, same session, same inputs.
    ref_log = HERE.parent / 'tests' / 'logs' / 'ir_reference.log'
    ref_log.parent.mkdir(parents=True, exist_ok=True)
    ref_outs = common.drive(common.make_config(), requests, [[0, 1, 2]],
                            script=common.REFERENCE, log_path=str(ref_log))
    ref_full = np.concatenate(ref_outs, axis=1)
    d_ref = float(np.max(np.abs(ref_full - want)))
    print(f'reference backend vs oracle: max_abs={d_ref:.3e} sha={sha(ref_full)}', flush=True)
    d_ir = float(np.max(np.abs(ir_model - ref_full)))
    print(f'model-graph executor vs reference backend: max_abs={d_ir:.3e}', flush=True)
    ok &= d_ref <= TOL and d_ir <= TOL

    # Candidate worker (shipped default variant) through the adapter.
    cand_log = HERE.parent / 'tests' / 'logs' / 'ir_candidate.log'
    cand_outs = common.drive(common.make_config(), requests, [[0, 1, 2]],
                             log_path=str(cand_log))
    cand_full = np.concatenate(cand_outs, axis=1)
    d_cand = float(np.max(np.abs(cand_full - want)))
    print(f'candidate worker vs oracle: max_abs={d_cand:.3e} sha={sha(cand_full)} '
          f'log={cand_log}', flush=True)
    ok &= d_cand <= TOL

    for name, graph in (('worker', worker_graph), ('model', model_graph)):
        print(f'\n=== summarize_graph({name}) ===', flush=True)
        try:
            print(summarize_graph(graph), flush=True)
        except Exception as exc:  # noqa: BLE001
            print(f'summarize_graph({name}) unavailable: {exc!r}', flush=True)

    print(f'\nIR VALIDATION: {"PASS" if ok else "FAIL"} '
          f'(tolerance {TOL:.0e}; fp32 conv ordering only)', flush=True)
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
