"""Environment / baseline probe for branch_features (diagnostic only)."""
import json
import sys
import time
from pathlib import Path

import torch

REPO = Path(__file__).resolve().parents[5]


def main():
    print(json.dumps({
        'torch': torch.__version__,
        'cuda': torch.version.cuda,
        'available': torch.cuda.is_available(),
        'device_count': torch.cuda.device_count(),
        'name': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        'cudnn': torch.backends.cudnn.version(),
        'threads': torch.get_num_threads(),
    }), flush=True)
    if not torch.cuda.is_available():
        return
    from branch_features.model import ReferencePipeline, full_sequence_oracle
    cfg = {'channels': 16, 'hidden': 32, 'length': 1043, 'chunk': 127,
           'device': 'cuda', 'weight_seed': 1234, 'prefix': 'probe_bf'}
    pipe = ReferencePipeline(str(REPO), cfg)
    rng = torch.Generator().manual_seed(7)
    feats = torch.randn(cfg['channels'], cfg['length'], generator=rng).numpy().astype('float32')
    for _ in range(2):
        t0 = time.perf_counter()
        out = pipe.step(feats[:, :127])
        torch.cuda.synchronize()
        t1 = time.perf_counter()
        print(f'chunk0 gpu {1e3 * (t1 - t0):.3f} ms', flush=True)
    pipe.reset()
    t0 = time.perf_counter()
    outs = []
    n_chunks = 0
    for pos in range(0, cfg['length'], cfg['chunk']):
        outs.append(pipe.step(feats[:, pos:pos + cfg['chunk']]))
        n_chunks += 1
    t1 = time.perf_counter()
    print(f'reference full request ({n_chunks} chunks): {1e3 * (t1 - t0):.3f} ms', flush=True)
    print(f'per chunk {1e3 * (t1 - t0) / n_chunks:.3f} ms', flush=True)

    # eager full-sequence equivalent on GPU, weights copied out of the pipeline
    layers = pipe.layers
    vals = torch.from_numpy(feats).unsqueeze(0).cuda()
    import torch.nn.functional as F
    for _ in range(3):
        t0 = time.perf_counter()
        with torch.inference_mode():
            a = layers['a1'](F.silu(layers['a0'](vals)))
            b = layers['b1'](F.silu(layers['b0'](vals)))
            gate = torch.sigmoid(vals.mean(dim=1, keepdim=True))
            out = gate * a + (1 - gate) * b + 0.1 * vals
            torch.cuda.synchronize()
        t1 = time.perf_counter()
        print(f'whole eager gpu: {1e3 * (t1 - t0):.3f} ms', flush=True)

    oracle = full_sequence_oracle(str(REPO), cfg, feats)
    joined = npconcat(outs, cfg)
    print('ref-chunked vs oracle max abs diff', float(abs(joined - oracle).max()), flush=True)
    print('whole-eager vs oracle max abs diff',
          float(abs(out.squeeze(0).cpu().numpy() - oracle).max()), flush=True)


def npconcat(outs, cfg):
    import numpy as np
    full = np.zeros((cfg['channels'], cfg['length']), dtype='float32')
    for i, o in enumerate(outs):
        full[:, i * cfg['chunk']:i * cfg['chunk'] + o.shape[-1]] = o
    return full


if __name__ == '__main__':
    main()
