"""Standalone optimized worker for branch_features.

Usage::

    python flashrt/apps/branch_features/backend/worker.py \
        --repository <repo root> --config <config.json>

Honours exactly the adapter contract at ``branch_features/adapter.py`` (which reuses
``causal_features.adapter``): creates the same shared-memory control / input / output /
metadata buffers, consumes opcodes 1 (start), 3 (reset), 2 (terminate) with the same
level-valued commit discipline, reads one complete feature sequence per request and
publishes ``ceil(length/chunk)`` output chunks in order with ``(request, index, valid)``
metadata.  Session histories survive across requests and are cleared by reset.

The compute engine is selectable for experiments (``--variant`` or the
``BRANCH_FEATURES_VARIANT`` environment variable); the default is the recommended
variant.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time


def _load_engine_factory(repository):
    try:
        from branch_features.backend import engine as engine_mod
        return engine_mod
    except Exception:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import engine as engine_mod
        return engine_mod


def _pause(state):
    """Idle wait that stays cheap but keeps request pickup latency low.

    Windows timer granularity makes ``time.sleep(0.0002)`` cost about a millisecond,
    which would dominate a sub-millisecond backend, so a short spin (yielding with
    ``sleep(0)``) is used right after activity and the coarser sleep only when the
    backend has been idle for a while.
    """
    idle = state[0] + 1
    state[0] = idle
    if idle < 4000:
        time.sleep(0)
    else:
        time.sleep(0.0002)
    return idle


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--variant', type=str, default=None)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))

    import numpy as np
    import torch
    from branch_features.adapter import open_buffers, close_buffers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    engine_mod = _load_engine_factory(args.repository)
    variant = args.variant or os.environ.get('BRANCH_FEATURES_VARIANT',
                                             engine_mod.DEFAULT_ENGINE)
    engine = engine_mod.make_engine(variant, str(args.repository), config)

    channels, chunk, length = config['channels'], config['chunk'], config['length']
    n_chunks = (length + chunk - 1) // chunk
    pad = np.zeros((channels, chunk), dtype=np.float32)
    meta = np.zeros((3,), dtype=np.int64)

    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    idle = [0]
    try:
        print(json.dumps({'ready': True, 'device': config['device'], 'task': 'branch_features',
                          'variant': variant}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    engine.reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                _pause(idle)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                _pause(idle)
                continue
            idle[0] = 0
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id, consumed = consumed, next_cursor
            if engine.bulk:
                frames, valids = engine.process(features[0])
                buffers['output'].write(frames)
                block = np.empty((n_chunks, 3), dtype=np.int64)
                block[:, 0] = request_id
                block[:, 1] = np.arange(n_chunks)
                block[:, 2] = valids
                buffers['metadata'].write(block)
            else:
                for index, valid, out in engine.process(features[0]):
                    pad[:, :valid] = out
                    buffers['output'].write(pad)
                    meta[0], meta[1], meta[2] = request_id, index, valid
                    buffers['metadata'].write(meta)
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
