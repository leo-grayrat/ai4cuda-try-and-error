"""Optimized sequential backend for causal_features (single GPU).

Same IPC/adapter contract as reference.py.  Differences:
  * per-layer state kept in preallocated history tensors (one copy per chunk,
    concatenation only of history+chunk, no full-graph tensor retention);
  * one reusable padded output buffer instead of np.zeros per chunk;
  * input moved to GPU once per request, not once per chunk;
  * tight hybrid spin/sleep polling for low chunk-gap latency.
"""
import argparse
import json
from pathlib import Path
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repository.resolve()))
    import numpy as np
    import torch
    import torch.nn.functional as F
    from causal_features.adapter import open_buffers, close_buffers
    from causal_features.model import build_layers

    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    device = config['device']
    layers = build_layers(args.repository, config, device)
    pads = [layer._time_causal_padding[0] for layer in layers]
    histories = [None] * len(layers)

    channels, length, chunk = config['channels'], config['length'], config['chunk']
    padded = np.zeros((channels, chunk), dtype=np.float32)

    def reset():
        for i in range(len(histories)):
            histories[i] = None

    @torch.inference_mode()
    def step(value):
        for index, layer in enumerate(layers):
            history = histories[index]
            joined = value if history is None else torch.cat([history, value], dim=-1)
            result = layer(joined)
            if history is not None:
                result = result[:, :, history.shape[-1]:]
            histories[index] = joined[:, :, -pads[index]:].clone()
            value = F.silu(result)
        return value

    buffers = open_buffers(config, create=True)
    consumed, last_command, active = 0, 0, False
    try:
        print(json.dumps({'ready': True, 'device': device}), flush=True)
        while True:
            opcode = buffers['control'].recv()
            if opcode != last_command:
                last_command = opcode
                if opcode == 2:
                    buffers['control'].commit()
                    break
                if opcode == 3:
                    reset()
                    active = False
                    buffers['control'].commit()
                elif opcode == 1:
                    active = True
                    buffers['control'].commit()
                elif opcode != 0:
                    raise ValueError(f'Unknown control opcode: {opcode}')
            if not active:
                time.sleep(0.0002)
                continue
            next_cursor, features = buffers['input'].read(consumed, 1)
            if features is None:
                time.sleep(0.0002)
                continue
            if next_cursor != consumed + 1:
                raise RuntimeError('Input overwritten before processing')
            request_id = consumed
            consumed = next_cursor
            # One host->device transfer for the whole request.
            gpu = torch.from_numpy(features[0].copy()).to(device)
            for index, position in enumerate(range(0, length, chunk)):
                output = step(gpu[:, position:position + chunk])
                valid = output.shape[-1]
                padded[:, :valid] = output.squeeze(0).cpu().numpy()
                buffers['output'].write(padded)
                buffers['metadata'].write(np.array([request_id, index, valid], dtype=np.int64))
    finally:
        close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
