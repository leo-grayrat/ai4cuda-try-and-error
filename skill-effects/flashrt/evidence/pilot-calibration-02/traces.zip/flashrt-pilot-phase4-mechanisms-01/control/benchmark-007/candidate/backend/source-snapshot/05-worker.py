"""Standalone optimized backend for the causal_features task (single RTX 5060).

Contract: identical to ``causal_features.reference`` -- ``--repository`` and
``--config`` JSON, original FlashRT shared-memory adapter, opcodes 1/3/2.

Optimization summary (all modes keep the exact causal semantics of the
reference; only *when* and *where* arithmetic happens changes):

  chunk  : per-chunk eager loop, weights/histories resident on the GPU and a
           single device->host transfer per chunk.  Removes the reference's
           per-layer H2D copy, per-layer D2H sync, torch.cat of python lists
           and per-chunk module dispatch.
  full   : the whole request is evaluated as one batched causal convolution
           pass (3 conv kernels instead of 3*N_chunks) and only then are the
           chunks published in order.
  hybrid : default.  Chunk 0 is evaluated and published first (minimal
           latency-to-first-output), the remaining samples are evaluated in a
           single batched pass and published (maximal throughput).  Two host
           syncs per request instead of 3*N_chunks.
  graph  : hybrid with the fixed-shape segments replayed from CUDA graphs once
           the session history is primed; falls back to eager on any capture
           failure.

The per-layer causal history is kept on the device and is advanced exactly like
the reference (last ``kernel-1`` samples of the *layer input* stream), so
request-to-request continuation and explicit resets behave identically.

Selected with the ``CF_MODE`` environment variable (default: hybrid).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

DEFAULTS = {
    'channels': 16,
    'hidden': 32,
    'length': 1043,
    'chunk': 127,
    'weight_seed': 703,
    'device': 'cuda:0',
}


def _bootstrap(repo: str):
    """Make ``causal_features.*`` importable regardless of launch cwd."""
    for path in (os.path.join(repo, 'flashrt', 'apps'), repo):
        if path not in sys.path:
            sys.path.insert(0, path)
    import causal_features.adapter as adapter
    import causal_features.model as model
    return adapter, model


class EagerEngine:
    """Three causal layers with device-resident histories, eager PyTorch."""

    def __init__(self, torch, layers, device):
        self.torch = torch
        self.F = torch.nn.functional
        self.dev = device
        self.params = []
        for layer in layers:
            self.params.append(
                (layer.conv.weight.detach(), layer.conv.bias.detach(),
                 layer._time_causal_padding[0], layer.pad_mode))
        self.histories = [None] * len(self.params)

    def reset(self):
        self.histories = [None] * len(self.params)

    def segment(self, x):
        """Run ``x`` (1, C, L) through all layers; returns (1, C, L)."""
        torch = self.torch
        for index, (weight, bias, left, mode) in enumerate(self.params):
            history = self.histories[index]
            joined = x if history is None else torch.cat([history, x], dim=-1)
            result = self.F.conv1d(self.F.pad(joined, (left, 0), mode=mode), weight, bias)
            if history is not None:
                result = result[:, :, history.shape[-1]:]
            self.histories[index] = joined[:, :, -left:].clone()
            x = self.F.silu(result)
        return x


class GraphEngine:
    """Hybrid eager/graph engine.

    The three per-layer history buffers are persistent device tensors and are
    both read and updated in place by the captured graph, so a replay has the
    same side effects as the eager path.  Capturing needs a primed session (a
    real history); the first segment after a reset runs eagerly and seeds the
    buffers.
    """

    def __init__(self, eager, seg_lengths):
        torch = eager.torch
        self.eager = eager
        self.torch = torch
        self.dev = eager.dev
        self.F = torch.nn.functional
        self.buffers = [torch.zeros(1, weight.shape[1], left, device=self.dev)
                        for (weight, _b, left, _m) in eager.params]
        self.graphs = {}
        self.statics = {}
        self.primed = False
        self.ok = False
        try:
            for length in seg_lengths:
                if length > 0:
                    self._capture(int(length))
            self.ok = True
        except Exception as exc:  # pragma: no cover - diagnostic path
            print(json.dumps({'cuda_graph': 'disabled', 'error': repr(exc)}),
                  file=sys.stderr, flush=True)
            self.ok = False
            self.graphs.clear()
            self.statics.clear()

    def reset(self):
        self.eager.reset()
        self.primed = False
        for buffer in self.buffers:
            buffer.zero_()

    def _forward(self, x, out):
        F = self.F
        for index, (weight, bias, left, mode) in enumerate(self.eager.params):
            history = self.buffers[index]
            joined = self.torch.cat([history, x], dim=-1)
            result = F.conv1d(F.pad(joined, (left, 0), mode=mode), weight, bias)
            result = result[:, :, history.shape[-1]:]
            self.buffers[index].copy_(joined[:, :, -left:])
            x = F.silu(result)
        out.copy_(x)

    def _capture(self, length):
        torch = self.torch
        channels = self.eager.params[0][0].shape[1]
        static_x = torch.zeros(1, channels, length, device=self.dev)
        static_out = torch.zeros(1, channels, length, device=self.dev)
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(2):
                self._forward(static_x, static_out)
        torch.cuda.current_stream().wait_stream(side)
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            self._forward(static_x, static_out)
        torch.cuda.synchronize()
        for buffer in self.buffers:
            buffer.zero_()
        self.graphs[length] = graph
        self.statics[length] = {'x': static_x, 'out': static_out}

    def segment(self, x):
        length = int(x.shape[-1])
        if self.ok and self.primed and length in self.graphs:
            static = self.statics[length]
            static['x'].copy_(x)
            self.graphs[length].replay()
            return static['out']
        out = self.eager.segment(x)
        if self.ok and not self.primed:
            for buffer, history in zip(self.buffers, self.eager.histories):
                buffer.copy_(history)
            self.primed = True
        return out


def _publish(array, request_id, chunk_index, chunk, buffers, scratch, metadata):
    import numpy as np
    valid = int(array.shape[-1])
    if valid == chunk:
        np.copyto(scratch, array)
    else:
        scratch.fill(0.0)
        scratch[:, :valid] = array
    # Data first, metadata second: the adapter rejects the opposite order.
    buffers['output'].write(scratch)
    metadata[0] = request_id
    metadata[1] = chunk_index
    metadata[2] = valid
    buffers['metadata'].write(metadata)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()

    repo = str(args.repository.resolve())
    adapter, model = _bootstrap(repo)

    import numpy as np
    import torch

    config = dict(DEFAULTS)
    config.update(json.loads(args.config.read_text(encoding='utf-8')))
    device = config['device']
    if isinstance(device, int):
        device = f'cuda:{device}'
    if device == 'cuda' and not torch.cuda.is_available():
        device = 'cpu'
    mode = os.environ.get('CF_MODE', 'full').strip().lower()

    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False

    layers = model.build_layers(repo, config, device)
    eager = EagerEngine(torch, layers, device)
    chunk = int(config['chunk'])
    length = int(config['length'])
    if mode == 'graph':
        engine = GraphEngine(eager, [min(chunk, length), length - min(chunk, length)])
    else:
        engine = eager
    engine.reset()

    buffers = adapter.open_buffers(config, create=True)
    channels = int(config['channels'])
    scratch = np.zeros((channels, chunk), dtype=np.float32)
    metadata = np.zeros((3,), dtype=np.int64)
    consumed, last_command, active = 0, 0, False
    idle_sleep = float(os.environ.get('CF_IDLE_SLEEP', '0.00002'))
    try:
        with torch.inference_mode():
            # Prewarm every code path a real request can hit, so the first
            # client request is not paying lazy CUDA/cuDNN initialisation.
            warm = torch.zeros(1, channels, length, device=device)
            for first in (0, 1):
                eager.reset()
                eager.segment(warm[:, :, :min(chunk, length)])
                if length > chunk:
                    eager.segment(warm[:, :, min(chunk, length):])
                if isinstance(engine, GraphEngine) and engine.ok and not engine.primed:
                    engine.reset()
                    engine.segment(warm[:, :, :min(chunk, length)])
                    if length > chunk:
                        engine.segment(warm[:, :, min(chunk, length):])
                    engine.reset()
            del warm
            engine.reset()
        print(json.dumps({'ready': True, 'device': device, 'mode': mode}), flush=True)
        with torch.inference_mode():
            while True:
                opcode = buffers['control'].recv()
                if opcode != last_command:
                    last_command = opcode
                    if opcode == 2:
                        buffers['control'].commit()
                        break
                    if opcode == 3:
                        engine.reset()
                        active = False
                        buffers['control'].commit()
                    elif opcode == 1:
                        active = True
                        buffers['control'].commit()
                    elif opcode != 0:
                        raise ValueError(f'Unknown control opcode: {opcode}')
                if not active:
                    time.sleep(idle_sleep)
                    continue
                next_cursor, features = buffers['input'].read(consumed, 1)
                if features is None:
                    time.sleep(idle_sleep)
                    continue
                if next_cursor != consumed + 1:
                    raise RuntimeError('Input overwritten before processing')
                request_id = consumed
                consumed = next_cursor
                total = int(features.shape[-1])
                x = torch.from_numpy(features[0]).unsqueeze(0).to(device)
                chunks = (total + chunk - 1) // chunk
                if mode == 'chunk':
                    for index in range(chunks):
                        start = index * chunk
                        part = x[:, :, start:min(total, start + chunk)]
                        out = engine.segment(part)
                        _publish(out[0].cpu().numpy(), request_id, index,
                                 chunk, buffers, scratch, metadata)
                elif mode == 'full':
                    out = engine.segment(x)[0].cpu().numpy()
                    for index in range(chunks):
                        start = index * chunk
                        _publish(out[:, start:min(total, start + chunk)],
                                 request_id, index, chunk, buffers, scratch, metadata)
                else:  # hybrid / graph
                    first = min(chunk, total)
                    out = engine.segment(x[:, :, :first])
                    _publish(out[0].cpu().numpy(), request_id, 0,
                             chunk, buffers, scratch, metadata)
                    if chunks > 1:
                        rest = engine.segment(x[:, :, first:])[0].cpu().numpy()
                        rest_len = total - first
                        for index in range(1, chunks):
                            local = index - 1
                            start = local * chunk
                            end = min(rest_len, start + chunk)
                            _publish(rest[:, start:end], request_id, index,
                                     chunk, buffers, scratch, metadata)
                del x
    finally:
        adapter.close_buffers(buffers, unlink=True)
        print(json.dumps({'closed': True}), flush=True)


if __name__ == '__main__':
    main()
