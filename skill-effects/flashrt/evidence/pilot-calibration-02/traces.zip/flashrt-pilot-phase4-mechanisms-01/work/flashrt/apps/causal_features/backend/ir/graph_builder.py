"""IR conversion of the causal_features reference backend.

The reference worker has exactly one exposed stage (the 3-layer causal network)
and no other pipeline stage, so the worker-level graph and the model-level graph
coincide: three ``CausalLayerOp`` operators plus a chunk-publication operator.
Each layer owns a separate ``chunk_persistent`` history state object, which is
what the IR analysis uses to reason about cross-chunk dependencies.
"""
import torch
import torch.nn.functional as F

from flashrt.ir import (IRGraph, IREdge, IROperator, OpType, StateObject,
                        StreamMode, TensorPort, ir_operator)


class CausalLayerOp(IROperator):
    def __init__(self, index):
        super().__init__(
            name=f'causal_layer_{index}', op_type=OpType.EXPOSED,
            inputs=[TensorPort('x')], outputs=[TensorPort('y')],
            state_reads=[f'hist_{index}'], state_writes=[f'hist_{index}'],
            stream_mode=StreamMode.STREAMING,
            config={'kernel_history': True})
        self.index = index

    def execute(self, inputs, ctx, state):
        weight, bias, left, mode = ctx.params[self.index]
        x = inputs['x']
        hist = state.get(f'hist_{self.index}')
        joined = x if hist is None else torch.cat([hist, x], dim=-1)
        y = F.conv1d(F.pad(joined, (left, 0), mode=mode), weight, bias)
        if hist is not None:
            y = y[:, :, hist.shape[-1]:]
        state.set(f'hist_{self.index}', joined[:, :, -left:].clone())
        return {'y': F.silu(y)}


@ir_operator(name='publish_chunk', op_type=OpType.EXPOSED,
             inputs=[TensorPort('x')], outputs=[TensorPort('chunk')],
             stream_mode=StreamMode.STREAMING)
def publish_chunk(inputs, ctx, state):
    ctx.outputs.append(inputs['x'])
    return {'chunk': inputs['x']}


def build_graph(layer_count=3):
    graph = IRGraph(name='causal_features')
    layers = []
    for index in range(layer_count):
        graph.add_state(StateObject(f'hist_{index}',
                                    'causal input history of layer',
                                    scope='chunk_persistent'))
        layers.append(CausalLayerOp(index))
    for op in layers:
        graph.add_operator(op)
    graph.add_operator(publish_chunk)
    for src, dst in zip(layers, layers[1:]):
        graph.add_edge(IREdge(src.name, 'y', dst.name, 'x'))
    graph.add_edge(IREdge(layers[-1].name, 'y', 'publish_chunk', 'x'))
    graph.chunk_ops = [op.name for op in layers] + ['publish_chunk']
    graph.external_inputs = [TensorPort('x')]
    graph.external_outputs = [TensorPort('chunk')]
    return graph
