"""Drive reference/candidate backends through the fixed adapter: oracle check +
latency / chunk-gap / offered-load benchmark.  --suite all runs every mode."""
import argparse, json, os, subprocess, sys, time
from pathlib import Path
import numpy as np

REPO = str(Path(__file__).resolve().parents[5])
APPS = os.path.join(REPO, 'flashrt', 'apps')
sys.path[:0] = [APPS, REPO]
from causal_features.adapter import FeatureAdapter
from causal_features.model import full_sequence_oracle
HERE = Path(__file__).resolve().parent
BACKEND = HERE.parent / 'worker.py'
RESULTS = HERE.parent / 'benchmarks' / 'results'
BASE = dict(channels=16, hidden=32, length=1043, chunk=127, weight_seed=703, device='cuda:0')
TOL = dict(atol=3e-5, rtol=3e-4)          # CONTRACT.zh.md CPU/GPU tolerance
BUDGET = 0.020                            # 20 ms chunk-gap budget


def cfg_for(prefix):
    cfg = dict(BASE); cfg['prefix'] = prefix; return cfg


def cleanup(prefix):
    from multiprocessing import shared_memory
    for name in (prefix, prefix + '_input', prefix + '_output', prefix + '_metadata'):
        for suf in ('__ctrl', '__meta', '__tensor'):
            try:
                h = shared_memory.SharedMemory(name=name + suf)
            except Exception:
                continue
            try:
                h.unlink()
            except Exception:
                pass
            h.close()


def launch(kind, cfg, mode=None):
    cleanup(cfg['prefix'])
    path = HERE / 'fixtures' / (cfg['prefix'] + '.json')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(cfg))
    env = os.environ.copy()
    env['PYTHONPATH'] = APPS + os.pathsep + REPO
    env.setdefault('CUDA_VISIBLE_DEVICES', '0')
    if mode:
        env['CF_MODE'] = mode
    cmd = ([sys.executable, '-m', 'causal_features.reference'] if kind == 'reference'
           else [sys.executable, str(BACKEND)])
    cmd += ['--repository', REPO, '--config', str(path)]
    proc = subprocess.Popen(cmd, cwd=REPO, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True)
    try:
        return proc, FeatureAdapter(cfg)
    except BaseException:
        proc.kill(); proc.communicate(); raise


def drive(kind, mode, cfg, actions):
    proc, ad = launch(kind, cfg, mode)
    outs = []
    try:
        ad.start()
        for op, feats in actions:
            if op == 'reset':
                ad.reset(); outs.append(None); continue
            rid, t_in = ad.submit(feats)
            chunks, times = [], []
            while ad.pending is not None:
                data, stamp = ad.receive(timeout_s=60)
                chunks.append(np.ascontiguousarray(data)); times.append(stamp)
            outs.append({'id': rid, 't_in': t_in, 'times': times, 'chunks': chunks})
        ad.terminate(); proc.wait(timeout=30)
    finally:
        if proc.poll() is None:
            proc.kill()
        stdout, stderr = proc.communicate(timeout=20)
        ad.close(); cleanup(cfg['prefix'])
    return outs, stdout, stderr


def check(kind, mode, tag, seed=1234):
    cfg = cfg_for('cf_' + tag)
    rng = np.random.default_rng(seed)
    draw = lambda: rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32)
    a, b, c = draw(), draw(), draw()
    actions = [('req', a), ('req', b), ('reset', None), ('req', a), ('req', c), ('req', b)]
    outs, stdout, stderr = drive(kind, mode, cfg, actions)
    history, produced, worst, ok, max_abs = [], [], 0.0, True, 0.0
    for (op, feats), out in zip(actions, outs):
        if op == 'reset':
            history = []; produced = []; continue
        history.append(feats)
        produced.append(np.concatenate(out['chunks'], -1))
        ref = full_sequence_oracle(REPO, cfg, np.concatenate(history, -1))
        got = np.concatenate(produced, -1)
        err = np.abs(got - ref)
        ok = ok and bool(np.all(err <= TOL['atol'] + TOL['rtol'] * np.abs(ref)))
        worst = max(worst, float((err - TOL['atol'] - TOL['rtol'] * np.abs(ref)).max()))
        max_abs = max(max_abs, float(err.max()))
    repro = float(np.abs(np.concatenate(outs[0]['chunks'], -1)
                         - np.concatenate(outs[3]['chunks'], -1)).max())
    ready = '"ready":true' in stdout.replace(' ', '')
    verdict = 'PASS' if (ok and ready and repro <= 1e-6) else 'FAIL'
    rec = {'tag': tag, 'kind': kind, 'mode': mode, 'verdict': verdict,
           'worst_excess_over_tol': worst, 'max_abs_error': max_abs,
           'reset_reproduction_max_abs': repro, 'tolerance': TOL,
           'stdout_tail': stdout[-300:], 'stderr_tail': stderr[-1200:]}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / ('check_' + tag + '.json')).write_text(json.dumps(rec, indent=1))
    print(json.dumps({k: rec[k] for k in ('tag', 'kind', 'mode', 'verdict',
                                          'worst_excess_over_tol',
                                          'reset_reproduction_max_abs')}), flush=True)
    if verdict != 'PASS':
        print(stderr[-2500:], file=sys.stderr)
    return rec


def measure(kind, mode, tag, n=15, seed=99, intervals=(0.02, 0.01, 0.005, 0.002, 0.001), per=12):
    cfg = cfg_for('cb_' + tag)
    rng = np.random.default_rng(seed)
    actions = [('req', rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32))
               for _ in range(n)]
    outs, stdout, stderr = drive(kind, mode, cfg, actions)
    lat = np.array([(o['times'][0] - o['t_in']) / 1e6 for o in outs])
    turn = np.array([(o['times'][-1] - o['t_in']) / 1e6 for o in outs])
    gaps = np.array([g for o in outs for g in np.diff(o['times'])]) / 1e6
    sweep = []
    proc, ad = launch(kind, cfg, mode)
    try:
        ad.start()
        for interval in intervals:
            feats = [rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32)
                     for _ in range(per)]
            t0 = time.perf_counter(); late, gg, error = [], [], None
            for i in range(per):
                target = t0 + i * interval
                while time.perf_counter() < target:
                    pass
                _rid, _t = ad.submit(feats[i]); late.append((time.perf_counter() - target) * 1e3)
                stamps = []
                try:
                    while ad.pending is not None:
                        _d, stamp = ad.receive(timeout_s=60); stamps.append(stamp)
                except Exception as exc:
                    error = repr(exc); break
                gg.extend(np.diff(stamps).tolist())
            wall = time.perf_counter() - t0
            gg = np.array(gg) / 1e6
            sweep.append({'offered_interval_ms': interval * 1e3,
                          'scheduled_req_per_s': 1.0 / interval,
                          'achieved_req_per_s': per / wall,
                          'median_submit_lateness_ms': float(np.median(late)) if late else None,
                          'gap_median_ms': float(np.median(gg)) if gg.size else None,
                          'gap_p95_ms': float(np.percentile(gg, 95)) if gg.size else None,
                          'gap_over_budget_frac': float(np.mean(gg > BUDGET * 1e3)) if gg.size else None,
                          'error': error})
        ad.terminate(); proc.wait(timeout=30)
    finally:
        if proc.poll() is None:
            proc.kill()
        proc.communicate(); ad.close(); cleanup(cfg['prefix'])
    summary = {'tag': tag, 'kind': kind, 'mode': mode, 'n_requests': n,
               'first_out_ms_median': float(np.median(lat[1:])),
               'first_out_ms_p95': float(np.percentile(lat[1:], 95)),
               'first_out_ms_cold': float(lat[0]),
               'turnaround_ms_median': float(np.median(turn[1:])),
               'turnaround_ms_p95': float(np.percentile(turn[1:], 95)),
               'chunk_gap_ms_median': float(np.median(gaps)) if gaps.size else None,
               'chunk_gap_ms_p95': float(np.percentile(gaps, 95)) if gaps.size else None,
               'chunk_gap_over_budget_frac': float(np.mean(gaps > BUDGET * 1e3)) if gaps.size else None,
               'sweep': sweep, 'stderr_tail': stderr[-500:]}
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / ('bench_' + tag + '.json')).write_text(json.dumps(summary, indent=1))
    print(json.dumps({k: v for k, v in summary.items() if k != 'sweep'}), flush=True)
    for row in sweep:
        print(json.dumps({'tag': tag, 'sweep': row}), flush=True)
    return summary


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--suite', default='all')
    ap.add_argument('--check-only', action='store_true'); ap.add_argument('--bench-only', action='store_true')
    args = ap.parse_args()
    jobs = [('reference', None, 'reference'), ('candidate', 'chunk', 'chunk'),
            ('candidate', 'full', 'full'), ('candidate', 'hybrid', 'hybrid'),
            ('candidate', 'graph', 'graph')]
    if args.suite != 'all':
        jobs = [j for j in jobs if j[2] == args.suite]
    checks = [] if args.bench_only else [check(*j) for j in jobs]
    if not args.check_only:
        for j in jobs:
            measure(*j)
    (RESULTS / 'checks.json').write_text(json.dumps(checks, indent=1))
    print(json.dumps({'verdicts': [(c['tag'], c['verdict']) for c in checks]}), flush=True)
