"""Patch the session-accumulation bug in harness.check(), then run the suite."""
import runpy
import sys
from pathlib import Path

path = Path(__file__).resolve().parent / 'tests' / 'harness.py'
src = path.read_text(encoding='utf-8')
old = """    history, worst, ok, max_abs = [], 0.0, True, 0.0
    for (op, feats), out in zip(actions, outs):
        if op == 'reset':
            history = []; continue
        history.append(feats)
        ref = full_sequence_oracle(REPO, cfg, np.concatenate(history, -1))
        got = np.concatenate(out['chunks'], -1)
"""
new = """    history, produced, worst, ok, max_abs = [], [], 0.0, True, 0.0
    for (op, feats), out in zip(actions, outs):
        if op == 'reset':
            history = []; produced = []; continue
        history.append(feats)
        produced.append(np.concatenate(out['chunks'], -1))
        ref = full_sequence_oracle(REPO, cfg, np.concatenate(history, -1))
        got = np.concatenate(produced, -1)
"""
if old not in src:
    if 'produced' in src:
        print('already patched')
    else:
        raise SystemExit('patch anchor not found')
else:
    path.write_text(src.replace(old, new), encoding='utf-8')
    print('patched harness.check')

sys.argv = [str(path)] + sys.argv[1:]
runpy.run_path(str(path), run_name='__main__')
