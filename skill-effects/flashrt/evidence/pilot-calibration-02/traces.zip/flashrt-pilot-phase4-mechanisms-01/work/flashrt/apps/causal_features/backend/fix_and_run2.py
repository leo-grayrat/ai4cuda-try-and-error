"""Fix: default mode full, graph history-channel dim, ms/s budget units; rerun."""
import runpy, sys
from pathlib import Path

here = Path(__file__).resolve().parent
w = here / 'worker.py'
s = w.read_text(encoding='utf-8')
s = s.replace("os.environ.get('CF_MODE', 'hybrid')", "os.environ.get('CF_MODE', 'full')")
s = s.replace("torch.zeros(1, weight.shape[0], left, device=self.dev)",
              "torch.zeros(1, weight.shape[1], left, device=self.dev)")
w.write_text(s, encoding='utf-8')
h = here / 'tests' / 'harness.py'
t = h.read_text(encoding='utf-8')
t = t.replace("float(np.mean(gg > BUDGET))", "float(np.mean(gg > BUDGET * 1e3))")
t = t.replace("float(np.mean(gaps > BUDGET))", "float(np.mean(gaps > BUDGET * 1e3))")
h.write_text(t, encoding='utf-8')
print('patched worker default=full + graph history channels + gap budget units')
sys.argv = [str(h)] + sys.argv[1:]
runpy.run_path(str(h), run_name='__main__')
