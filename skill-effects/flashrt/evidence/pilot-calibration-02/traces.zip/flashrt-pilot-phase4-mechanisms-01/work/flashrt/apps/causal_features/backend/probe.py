import inspect
import flashrt.ir as ir
from flashrt.ir import graph, analysis
for obj in [graph.IRGraph, graph.IROperator, graph.IREdge, graph.StateObject,
            graph.TensorPort, analysis.find_pipeline_stages,
            analysis.summarize_graph, analysis.analyze_cross_chunk_dependencies,
            analysis.find_streaming_overlaps, analysis.compute_critical_path]:
    print(getattr(obj, '__name__', obj), inspect.signature(obj))
print([n for n in dir(graph.IRGraph) if not n.startswith('_')])
print(inspect.getsource(graph.IRGraph.add_operator))
print(inspect.getsource(graph.IRGraph.add_state))
print(inspect.getsource(graph.IRGraph.validate))
