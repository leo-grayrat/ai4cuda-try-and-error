"""Phase-2 IR validation: run the IR graph through the original
``SequentialExecutor`` on real inputs and compare, chunk by chunk, against the
reference backend driven through the fixed adapter (and against the CPU
full-sequence oracle).  Also prints/stores the IR analysis summary.
"""
import json, sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / 'ir'))
import harness as H                    # noqa: E402
import graph_builder as GB             # noqa: E402
from flashrt.ir import SequentialExecutor, summarize_graph   # noqa: E402
from causal_features.model import build_layers                # noqa: E402


def main():
    cfg = H.cfg_for('ir_check')
    rng = np.random.default_rng(7)
    draw = lambda: rng.standard_normal((cfg['channels'], cfg['length'])).astype(np.float32)
    actions = [('req', draw()), ('req', draw())]
    outs, stdout, stderr = H.drive('reference', None, cfg, actions)

    graph = GB.build_graph(3)
    executor = SequentialExecutor(graph)
    executor.init_state({f'hist_{i}': None for i in range(3)})
    layers = build_layers(H.REPO, cfg, 'cpu')
    ctx = type('Ctx', (), {})()
    ctx.params = [(l.conv.weight.detach(), l.conv.bias.detach(),
                   l._time_causal_padding[0], l.pad_mode) for l in layers]
    ctx.outputs = []

    ok, worst, first_run = True, 0.0, None
    for i, (_op, feats) in enumerate(actions):
        ctx.outputs = []
        for start in range(0, cfg['length'], cfg['chunk']):
            part = feats[:, start:start + cfg['chunk']]
            executor.run_chunk({'x': torch.from_numpy(part).unsqueeze(0)}, ctx)
        got = np.concatenate([o[0].numpy() for o in ctx.outputs], -1)
        ref = np.concatenate(outs[i]['chunks'], -1)
        err = np.abs(got - ref)
        tol = H.TOL['atol'] + H.TOL['rtol'] * np.abs(ref)
        ok = ok and bool(np.all(err <= tol))
        worst = max(worst, float((err - tol).max()))
        if first_run is None:
            first_run = got

    # Reset semantics: re-initialising the histories must reproduce request 1.
    executor.init_state({f'hist_{i}': None for i in range(3)})
    ctx.outputs = []
    for start in range(0, cfg['length'], cfg['chunk']):
        part = actions[0][1][:, start:start + cfg['chunk']]
        executor.run_chunk({'x': torch.from_numpy(part).unsqueeze(0)}, ctx)
    replay = np.concatenate([o[0].numpy() for o in ctx.outputs], -1)
    repro = float(np.abs(replay - first_run).max())

    latencies = {name: 0.06e-3 for name in graph.operators}
    summary = summarize_graph(graph, op_latencies=latencies)
    notes = HERE.parent / 'notes'
    notes.mkdir(parents=True, exist_ok=True)
    (notes / 'ir_analysis.txt').write_text(summary, encoding='utf-8')
    print(summary)
    verdict = 'PASS' if (ok and repro <= 1e-6) else 'FAIL'
    record = {'verdict': verdict, 'worst_excess_over_tol': worst,
              'reset_reproduction_max_abs': repro, 'tolerance': H.TOL,
              'reference_stderr_tail': stderr[-600:]}
    (H.RESULTS / 'ir_validation.json').write_text(json.dumps(record, indent=1))
    print(json.dumps(record), flush=True)
    if verdict != 'PASS':
        sys.exit(1)


if __name__ == '__main__':
    main()
